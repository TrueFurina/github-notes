# 📈 GitHub Trending 冲榜 & Awesome 进榜操作手册

> 目标：1 个旗舰项目 30 天内进 GitHub Trending + Awesome 名单，涨 Star 500-2000

---

## 一、选择冲榜项目

### 你的候选（按冲榜可行性排序）

| 排名 | 项目 | Star | 领域 | 冲榜难度 | 推荐动作 |
|------|------|------|------|----------|----------|
| 🥇 | **AGI-Distiller** | 9 | AI/LLM | ⭐⭐ 低 | self-evolving + distillation 都是热门关键词 |
| 🥈 | **passive-recon** | 7 | Security/OSINT | ⭐⭐ 低 | EASM 是安全圈新热点 |
| 🥉 | **marl-ecdsa** | 4 | MARL/Research | ⭐⭐⭐ 中 | 学术向，但 MARL 领域热度在涨 |

**推荐首选 AGI-Distiller** — "self-evolving knowledge distillation" 这个概念自带传播力，容易吸引 AI 社区注意力。

---

## 二、冲榜前的准备（3-5 天）

### 1. 给目标项目做 v1.0 版本标记
```powershell
# 在 GitHub Web 上：Releases → Create new release
# Tag: v1.0.0
# Title: AGI-Distiller v1.0 — Self-evolving Knowledge Distillation System
# Body 写完整的 Release Notes（新增了什么、怎么用、架构图）
# 这是 Trending 冲榜的"信号弹"
```

### 2. README 终极版（必须）
- 一个架构图（Mermaid 或 draw.io）
- 快速开始：`pip install && python main.py --demo`
- 效果对比：蒸馏前 vs 蒸馏后 5-shot accuracy 表格
- 3-5 个真实用户反馈（即使是朋友）

### 3. 准备 Demo
- 录一个 60 秒 Bilibili/YouTube 视频
- 放一个在线 Demo（HuggingFace Spaces / Streamlit Community Cloud）
- 在 Blog 上写完整介绍

---

## 三、冲榜 7 天执行计划

### Day 1 — Release + 预热
- [ ] GitHub Release v1.0
- [ ] Blog 发布：《Self-Evolving Knowledge Distillation — 让小模型像大模型一样思考》
- [ ] B 站/YouTube 60 秒 Demo 视频
- [ ] Twitter/X 发帖（英文）：`I built a self-evolving knowledge distillation system...`

### Day 2-3 — 社区扩散
**国内**（中文）：
- [ ] V2EX 发帖（Python 板块）— 标题：《我做了一个让小模型自进化知识蒸馏的系统》
- [ ] 知乎回答相关问题（搜"知识蒸馏"、"小模型"）
- [ ] 微博/小红书发帖
- [ ] 微信群/QQ 群分享（找 AI/LLM 相关群）

**国际**（英文）：
- [ ] Hacker News 提交 — https://news.ycombinator.com/submit
  - 标题：`Show HN: AGI-Distiller — self-evolving knowledge distillation`
  - 关键：标题以 "Show HN:" 开头，提交后自己评论讲背景
- [ ] Reddit r/MachineLearning 发帖
- [ ] Reddit r/LocalLLaMA 发帖
- [ ] Reddit r/PromptEngineering 发帖

### Day 4-5 — Awesome 名单 PR
目标 Awesome 列表：
- [ ] [awesome-llm-apps](https://github.com/ttngu207/awesome-llm-apps) — 最热门 LLM 应用列表
- [ ] [awesome-ai-agents](https://github.com/e2b-dev/awesome-ai-agents) — AI Agent 列表
- [ ] [awesome-knowledge-distillation](https://github.com/huggingface/awesome-knowledge-distillation) — 知识蒸馏专题
- [ ] [awesome-cyber-security](https://github.com/haris989/awesome-cyber-security) — 如果冲 passive-recon
- [ ] [awesome-osint](https://github.com/jivoi/awesome-osint) — passive-recon

PR 模板：
```markdown
## Adding: [AGI-Distiller](https://github.com/TrueFurina/AGI-Distiller)

- **Stars**: 15+ (PR 时已有)
- **Description**: Self-evolving knowledge distillation — small models self-improve by distilling from larger models, without human-labeled data
- **Why it belongs**: Unique approach combining knowledge distillation with agent self-reflection loop
```

### Day 6-7 — Trending 冲榜关键期
GitHub Trending 算法看重 **24 小时内的 Star 增长率**。策略：
1. 让所有能帮忙的朋友在 Day 6 集中 Star（时间窗口：同 24 小时内）
2. Reddit/Hacker News 的帖子如果上了首页，Star 会自然来
3. 进 Trending 后自然会滚雪球 — Trending 页面本身带来大量 Star

**进入 Trending 需要多少 Star？**
- Python 日榜：~20-30 Star/天
- 总榜（Global）：~50-80 Star/天
- 第 7 天前拿到 50+ Star 基本稳进 Python Trending

---

## 四、冲榜后维护

进 Trending 后，**不要停**。继续：
1. 每天回应所有 issue 和 PR（新用户会来提）
2. 给新贡献者打 `good first issue` 标签
3. 跟进 Awesome 名单 PR（第一次 PR 被拒就第二次，换描述或等项目更成熟）
4. 每周发一个小更新（fix bug / 加 feature）

---

## 五、风险与避坑

| 风险 | 规避 |
|------|------|
| Hacker News 被 downvote | 不要用营销语，用 Show HN 格式，自己评论讲技术细节 |
| Awesome PR 被拒（太新） | 等 Star 到 30+ 再 PR，或先在 issue 里介绍 |
| 进 Trending 后代码质量被质疑 | 保证 README/测试/Demo 都到位 |
| Star 快速下降（虚假） | 不要买 Star — GitHub 算法会检测并降权 |

---

## 六、时间线总览

```
Week 1 (准备):
  ├─ 选项目 (AGI-Distiller)
  ├─ 写架构图 + v1.0 Release Notes
  ├─ 录 Demo 视频 + Blog
  └─ 检查 README 终极版

Week 2 (冲榜):
  Day 1: Release v1.0 + Blog + Video + Twitter
  Day 2: V2EX + 知乎 + HN + Reddit
  Day 3: 二次宣传 + Awesome PR 1-2
  Day 4-5: Awesome PR 3-5
  Day 6: 集中 Star (目标 50+/24h)
  Day 7: 观察 Trending 结果

Week 3+ (维护):
  ├─ 回应 issue
  ├─ 合并 PR
  ├─ Awesome 跟进
  └─ 每周小更新
```

---

## 七、成功标志

- ✅ GitHub Python Trending 日榜前 10
- ✅ 至少 1 个 Awesome 列表合并你的 PR
- ✅ Star 从 9 → 50+（进 Trending）→ 200+（稳定）
- ✅ 有第一个外部 Contributors（不是你自己）
- ✅ Hacker News 或 Reddit 上有技术讨论帖

---

**核心公式**：好项目 × v1.0 Release × HN/Reddit 曝光 × Awesome PR × 集中 Star = Trending

**最坏情况**：没进 Trending 但 Star 从 9 涨到 30，进了一个 Awesome 列表，为下次冲榜积累基础。
