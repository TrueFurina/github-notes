"""P0 止血改动执行器 —— 默认只出计划(diff)，不写远端。

用法:
    python apply_p0.py plan            # 只预览，打印每处 diff（默认）
    python apply_p0.py plan F1,F4      # 只看指定项
    python apply_p0.py apply all --yes # 真正写入 GitHub
    python apply_p0.py apply F3 --yes  # 只写指定项
    python apply_p0.py verify          # 应用后核验

设计原则:
  * 锚点式替换：old 文本没命中就跳过并报告，重复执行安全；
  * 绝不删除仓库里的任何文件（.env.test 用占位内容覆盖，不 rm）；
  * 所有改动一次性 commit，message 里写清原因。
"""
import argparse
import base64
import difflib
import json
import os
import sys

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, r"D:/github/github-audit")
sys.path.insert(0, HERE)

import specs  # noqa: E402
from ghlib import api  # noqa: E402

FILES = os.path.join(HERE, "files")
OWNER = specs.OWNER


# ----------------------------------------------------------------- 基础工具
def fetch(repo, path):
    info = api(f"/repos/{OWNER}/{repo}")
    if "__error" in info:
        return None, None, None
    branch = info["default_branch"]
    r = api(f"/repos/{OWNER}/{repo}/contents/{path}?ref={branch}")
    if isinstance(r, dict) and r.get("content") and "__error" not in r:
        return base64.b64decode(r["content"]).decode("utf-8"), r["sha"], branch
    return None, None, branch


def put(repo, path, text, sha, branch, message, dry=True):
    if dry:
        return {"dry_run": True}
    body = {
        "message": message,
        "content": base64.b64encode(text.encode("utf-8")).decode("ascii"),
        "branch": branch,
    }
    if sha:
        body["sha"] = sha
    r = api_put(f"/repos/{OWNER}/{repo}/contents/{path}", body)
    return {"commit": (r.get("commit") or {}).get("sha", "")[:12],
            "error": r.get("__error"), "detail": r.get("detail")}


def api_put(path, body):
    """PUT 需要 payload，ghlib.api 只做 GET，这里单独实现。"""
    import urllib.request
    from ghlib import HEADERS
    req = urllib.request.Request(
        "https://api.github.com" + path,
        data=json.dumps(body).encode("utf-8"),
        headers={**HEADERS, "Content-Type": "application/json"},
        method="PUT")
    try:
        with urllib.request.urlopen(req, timeout=60) as r:
            return json.loads(r.read() or b"{}")
    except Exception as e:  # noqa: BLE001
        body = getattr(e, "read", lambda: b"")()
        return {"__error": str(e), "detail": body.decode("utf-8", "ignore")[:300]}


def api_patch(path, body):
    import urllib.request
    from ghlib import HEADERS
    req = urllib.request.Request(
        "https://api.github.com" + path,
        data=json.dumps(body).encode("utf-8"),
        headers={**HEADERS, "Content-Type": "application/json"},
        method="PATCH")
    try:
        with urllib.request.urlopen(req, timeout=60) as r:
            return json.loads(r.read() or b"{}")
    except Exception as e:  # noqa: BLE001
        detail = getattr(e, "read", lambda: b"")()
        return {"__error": str(e), "detail": detail.decode("utf-8", "ignore")[:300]}


def show_diff(label, old, new, limit=40, redact=False):
    print(f"\n--- {label}")
    if redact:
        old, new = redact_env(old), redact_env(new)
    d = list(difflib.unified_diff(
        (old or "").splitlines(), (new or "").splitlines(),
        fromfile="current", tofile="proposed", lineterm="", n=2))
    if not d:
        print("    (无变化 / 已应用过)")
        return 0
    for ln in d[:limit]:
        print("   ", ln[:200])
    if len(d) > limit:
        print(f"    ... 省略 {len(d) - limit} 行")
    return len(d)


def redact_env(text):
    """把 KEY=value 形式的值打码，避免在终端回显真实密钥。"""
    import re
    if not text:
        return text
    return re.sub(r"^([A-Z0-9_]{3,})=(.+)$",
                  lambda m: f"{m.group(1)}=***(len={len(m.group(2))})",
                  text, flags=re.M)


def read_local(name):
    with open(os.path.join(FILES, name), encoding="utf-8") as f:
        return f.read()


# ----------------------------------------------------------------- 各项修复
def plan_f1(dry):
    print("\n===== F1 三个头部仓 LICENSE -> 标准 MIT =====")
    mit = read_local("LICENSE-MIT.txt").replace(
        "Copyright (c) [year] [fullname]", specs.COPYRIGHT)
    for repo in specs.F1_MIT_REPOS:
        old, sha, branch = fetch(repo, "LICENSE")
        if old is None:
            print(f"  [{repo}] LICENSE 不存在，跳过")
            continue
        if old.strip() == mit.strip():
            print(f"  [{repo}] 已是标准 MIT，跳过")
            continue
        show_diff(f"{repo}/LICENSE", old, mit)
        r = put(repo, "LICENSE", mit, sha, branch,
                "chore(license): replace source-available text with standard MIT\n\n"
                "README 与徽章已对外声明 MIT，LICENSE 文件却是 All Rights Reserved，"
                "两者互斥。统一为 MIT 以消除授权歧义。", dry)
        print("    写入:", "dry-run" if dry else r)


def plan_f1b(dry):
    print("\n===== F1B README 版权行与 MIT 对齐 =====")
    for repo, edits in specs.F1B_EDITS.items():
        old, sha, branch = fetch(repo, "README.md")
        if old is None:
            print(f"  [{repo}] README 抓取失败")
            continue
        new = old
        for o, n in edits:
            if o in new:
                new = new.replace(o, n, 1)
            elif n.split("（此")[0][:30] in new:
                print(f"  [{repo}] 已应用过")
            else:
                print(f"  [{repo}] !! 锚点未命中，跳过")
        if new == old:
            continue
        show_diff(f"{repo}/README.md（版权行）", old[:400], new[:400], limit=12)
        r = put(repo, "README.md", new, sha, branch,
                "docs(readme): align copyright notice with MIT license\n\n"
                "MIT 不允许附加禁止商用/禁止竞赛使用的限制，原版权声明与 LICENSE 互斥；"
                "改为与 MIT 一致的表述，并把注明来源降级为非强制请求。", dry)
        print("    写入:", "dry-run" if dry else r)


def plan_f2(dry):
    print("\n===== F2 pikachu：补上游署名 + 换 Apache-2.0 + 去重复声明 =====")
    repo = specs.PIKACHU_REPO
    # 用上游原件的逐字副本还原（该仓 2026-08-16 把它换成了 All Rights Reserved），
    # 而不是自己拼一份 Apache 文本，避免与上游产生任何差异。
    apache = read_local("LICENSE-APACHE-pikachu-restored.txt")
    old, sha, branch = fetch(repo, "LICENSE")
    show_diff(f"{repo}/LICENSE", old, apache, limit=12)
    r = put(repo, "LICENSE", apache, sha, branch,
            "chore(license): adopt Apache-2.0 to comply with upstream\n\n"
            "上游 zhuifengshaonianhanlu/pikachu 为 Apache-2.0，"
            "派生作品须保留同一许可与署名。", dry)
    print("    写入:", "dry-run" if dry else r)

    old_n, sha_n, _ = fetch(repo, "NOTICE")
    r = put(repo, "NOTICE", specs.NOTICE_PIKACHU, sha_n, branch,
            "docs(notice): add upstream attribution (Apache-2.0 §4)", dry)
    print("    NOTICE 写入:", "dry-run" if dry else r)

    old_r, sha_r, branch_r = fetch(repo, "README.md")
    if old_r is None:
        print("  README 抓取失败，跳过")
        return
    new_r = old_r
    for o, n in specs.PIKACHU_README_EDITS:
        if o in new_r:
            new_r = new_r.replace(o, n, 1)
        elif n.split("\n")[0] in new_r:
            print(f"    已应用过: {o[:40]}...")
        else:
            print(f"    !! 锚点未命中，跳过: {o[:50]}")
    stripped = specs.find_block(new_r, *specs.ALL_RIGHTS_BLOCK_MARKERS)
    if stripped:
        new_r = stripped
    new_r = new_r.rstrip() + "\n"
    if new_r != old_r:
        show_diff(f"{repo}/README.md", old_r, new_r, limit=30)
        r = put(repo, "README.md", new_r, sha_r, branch_r,
                "docs(readme): credit upstream, unify license statement\n\n"
                "删除与 Apache-2.0 互斥的 'All Rights Reserved' 段落，"
                "补上游署名与改动清单。", dry)
        print("    写入:", "dry-run" if dry else r)


def plan_f3(dry):
    print("\n===== F3 同一 README 内互斥许可段去重 =====")
    for repo in specs.F3_DEDUPE_REPOS:
        old, sha, branch = fetch(repo, "README.md")
        if old is None:
            print(f"  [{repo}] README 抓取失败，跳过")
            continue
        new = specs.find_block(old, *specs.ALL_RIGHTS_BLOCK_MARKERS)
        if not new:
            print(f"  [{repo}] 未找到 All Rights Reserved 段（可能已清理），跳过")
            continue
        new = new.rstrip() + "\n"
        show_diff(f"{repo}/README.md", old, new, limit=24)
        r = put(repo, "README.md", new, sha, branch,
                "docs(readme): remove contradictory 'All Rights Reserved' section\n\n"
                "同一篇 README 既声明 MIT 又声明 source-available/all-rights-reserved，"
                "保留 MIT 声明，删除互斥段落。", dry)
        print("    写入:", "dry-run" if dry else r)


def plan_f4(dry):
    print("\n===== F4 xihu 首屏：去本机路径 + 长声明收进 details =====")
    repo = specs.XIHU_REPO
    old, sha, branch = fetch(repo, "README.md")
    if old is None:
        print("  README 抓取失败，跳过")
        return
    lines = old.split("\n")
    # 1) FROZEN 横幅：4 行 -> 1 行
    s = e = None
    for i, ln in enumerate(lines):
        if s is None and ln.startswith(specs.XIHU_FROZEN_START):
            s = i
        elif s is not None and ln.startswith(specs.XIHU_FROZEN_END):
            e = i
            break
    if s is not None and e is not None:
        lines[s:e + 1] = [specs.XIHU_NEW_FROZEN]
    else:
        print("  FROZEN 横幅锚点未命中（可能已改过）")
    # 2) 两段长声明 -> <details>
    ds = de = None
    for i, ln in enumerate(lines):
        if ds is None and ln.startswith(specs.XIHU_DETAILS_START):
            ds = i
        elif ds is not None and ln.startswith(specs.XIHU_DETAILS_END):
            de = i
            break
    if ds is not None and de is not None:
        inner = [ln for ln in lines[ds:de + 1] if ln.strip()]
        lines[ds:de + 1] = (["<details>", specs.XIHU_DETAILS_SUMMARY, ""]
                            + ["\n\n".join(inner)] + ["", "</details>"])
    else:
        print("  声明段锚点未命中（可能已改过）")
    new = "\n".join(lines)
    if new == old:
        print("  (无变化)")
        return
    show_diff(f"{repo}/README.md", old, new, limit=30)
    r = put(repo, "README.md", new, sha, branch,
            "docs(readme): declutter first screen\n\n"
            "删除首屏本机路径 E:\\Program\\SecAutoMind（暴露本地目录结构），"
            "把诚实声明与口径更正收进 <details>，内容逐字保留。", dry)
    print("    写入:", "dry-run" if dry else r)


def plan_f5(dry):
    print("\n===== F5 MARS-408：.env.test 占位化 + .gitignore 补规则 =====")
    print("  注意：覆盖文件不会清除 Git 历史里的旧值 —— 必须并行确认/轮换密钥")
    repo = specs.ENV_TEST_REPO
    old, sha, branch = fetch(repo, specs.ENV_TEST_PATH)
    if old is None:
        print("  文件不存在，跳过")
    else:
        show_diff(f"{repo}/{specs.ENV_TEST_PATH}", old, specs.ENV_TEST_SAFE,
                  limit=12, redact=True)
        r = put(repo, specs.ENV_TEST_PATH, specs.ENV_TEST_SAFE, sha, branch,
                "security: scrub test env secrets from tracked file\n\n"
                "AUTH_SECRET / ADMIN_PASSWORD 为明文会话密钥字段，改为空值占位，"
                "真实值走环境变量；.gitignore 补 .env.test 规则。", dry)
        print("    写入:", "dry-run" if dry else r)

    old_g, sha_g, branch_g = fetch(repo, ".gitignore")
    if old_g is None:
        print("  .gitignore 不存在，跳过")
        return
    if ".env.test" in old_g:
        print("  .gitignore 已含 .env.test，跳过")
        return
    new_g = old_g.rstrip() + "\n" + specs.GITIGNORE_APPEND
    show_diff(f"{repo}/.gitignore", old_g, new_g, limit=16)
    r = put(repo, ".gitignore", new_g, sha_g, branch_g,
            "chore(gitignore): ignore .env.test", dry)
    print("    写入:", "dry-run" if dry else r)


def plan_f6(dry):
    print("\n===== F6 开启 Secret Scanning + Push Protection =====")
    for repo in specs.F6_REPOS:
        info = api(f"/repos/{OWNER}/{repo}")
        sa = (info.get("security_and_analysis") or {})
        cur = sa.get("secret_scanning", {}).get("status")
        prot = sa.get("secret_scanning_push_protection", {}).get("status")
        print(f"  [{repo}] secret_scanning={cur} push_protection={prot}")
        if cur == "enabled" and prot == "enabled":
            print("    已开启，跳过")
            continue
        if dry:
            print("    -> 将 PATCH 开启（dry-run）")
            continue
        r = api_patch(f"/repos/{OWNER}/{repo}", {"security_and_analysis": {
            "secret_scanning": {"status": "enabled"},
            "secret_scanning_push_protection": {"status": "enabled"}}})
        ok = (r.get("security_and_analysis", {})
                .get("secret_scanning", {}).get("status"))
        print("    结果:", ok or r)


PLANNERS = {"F1": plan_f1, "F1B": plan_f1b, "F2": plan_f2, "F3": plan_f3,
            "F4": plan_f4, "F5": plan_f5, "F6": plan_f6}


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("cmd", choices=["plan", "apply", "verify"])
    ap.add_argument("which", nargs="?", default="all")
    ap.add_argument("--yes", action="store_true", help="apply 时必须显式确认")
    a = ap.parse_args()

    if a.cmd == "verify":
        return verify()
    if a.cmd == "apply" and not a.yes:
        print("拒绝执行：apply 需要 --yes 显式确认。先跑 `plan` 看 diff。")
        return 1

    dry = a.cmd == "plan"
    which = (list(PLANNERS) if a.which in ("all", None)
             else [x.strip().upper() for x in a.which.split(",")])
    if dry:
        print("=" * 78)
        print("DRY RUN —— 只打印将发生的变更，不写任何远端内容")
        print("=" * 78)
    for k in which:
        if k not in PLANNERS:
            print("unknown fix:", k)
            continue
        PLANNERS[k](dry)
    if dry:
        print("\n确认无误后执行: python apply_p0.py apply all --yes")
    return 0


def verify():
    print("=" * 78)
    print("核验：OK=已达成 / PEND=等决策 / FAIL=需要修")
    print("=" * 78)
    fails, pends = 0, 0

    def line(state, label, detail):
        nonlocal fails, pends
        if state == "FAIL":
            fails += 1
        elif state == "PEND":
            pends += 1
        print(f"  [{state}] {label:46} {detail}")

    # F1: 三个头部仓 license 变为 MIT
    for repo in specs.F1_MIT_REPOS:
        lic = (api(f"/repos/{OWNER}/{repo}").get("license") or {}).get("spdx_id")
        line("OK" if lic == "MIT" else "FAIL", f"F1 {repo}", f"license={lic}")

    # F3: 同一文档不再同时出现 MIT 声明与 All Rights Reserved
    for repo in specs.F3_DEDUPE_REPOS:
        old, _, _ = fetch(repo, "README.md")
        txt = old or ""
        conflict = ("All Rights Reserved" in txt) and ("MIT" in txt)
        line("FAIL" if conflict else "OK", f"F3 {repo}",
             "仍有互斥许可声明" if conflict else "README 单一授权")
        lic = (api(f"/repos/{OWNER}/{repo}").get("license") or {}).get("spdx_id")
        if lic != "MIT":
            line("PEND", f"F3+{repo} LICENSE 换 MIT 全文",
                 f"license={lic}（需团队授权后再改）")

    # F4: xihu 首屏无本机路径、声明收进 details
    old, _, _ = fetch(specs.XIHU_REPO, "README.md")
    txt = old or ""
    leak = "E:////Program////SecAutoMind" in txt
    det = "<details>" in txt
    line("FAIL" if (leak or not det) else "OK", f"F4 {specs.XIHU_REPO}",
         f"本机路径泄露={leak} details={det}")

    # F6: 四个仓开启扫描
    for repo in specs.F6_REPOS:
        sa = api(f"/repos/{OWNER}/{repo}").get("security_and_analysis") or {}
        cur = sa.get("secret_scanning", {}).get("status")
        prot = sa.get("secret_scanning_push_protection", {}).get("status")
        line("OK" if cur == "enabled" and prot == "enabled" else "FAIL",
             f"F6 {repo}", f"scan={cur} push={prot}")

    # F2 / F5: 仍未执行，按计划挂起
    lic = (api(f"/repos/{OWNER}/{specs.PIKACHU_REPO}").get("license") or {}).get("spdx_id")
    line("PEND" if lic != "Apache-2.0" else "OK", f"F2 {specs.PIKACHU_REPO}",
         f"license={lic}" + ("" if lic == "Apache-2.0" else "（未还原，跑 apply F2）"))
    env, _, _ = fetch(specs.ENV_TEST_REPO, specs.ENV_TEST_PATH)
    if env is None:
        # 文件已不在 HEAD（可能是被删除或替换成 .env.test.example）。
        # 注意：这不等于风险清零——旧值仍在历史里，轮换才是根治。
        line("OK", "F5 MARS-408 .env.test",
             "文件已不在 HEAD（历史仍含旧值 → 仍需轮换那把 AUTH_SECRET）")
    else:
        dirty = False
        for ln in env.splitlines():
            if ln.startswith("AUTH_SECRET=") and ln.split("=", 1)[1].strip():
                dirty = True
        line("PEND" if dirty else "OK", "F5 MARS-408 .env.test",
             "仍有明文值（等轮换确认后跑 apply F5）" if dirty else "已占位化")

    print(f"\n结论: FAIL={fails}  PEND={pends}")
    return 0 if not fails else 1


if __name__ == "__main__":
    sys.exit(main())
