# 第 41 轮补丁 PR — 规范

## 背景与阻塞

本轮沿用既定流程：本机无源码仓库，通过 GitHub API 直推 fork 分支，对 `TencentCloud/Octop`（base `develop`）开最小补丁 PR。先查 open PR 占用：

- `#2712` open（占用 `feishu_bot_creator.py` / `yuanbao_bot_creator.py` / `test_feishu_bot_creator.py`）
- `#2714` open（占用 `subprocess_io.py`）
- `#2715` open（占用 `feishu_runner.py` / `test_feishu_runner.py`）
- `#2620` open（占用 `api/routers/channels.py`）
- 占用矩阵共 503 个文件（`D:/github/_r40/open_files.json`）

因此第 40 轮台账里记录的高危项 `feishu_bot_creator._send_greeting` 的 `ctx.check_hostname=False / verify_mode=ssl.CERT_NONE`（全仓库唯一禁用 TLS 校验处，会把 `app_secret` POST 出去）**仍被自家 #2712 同文件占用**，按「不与任何 open PR 改同一文件」的规则继续延后，不在本轮动。

## 本轮缺陷（已核实）

文件：`src/octop/infra/users/preferences.py`，函数 `validate_remote_browser_bookmarks`，第 95-97 行：

```python
        url = normalize_nav_url(str(item.get("url") or ""))
        if not url.startswith(("http://", "https://")):
            continue
```

配套事实（均已逐字节核对 develop 原文，快照 `D:/github/octop-local/Octop-main` 与 develop 一致，11043 字节）：

1. `src/octop/infra/utils/url.py:9-13` 的 `normalize_nav_url` 对已带 scheme 的输入**原样返回**，不做大小写归一：`HTTPS://example.com` → `HTTPS://example.com`。
2. `tests/unit/utils/test_url.py:21` 明确固定了该契约：`assert normalize_nav_url("HTTPS://x.com/") == "HTTPS://x.com/"`。所以 `url.py` 的行为是有意为之，**不应改 url.py**。
3. 于是下游第 96 行的 `startswith(("http://", "https://"))` 大小写敏感 → 对 `HTTPS://…` 判为假 → `continue` 静默丢弃；用户保存远程浏览器书签后该书签凭空消失（`validate_remote_browser_bookmarks` 也用于 `get_remote_browser_bookmarks_from_json`，即读回旧数据时同样丢）。

反例：`HTTPS://x.com`、`Http://x.com` 这类大小写变体的 scheme 在复制粘贴文本/日志里真实存在，Browsers 与 `urllib` 都视其为合法 http(s) URL。

## 改动（最小化）

1. `src/octop/infra/users/preferences.py` 第 96 行：

```python
        if not url.lower().startswith(("http://", "https://")):
```

仅此一行；`seen` 去重、title 回退、上限校验等逻辑不变。

2. `tests/unit/users/test_preferences.py` 追加一条回归测试（文件当前无同义用例，`test_validate_skips_invalid_urls` 只覆盖 `ftp://` 与空串）：

```python
def test_validate_accepts_uppercase_scheme() -> None:
    out = validate_remote_browser_bookmarks(
        [
            {"url": "HTTPS://example.com/path", "title": "Upper"},
            {"url": "Http://second.test", "title": ""},
        ]
    )
    assert [b.url for b in out] == ["HTTPS://example.com/path", "Http://second.test"]
    assert out[0].title == "Upper"
```

## 验收标准

- 基线（未打补丁）：新增用例失败，`len(out) == 0`（书签被丢弃）。
- 打补丁后：`tests/unit/users/test_preferences.py` 全通过；`tests/unit/utils/test_url.py` 仍全通过（证明未破坏 `normalize_nav_url` 契约）。
- `ruff check` 与 `ruff format --check` 通过（line-length=100，select E,F,W,I,B,UP,SIM,C4）。
- 快照改动复原、临时测试文件删除，不污染本地镜像。

## 远端写入

- 分支名 `fix/bookmark-scheme-case`，base `develop`，fork `TrueFurina/Octop`。
- 两个文件：`src/octop/infra/users/preferences.py`（改 1 行）、`tests/unit/users/test_preferences.py`（追加 1 个用例）。
- 流程：`make_pr.py --dry-run` → 真开 → `api` 复核 `state/mergeable/files/新增删除行数`。
- 冲突复核：两文件均不在 503 条 open 文件矩阵内。

## 明确的非目标

- 不改 `src/octop/api/routers/browser/stream.py` 中同构副本（该文件被 open PR 占用）。
- 不改 `src/octop/infra/utils/url.py`（大小写保留已被既有单测固定）。
- 不碰 `feishu_bot_creator.py`（TLS 高危项，等 #2712 关闭/合并）。
- 不制造与本缺陷无关的顺手改动。

## 下一轮方向

1. 若 `#2712` 已关闭或合并 → 做 `feishu_bot_creator._send_greeting` 的 TLS 校验修复（去掉 `check_hostname=False` / `CERT_NONE`，补断言 `verify_mode == ssl.CERT_REQUIRED`、`check_hostname` 为真的测试）。
2. 若仍 open → 继续 free 文件巡检：优先 `src/octop/cli/commands/channel.py` 的 `bind_wecom` / `bind_weixin` 相较 `bind_qq` 缺少 existing config 合并（`patch_channel_offline` 是整体替换 `config_json`），需先确认产品语义再动。
