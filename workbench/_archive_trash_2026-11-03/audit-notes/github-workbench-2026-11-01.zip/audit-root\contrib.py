import json, subprocess, time, urllib.request, http.client, collections

TOKEN = subprocess.run(["powershell","-NoProfile","-Command",
    "[Environment]::GetEnvironmentVariable('GITHUB_TOKEN','User')"],
    capture_output=True, text=True).stdout.strip()
H = {"Authorization":"Bearer "+TOKEN,"User-Agent":"raccoon","Accept":"application/vnd.github+json","Connection":"close"}

def get(url):
    for i in range(3):
        try:
            r = urllib.request.Request(url, headers=H)
            with urllib.request.urlopen(r, timeout=40) as resp:
                parts=[]
                try:
                    while True:
                        b=resp.read(16384)
                        if not b: break
                        parts.append(b)
                except http.client.IncompleteRead as e:
                    parts.append(e.partial)
                return json.loads(b"".join(parts))
        except Exception as e:
            if i==2: print("ERR", repr(e)[:60], url[:80]); return None
            time.sleep(2)

res={}
for label,q in [("prs","is:pr author:TrueFurina"),("issues","is:issue author:TrueFurina")]:
    items=[]
    for page in (1,2,3):
        d=get(f"https://api.github.com/search/issues?q={urllib.parse.quote(q)}&per_page=50&page={page}")
        if not d or "items" not in d: break
        items.extend(d["items"])
        if len(d["items"])<50: break
    res[label]=items
    print(label, "total:", (d or {}).get("total_count"), "fetched:", len(items))

merged=[i for i in res["prs"] if i.get("pull_request",{}).get("merged_at")]
print("merged PRs:", len(merged), "/", len(res["prs"]))
repos=collections.Counter(i["repository_url"].split("/repos/")[-1] for i in res["prs"])
print("PR repos:", repos.most_common(15))
for i in res["prs"][:15]:
    print(f'  [{i["state"]:6s}] {"MERGED" if i.get("pull_request",{}).get("merged_at") else "      "} {i["repository_url"].split("/repos/")[-1]:38s} {i["title"][:60]}')
print("issue repos:", collections.Counter(i["repository_url"].split("/repos/")[-1] for i in res["issues"]).most_common(12))

json.dump(res, open("contrib.json","w",encoding="utf-8"), ensure_ascii=False)
