"""GFI 占位复核（四个信号：assignees / 评论认领话术 / open PR / merged PR）。

2026-11-01 的教训：只看 comment 关键词 + open PR 会把
  - #9086（/claim 是 slash 命令，且被 assigned）误判成空闲
  - #8621（修复已合入 release/v3，只是没发布）误判成空闲
所以四个信号必须同时看。

用法：python claims.py [数量]
"""
import json, os, re, sys, urllib.request

TOKEN = os.environ["GITHUB_TOKEN"]
H = {"Authorization": "Bearer " + TOKEN,
     "Accept": "application/vnd.github+json",
     "User-Agent": "insight-scout"}
H_TL = dict(H, Accept="application/vnd.github.mockingbird-preview+json")
REPO = "apache/airflow"
CLAIM = re.compile(
    r"i'?d like to work|i will work|i'll work|working on (this|it)|pick this up|"
    r"interested in working|assign (it|this|me)|i'?ve submitted|i have prepared|"
    r"i am working|would like to take|can i take|submit a (pr|rp)|please assign|"
    r"/claim|i'?ll take|taking this|i can take", re.I)


def api(url, h=H):
    return json.loads(urllib.request.urlopen(urllib.request.Request(url, headers=h), timeout=30).read().decode())


data = json.load(open(r"d:\github\_insight\airflow_gfi_ranked.json", encoding="utf-8"))
limit = int(sys.argv[1]) if len(sys.argv) > 1 else len(data)

rows, free = [], []
for c in data[:limit]:
    n = c["number"]
    try:
        iss = api(f"https://api.github.com/repos/{REPO}/issues/{n}")
        tl = api(f"https://api.github.com/repos/{REPO}/issues/{n}/timeline?per_page=30", H_TL)
    except Exception as e:
        print(f"#{n} ERR {e}")
        continue
    assigned = [a["login"] for a in iss.get("assignees") or []]
    open_prs = merged_prs = 0
    for ev in tl:
        if ev.get("event") != "cross-referenced":
            continue
        si = ((ev.get("source") or {}).get("issue") or {})
        if not si.get("pull_request"):
            continue
        if ((si.get("repository") or {}).get("full_name")) != REPO:
            continue
        if si.get("state") == "open":
            open_prs += 1
        elif (si.get("pull_request") or {}).get("merged_at"):
            merged_prs += 1
    claims = []
    if iss["comments"]:
        try:
            cs = api(f"https://api.github.com/repos/{REPO}/issues/{n}/comments?per_page=20")
            claims = [x["user"]["login"] for x in cs
                      if CLAIM.search(" ".join((x["body"] or "").split()))]
        except Exception:
            pass
    taken = bool(assigned or claims or open_prs or merged_prs)
    rows.append((n, assigned, claims, open_prs, merged_prs))
    if not taken:
        free.append(c)

def cnt(i):
    return sum(1 for r in rows if r[i])

print(f"样本 {len(rows)} | assignees {cnt(1)} | 认领评论 {cnt(2)} | open PR {cnt(3)} | merged PR {cnt(4)} | "
      f"完全未被占 {len(free)}")
print("\n=== 完全未被占（四信号皆无）===")
for c in sorted(free, key=lambda x: (-x["score"], x["comments"])):
    print(f"#{c['number']} score={c['score']} comments={c['comments']} created={c['created'][:10]} | {c['title'][:90]}")
