import json, subprocess, time, urllib.request, http.client, urllib.parse, collections

TOKEN = subprocess.run(["powershell","-NoProfile","-Command",
    "[Environment]::GetEnvironmentVariable('GITHUB_TOKEN','User')"],
    capture_output=True, text=True).stdout.strip()
H = {"Authorization":"Bearer "+TOKEN,"User-Agent":"raccoon","Accept":"application/vnd.github+json","Connection":"close"}

def get(url):
    for i in range(3):
        try:
            r = urllib.request.Request(url, headers=H)
            with urllib.request.urlopen(r, timeout=45) as resp:
                parts=[]
                try:
                    while True:
                        b=resp.read(16384)
                        if not b: break
                        parts.append(b)
                except http.client.IncompleteRead as e:
                    parts.append(e.partial)
                return json.loads(b"".join(parts))
        except Exception:
            time.sleep(2)
    return None

ext=json.load(open("ext_prs.json",encoding="utf-8"))
def repo(i): return i["repository_url"].split("/repos/")[-1]
def merged(i): return bool(i.get("pull_request",{}).get("merged_at"))

tiers = {r: {"total":0,"merged":0,"closed":0,"open":0} for r in ["fastapi/fastapi","kubeflow/testing","opendatahub-io/notebooks","collective/icalendar","tableau/server-client-python","protectai/modelscan","wandb/rai-toolkit","TencentCloud/Octop"]}
for i in ext:
    r=repo(i)
    if r in tiers:
        tiers[r]["total"]+=1
        if merged(i): tiers[r]["merged"]+=1
        elif i["state"]=="open": tiers[r]["open"]+=1
        else: tiers[r]["closed"]+=1
print("=== PER-REPO PR OUTCOME (notable upstreams) ===")
for r,v in sorted(tiers.items(), key=lambda x:-x[1]["total"]):
    if v["total"]: print(f'{r:34s} total={v["total"]:2d} merged={v["merged"]:2d} closed_unmerged={v["closed"]:2d} open={v["open"]:2d}')

print("\n=== MERGE RATE BY TITLE TYPE ===")
by=collections.defaultdict(lambda:[0,0])
for i in ext:
    t=i["title"].split(":")[0].split("(")[0].strip().lower()
    by[t][0]+=1
    if merged(i): by[t][1]+=1
for k,(n,m) in sorted(by.items(), key=lambda x:-x[1][0])[:8]:
    print(f"{k:10s} n={n:3d} merged={m:3d} rate={100*m/n:.0f}%")

print("\n=== PACKAGING / RELEASE ===")
own=[r for r in json.load(open("raw.json",encoding="utf-8"))["repos"] if not r.get("fork")]
for r in sorted(own,key=lambda x:(-x["stargazers_count"],-x["size"]))[:12]:
    fn=r["full_name"]
    c=get(f"https://api.github.com/repos/{fn}/contents/")
    names=[x["name"] for x in (c or []) if isinstance(c,list)] if isinstance(c,list) else []
    pkg=any(n in names for n in ("pyproject.toml","setup.py","package.json"))
    rel=get(f"https://api.github.com/repos/{fn}/releases?per_page=3")
    tags=get(f"https://api.github.com/repos/{fn}/tags?per_page=3")
    print(f'{r["name"][:30]:32s} pkg={"Y" if pkg else "-"} releases={len(rel) if isinstance(rel,list) else 0} tags={len(tags) if isinstance(tags,list) else 0} homepage={bool(r.get("homepage"))}')

print("\n=== ACTION COUNT / CI BADGES in README ===")
import base64
for fn in ["AGI-Distiller","passive-recon","MARS-408","xihu-sword-ctf-agent","SecAutoMind-src","comment-distillery"]:
    rd=get(f"https://api.github.com/repos/TrueFurina/{fn}/readme")
    t=base64.b64decode(rd["content"]).decode("utf-8","replace") if rd and rd.get("content") else ""
    print(f'{fn:26s} len={len(t):6d} badges={t.count("img.shields.io")} has_gif={"gif" in t.lower()} has_install={"pip install" in t or "docker run" in t or "npm i" in t} en_zh={"README.zh" in str("") }')