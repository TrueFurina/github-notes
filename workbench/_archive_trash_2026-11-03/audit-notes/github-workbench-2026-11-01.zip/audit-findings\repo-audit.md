# TrueFurina（Dream）原创仓库工程质量审计

- **审计对象**：`github.com/TrueFurina`，原创（`fork=false`、`owner=TrueFurina`）仓库 **42** 个；其中私有 6 个、归档 0 个。
- **不在范围**：160 个 fork、111 个 archived 仓库（本次共 202 条 repo 记录被筛出 42 条）。
- **数据来源**：`raw.json`（2026-10-28 21:42 快照）+ GitHub REST API 逐仓复核（`/readme`、`/license`、`/git/trees?recursive=1`、`/contents/.github/workflows`、`/releases`、`/commits`、`/branches`）。
- **字数口径**：README 解码后**去空白字符数**（`len("".join(text.split()))`），比字节数更接近"正文字数"。
- **体积口径**：GitHub `size` 字段（KB，不含 Release 附件与 LFS 实体），1MB = 1024KB。

---

## 0. 结论速览

| 指标 | 数值 | 结论 |
|---|---|---|
| 仓库总数（原创） | 42 | 粒度偏碎，6 组"主仓+材料仓"重复 |
| README 缺失 | **5**（12%） | 全部集中在材料仓/交付仓 |
| README 平均字数 | **5,435** 字（中位 3,768） | 文档投入不低，**短板不在写文档** |
| 有 LICENSE 文件 | 16（38%） | 其中仅 **6 个 MIT（14%）**；10 个自定义文本里 **6 个 README 又称 MIT**（互斥授权） |
| 完全无 LICENSE | **26（62%）** | 默认"保留所有权利"，外部无法合规复用 |
| 有 CI | 12（29%） | 其中真正执行测试的只有 **7 个（17%）** |
| 有 tests | **21（50%）** | 测试意识强于 CI 意识，缺"自动跑"的闭环 |
| 有依赖清单 | 18（43%） | Python 仓最大缺口 |
| 发过 Release | **5（12%）** | 仅这 5 仓挂了约 965MB 安装包附件，其余 37 仓无分发通道 |
| 体积 > 50MB | **2**（MARS-408 108.7MB、SecAutoMind-src 88.0MB） | 另有 3 仓 23–48MB，逼近阈值 |
| 有 topics / homepage | 13（31%）/ 4（10%） | 可发现性几乎未经营 |
| 全仓 star 合计 | 92 | 9★ 已是头部，规范缺口直接压住增长 |

**一句话**：这不是"不会写文档"的账号——README 平均 5.4k 字、中位数 3.8k 字，明显高于个人项目平均；真正塌陷的是**工程闭环的后半段**：许可证（62% 裸奔 + 6 个仓 README 与 LICENSE 互相打脸）、CI（71% 没有）、Release（88% 没有）。三者共同造成"代码能读、不能合规复用、不能装、不敢依赖"。

**最该先做的一件事**：`AGI-Distiller` / `passive-recon` / `DevRadar` 三个头部仓的 README 都写着 MIT，`LICENSE` 文件里却是"All Rights Reserved"。这已经不是规范问题，而是会给下游造成实际损失的授权错误。

---

## 1. P0 · 结构与合规问题（先修这些）

### 1.1 许可证体系整体失效：62% 无授权，24% 自造条款

| 类型 | 数量 | 仓库 |
|---|---|---|
| 无 LICENSE | **26** | MARS-408、SecAutoMind-src、Denia、physics-scheduler-agent、FDE、marl-ecdsa、marl-ecdsa-competition-materials、AI-Arena、mcd-meal-optimizer、AeroRider、aerorider-delivery、MangDeHenZhi、MangDeHenZhi-materials、MangDeZhiXun、sage-paper、sage-paper-public、coastal-traffic-visual-analytics、2026-crypto-math-challenge、xihu-ctf-deliverables、workspace、TrueFurina、SecAutoMind、docker-forensics-toolkit、win-appx-doctor、workbuddy-vivo-fix、wsl-docker-recovery |
| 自定义（GitHub 判 `NOASSERTION`） | **10** | AGI-Distiller、passive-recon、DevRadar-GitHub-Trending-Monitor、cyber-terms-hub、2026-Challenge-Cup-Security-LLM-Triage-Agent、2025-Challenge-Cup-CyberRange-AI-Arena、xuandun-cyber-range、soft-skills-platform、pikachu、desktop-tutorial |
| 标准 MIT | **6** | xihu-sword-ctf-agent、comment-distillery、livecaption-lab、spn-linear-cryptanalysis、law-case-pdf2docx、dev-snippets-archive |

三个具体病症：

**病症 A：README 承诺 MIT，LICENSE 文件写"保留所有权利"——同一仓库两套互斥授权**

这是本次审计最严重的发现。10 个 `NOASSERTION` 仓共用同一份 752 字符的 `Source-Available · All Rights Reserved` 文本（禁止复制/修改/衍生/商用，需书面许可），但其中 **6 个仓的 README 明确宣称 MIT**（5 个还挂着 MIT 徽章），README 与 LICENSE 互斥：

| 仓库 | README 的声明 | LICENSE 文件实际内容 | 影响 |
|---|---|---|---|
| **AGI-Distiller**（9★） | 徽章 `License: MIT` + 链接到 LICENSE | All Rights Reserved | 头部项目，对外=MIT，对内=禁止一切 |
| **passive-recon**（7★） | 徽章 `license-MIT` + `## 📜 License` 段正文写 `MIT` | All Rights Reserved | 同上 |
| **DevRadar-GitHub-Trending-Monitor**（4★） | 徽章 + "licensed under the **MIT License** — see the LICENSE file" | All Rights Reserved | README 直接指向一个内容相反的 LICENSE |
| **pikachu** | 徽章 + "🆓 完全免费开源 ✅ MIT 协议" | All Rights Reserved | 同时还缺上游署名（见下） |
| **xuandun-cyber-range** | `## 📜 许可证 [MIT](./LICENSE)`，同一文件末尾又有 `## License & Usage Notice` | All Rights Reserved | 单篇 README 内部自相矛盾 |
| **2026-Challenge-Cup-Security-LLM-Triage-Agent** | `## 🤝 License [MIT](LICENSE) © Minjiang University Team` + 紧随其后 `## License & Usage Notice` | All Rights Reserved | 赛题交付，评审方会直接看到矛盾 |

后果比"没有 LICENSE"更糟：下游按 README 判定可用（`pip install`、二次分发、企业引入），实际许可禁止——一旦发生就是版权纠纷。GitHub 的 license 检测器已经给出 `Other` 结论，等于自动挡掉了所有依赖扫描与 awesome-list。

**病症 B：`pikachu` 疑似第三方靶场重打包，README 无任何上游署名**

README 自述"Pikachu 漏洞靶场 **定制版**"，文件树与上游 `zhuifengshaonianhanlu/pikachu`（4,578★，**Apache-2.0**）高度一致（289 文件、`assets/` 原样保留、`pkxss` 结构相同），但全文检索不到原作者/上游链接任何字样，LICENSE 也不是上游许可。**已核实：上游为 Apache-2.0，因此正确做法不是改 MIT，而是继续 Apache-2.0 + 保留署名 + 声明改动**——这是全账号唯一的法律风险项。

**病症 C：主力仓零授权**

`MARS-408`（6★、41 分支、17KB CI）与 `SecAutoMind-src`（88MB、20 分支、Go+Python 双栈）都没有任何 LICENSE——体量最大、工程最重的两个仓，对外授权最不清晰。

### 1.2 体积：2 仓超 50MB，且完全没用 LFS

| 仓库 | 体积 | 主要占用 | 处置建议 |
|---|---|---|---|
| **MARS-408** | **108.7 MB** | 根目录 4 张架构图 PNG（数 MB 级）+ `documents/`、`archive/`、`deliverables/`、`site/` | 图片迁 Release 附件或压缩为 WebP；`.gitattributes` 加 LFS 规则；`archive/` 迁出 |
| **SecAutoMind-src** | **88.0 MB** | `SecAutoMind_PPT/`、`assets/`、`knowledge_base/`、`data/`、`CTF-Agent_融合` | PPT/知识库打包进 Release，正文只留源码 |
| coastal-traffic-visual-analytics | 47.5 MB | 数据集/可视化产物 | 已接近阈值，数据集外置 |
| 2026-crypto-math-challenge | 32.6 MB | 赛题材料 | 材料仓，可 Git LFS |
| 2025-Challenge-Cup-CyberRange-AI-Arena | 31.9 MB | 靶场镜像/材料 | 同上 |

两仓的 `.gitattributes` 都只处理行尾（EOL），没有一条 LFS 规则——已逐字确认不含 `filter=lfs`。两仓合计 **196.7MB**，占 42 仓总体积（416.1MB）的 **47.3%**，接近一半的体积压在两个仓里。

反差点在于：**作者其实会用 Release 附件**——`SecAutoMind-src` 的 `main` Release 挂了 **449MB** 安装包，`SecAutoMind` 的 v1.7.28 挂了 **444MB**，`marl-ecdsa` 60MB，`comment-distillery` 12MB。说明"大文件走 Release"这条路已经走通，只是 **`MARS-408` 没走**：它是重资产仓里唯一 0 Release 的一个，把 108.7MB 全压进 git 历史，每次 clone 都要拉全量。

### 1.3 仓库碎片化：6 组"主仓 + 材料仓"，材料仓普遍零文档

| 主仓 | 材料/镜像仓 | 材料仓状态 |
|---|---|---|
| MangDeHenZhi（8.6MB，3 CI） | MangDeHenZhi-materials（7.9MB） | **无 README**、无 LICENSE、无 CI |
| marl-ecdsa（3.9MB） | marl-ecdsa-competition-materials（0.3MB） | **无 README**、无 description、无 topics |
| SecAutoMind-src（88MB，源码） | SecAutoMind（0.1MB，仅 `index.html`+`robots.txt`） | **无 README**，但发了 v1.7.28 Release |
| AeroRider（0.4MB） | aerorider-delivery（2.7MB） | 无 description、无 topics、无 README 关联 |
| sage-paper（1.3MB） | sage-paper-public（0.2MB） | 两仓 README **完全相同**（7,469 字），内容重复 |
| xihu-sword-ctf-agent（6.2MB，MIT，pytest+ruff） | xihu-ctf-deliverables（1.1MB，私有） | **无 README**、无 LICENSE、无 gitignore |

这 6 组共 12 个仓，其中 4 个是零 README；star 也被摊薄——42 个仓合计仅 92★，最高 9★。

---

## 2. P1 · 工程闭环缺失：CI 与 Release 是最大空白

### 2.1 CI 覆盖 29%，真正跑断言的只有 17%

有 workflow 的 12 个仓，按"是否真的执行测试"再切一刀：

| 真正跑测试（7） | 只做构建/部署/杂务（5） |
|---|---|
| MARS-408（pytest + npm test，3 个 workflow：security-gates / backend-test / p0-regression）<br>xihu-sword-ctf-agent（pytest + ruff）<br>physics-scheduler-agent（pytest + vitest + ruff）<br>MangDeHenZhi（vitest）<br>SecAutoMind-src（go test）<br>passive-recon（pytest）<br>comment-distillery（unittest + compileall） | **TrueFurina**（snake 贪吃蛇动画，纯装饰）<br>**marl-ecdsa**（build-binaries.yml 只打包，无断言）<br>**AGI-Distiller**（golden-regression 无测试运行器）<br>**xuandun-cyber-range**（deploy only）<br>**2026-Challenge-Cup-Security-LLM-Triage-Agent**（ci.yml 内无任何 pytest/ruff） |

问题最突出的三个空白：

- **`Denia`**（24.6MB、825 文件、私有、最近提交 2026-10-28、已有 tests）**零 CI**。这是当前最活跃的桌面应用项目，靠手工回归。
- **`cyber-terms-hub`**（23.3MB、122 文件、22,365 字 README、112 张外链截图）零 CI 零测试——纯数据仓恰恰最适合做"链接存活 + JSON schema"校验，一条 workflow 就能防住图片腐烂。
- **`2026-Challenge-Cup-Security-LLM-Triage-Agent`** 有 `ci.yml` 但里面没有任何测试/静态检查命令，属于"有 CI 徽章、无 CI 内容"。

### 2.2 Release 覆盖 12%，且与 README 自相矛盾

仅 5 个仓有 Release：`comment-distillery`（v1.7.0，12MB 附件）、`passive-recon`（v0.1.0，无附件）、`marl-ecdsa`（ccf-submission-exe-v1.0.0，60MB）、`SecAutoMind`（v1.7.28，**444MB**）、`SecAutoMind-src`（tag 名为 `main`，**449MB**）。也就是说：**会发 Release 的仓都把安装包发出去了（合计约 965MB 附件），剩下 37 个仓一件可执行产物都没有**——不是不会发，是只对最头部的两个产品发了。

最直接的破窗：**`Denia` 的 README「快速开始」下第一条就是"路线 A · 用安装包（给测试用户）"并指向 `docs/使用指南_内测版v1.0.md`，但该仓 0 个 Release**。文档承诺了分发渠道，渠道不存在；用户只能走"路线 B 从源码跑"。同类问题：`MARS-408`（README 有 17KB CI + 完整部署文档，0 Release，108MB 源码裸奔）、`xihu-sword-ctf-agent`（6.2MB、MIT、pytest 全绿，0 Release）。

---

## 3. P2 · 文档与元数据

- **README 质量不差，是元数据拖后腿**：平均 5,435 字，>10k 字的仓有 9 个（cyber-terms-hub 22,365、xihu-sword-ctf-agent 17,455、TrueFurina 13,287、physics-scheduler-agent 12,786、MARS-408 12,509、AGI-Distiller 11,498、comment-distillery 11,465、DevRadar 10,915、passive-recon 10,037）。但 **topics 只有 31%、homepage 只有 10%**，GitHub 搜索几乎抓不到。
- **5 个仓零 README**：`xihu-ctf-deliverables`、`workspace`、`marl-ecdsa-competition-materials`、`MangDeHenZhi-materials`、`SecAutoMind`。其中 `workspace`（3.4MB、118 文件）是典型的"杂物间仓"，没有 README 就无法判断里面是什么，建议要么补 3 行说明，要么直接归档。
- **`marl-ecdsa` README 仅 259 字**，却是 3.9MB、有 CI、有 Release 的参赛主仓——最该讲清楚方法的仓，文档最短。
- **`sage-paper` 与 `sage-paper-public` 的 README 完全一致**（均 7,469 字），说明"公开发布"是复制而非派生，后续必然漂移。
- 9 个仓无 description：`marl-ecdsa-competition-materials`、`aerorider-delivery`、`docker-forensics-toolkit`、`win-appx-doctor`、`workspace`、`xihu-ctf-deliverables`、`law-case-pdf2docx`、`soft-skills-platform`、`pikachu`。

---

## 4. P3 · 仓库卫生

- **`.gitignore` 缺失 13 个**（69% 有）：`TrueFurina`、`dev-snippets-archive`、`SecAutoMind`、`docker-forensics-toolkit`、`win-appx-doctor`、`workbuddy-vivo-fix`、`wsl-docker-recovery`、`cyber-terms-hub`、`workspace`、`2026-crypto-math-challenge`、`xihu-ctf-deliverables`、`desktop-tutorial`、`pikachu`。
- **`TrueFurina`（个人主页仓）有 100 个分支**，仓内只有 3 个文件（`README.md`、`PULL_SHARK_LOG.md`、`snake.yml`）。分支数远超文件数，说明历史实验分支从未清理。
- **`pikachu` 提交了 `.DS_Store` 与 `assets/css/bootstrap.min.css.bak`**，属于本地残留。
- **`desktop-tutorial` 是 GitHub Desktop 默认模板仓**（2 个文件、735 字），被改成自定义 license 却无任何项目内容，建议直接删除或归档，避免污染仓库列表。
- 非 Python 仓的依赖缺失：`docker-forensics-toolkit`（PowerShell，无 `*.psd1`/模块清单）、`win-appx-doctor`（Batchfile，无说明依赖）。

---

## 5. 全量明细（按严重度排序，42 行）

> CI 列数字 = workflow 文件数；tests 列 Y = 存在 `tests/`、`test_*.py`、`*_test.py`、`conftest.py` 或 `*.test.*`；"自定义" = GitHub 判 `NOASSERTION` 的 Source-Available 文本。

| 仓库名 | README字数 | License | CI | tests | 依赖文件 | Release | 体积MB | 备注 |
|---|---|---|---|---|---|---|---|---|
| xihu-ctf-deliverables | 0 | 无 | — | — | 无 | 无 | 1.1 | 无README/无LICENSE/无CI/无测试/无依赖/无Release/无.gitignore/无描述/无topics（私有交付仓） |
| workspace | 0 | 无 | — | — | 无 | 无 | 3.4 | 无README/无LICENSE/无CI/无测试/无依赖/无Release/无.gitignore/无描述/无topics（118 文件杂物间） |
| marl-ecdsa-competition-materials | 0 | 无 | — | — | 无 | 无 | 0.3 | 无README/无LICENSE/无CI/无测试/无依赖/无Release/无描述/无topics |
| MangDeHenZhi-materials | 0 | 无 | — | — | 无 | 无 | 7.9 | 无README/无LICENSE/无CI/无测试/无依赖/无Release/无topics |
| SecAutoMind | 0 | 无 | — | — | 无 | v1.7.28 | 0.1 | 无README/无LICENSE/无CI/无测试/无.gitignore（仅 index.html，官网壳仓） |
| docker-forensics-toolkit | 1730 | 无 | — | — | 无 | 无 | 0.0 | 无LICENSE/无CI/无测试/无依赖/无Release/无.gitignore/无描述/无topics |
| win-appx-doctor | 3768 | 无 | — | — | 无 | 无 | 0.0 | 无LICENSE/无CI/无测试/无依赖/无Release/无.gitignore/无描述/无topics |
| wsl-docker-recovery | 1882 | 无 | — | — | 无 | 无 | 0.0 | 无LICENSE/无CI/无测试/无依赖/无Release/无.gitignore/无topics |
| workbuddy-vivo-fix | 659 | 无 | — | — | 无 | 无 | 0.0 | 无LICENSE/无CI/无测试/无依赖/无Release/无.gitignore/无topics |
| coastal-traffic-visual-analytics | 4295 | 无 | — | — | 无 | 无 | 47.5 | 无LICENSE/无CI/无测试/无依赖/无Release/无topics；47.5MB 逼近阈值 |
| sage-paper | 7469 | 无 | — | — | 无 | 无 | 1.3 | 无LICENSE/无CI/无测试/无依赖/无Release/无topics；README 与 sage-paper-public 完全重复 |
| sage-paper-public | 7469 | 无 | — | — | 无 | 无 | 0.2 | 无LICENSE/无CI/无测试/无依赖/无Release/无topics；README 系拷贝 |
| 2026-crypto-math-challenge | 810 | 无 | — | Y | 无 | 无 | 32.6 | 无LICENSE/无CI/无依赖/无Release/无.gitignore；赛题材料，宜用 LFS |
| TrueFurina | 13287 | 无 | 1 | — | 无 | 无 | 0.6 | 无LICENSE/无测试/无.gitignore/无topics；**100 个分支**但仅 3 个文件 |
| aerorider-delivery | 3554 | 无 | — | — | req | 无 | 2.7 | 无LICENSE/无CI/无测试/无Release/无描述/无topics（AeroRider 材料仓） |
| cyber-terms-hub | 22365 | 自定义 | — | — | 无 | 无 | 23.3 | 非标准License/无CI/无测试/无Release/无.gitignore；23MB 里 112 张外链截图占绝大部分 |
| desktop-tutorial | 735 | 自定义 | — | — | 无 | 无 | 0.0 | GitHub Desktop 模板仓，无项目内容却挂自定义授权；建议删除/归档 |
| FDE | 3262 | 无 | — | Y | 无 | 无 | 0.7 | 无LICENSE/无CI/无依赖/无Release |
| pikachu | 6318 | 自定义 | — | Y | 无 | 无 | 3.4 | **README 写「完全免费开源 ✅ MIT 协议」，LICENSE 实为 All Rights Reserved**；定制版无上游署名；无CI/无.gitignore/提交 .DS_Store |
| MangDeZhiXun | 1776 | 无 | — | — | package.json | 无 | 6.8 | 无LICENSE/无CI/无测试/无Release/无topics |
| MARS-408 | 12509 | 无 | 3 | Y | package.json | 无 | 108.7 | **无LICENSE**/**108.7MB 超限**/无Release；tests 仅 1 个文件，与 17KB 安全门禁不匹配 |
| soft-skills-platform | 591 | 自定义 | — | — | package.json | 无 | 1.2 | 非标准License/无CI/无测试/无Release/无描述/无topics |
| law-case-pdf2docx | 2364 | MIT | — | — | 无 | 无 | 0.0 | 无CI/无测试/无依赖/无Release/无描述/无topics |
| marl-ecdsa | 259 | 无 | 1 | Y | pyproject,requirements | ccf-submission-exe-v1.0.0 | 3.9 | **README 仅 259 字**/无LICENSE/无topics；CI 只 build 不测试 |
| AI-Arena | 2823 | 无 | — | Y | pyproject,requirements | 无 | 1.0 | 无LICENSE/无CI/无Release/无topics |
| Denia | 3366 | 无 | — | Y | requirements,requirements-optional,package.json | 无 | 24.6 | **无LICENSE/无CI/无Release**；README 承诺"路线A 用安装包"但无 Release；当前最活跃仓 |
| mcd-meal-optimizer | 9078 | 无 | — | Y | requirements.txt | 无 | 0.1 | 无LICENSE/无CI/无Release |
| AeroRider | 3461 | 无 | — | Y | requirements.txt | 无 | 0.4 | 无LICENSE/无CI/无Release |
| DevRadar-GitHub-Trending-Monitor | 10915 | 自定义 | — | — | requirements.txt | 无 | 1.1 | **README 写「MIT License」并指向 LICENSE，该文件实为 All Rights Reserved**/无CI/无测试/无Release |
| SecAutoMind-src | 4371 | 无 | 3 | Y | go.mod,requirements.txt | main | 88.0 | **无LICENSE**/**88.0MB 超限**；tests 散落 `scripts/*_test.py` 无 `tests/` 目录 |
| dev-snippets-archive | 2008 | MIT | — | Y | 无 | 无 | 0.0 | 无CI/无依赖/无Release/无.gitignore/无topics |
| 2025-Challenge-Cup-CyberRange-AI-Arena | 5259 | 自定义 | — | Y | requirements.txt,setup.cfg | 无 | 31.9 | 非标准License/无CI/无Release/无topics；31.9MB |
| AGI-Distiller | 11498 | 自定义 | 1 | Y | 无 | 无 | 0.5 | **README 挂 MIT 徽章，LICENSE 实为 All Rights Reserved**；无依赖清单/无Release；9★ 头部仓 |
| MangDeHenZhi | 9164 | 无 | 3 | Y | package.json | 无 | 8.6 | 无LICENSE/无Release/无topics |
| spn-linear-cryptanalysis | 6039 | MIT | — | Y | 无 | 无 | 0.6 | 无CI/无依赖/无Release/无topics |
| physics-scheduler-agent | 12786 | 无 | 1 | Y | requirements,requirements-dev,package.json | 无 | 1.7 | 无LICENSE/无Release |
| xuandun-cyber-range | 3729 | 自定义 | 1 | — | package.json | 无 | 0.0 | **README 内既写 `[MIT](LICENSE)` 又写 `License & Usage Notice`**/无测试（CI 仅 deploy）/无Release/无topics |
| livecaption-lab | 4676 | MIT | — | Y | 无 | 无 | 0.1 | 无CI/无依赖/无Release |
| 2026-Challenge-Cup-Security-LLM-Triage-Agent | 5034 | 自定义 | 1 | Y | pyproject,requirements | 无 | 1.0 | **README 同时写 MIT 与 License & Usage Notice**/**ci.yml 内无任何测试命令**/无Release/无topics |
| passive-recon | 10037 | 自定义 | 1 | Y | requirements.txt | v0.1.0 | 2.4 | **README 写 MIT 徽章 +「## License MIT」，LICENSE 实为 All Rights Reserved**；其余指标良好，7★ 头部仓 |
| xihu-sword-ctf-agent | 17455 | MIT | 1 | Y | pyproject,requirements | 无 | 6.2 | 无Release（6.2MB 成品无分发通道） |
| comment-distillery | 11465 | MIT | 3 | Y | 零依赖（刻意） | v1.7.0 | 1.8 | 基本合规：MIT + 3 CI + tests + Release，全仓**唯一**完整闭环 |

---

## 6. 五条最高优先级动作

**① 立刻修掉三个头部仓的"README 说 MIT / LICENSE 说保留所有权利"矛盾**
直接替换 `AGI-Distiller/LICENSE`、`passive-recon/LICENSE`、`DevRadar-GitHub-Trending-Monitor/LICENSE` 三个文件的全文为标准 MIT 文本（保留 `Copyright (c) 2026 TrueFurina` 版权行）。理由：这三个仓的 README 徽章与 License 段已对外承诺 MIT，改 LICENSE 是唯一自洽且零返工的方向（反方向要改徽章、改段落、还要向已使用方解释）。这三仓合计 20★，是账号全部 92★ 的 22%，也是被外部引用最可能的三处。

**② 清除 `pikachu` 的双重声明并补上游署名**
改 `pikachu/README.md`：删掉 `## License & Usage Notice`（All Rights Reserved）整段，把"🆓 完全免费开源 ✅ MIT 协议"与 MIT 徽章改为 Apache-2.0；同时把 `pikachu/LICENSE` 换成 **Apache-2.0 全文**（上游 `zhuifengshaonianhanlu/pikachu` 为 Apache-2.0，派生作品不能改成 MIT），并新增 `NOTICE` 写上游署名、版权与改动清单。同批处理 `xuandun-cyber-range/README.md`、`2026-Challenge-Cup-Security-LLM-Triage-Agent/README.md`（两者都在同一篇里既写 `[MIT](LICENSE)` 又写 `## License & Usage Notice`），只保留一段。

**③ `MARS-408` + `SecAutoMind-src`：补 LICENSE，体积从 196MB 压到 40MB 以内**
建 `MARS-408/LICENSE` 与 `SecAutoMind-src/LICENSE`（建议 Apache-2.0，含专利授权，适配安全产品）；`MARS-408/.gitattributes` 与 `SecAutoMind-src/.gitattributes` 追加 LFS 规则（`*.png filter=lfs`、`*.pptx filter=lfs`、`documents/**`、`knowledge_base/**`）；把 `MARS-408` 根目录 4 张架构 PNG + `deliverables/`、`SecAutoMind-src` 的 `SecAutoMind_PPT/` 与 `assets/` 移出仓库，作为首个 Release 的附件发布（`MARS-408` 目前 0 Release；`SecAutoMind-src` 虽已有 Release 但附件是 449MB 安装包，仓内这 88MB 素材应一并外置）。这两仓占全账号体积 **47.3%**，也是唯二触发 50MB 阈值告警的仓。

**④ `Denia`：补 CI + 发首个 Release，让 README 的"路线 A"成立**
建 `Denia/.github/workflows/ci.yml`（matrix py3.10/3.12，`windows-latest`，跑 `python -m compileall src/` + 现有 tests + `src/agent_pro/selftest.py`）；打 `v0.2.0` tag 发布 Release，附 Windows 安装包（README 标注的 build 20261018）。现状：24.6MB、825 文件、当日仍在提交的最活跃仓，零 CI 零 Release，而 README「快速开始 · 路线 A · 用安装包」指向的下载入口并不存在。

**⑤ 给 5 个零 README 仓补最小说明，并合并 6 组重复仓**
建 `MangDeHenZhi-materials/README.md`、`workspace/README.md`、`marl-ecdsa-competition-materials/README.md`、`xihu-ctf-deliverables/README.md`、`SecAutoMind/README.md`，每个 3 段即可：这是什么 / 与主仓的关系 / 如何引用（指向主仓）。同步决策：`sage-paper-public`（README 与 `sage-paper` 完全重复）与 `desktop-tutorial`（GitHub Desktop 模板空仓）直接归档；`AeroRider`/`aerorider-delivery`、`xihu-sword-ctf-agent`/`xihu-ctf-deliverables` 在双方 README 互加说明。另清 `TrueFurina` 仓的 100 个历史分支（只留 `main`），并给 `2026-Challenge-Cup-Security-LLM-Triage-Agent/.github/workflows/ci.yml` 补上真正的 `pytest`/`ruff` 步骤（该文件目前只有 CI 骨架，无任何检查命令）。

---

## 7. 统计口径说明

| 指标 | 定义 | 结果 |
|---|---|---|
| README 平均字数 | 42 仓 README 去空白字符数算术平均（缺失计 0） | **5,435 字**；中位 3,768；缺失 5 仓 |
| 有 CI 比例 | `.github/workflows/` 下存在 ≥1 个 `.yml/.yaml` | **12/42 = 28.6%**；其中真正执行测试 7/42 = 16.7% |
| 有 LICENSE 比例 | `/license` 接口返回有效 license 对象（含 `NOASSERTION`） | **16/42 = 38.1%**；其中标准 OSI 仅 6/42 = 14.3%，`NOASSERTION` 10/42 = 23.8% |
| 有 tests 比例 | 递归文件树命中 `tests/`、`test/`、`test_*.py`、`*_test.py`、`conftest.py`、`*.test.*` | **21/42 = 50.0%** |
| 有依赖清单 | `requirements*.txt` / `pyproject.toml` / `package.json` / `go.mod` / `setup.cfg` 任一（含嵌套目录） | 18/42 = 42.9% |
| 有 Release | `/releases` 返回 ≥1 条 | 5/42 = 11.9% |
| 有 .gitignore | 根目录存在 `.gitignore` | 29/42 = 69.0% |
| 有 description / topics / homepage | 字段非空 | 33 / 13 / 4（78.6% / 31.0% / 9.5%） |
| 体积 > 50MB | `size` KB > 51,200 | 2 仓（MARS-408 108.7MB、SecAutoMind-src 88.0MB） |

**数据可信度备注**：`MARS-408`（108.7MB）与 `SecAutoMind-src`（88.0MB）的递归树请求会触发本机代理 500KB 截断，这两仓的文件清单由 `/contents/` 根目录 + 指定子目录逐层补齐，tests 判定经单独复核（分别为 `tests/benchmark_evidence_gate.py`、`scripts/*_test.py`），故表中标 Y 而非脚本初判的 N。其余 40 仓均基于完整递归树。
