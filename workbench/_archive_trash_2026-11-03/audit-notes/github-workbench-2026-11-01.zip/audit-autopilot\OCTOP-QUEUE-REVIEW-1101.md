# Octop 三仓 open PR 队列体检

生成时间：2026-11-01 10:32 ｜ 数据源：`/repos/{repo}/pulls?state=open` 逐个取详情
范围：`TencentCloud/Octop`、`octop-harness`、`octop-memory` 中**本人**提交且仍 open 的 PR

## 一句话

**87 个 open PR 里，86 个 `mergeable=true`（无冲突，技术上是"点一下就能合"），
1 个有冲突，46 个开了 ≥3 天零评论（维护者没打开过）。**

## 先说清楚 `mergeable_state=unstable` 是怎么回事

这三个仓 `unstable` 占绝大多数（本报告里 86 个），但它**不是"检查失败"**：

```
mergeable=true
combined status = pending，但 statuses 数量 = 0
check-runs = GITHUB_OPENSOURCE_SCAN_PIPELINE → completed / success
分支保护 required_status_checks.contexts = []（三仓都是空）
```

GitHub 在"零个 commit status"时把 combined status 报成 `pending`，于是 `mergeable_state`
标成 `unstable`。**换句话说：它表示"没有 CI 在报状态"，不是"CI 挂了"。**

本次抽查了 10 个 `unstable` 的 PR：其中 **10 个**确认"无失败检查 + 零 status"，
其余可能是并发抖动或确有失败。样本不大，所以下面按"无冲突"而不是"检查全绿"来分组。

## 分布

| 维度 | 数值 |
|---|---|
| 总计 | **87** |
| `mergeable=true`（无冲突） | **86** |
| `mergeable=false`（有冲突） | 1 |
| 其中 `mergeable_state=unstable` | 86 |
| `behind` / `blocked` | 0 / 0 |
| 草稿 | 0 |
| 零评论且 ≥3 天 | **46** |

按仓库：octop-harness 64, Octop 17, octop-memory 6

按 `mergeable_state` 原始计数：{'unstable': 86, 'dirty': 1}

## A. 无冲突，可合（86）

技术门槛已经没了，缺的只是维护者的一次点击。**优先级最高**——每合一个，队列少一个。

| 仓库 | # | 标题 | 规模 | 年龄 | 空闲 | 评论 |
|---|---:|---|---|---:|---:|---:|
| octop-harness | [#83](https://github.com/TencentCloud/octop-harness/pull/83) | feat(tool_guard): detect Windows and PowerShell attack command | +199/−1 | 14d | 4d | 3 |
| octop-memory | [#29](https://github.com/TencentCloud/octop-memory/pull/29) | fix(memory): batch extraction and persist the extracted cursor | +348/−12 | 7d | 3d | 2 |
| octop-memory | [#30](https://github.com/TencentCloud/octop-memory/pull/30) | fix(storage): honor rejected candidates when deduplicating re- | +38/−13 | 6d | 4d | 1 |
| octop-harness | [#132](https://github.com/TencentCloud/octop-harness/pull/132) | fix(session_header): catch ValueError on ContextVar reset acro | +7/−1 | 4d | 4d | 0 |
| octop-harness | [#129](https://github.com/TencentCloud/octop-harness/pull/129) | fix(docker): preserve leading dots in relative paths (issue #4 | +9/−2 | 4d | 4d | 0 |
| octop-harness | [#128](https://github.com/TencentCloud/octop-harness/pull/128) | fix(tool_guard): add Windows PowerShell attack detection rules | +133/−1 | 4d | 4d | 0 |
| octop-harness | [#127](https://github.com/TencentCloud/octop-harness/pull/127) | fix(runtime): treat a non-UTF-8 workspace .env as unreadable | +5/−1 | 4d | 4d | 0 |
| octop-harness | [#126](https://github.com/TencentCloud/octop-harness/pull/126) | fix: enforce workspace sandbox isolation for absolute paths | +62/−6 | 4d | 4d | 0 |
| octop-harness | [#124](https://github.com/TencentCloud/octop-harness/pull/124) | fix(decision): remove system-prompt text mutation in _relocate | +8/−9 | 4d | 4d | 0 |
| octop-harness | [#123](https://github.com/TencentCloud/octop-harness/pull/123) | Add LoopGuardMiddleware to break repeated identical tool-call  | +264/−26 | 4d | 4d | 0 |
| octop-harness | [#121](https://github.com/TencentCloud/octop-harness/pull/121) | fix(tool_guard): add defense_evasion threat category + re-file | +2/−1 | 4d | 4d | 0 |
| octop-harness | [#116](https://github.com/TencentCloud/octop-harness/pull/116) | fix(teams): isolate inbox worker from caller's contextvars (#1 | +22/−1 | 4d | 4d | 0 |
| octop-memory | [#36](https://github.com/TencentCloud/octop-memory/pull/36) | fix(router): add episode to default recall sources | +6/−0 | 4d | 4d | 0 |
| octop-memory | [#35](https://github.com/TencentCloud/octop-memory/pull/35) | fix(hermes): pass llm and extraction config blocks through bri | +6/−0 | 4d | 4d | 0 |
| octop-memory | [#34](https://github.com/TencentCloud/octop-memory/pull/34) | fix(extract): batch event feed + persist cursor across restart | +156/−26 | 4d | 4d | 0 |
| octop-memory | [#33](https://github.com/TencentCloud/octop-memory/pull/33) | fix(manual-docs): advance audit cursor on uncertain results | +10/−7 | 4d | 2d | 0 |
| octop-harness | [#176](https://github.com/TencentCloud/octop-harness/pull/176) | fix(probe): narrow suppress(Exception) to (OSError, RuntimeErr | +5/−6 | 3d | 3d | 0 |
| octop-harness | [#175](https://github.com/TencentCloud/octop-harness/pull/175) | fix(probe): narrow suppress(Exception) to suppress(OSError) in | +4/−5 | 3d | 3d | 0 |
| octop-harness | [#174](https://github.com/TencentCloud/octop-harness/pull/174) | fix(clean): add missing_ok=True to Path.unlink calls in PPTX c | +9/−9 | 3d | 3d | 0 |
| octop-harness | [#173](https://github.com/TencentCloud/octop-harness/pull/173) | fix(core): replace deprecated asyncio.get_event_loop | +3/−3 | 3d | 3d | 0 |
| octop-harness | [#172](https://github.com/TencentCloud/octop-harness/pull/172) | fix(backends): use unlink(missing_ok=True) in probe cleanup | +3/−4 | 3d | 3d | 0 |
| octop-harness | [#171](https://github.com/TencentCloud/octop-harness/pull/171) | fix(cli): make shutil.rmtree resilient with ignore_errors | +4/−4 | 3d | 3d | 0 |
| octop-harness | [#170](https://github.com/TencentCloud/octop-harness/pull/170) | fix(cli): add encoding=utf-8 to setup wizard config read | +1/−1 | 3d | 3d | 0 |
| octop-harness | [#169](https://github.com/TencentCloud/octop-harness/pull/169) | fix(tools): add encoding=utf-8 to macOS screencapture subproce | +2/−0 | 3d | 3d | 0 |
| octop-harness | [#168](https://github.com/TencentCloud/octop-harness/pull/168) | fix(cli): add encoding=utf-8 to subprocess text=True in update | +1/−0 | 3d | 3d | 0 |
| octop-harness | [#167](https://github.com/TencentCloud/octop-harness/pull/167) | fix(skills): use time.monotonic() for kernel deadline loops | +6/−6 | 3d | 3d | 0 |
| octop-harness | [#166](https://github.com/TencentCloud/octop-harness/pull/166) | fix(tools): specify encoding=utf-8 on subprocess text=True cal | +2/−0 | 3d | 3d | 0 |
| octop-harness | [#165](https://github.com/TencentCloud/octop-harness/pull/165) | fix(config): guard bare int() calls in ModelConfig.from_dict | +9/−3 | 3d | 3d | 0 |
| octop-harness | [#164](https://github.com/TencentCloud/octop-harness/pull/164) | fix(history): guard bare int() calls in ContextUsage.from_dict | +22/−10 | 3d | 3d | 0 |
| octop-harness | [#163](https://github.com/TencentCloud/octop-harness/pull/163) | fix(llm): log swallowed OSError when reading local image files | +5/−19 | 3d | 3d | 0 |
| octop-harness | [#162](https://github.com/TencentCloud/octop-harness/pull/162) | fix(builtin): filter macOS-only skills in sync and template la | +132/−7 | 3d | 3d | 0 |
| octop-harness | [#160](https://github.com/TencentCloud/octop-harness/pull/160) | feat(memory): add deprecate/replace tools so agents can self-m | +71/−1 | 3d | 3d | 0 |
| octop-harness | [#159](https://github.com/TencentCloud/octop-harness/pull/159) | fix(memory): strengthen recall context markers to prevent fals | +6/−3 | 3d | 3d | 0 |
| octop-harness | [#158](https://github.com/TencentCloud/octop-harness/pull/158) | feat(middleware): add LoopGuardMiddleware to break tool-call l | +147/−0 | 3d | 3d | 0 |
| octop-harness | [#157](https://github.com/TencentCloud/octop-harness/pull/157) | fix(teams): expose callee default MCP tools in one-shot peer r | +2/−0 | 3d | 3d | 0 |
| octop-harness | [#153](https://github.com/TencentCloud/octop-harness/pull/153) | fix(harness): consume compatibility field so macos-only builti | +93/−0 | 3d | 3d | 0 |
| octop-harness | [#152](https://github.com/TencentCloud/octop-harness/pull/152) | fix(harness): normalise cumulative-vs-incremental stream usage | +122/−0 | 3d | 3d | 0 |
| octop-harness | [#151](https://github.com/TencentCloud/octop-harness/pull/151) | fix(harness): skip reasoning_content round-trip for providers  | +9/−1 | 3d | 3d | 0 |
| octop-harness | [#150](https://github.com/TencentCloud/octop-harness/pull/150) | fix(harness): update kimi_search default model to kimi-k3.1-pr | +11/−5 | 3d | 3d | 0 |
| octop-harness | [#149](https://github.com/TencentCloud/octop-harness/pull/149) | fix(agent): skip negative media directive when MCP media tools | +67/−1 | 3d | 3d | 0 |

_（共 86 个，此处列前 40）_


## B. 有冲突，需要 rebase 或重开（1）

`mergeable=false` 意味着和 base 打架。要么 rebase，要么关掉重开一个干净的。
**放着不动最糟**：占用名额，且每次 base 前进都更难解。

| 仓库 | # | 标题 | 规模 | 年龄 | 空闲 | 评论 |
|---|---:|---|---|---:|---:|---:|
| octop-harness | [#106](https://github.com/TencentCloud/octop-harness/pull/106) | fix(llm): bound OpenAI-compatible requests with a default time | +34/−0 | 7d | 4d | 1 |


## C. 零评论且 ≥3 天（46）

维护者从没打开过。它们不是"被拒绝"，是**没有被看见**。对这批，提高单条质量的收益
远大于再开新的。

| 仓库 | # | 标题 | 规模 | 年龄 | 空闲 | 评论 |
|---|---:|---|---|---:|---:|---:|
| octop-harness | [#176](https://github.com/TencentCloud/octop-harness/pull/176) | fix(probe): narrow suppress(Exception) to (OSError, RuntimeErr | +5/−6 | 3d | 3d | 0 |
| octop-harness | [#175](https://github.com/TencentCloud/octop-harness/pull/175) | fix(probe): narrow suppress(Exception) to suppress(OSError) in | +4/−5 | 3d | 3d | 0 |
| octop-harness | [#174](https://github.com/TencentCloud/octop-harness/pull/174) | fix(clean): add missing_ok=True to Path.unlink calls in PPTX c | +9/−9 | 3d | 3d | 0 |
| octop-harness | [#173](https://github.com/TencentCloud/octop-harness/pull/173) | fix(core): replace deprecated asyncio.get_event_loop | +3/−3 | 3d | 3d | 0 |
| octop-harness | [#172](https://github.com/TencentCloud/octop-harness/pull/172) | fix(backends): use unlink(missing_ok=True) in probe cleanup | +3/−4 | 3d | 3d | 0 |
| octop-harness | [#171](https://github.com/TencentCloud/octop-harness/pull/171) | fix(cli): make shutil.rmtree resilient with ignore_errors | +4/−4 | 3d | 3d | 0 |
| octop-harness | [#170](https://github.com/TencentCloud/octop-harness/pull/170) | fix(cli): add encoding=utf-8 to setup wizard config read | +1/−1 | 3d | 3d | 0 |
| octop-harness | [#169](https://github.com/TencentCloud/octop-harness/pull/169) | fix(tools): add encoding=utf-8 to macOS screencapture subproce | +2/−0 | 3d | 3d | 0 |
| octop-harness | [#168](https://github.com/TencentCloud/octop-harness/pull/168) | fix(cli): add encoding=utf-8 to subprocess text=True in update | +1/−0 | 3d | 3d | 0 |
| octop-harness | [#167](https://github.com/TencentCloud/octop-harness/pull/167) | fix(skills): use time.monotonic() for kernel deadline loops | +6/−6 | 3d | 3d | 0 |
| octop-harness | [#166](https://github.com/TencentCloud/octop-harness/pull/166) | fix(tools): specify encoding=utf-8 on subprocess text=True cal | +2/−0 | 3d | 3d | 0 |
| octop-harness | [#165](https://github.com/TencentCloud/octop-harness/pull/165) | fix(config): guard bare int() calls in ModelConfig.from_dict | +9/−3 | 3d | 3d | 0 |
| octop-harness | [#164](https://github.com/TencentCloud/octop-harness/pull/164) | fix(history): guard bare int() calls in ContextUsage.from_dict | +22/−10 | 3d | 3d | 0 |
| octop-harness | [#163](https://github.com/TencentCloud/octop-harness/pull/163) | fix(llm): log swallowed OSError when reading local image files | +5/−19 | 3d | 3d | 0 |
| octop-harness | [#162](https://github.com/TencentCloud/octop-harness/pull/162) | fix(builtin): filter macOS-only skills in sync and template la | +132/−7 | 3d | 3d | 0 |
| octop-harness | [#160](https://github.com/TencentCloud/octop-harness/pull/160) | feat(memory): add deprecate/replace tools so agents can self-m | +71/−1 | 3d | 3d | 0 |
| octop-harness | [#159](https://github.com/TencentCloud/octop-harness/pull/159) | fix(memory): strengthen recall context markers to prevent fals | +6/−3 | 3d | 3d | 0 |
| octop-harness | [#158](https://github.com/TencentCloud/octop-harness/pull/158) | feat(middleware): add LoopGuardMiddleware to break tool-call l | +147/−0 | 3d | 3d | 0 |
| octop-harness | [#157](https://github.com/TencentCloud/octop-harness/pull/157) | fix(teams): expose callee default MCP tools in one-shot peer r | +2/−0 | 3d | 3d | 0 |
| octop-harness | [#153](https://github.com/TencentCloud/octop-harness/pull/153) | fix(harness): consume compatibility field so macos-only builti | +93/−0 | 3d | 3d | 0 |
| octop-harness | [#152](https://github.com/TencentCloud/octop-harness/pull/152) | fix(harness): normalise cumulative-vs-incremental stream usage | +122/−0 | 3d | 3d | 0 |
| octop-harness | [#151](https://github.com/TencentCloud/octop-harness/pull/151) | fix(harness): skip reasoning_content round-trip for providers  | +9/−1 | 3d | 3d | 0 |
| octop-harness | [#150](https://github.com/TencentCloud/octop-harness/pull/150) | fix(harness): update kimi_search default model to kimi-k3.1-pr | +11/−5 | 3d | 3d | 0 |
| octop-harness | [#149](https://github.com/TencentCloud/octop-harness/pull/149) | fix(agent): skip negative media directive when MCP media tools | +67/−1 | 3d | 3d | 0 |
| octop-harness | [#148](https://github.com/TencentCloud/octop-harness/pull/148) | clear usage_metadata per stream chunk to fix summed-token infl | +29/−8 | 3d | 3d | 0 |
| octop-harness | [#146](https://github.com/TencentCloud/octop-harness/pull/146) | gate reasoning_content round-trip behind model.thinking (#2498 | +13/−1 | 3d | 3d | 0 |
| octop-harness | [#145](https://github.com/TencentCloud/octop-harness/pull/145) | fix(opensandbox): add mkdir_path / delete_path / move_path (#1 | +33/−0 | 3d | 3d | 0 |
| octop-harness | [#144](https://github.com/TencentCloud/octop-harness/pull/144) | fix(mcp): stop freezing server_names snapshot in MCPToolMiddle | +48/−14 | 3d | 3d | 0 |
| octop-harness | [#142](https://github.com/TencentCloud/octop-harness/pull/142) | Fix disabled skills still executable via /slash invoke (close  | +56/−1 | 3d | 3d | 0 |
| octop-harness | [#141](https://github.com/TencentCloud/octop-harness/pull/141) | fix(kimi-search): make Moonshot model configurable via env (#1 | +6/−1 | 3d | 3d | 0 |

_（共 46 个，此处列前 30）_


## D. 时间轴两端

最老的 12 个：

| 仓库 | # | 标题 | 规模 | 年龄 | 空闲 | 评论 |
|---|---:|---|---|---:|---:|---:|
| octop-harness | [#83](https://github.com/TencentCloud/octop-harness/pull/83) | feat(tool_guard): detect Windows and PowerShell attack command | +199/−1 | 14d | 4d | 3 |
| octop-harness | [#106](https://github.com/TencentCloud/octop-harness/pull/106) | fix(llm): bound OpenAI-compatible requests with a default time | +34/−0 | 7d | 4d | 1 |
| octop-memory | [#29](https://github.com/TencentCloud/octop-memory/pull/29) | fix(memory): batch extraction and persist the extracted cursor | +348/−12 | 7d | 3d | 2 |
| octop-memory | [#30](https://github.com/TencentCloud/octop-memory/pull/30) | fix(storage): honor rejected candidates when deduplicating re- | +38/−13 | 6d | 4d | 1 |
| octop-harness | [#132](https://github.com/TencentCloud/octop-harness/pull/132) | fix(session_header): catch ValueError on ContextVar reset acro | +7/−1 | 4d | 4d | 0 |
| octop-harness | [#129](https://github.com/TencentCloud/octop-harness/pull/129) | fix(docker): preserve leading dots in relative paths (issue #4 | +9/−2 | 4d | 4d | 0 |
| octop-harness | [#128](https://github.com/TencentCloud/octop-harness/pull/128) | fix(tool_guard): add Windows PowerShell attack detection rules | +133/−1 | 4d | 4d | 0 |
| octop-harness | [#127](https://github.com/TencentCloud/octop-harness/pull/127) | fix(runtime): treat a non-UTF-8 workspace .env as unreadable | +5/−1 | 4d | 4d | 0 |
| octop-harness | [#126](https://github.com/TencentCloud/octop-harness/pull/126) | fix: enforce workspace sandbox isolation for absolute paths | +62/−6 | 4d | 4d | 0 |
| octop-harness | [#124](https://github.com/TencentCloud/octop-harness/pull/124) | fix(decision): remove system-prompt text mutation in _relocate | +8/−9 | 4d | 4d | 0 |
| octop-harness | [#123](https://github.com/TencentCloud/octop-harness/pull/123) | Add LoopGuardMiddleware to break repeated identical tool-call  | +264/−26 | 4d | 4d | 0 |
| octop-harness | [#121](https://github.com/TencentCloud/octop-harness/pull/121) | fix(tool_guard): add defense_evasion threat category + re-file | +2/−1 | 4d | 4d | 0 |


最新的 12 个（增速参考）：

| 仓库 | # | 标题 | 规模 | 年龄 | 空闲 | 评论 |
|---|---:|---|---|---:|---:|---:|
| Octop | [#2709](https://github.com/TencentCloud/Octop/pull/2709) | fix(codex): normalize token refresh failures so callers get Co | +86/−9 | 1d | 1d | 0 |
| Octop | [#2708](https://github.com/TencentCloud/Octop/pull/2708) | fix(users): swap the new portrait in before deleting the old o | +78/−4 | 1d | 1d | 0 |
| Octop | [#2707](https://github.com/TencentCloud/Octop/pull/2707) | fix(gateway): keep the WeCom credential key durable so a lost  | +144/−14 | 1d | 1d | 0 |
| Octop | [#2706](https://github.com/TencentCloud/Octop/pull/2706) | fix(security): write tool guard rules atomically so a torn sav | +81/−3 | 1d | 1d | 0 |
| Octop | [#2705](https://github.com/TencentCloud/Octop/pull/2705) | fix(knowledge): write documents atomically so a failed save ca | +88/−1 | 1d | 1d | 0 |
| Octop | [#2704](https://github.com/TencentCloud/Octop/pull/2704) | fix(ollama): keep cancelled model downloads cancelled | +104/−2 | 1d | 1d | 0 |
| Octop | [#2699](https://github.com/TencentCloud/Octop/pull/2699) | fix(media): serialize inbound attachment path allocation and u | +31/−2 | 1d | 1d | 0 |
| Octop | [#2697](https://github.com/TencentCloud/Octop/pull/2697) | fix(plugins): serialize config.json read-modify-write | +194/−20 | 1d | 1d | 0 |
| Octop | [#2696](https://github.com/TencentCloud/Octop/pull/2696) | fix(config): route the last two config.json writers through th | +139/−30 | 1d | 1d | 0 |
| Octop | [#2695](https://github.com/TencentCloud/Octop/pull/2695) | fix(tls): merge config.json atomically when installing certifi | +36/−2 | 1d | 1d | 0 |
| Octop | [#2694](https://github.com/TencentCloud/Octop/pull/2694) | fix(config): write first-run config.json atomically | +50/−1 | 1d | 1d | 0 |
| Octop | [#2693](https://github.com/TencentCloud/Octop/pull/2693) | fix(env): write ~/.octop/env atomically | +50/−1 | 1d | 1d | 0 |


## 建议（只建议，不执行）

1. **先合 A 组的 86 个**（至少先把 A 组里最老的 20 个）。理由：不需要任何人改代码，
   纯粹是"点一下"；合掉之后队列可读性立刻改善。
2. **B 组 1 个二选一**：能 rebase 的 rebase，改不动的关掉并写一句原因。
3. **C 组 46 个先别动**：它们的问题是"没被看见"。
4. **停止新增**。当前增速下（约 50–90 个/小时），任何"再提一个更小的 PR"都在稀释前面的努力。

> 本文件是只读体检的产物：没有关闭、没有评论、没有推送。
