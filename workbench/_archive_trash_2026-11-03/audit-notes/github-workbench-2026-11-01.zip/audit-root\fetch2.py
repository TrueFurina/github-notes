"""Robust GitHub profile fetcher (no external deps).

Fixes IncompleteRead by reading with chunked fallback + partial recovery.
"""
import json
import os
import subprocess
import time
import urllib.error
import urllib.request
from http.client import IncompleteRead

HERE = os.path.dirname(os.path.abspath(__file__))


def _token() -> str:
    tok = os.environ.get("GITHUB_TOKEN", "").strip()
    if tok:
        return tok
    tok = subprocess.run(
        ["powershell", "-NoProfile", "-Command",
         "[Environment]::GetEnvironmentVariable('GITHUB_TOKEN','User')"],
        capture_output=True, text=True).stdout.strip()
    if not tok:
        raise SystemExit("GITHUB_TOKEN not found in process or user env")
    return tok


TOKEN = _token()
H = {
    "Authorization": "Bearer " + TOKEN,
    "User-Agent": "github-audit/2.0",
    "Accept": "application/vnd.github+json",
    "X-GitHub-Api-Version": "2022-11-28",
}


def get(url, tries=4):
    # NOTE: local proxy truncates responses > ~500KB, so callers must keep
    # per_page small (30) to stay under that ceiling.
    for i in range(tries):
        req = urllib.request.Request(url, headers=H)
        try:
            with urllib.request.urlopen(req, timeout=60) as r:
                raw = b""
                while True:
                    try:
                        chunk = r.read(32768)
                    except IncompleteRead as e:
                        raw += getattr(e, "partial", b"") or b""
                        break
                    if not chunk:
                        break
                    raw += chunk
            return json.loads(raw) if raw else None
        except IncompleteRead as e:
            partial = getattr(e, "partial", b"") or b""
            try:
                return json.loads(partial)
            except Exception:
                time.sleep(2 + i)
                continue
        except urllib.error.HTTPError as e:
            body = ""
            try:
                body = e.read().decode("utf-8", "ignore")[:200]
            except Exception:
                pass
            if e.code in (403, 429):
                time.sleep(8 * (i + 1))
                continue
            print(f"HTTP {e.code} {url} {body}")
            return {"__error": e.code}
        except Exception as e:
            print(f"ERR {e.__class__.__name__}: {e} {url}")
            time.sleep(3)
    return None


def paged(url, per=25, cap=1000):
    out, page = [], 1
    while len(out) < cap:
        sep = "&" if "?" in url else "?"
        chunk = get(f"{url}{sep}per_page={per}&page={page}")
        if not isinstance(chunk, list) or not chunk:
            break
        out.extend(chunk)
        if len(chunk) < per:
            break
        page += 1
    return out


def main():
    me = get("https://api.github.com/user") or {}
    login = me.get("login")
    data = {
        "fetched_at": time.strftime("%Y-%m-%dT%H:%M:%S%z"),
        "user": me,
        "rate_limit": get("https://api.github.com/rate_limit"),
        "repos": paged("https://api.github.com/user/repos?affiliation=owner&sort=pushed"),
        "starred": paged("https://api.github.com/user/starred", cap=300),
        "orgs": get("https://api.github.com/user/orgs"),
        "events": paged(f"https://api.github.com/users/{login}/events/public", cap=300),
    }
    if isinstance(data["repos"], list):
        data["repo_languages"] = {}
        active = [r for r in data["repos"]
                  if not r.get("fork") and not r.get("archived")]
        active.sort(key=lambda r: r.get("pushed_at") or "", reverse=True)
        for r in active[:25]:
            langs = get(r["languages_url"])
            if isinstance(langs, dict) and "__error" not in langs:
                data["repo_languages"][r["full_name"]] = langs
            contrib = get(r["contributors_url"] + "?per_page=1&anon=1")
            if isinstance(contrib, list):
                data.setdefault("repo_contributors", {})[r["full_name"]] = len(contrib)
    with open(os.path.join(HERE, "raw.json"), "w", encoding="utf-8") as f:
        json.dump(data, f, ensure_ascii=False, indent=1)

    repos = data["repos"] if isinstance(data["repos"], list) else []
    rl = (data.get("rate_limit") or {}).get("rate", {})
    print("login:", login)
    print("repos:", len(repos), "| starred:", len(data["starred"] or []),
          "| events:", len(data["events"] or []), "| orgs:",
          [o.get("login") for o in (data["orgs"] or [])])
    print("rate:", rl.get("remaining"), "/", rl.get("limit"))


if __name__ == "__main__":
    main()
