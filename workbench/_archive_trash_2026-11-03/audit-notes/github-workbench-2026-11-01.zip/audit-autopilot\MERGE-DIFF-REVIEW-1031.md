# 起步 10 个 · diff 逐个读（2026-10-31 00:40）

目的：在"点 Merge"之前，先判断**改动是否符合它自己声称的事**。这不是 CI，也不是代码审查，
只做三件能静态确认的事：

1. 改的文件是否可编译（`ast.parse`）；
2. 依赖的名字是否真的存在（import / dataclass 字段）；
3. 改动是否与标题描述一致，以及有什么**行为风险**（CI 抓不到的那种）。

> 方法说明：9 个 Python 文件全部用 `ast.parse` 解析通过；`#2606` 的 `LDAPException` 已确认
> 在 `from ldap3.core.exceptions import LDAPException` 里；`#35` 的 `llm` / `extraction`
> 已确认是 `MemoryRuntimeConfig` 的 dataclass 字段。

## 结论表

| # | PR | 与标题一致 | 静态验证 | 判断 |
|---|---|---|---|---|
| 1 | `Octop #2369` | ✅ 文档改路径 | — | **可直接合** |
| 2 | `Octop #2494` | ✅ 单文件搜索不再扫兄弟文件 | 语法 OK | **可直接合** |
| 3 | `Octop #2484` | ✅ active-turn 泄漏加 TTL 清理 | 语法 OK | **有行为风险**（见下） |
| 4 | `octop-harness #129` | ✅ 修 `lstrip("./")` 字符集 bug | 语法 OK | **可直接合**，修得漂亮 |
| 5 | `octop-harness #127` | ✅ `UnicodeDecodeError` 不属 `OSError` | 语法 OK | **可直接合** |
| 6 | `octop-harness #124` | ✅ 不再改系统提示词文本 | 语法 OK | **依赖下游重建**（见下） |
| 7 | `octop-memory #36` | ✅ 把 episode 加入默认召回源 | 语法 OK | 可合，依赖 gather 已支持 |
| 8 | `octop-memory #35` | ✅ 透传 llm / extraction 配置 | 字段已确认存在 | **可直接合** |
| 9 | `octop-memory #33` | ✅ 审计游标在"不确定"时也前进 | 语法 OK | **语义变了**（见下） |
| 10 | `Octop #2606` | ✅ `suppress(Exception)` → `LDAPException` | 异常类已 import | **可直接合** |

## 三个需要你判断的

### `#2484` ws_hub 的 30 秒 TTL

改动把 `_active_turns` 从 set 变成 `dict[thread_id, monotonic]`，并在 `is_turn_active()` 里
先调 `evict_stale_turns(max_quiet_seconds=30)`。修复的是"任务被取消后 `mark_turn_idle` 永远不执行，
前端一直显示 turn_active"。

风险：**阈值 30 秒是猜的**。如果一次真实 turn 中间有超过 30 秒不推帧（长模型调用、工具等待），
它会被判成孤儿，前端提前显示"已完成"。建议合之前确认三点：`push_to_thread` 是不是每帧都调、
有没有别的长静默路径、30 秒是否与前端轮询间隔冲突。

### `#124` 不再改系统提示词

改动的说法是"下游渲染器会从 `request.state["skills_metadata"]` 重建 'Available Skills:' 段落"。
这句话**我无法静态验证**——要确认 `_STABLE_SKILLS_*` / `_rewrite_skill_content` 之外，
确实存在一个按 state 重建的渲染路径，否则技能段落会消失（比提示词抖动严重得多）。

### `#33` 审计游标语义

原逻辑：遇到 `match is None` / `uncertain` / 已废弃 / 断言变化 → `continue`，**不记录已检查**。
新逻辑：先 `checked[atom.id] = hashes[atom.id]`，再 `continue`。

这正是标题要的（"不确定也前进，避免永远重审"），但代价是：**这次不成功的匹配不会被重试**。
如果上游匹配器只是临时失败，文档就再也不会被复核一次。合之前值得确认这是产品意图。

## 可以直接合的 6 个

`#2369`、`#2494`、`#129`、`#127`、`#35`、`#2606`。

其中三个是"一行级"修复，误合成本几乎为零：

| PR | 改动 |
|---|---|
| `#2606` | `suppress(Exception)` → `suppress(LDAPException)`，异常类已 import |
| `#127` | `except (OSError, UnicodeDecodeError)` |
| `#2369` | 文档里 `<OCTOP_HOME>/octop-login.txt` 路径 |

## 一个自我更正

我第一遍读 `#33` 的 patch 时，看到的是：

```python
if match is None or ... or current.assertion != atom
    continue
```

**没有冒号、`atom` 后面缺 `.assertion`** —— 看起来是 SyntaxError，我差点把它写成"不能合"。
实际取回文件 `ast.parse` 后发现完全正确：`current.assertion != atom.assertion:`。

原因是我自己打印 patch 时按 140 字符截断，把行尾切掉了。
**结论：读 diff 的截断显示会伪造语法错误，判断可编译性必须看完整文件。**

## 边界

- 这不是 CI。上面 9 个文件只做了语法解析，没有导入执行、没有跑测试。
- 这也不是代码审查：我只判断"改动是否做了标题说的事、依赖是否存在"，
  没有评估设计是否合理、性能是否可接受。
- 仓库的 CI 只有 `GITHUB_OPENSOURCE_SCAN_PIPELINE`，**不跑测试**——所以合进去等于直接进 main。


---

## 追加（00:50）：`#2484` 已按方案 B 改掉

阈值 `30.0 → 900.0`，docstring 补了依据（为什么不能更短、什么时候才能收紧）。
commit `244979a8b8`，push 到 `TrueFurina/Octop:fix/turn-active-flag-leak-2456`。

核验：`ast.parse` 通过；PR head 更新为 `244979a8`，`+60/−4`，`mergeable=true`（clean）。

改后它进入"可直接合"：修的是真问题（`finally` 不执行导致 active 泄漏），
只是不再用 30 秒去赌工具耗时。
