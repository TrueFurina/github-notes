"""第 2 周改动定义：5 个零文档仓的 README、Denia 首个 CI、缺失的 description / topics。

内容全部基于实际目录树与 README 现有信息撰写，没有编造功能。
"""

# ---------------------------------------------------------------- README 补全
README_NEW = {}

README_NEW["workspace"] = """# workspace

> 工作区暂存仓（**非稳定交付物**）。用于在多个项目之间搬运草稿、看板与配置，内容会随工作流变动。

## 里面有什么

- `guochuang2026_deliverables/` —— 国创 2026 项目的交付与过程材料：12 天冲刺总控看板、M1 启动包与详细操作 SOP、真机验证 SOP、Precision 补测方案、R9 补捞验证记录
- `guochuang2026_deliverables/platform_config/` —— 平台多智能体配置：`agents_md/` 下的 orchestrator、literature、experiment、evaluation、writing 等角色定义，以及 `agents_official.json`
- `HEA_data_clean.csv` 等 —— 该项目的清洗后数据与图表素材

## 与主仓的关系

本仓只做暂存与转运，**不是任何项目的正式入口**。国创 2026 的说明入口见 `guochuang2026_deliverables/README.md`。

## 使用与引用

内容随时可能被清理或改写，请勿直接依赖本仓路径；需要引用时以 `guochuang2026_deliverables/` 内的说明文件为准。

## License

见 [LICENSE](LICENSE)。
"""

README_NEW["SecAutoMind"] = """# SecAutoMind · 官网单页

> 本仓只存放 SecAutoMind 的产品官网（`index.html` + `robots.txt`），**不含源码**。

| | |
|---|---|
| 源码 | [TrueFurina/SecAutoMind-src](https://github.com/TrueFurina/SecAutoMind-src) |
| 下载 | [SecAutoMind-src Releases](https://github.com/TrueFurina/SecAutoMind-src/releases) |
| 定位 | 面向**授权场景**的自主多智能体安全验证平台（赛事题号 XH-202609）：确定性工具优先，LLM 只在静态分析未命中时介入，敏感动作需人工审批 |

## 为什么单独一个仓

官网要独立部署到 GitHub Pages，与 88MB 的源码仓解耦——改一行首页文案不应该触发一次全量拉取。

## 维护约定

产品能力的任何更新只改 `SecAutoMind-src`；本仓仅同步首页文案、下载链接与 robots 策略。
"""

README_NEW["marl-ecdsa-competition-materials"] = """# marl-ecdsa · 竞赛材料归档

> MARL-ECDSA（面向协作多智能体强化学习的可信共识与激励机制）的**参赛材料仓**。
> 代码在 [marl-ecdsa](https://github.com/TrueFurina/marl-ecdsa)，本仓只放申报书、设计报告与答辩材料。

## 目录

| 目录 | 内容 |
|---|---|
| `01-application/` | 竞赛申报书 |
| `02-design-report/` | 设计报告：学术创新深度论证、BC-MARL 收敛性理论分析、形式化安全模型（STRIDE）、共识机制横向对比 |
| `03-innovation-whitepaper/` | 技术创新白皮书（CW-PBFT 与 Nash 均衡证明） |
| `04-defense-ppt/` | 决赛 PPT 框架与 15 分钟路演逐页讲稿 |
| `05-qa-bank/` | 答辩问答知识库、决赛"最狠 10 问"成文防线 |
| `06-test-report/` | 全维度测试与安全攻防报告 |
| `SUBMIT_*` / `FINAL_*` | 提交清单、打包规范、复现说明书与赛后拓展路线 |

## 与代码仓的关系

- 理论推导与实验数据以 [marl-ecdsa](https://github.com/TrueFurina/marl-ecdsa) 为准；
- 本仓文档里的数字若与代码仓不一致，以代码仓最后一次跑批结果为准。

## 说明

本仓为私有归档，含竞赛申报材料，请勿外传或转公开。
"""

README_NEW["MangDeHenZhi-materials"] = """# 芒得很职 · 创赛材料仓

> **⚠️ 本仓含学生个人信息（`06-学生信息/`：姓名、学号、分班、宿舍安排），仅限团队成员访问。**
> 禁止转为公开仓库、禁止 fork 到个人账号、禁止把该目录内容贴进任何公开文档或截图。

## 目录

| 目录 | 内容 |
|---|---|
| `00-项目总览.md` | 项目一句话定位与阅读顺序 |
| `01-商业计划书/` | BP 正文、图表生成与排版校验脚本 |
| `02-平台文档/` | 平台侧执行包（前测、SOP）与 BP 截图 |
| `03-过程档案/` | 过程记录与版本存档 |
| `04-图表素材/` | 配图源文件 |
| `05-软著材料/` | 软件著作权申报材料 |
| `06-学生信息/` | **敏感**：学生名单、分班、宿舍安排 |
| `07-OPC协作/` | 协作任务记录 |
| `08-论文研究/` `09-战略分析/` `10-技术方案与集成/` | 研究与方案材料 |

## 与主仓的关系

平台代码与可运行产物在 [MangDeHenZhi](https://github.com/TrueFurina/MangDeHenZhi)；本仓只放材料，不参与构建。

## 数据处置建议

`06-学生信息/` 属于《个人信息保护法》口径下的敏感个人信息。建议逐步迁出到本地加密存储，仓库内只保留字段说明与脱敏样例；如需保留，请把协作者收敛到最小集合，并定期核对没有外泄的 fork。
"""

README_NEW["xihu-ctf-deliverables"] = """# 西湖论剑 · CTF 参赛过程档案

> 第九届西湖论剑 AI CTF 赛道的**过程与交付档案**（私有）。能力主体已并入
> [SecAutoMind](https://github.com/TrueFurina/SecAutoMind-src)，本仓用于复盘留痕。

## 目录

| 路径 | 内容 |
|---|---|
| `_INDEX.md` | 全仓索引与阅读顺序 |
| `deliverables/` | 交付物 |
| `协同任务总账-TOP0.md` | 任务分派与完成情况 |
| `整改核查结论-20260822.md` / `第五轮修复作战计划-20260822.md` | 赛后整改与修复计划 |
| `.workbuddy/` | 本地 AI 协作记忆的过程快照（含 `backup_docorg/` 的历史文档） |

## ⚠️ 入库注意事项

`.workbuddy/` 是工具产生的本地记忆目录，**默认不应入库**——它可能夹带本机路径、会话内容与配置片段。
若后续还要往本仓提交，请先确认：

1. `.gitignore` 里已忽略 `.workbuddy/`；
2. 目录内没有密钥、Token、内网地址；
3. 需要留档的内容改为手工摘录到 `deliverables/`。

## 关系

- 能力与代码：[SecAutoMind-src](https://github.com/TrueFurina/SecAutoMind-src)
- 赛事结论与口径以 [xihu-sword-ctf-agent](https://github.com/TrueFurina/xihu-sword-ctf-agent) 的 README 为准
"""

# ---------------------------------------------------------------- Denia CI
DENIA_CI_PATH = ".github/workflows/ci.yml"
DENIA_CI = """name: ci

on:
  push:
    branches: [master]
  pull_request:
  workflow_dispatch:

permissions:
  contents: read

concurrency:
  group: ci-${{ github.ref }}
  cancel-in-progress: true

jobs:
  syntax:
    name: syntax gate
    runs-on: windows-latest
    steps:
      - uses: actions/checkout@v4
      - uses: actions/setup-python@v5
        with:
          python-version: "3.12"
      - name: byte-compile (hard gate)
        run: python -m compileall -q src main.py tools
      - name: validate requirements syntax (advisory)
        continue-on-error: true
        run: python tools/check_requirements.py

  unit:
    name: unit tests (observe mode)
    needs: syntax
    runs-on: windows-latest
    # 观察模式：仓库此前零 CI，先让它跑起来看真实失败面。
    # 连续 3 次全绿后，把下面这行删掉，让它成为真正的门禁。
    continue-on-error: true
    steps:
      - uses: actions/checkout@v4
      - uses: actions/setup-python@v5
        with:
          python-version: "3.12"
      - name: install test deps
        # 刻意不装 PyAudio / sounddevice / pywebview：CI 无音频与桌面会话，
        # 装它们只会让安装阶段先失败。依赖它们的用例在观察模式下失败是预期内的。
        run: |
          python -m pip install --upgrade pip
          python -m pip install pytest pyyaml httpx numpy requests psutil rich
      - name: pytest
        run: python -m pytest src/tests -q -p no:cacheprovider --maxfail=15
"""

# ---------------------------------------------------------------- 元数据
DESCRIPTIONS = {
    "marl-ecdsa-competition-materials":
        "MARL-ECDSA 竞赛材料归档：申报书、设计报告、创新白皮书、答辩 PPT 与测试报告（代码见 marl-ecdsa）",
    "xihu-ctf-deliverables":
        "第九届西湖论剑 AI CTF 参赛过程与交付档案（能力已并入 SecAutoMind）",
}

TOPICS = {
    "Denia": ["ai-companion", "desktop-app", "local-first", "python", "privacy", "llm"],
    "marl-ecdsa-competition-materials":
        ["marl", "blockchain", "ecdsa", "competition", "research-materials"],
    "MangDeHenZhi-materials":
        ["competition", "business-plan", "education-platform", "materials"],
    "2026-crypto-math-challenge":
        ["cryptography", "ecdsa", "lattice", "sis", "competition-archive"],
    "xihu-ctf-deliverables":
        ["ctf", "ai-agent", "competition-archive", "writeup"],
}
# desktop-tutorial 不加 topics：它是 GitHub Desktop 模板空仓，建议归档而非美化
TOPICS_SKIP = {"desktop-tutorial"}


# ---------------------------------------------------------------- W5 Denia 收集隔离
# CI 首次运行发现：src/tests/test_doctor_asr.py 在 import 阶段执行自检并 sys.exit(1)，
# 导致 pytest 以 INTERNALERROR 中断整个收集，55 个用例一个都没跑到。
DENIA_CONFTEST_PATH = "src/tests/conftest.py"
DENIA_CONFTEST = '''"""pytest 收集策略。

`src/tests/` 下混着两类文件：

1. **pytest 用例** —— 定义 `def test_*()`，由 pytest 收集执行；
2. **独立自检脚本** —— import 阶段就跑完整检查、失败时 `sys.exit(1)`。
   典型是 `test_doctor_asr.py`（7 段自检，末尾汇总"共 N 处不符"后退出）。

第 2 类一旦被 pytest 收集，会在 import 阶段抛出 `SystemExit`，pytest 无法把它
当成普通失败，只能以 `INTERNALERROR` 中断整个会话——结果是所有正常用例都跑不到。
（2026-10-28 首次接入 CI 时实测到的就是这个。）

所以这里显式排除它们。排除不影响单独执行：

    python src/tests/test_doctor_asr.py

如果要把它改造成真正的 pytest 用例，做法是把自检体包进 `def test_doctor_asr():`
并把 `sys.exit(1)` 换成 `assert` / `pytest.fail`，然后从下面的列表里删掉。
"""

collect_ignore = [
    "test_doctor_asr.py",
    "_dlg_voice_harness.py",
]
'''
