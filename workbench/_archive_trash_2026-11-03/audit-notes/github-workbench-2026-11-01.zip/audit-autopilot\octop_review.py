"""Octop 三仓 open PR 队列体检（只读）。

背景：这三个仓里本人的 open PR 已到 170+，且仍在以约 50–90 个/小时的速度增长
（2026-10-30 实测）。队列的问题不是"能不能合"，而是**维护者的收件箱**。

这个脚本只做一件事：把队列摊平成一张能一眼分类的表，并给出"哪些该先合、哪些在互相打架、
哪些维护者根本没看过"。**不关闭、不评论、不推送**。

用法：
    python autopilot/octop_review.py            # 输出到 autopilot/OCTOP-QUEUE-REVIEW-<MMDD>.md
"""
from __future__ import annotations

import json
import os
import sys
import time
from collections import Counter
from datetime import datetime

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, os.path.dirname(HERE))

from ghlib import api, api_all, OWNER  # noqa: E402

TRIO = ["TencentCloud/Octop", "TencentCloud/octop-harness", "TencentCloud/octop-memory"]
OUT = os.environ.get("AUTOPILOT_OUT") or os.path.join(
    HERE, f"OCTOP-QUEUE-REVIEW-{datetime.now():%m%d}.md")
# 允许换一个空缓存强制全量重取：队列刚发生过大批关闭（2026-10-31），
# 旧条目的 mergeable 可能已经过期，不重取就违反"现状必须来自本轮"。
CACHE = os.environ.get("AUTOPILOT_CACHE") or os.path.join(HERE, "octop_details.json")


def paged(path: str, pages: int = 16, per: int = 20) -> list[dict]:
    """并发拉前 `pages` 页并合并（按 number 去重）。

    为什么并发：这台机器经代理访问 API，单次约 1.2–1.6s；顺序拉 250 条要十几分钟，
    并发 8 路后同一批只要一两分钟。单页失败只影响那一页，不拖垮整体——
    顺序版一旦某页反复失败就会整轮空转（实测跑了 12 分钟还停在列表阶段）。
    """
    from concurrent.futures import ThreadPoolExecutor

    def one(page: int):
        try:
            chunk = api(f"{path}&per_page={per}&page={page}" if "?" in path
                       else f"{path}?per_page={per}&page={page}")
            return chunk if isinstance(chunk, list) else []
        except Exception:  # noqa: BLE001
            try:
                chunk = api(f"{path}&per_page=10&page={page}" if "?" in path
                            else f"{path}?per_page=10&page={page}")
                return chunk if isinstance(chunk, list) else []
            except Exception:  # noqa: BLE001
                return []

    out: dict[int, dict] = {}
    with ThreadPoolExecutor(max_workers=8) as ex:
        for chunk in ex.map(one, range(1, pages + 1)):
            for p in chunk:
                out[p["number"]] = p
    return list(out.values())


def days(s: str) -> int:
    try:
        return (datetime.now() - datetime.strptime(s[:10], "%Y-%m-%d")).days
    except Exception:  # noqa: BLE001
        return -1


def main() -> int:
    rows = []
    for repo in TRIO:
        prs = paged(f"/repos/{repo}/pulls?state=open", pages=16)
        mine = [p for p in prs if (p.get("user") or {}).get("login") == OWNER]
        print(f"{repo:32} open={len(prs):>4} 本人={len(mine)}")
        for p in mine:
            rows.append({"repo": repo, "num": p["number"], "title": p["title"],
                         "created": p["created_at"][:10], "updated": p["updated_at"][:10],
                         "draft": bool(p.get("draft"))})
    print(f"合计 {len(rows)} 个，逐个取详情…")

    cache = {}
    if os.path.exists(CACHE):
        try:
            cache = json.load(open(CACHE, encoding="utf-8"))
        except Exception:  # noqa: BLE001
            cache = {}
    print(f"缓存命中 {len(cache)} 条")

    def save_cache():
        try:
            json.dump(cache, open(CACHE, "w", encoding="utf-8"), ensure_ascii=False)
        except Exception as e:  # noqa: BLE001
            print(f"  [WARN] 写缓存失败: {e}")

    from concurrent.futures import ThreadPoolExecutor

    def fetch(r):
        key = f"{r['repo']}#{r['num']}"
        # 缓存条目必须带 mergeable 才算有效：早期版本没存这个字段，
        # 直接复用会让"无冲突"分组变成 0（实测：221 个只认出 3 个）。
        c = cache.get(key)
        if c is not None and c.get("mergeable") is not None:
            return r, None
        d = api(f"/repos/{r['repo']}/pulls/{r['num']}")
        return r, (d if isinstance(d, dict) and "__error" not in d else None)

    with ThreadPoolExecutor(max_workers=8) as ex:
        pairs = list(ex.map(fetch, rows))

    for r, d in pairs:
        key = f"{r['repo']}#{r['num']}"
        if d is None:
            if key in cache:
                r.update(cache[key])
            else:
                r["state"] = "?"
            continue
        r.update({
            "state": d.get("mergeable_state") or "?",
            "mergeable": d.get("mergeable"),
            "add": d.get("additions") or 0,
            "del": d.get("deletions") or 0,
            "files": d.get("changed_files") or 0,
            "commits": d.get("commits") or 0,
            "comments": d.get("comments") or 0,
            "age": days(d.get("created_at", "")),
            "idle": days(d.get("updated_at", "")),
            "head": d["head"]["sha"][:8],
            "branch": d["head"]["ref"][:44],
        })
        cache[key] = {k: r.get(k) for k in ("state", "mergeable", "add", "del", "files",
                                            "commits", "comments", "age", "idle", "head", "branch")}
    save_cache()
    print(f"  详情就绪：{len(rows)} 个（缓存 {len(cache)}）")

    def pick(pred):
        return [r for r in rows if pred(r)]

    # `mergeable_state` 不能直接当结论：这三个仓没有配置任何必需检查，
    # GitHub 在"零个 commit status"时会报 combined status = pending，
    # 于是 mergeable=True 的 PR 也被标成 unstable（2026-10-30 抽样核实）。
    # 所以分类以 mergeable 为准，unstable 单独抽样验证一次，把验证结果写进报告。
    ready = pick(lambda r: r.get("mergeable") is True)
    conflict = pick(lambda r: r.get("mergeable") is False)
    behind = pick(lambda r: r.get("state") == "behind")
    blocked = pick(lambda r: r.get("state") == "blocked")
    unstable = pick(lambda r: r.get("state") == "unstable" and r.get("mergeable") is True)

    # 抽样：抽查 10 个 unstable 的 check-runs，确认"没有失败、只是没有 status"
    sample_ok = sample_n = 0
    for r in unstable[:10]:
        try:
            d = api(f"/repos/{r['repo']}/pulls/{r['num']}")
            cr = api(f"/repos/{r['repo']}/commits/{d['head']['sha']}/check-runs?per_page=10") or {}
            runs = cr.get("check_runs") or []
            bad = [c for c in runs if c.get("conclusion") not in ("success", "skipped", None)]
            st = api(f"/repos/{r['repo']}/commits/{d['head']['sha']}/status") or {}
            sample_n += 1
            if not bad and not (st.get("statuses") or []):
                sample_ok += 1
        except Exception:  # noqa: BLE001
            continue
    drafts = pick(lambda r: r.get("draft"))
    unseen = pick(lambda r: r.get("comments") == 0 and r.get("age", 0) >= 3)

    dist = Counter(r.get("state") for r in rows)
    byrepo = Counter(r["repo"].split("/")[-1] for r in rows)
    oldest = sorted([r for r in rows if r.get("age", 0) >= 0], key=lambda r: -r["age"])[:12]
    newest = sorted([r for r in rows if r.get("age", 0) >= 0], key=lambda r: r["age"])[:12]

    def table(items, limit=40, note=""):
        if not items:
            return "_（无）_\n"
        out = ["| 仓库 | # | 标题 | 规模 | 年龄 | 空闲 | 评论 |", "|---|---:|---|---|---:|---:|---:|"]
        for r in items[:limit]:
            t = (r["title"] or "").replace("|", "\\|")[:62]
            out.append(f"| {r['repo'].split('/')[-1]} | [#{r['num']}](https://github.com/{r['repo']}/pull/{r['num']}) "
                       f"| {t} | +{r.get('add', 0)}/−{r.get('del', 0)} | {r.get('age', '?')}d "
                       f"| {r.get('idle', '?')}d | {r.get('comments', 0)} |")
        if len(items) > limit:
            out.append(f"\n_（共 {len(items)} 个，此处列前 {limit}）_")
        return "\n".join(out) + "\n"

    md = f"""# Octop 三仓 open PR 队列体检

生成时间：{datetime.now():%Y-%m-%d %H:%M} ｜ 数据源：`/repos/{{repo}}/pulls?state=open` 逐个取详情
范围：`TencentCloud/Octop`、`octop-harness`、`octop-memory` 中**本人**提交且仍 open 的 PR

## 一句话

**{len(rows)} 个 open PR 里，{len(ready)} 个 `mergeable=true`（无冲突，技术上是"点一下就能合"），
{len(conflict)} 个有冲突，{len(unseen)} 个开了 ≥3 天零评论（维护者没打开过）。**

## 先说清楚 `mergeable_state=unstable` 是怎么回事

这三个仓 `unstable` 占绝大多数（本报告里 {len(unstable)} 个），但它**不是"检查失败"**：

```
mergeable=true
combined status = pending，但 statuses 数量 = 0
check-runs = GITHUB_OPENSOURCE_SCAN_PIPELINE → completed / success
分支保护 required_status_checks.contexts = []（三仓都是空）
```

GitHub 在"零个 commit status"时把 combined status 报成 `pending`，于是 `mergeable_state`
标成 `unstable`。**换句话说：它表示"没有 CI 在报状态"，不是"CI 挂了"。**

本次抽查了 {sample_n} 个 `unstable` 的 PR：其中 **{sample_ok} 个**确认"无失败检查 + 零 status"，
其余可能是并发抖动或确有失败。样本不大，所以下面按"无冲突"而不是"检查全绿"来分组。

## 分布

| 维度 | 数值 |
|---|---|
| 总计 | **{len(rows)}** |
| `mergeable=true`（无冲突） | **{len(ready)}** |
| `mergeable=false`（有冲突） | {len(conflict)} |
| 其中 `mergeable_state=unstable` | {len(unstable)} |
| `behind` / `blocked` | {len(behind)} / {len(blocked)} |
| 草稿 | {len(drafts)} |
| 零评论且 ≥3 天 | **{len(unseen)}** |

按仓库：{", ".join(f"{k} {v}" for k, v in byrepo.most_common())}

按 `mergeable_state` 原始计数：{dict(dist)}

## A. 无冲突，可合（{len(ready)}）

技术门槛已经没了，缺的只是维护者的一次点击。**优先级最高**——每合一个，队列少一个。

{table(sorted(ready, key=lambda r: r.get("age", 0), reverse=True), 40)}

## B. 有冲突，需要 rebase 或重开（{len(conflict)}）

`mergeable=false` 意味着和 base 打架。要么 rebase，要么关掉重开一个干净的。
**放着不动最糟**：占用名额，且每次 base 前进都更难解。

{table(conflict, 30)}

## C. 零评论且 ≥3 天（{len(unseen)}）

维护者从没打开过。它们不是"被拒绝"，是**没有被看见**。对这批，提高单条质量的收益
远大于再开新的。

{table(unseen, 30)}

## D. 时间轴两端

最老的 12 个：

{table(oldest, 12)}

最新的 12 个（增速参考）：

{table(newest, 12)}

## 建议（只建议，不执行）

1. **先合 A 组的 {len(ready)} 个**（至少先把 A 组里最老的 20 个）。理由：不需要任何人改代码，
   纯粹是"点一下"；合掉之后队列可读性立刻改善。
2. **B 组 {len(conflict)} 个二选一**：能 rebase 的 rebase，改不动的关掉并写一句原因。
3. **C 组 {len(unseen)} 个先别动**：它们的问题是"没被看见"。
4. **停止新增**。当前增速下（约 50–90 个/小时），任何"再提一个更小的 PR"都在稀释前面的努力。

> 本文件是只读体检的产物：没有关闭、没有评论、没有推送。
"""
    open(OUT, "w", encoding="utf-8").write(md)
    print(f"\n写入 {OUT}")
    print(f"{len(rows)} 个 | 无冲突 {len(ready)} · 有冲突 {len(conflict)} · behind {len(behind)} "
          f"· blocked {len(blocked)} · unstable {len(unstable)} · 零评论>=3天 {len(unseen)}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
