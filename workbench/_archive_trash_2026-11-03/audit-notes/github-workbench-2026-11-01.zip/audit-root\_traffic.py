import sys, json, time
sys.path.insert(0, r'D:/github/github-audit')
from ghlib import api

d = json.load(open('raw.json', encoding='utf-8'))
own = [x for x in d['repos'] if not x.get('fork') and not x.get('archived')]
own.sort(key=lambda x: (-x.get('stargazers_count', 0), x.get('pushed_at') or ''))
cands = [x['name'] for x in own[:22]]

out = {}
for n in cands:
    v = api(f'/repos/TrueFurina/{n}/traffic/views')
    c = api(f'/repos/TrueFurina/{n}/traffic/clones')
    rf = api(f'/repos/TrueFurina/{n}/traffic/referrers')
    pp = api(f'/repos/TrueFurina/{n}/traffic/popular/paths')
    out[n] = {
        'views': v if isinstance(v, dict) and '__error' not in v else v,
        'clones': c if isinstance(c, dict) and '__error' not in c else c,
        'referrers': rf if isinstance(rf, list) else rf,
        'paths': pp if isinstance(pp, list) else pp,
    }
    print(n, (v or {}).get('count'), (v or {}).get('uniques'), '| clone', (c or {}).get('count'), (c or {}).get('uniques'), '| ref', (len(rf) if isinstance(rf, list) else rf))
    time.sleep(0.3)

json.dump(out, open('_traffic.json', 'w', encoding='utf-8'), ensure_ascii=False, indent=1)
print('saved', len(out))
