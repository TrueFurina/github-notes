# 23 个 NOASSERTION 仓：许可证决策表

生成时间：2026-10-29 00:40 ｜ 数据源：`/user/repos`（原创、公开、非 fork）

---

## 0. 先纠正一个技术前提

那 23 个仓挂的都是一份 **752 字符的自定义文本**（"Source-Available · All Rights Reserved"），
2026-08-16 批量写入。关键事实：

> **GitHub 只认 SPDX 清单里的许可证。**这段自定义文本不被识别，所以
> `license.spdx_id` 是 `NOASSERTION`——仓库列表、搜索结果、个人页的仓库卡片上
> **不会显示任何许可标识**。

也就是说，"保留所有权利"这个意图**根本没传达出去**。访客看到的不是"禁止使用"，
而是"没说"。对一个想积累影响力的账号，这是纯亏损：既没起到保护作用
（真想抄的人不看 LICENSE），又挡住了正常引用。

**但反过来也不能一刀切改 MIT。** MIT 是**软件许可**，把它套在数据集、术语库、
官网首页、论文稿件上在法理上是错配的——那些是"作品"，不是"程序"。

---

## 1. 五个类别与建议

### A. 排错工具 / 小脚本 → **MIT**（4 个）

这类仓的全部价值在于"别人遇到同样的问题能搜到并直接用"。保留权利让它价值归零。

| 仓库 | 体积 | 是什么 |
|---|---:|---|
| `win-appx-doctor` | 0.01MB | Windows AppX/照片应用诊断修复（PowerShell + CMD） |
| `docker-forensics-toolkit` | 0.01MB | Docker 引擎连环死亡的配套排查脚本 |
| `wsl-docker-recovery` | 0.02MB | WSL/Docker Desktop/浏览器登录恢复脚本 |
| `workbuddy-vivo-fix` | 0.04MB | WorkBuddy 安装卡死 + vivo 驱动修复产物 |

这四个加起来不到 100KB，没有任何商业价值需要保护，但正好是最容易被别人搜到、最容易被 star 的类型。

### B. 论文复现包 → **MIT**（3 个）

审稿人、读者、同行的第一需求就是**能跑**。复现包挂"保留所有权利"，等于自相矛盾。

| 仓库 | 体积 | 是什么 |
|---|---:|---|
| `aerorider-delivery` | 2.7MB | 骑手-无人机协同配送论文第 5–6 章复现代码与数据 |
| `AeroRider` | 0.4MB | MAPPO/CTDE 多智能体 RL 配送调度（含 FFD/BFD/GA/PSO 基线） |
| `marl-ecdsa` | 3.9MB | MARL-ECDSA 共识链，公开项目主页与 Dashboard 分发 |

### C. 应用 / 平台 → **看你想要什么**（9 个）

这一类没有标准答案，取决于"你希望别人拿去改，还是只希望他们看"。

| 仓库 | ★ | 体积 | 判断建议 |
|---|---:|---:|---|
| `MARS-408` | 5 | 108.7MB | **建议 MIT**：全账号星数最高，学术系统，放开才能被引用/复现 |
| `MangDeHenZhi` | 3 | 8.6MB | 建议 MIT：已有完整 CI/CHANGELOG/CONTRIBUTING，工程化最完整的那个 |
| `FDE` | 3 | 0.7MB | 建议 MIT：RAG 客服 copilot，属于可复用架构 |
| `soft-skills-platform` | 3 | 1.2MB | 建议 MIT：前端原型，无核心壁垒 |
| `physics-scheduler-agent` | 3 | 1.8MB | 建议 MIT：排课助手，工具属性强 |
| `SecAutoMind-src` | 0 | 88MB | **建议保留**：旗舰产品，源码可查已足够；要放开等商业化想清楚 |
| `AI-Arena` | 0 | 1.0MB | 建议 MIT：评测台，放开有利于被引用 |
| `MangDeZhiXun` | 0 | 6.8MB | 建议保留：产教工坊源码，与商业产品线重叠 |
| `mcd-meal-optimizer` | 1 | 0.1MB | 见 E 类（赛事） |

### D. 内容 / 数据集 → **CC BY 4.0，不要 MIT**（3 个）

| 仓库 | 体积 | 为什么不能用 MIT |
|---|---:|---|
| `cyber-terms-hub` | 23.3MB | 术语库/资源导航，是**汇编作品**不是程序。MIT 只覆盖"软件"，对词条内容不适用 |
| `workspace` | 3.4MB | 暂存仓（自己声明"非稳定交付物"），本来就不该被引用；保留即可 |
| `sage-paper-public` | 0.2MB | 未发表论文工作区。**建议直接转私有**，而不是换许可证 |

`cyber-terms-hub` 若确实希望被引用，正确做法是 `LICENSE` 放 **CC-BY-4.0** 全文
（API 可直接取，18,654 字符），这样 GitHub 会显示 `CC-BY-4.0` 徽章，从 NOASSERTION 变成可识别。

> 注意：**CC BY-NC（禁商用）变体 GitHub API 不提供**（`/licenses/cc-by-nc-4.0` 返回 404）。
> 要 NC 只能手工放入全文，且 GitHub 大概率仍显示 unknown——等于回到现在这个"没说"的状态。
> 如果核心诉求是禁商用，那"保留权利"其实是对的，只是要在 README 里写清楚，别指望徽章。

### E. 赛事作品 → **先查主办方条款，暂不动**（2 个）

| 仓库 | ★ | 风险 |
|---|---:|---|
| `2025-Challenge-Cup-CyberRange-AI-Arena` | 2 | 挑战杯（安恒赞助）作品，若赛题要求"作品归主办方"，你不能单方 relicense |
| `mcd-meal-optimizer` | 1 | 麦当劳程序员创意开发大赛参赛作品，同上 |

这两个先别动。查一下报名须知里的知识产权条款，30 秒能确认；确认前改许可反而是风险。

### F. 落地页 / 索引 → **别挂"保留所有权利"**（2 个）

| 仓库 | ★ | 为什么 |
|---|---:|---|
| `TrueFurina` | 3 | 个人主页仓库。内容就是给人看的，挂防御性许可观感最差，且拦不住任何东西 |
| `SecAutoMind` | 1 | 官网落地页（Pages 已上线，全账号浏览最高）。同上 |

建议 **CC-BY-4.0** 或 MIT（内容类用 CC 更准确）。这两个仓零商业价值，纯粹是门面。

### G. 已收口归档 → 无所谓（1 个）

`coastal-traffic-visual-analytics`（47.5MB，自述"已收口归档"）。保持现状即可，
真要清理是归档仓库而不是改许可。

---

## 3. 前置核查：这些仓是不是"只有你一个人写的"

改许可的前提是**你有权许可全部代码**。逐个查了贡献者和提交者姓名：

| 仓库 | 关联账号 | 提交者姓名分布 | 判定 |
|---|---|---|---|
| `win-appx-doctor` | TrueFurina | — | 单人 |
| `docker-forensics-toolkit` | TrueFurina | — | 单人 |
| `wsl-docker-recovery` | TrueFurina | — | 单人 |
| `workbuddy-vivo-fix` | TrueFurina | — | 单人 |
| `aerorider-delivery` | TrueFurina | — | 单人 |
| `AeroRider` | TrueFurina | — | 单人 |
| `marl-ecdsa` | TrueFurina | — | 单人 |
| `MARS-408` | TrueFurina 203 + dependabot 1 | 糖露星霜•暖霞拾光 143、Dream 66、TrueFurina 9、C-实验数据 6 | **单人**（多个 git 身份） |
| `cyber-terms-hub` | TrueFurina | — | 单人 |
| `FDE` | TrueFurina | — | 单人 |
| `AI-Arena` | TrueFurina | — | 单人 |
| `MangDeHenZhi` | TrueFurina 229 + **noreply 49** + dependabot 21 | 糖露星霜•暖霞拾光 260、dependabot 21、Dream 12、MangDeHenZhi Project 6 | **单人**，见下 |
| `soft-skills-platform` | TrueFurina 13 + **Jasen2009 6** | TrueFurina 10、**Manus AI 6**、Dream 2 | **待你确认** |

两个看起来像"第三方"的，实际都不是：

- **`MangDeHenZhi` 的 `noreply`（49 次）**：提交者姓名是 `糖露星霜•暖霞拾光`，同一个名字在 `MARS-408` 里出现 143 次，
  且这些提交大量关联到 `TrueFurina` 账号本身。这是**同一个人的另一个 git 身份**
  （另一台机器把 `user.email` 设成了 `noreply@github.com`，GitHub 就归到了一个名叫 `noreply` 的账号下）。
- **`soft-skills-platform` 的 `Jasen2009`（6 次）**：这 6 条提交的署名都是 **`Manus AI`**
  （"Feat: Complete UI/UX overhaul based on reference page"），是 AI 代理生成的提交。
  `Jasen2009` 是真实账号但 0 个公开仓——**需要你确认这是不是你的第二个账号**。
  如果是，那这仓也是单人作品；如果不是，这仓不能单方面改许可。

**结论**：除 `soft-skills-platform` 待确认外，其余全部是单人作品，你有权决定许可。

---

## 4. 汇总：建议动作

| 动作 | 数量 | 仓库 |
|---|---:|---|
| **改 MIT** | 8 | win-appx-doctor、docker-forensics-toolkit、wsl-docker-recovery、workbuddy-vivo-fix、aerorider-delivery、AeroRider、marl-ecdsa、MARS-408 |
| **改 MIT（可选）** | 3 | MangDeHenZhi、FDE、AI-Arena |
| **待确认身份** | 1 | soft-skills-platform（Jasen2009 是不是你） |
| **改 CC-BY-4.0** | 3 | cyber-terms-hub、TrueFurina、SecAutoMind |
| **转私有** | 1 | sage-paper-public |
| **保持不动** | 7 | SecAutoMind-src、MangDeZhiXun、workspace、physics-scheduler-agent、2025-CC-CyberRange、mcd-meal-optimizer、coastal-traffic-visual-analytics |

**如果只做一件事**：把 A、B 两类共 7 个仓改 MIT。它们体积加起来 7MB，
是全账号里"最该被复用却最不该设限"的部分，改动零风险，收益最直接。

---

## 5. 为什么我没有直接执行

前面那些改动（描述、README、`.gitignore`、`sage-paper` 转私有）有一个共同点：**可回退**。
许可证不是。

> **MIT 一旦发出，授予就是不可撤回的。** 你可以把 LICENSE 改回去，但已经下载/克隆过的人
> 按 MIT 获得的复制、修改、分发、商用权利继续有效——它不会因为仓库变心而失效。

这就是它和"改描述""加 gitignore"的本质区别：那两类改错了 `git revert` 就干净了，
这一类改错了只能追认。而 2026-08-16 那次把 24 个仓统一收紧，看起来是**有意为之**，
所以我停在这里，等你一句确认。脚本已就绪、已 dry-run 通过。

---

## 6. 怎么执行


```bash
# 看将要改什么（默认 dry-run）
python apply_license_batch.py tools papers

# 实际写入
python apply_license_batch.py tools papers --yes

# 内容类走 CC-BY-4.0
python apply_license_batch.py content --yes

# 把论文工作区转私有
python apply_license_batch.py private --yes
```

许可全文一律从 `GET /licenses/{key}` 取（MIT 1,069 字符 / CC-BY-4.0 18,654 字符），
不手打，避免法务文本转录错误——和 F1、F2 用的是同一套做法。
版权行沿用各仓 README 里已写明的持有人，不擅自改成个人名。

每组都独立可回退：`git revert <commit>`，或脚本打印的旧 sha 直接 `PATCH` 回去。
