# 第 2 周执行记录 · 2026-10-28 22:41–22:50

## 先说一个必须更正的数字

上午审计说「9 个仓无 description、29 个仓无 topics」。**现在实测：42 个原创仓里 0 个缺 description、1 个缺 topics**（只剩 `desktop-tutorial`）。

原因是这半天里已有别的会话/脚本动过（目录里存在 `fix-topics.ps1`、`fix-license.ps1`、`fix-selfstar.ps1`），
或者审计当时读的是 `/user/repos` 列表接口——该接口在未指定 `application/vnd.github+json` 媒体类型时**不返回 topics 字段**，会把"有 topics"误判成"没有"。

**结论**：这一项不需要再做宣传口径上的补救。本次只补了 5 个私有仓的 topics（私有仓的 topics 对搜索引擎没有价值，只对你自己在仓库列表里辨认有用）。

---

## 已完成

### W1 · 五个零文档仓补 README（全部为新增，未覆盖任何已有文件）

| 仓库 | commit | README 内容要点 |
|---|---|---|
| workspace | [`508c99a`](https://github.com/TrueFurina/workspace/commit/508c99a) | 明确定位为"暂存仓、非稳定交付物"；列出 `guochuang2026_deliverables/` 与 `platform_config/agents_md/` 的作用；声明不要依赖本仓路径 |
| SecAutoMind | [`40f825a`](https://github.com/TrueFurina/SecAutoMind/commit/40f825a) | 声明本仓只是官网单页、不含源码；给出源码仓与 Releases 入口；解释为什么拆仓（Pages 部署 + 88MB 源码解耦） |
| marl-ecdsa-competition-materials | [`f2cc615`](https://github.com/TrueFurina/marl-ecdsa-competition-materials/commit/f2cc615) | 六个目录（申报书/设计报告/白皮书/答辩 PPT/问答库/测试报告）逐项说明；写明"数字以代码仓跑批为准" |
| MangDeHenZhi-materials | [`0c8a827`](https://github.com/TrueFurina/MangDeHenZhi-materials/commit/0c8a827) | 首段就是 **PII 警示**（`06-学生信息/` 含姓名/学号/分班/宿舍，禁转公开、禁 fork 到个人号）；给出迁出建议 |
| xihu-ctf-deliverables | [`918c79c`](https://github.com/TrueFurina/xihu-ctf-deliverables/commit/918c79c) | 说明这是赛后过程档案、能力已并入 SecAutoMind；**单独一节警告 `.workbuddy/` 不应入库**（可能夹带本机路径/会话内容/配置片段） |

### W2 · Denia 首个 CI

`Denia/.github/workflows/ci.yml`（commit [`ea24f3c`](https://github.com/TrueFurina/Denia/commit/ea24f3c)），workflow 已触发：
<https://github.com/TrueFurina/Denia/actions/runs/40709297302>

设计取舍（不是随手抄的模板）：

| 设计 | 原因 |
|---|---|
| `syntax` job 是硬门禁，只跑 `python -m compileall -q src main.py tools` | 确定性 100% 通过，不会让 CI 第一天就红；语法错误挡在 PR 阶段 |
| `unit` job 先设 `continue-on-error: true` | 仓库此前零 CI，55 个用例里有依赖音频/桌面会话的（`test_asr_*`、`test_pet_shell_*`），Windows runner 上必然失败。先观察真实失败面，**连续 3 次全绿后删掉这行**变成真门禁 |
| 只装 `pytest pyyaml httpx numpy requests psutil rich`，**刻意不装** PyAudio / sounddevice / pywebview | CI 无音频设备与桌面会话，装了只会让安装阶段先炸；依赖它们的用例失败是预期内的 |
| `concurrency` + `permissions: contents: read` | 同分支连推时取消旧任务；最小权限 |

### W3 · 补 description（2 个）

- `marl-ecdsa-competition-materials` → 「MARL-ECDSA 竞赛材料归档：申报书、设计报告、创新白皮书、答辩 PPT 与测试报告（代码见 marl-ecdsa）」
- `xihu-ctf-deliverables` → 「第九届西湖论剑 AI CTF 参赛过程与交付档案（能力已并入 SecAutoMind）」

### W4 · 补 topics（5 个私有仓）

Denia 6 个、marl-ecdsa-competition-materials 5 个、MangDeHenZhi-materials 4 个、2026-crypto-math-challenge 5 个、xihu-ctf-deliverables 4 个。
`desktop-tutorial` **刻意不加**——它是 GitHub Desktop 的模板空仓，正确处置是归档（archive）而不是美化。

`apply_week2.py verify` → 13 项全部 `[OK]`。

### W5 · CI 首跑抓到的真 bug（这条比上面所有改动都值钱）

第一次 CI 跑完：`syntax` 通过，`unit` 失败。拉日志（`denia_ci_pytest.log`）后定位到根因——

```
INTERNALERROR>   File "D:\a\Denia\Denia\src\tests\test_doctor_asr.py", line 131, in <module>
INTERNALERROR>     sys.exit(1)
INTERNALERROR> SystemExit: 1
3 errors in 2.81s
```

**`src/tests/test_doctor_asr.py` 不是 pytest 用例，而是一个自检脚本**：import 阶段就执行 7 段检查
（"1) model_path 指向不存在的目录…""7) 配置没加载成功"），发现"共 1 处不符"后直接 `sys.exit(1)`。
pytest 无法把 import 期的 `SystemExit` 当成普通失败，只能 `INTERNALERROR` **中断整个收集**——
**55 个用例一个都没跑到**。

这不是 CI 的问题，是你本地跑 `pytest src/tests` 时也会中的招：只要这个文件在目录里，全部用例都跑不了。

处置（commit [`b211d8e`](https://github.com/TrueFurina/Denia/commit/b211d8e)）：新增 `src/tests/conftest.py`，
用 `collect_ignore` 把它和 `_dlg_voice_harness.py` 排除在收集之外，脚本仍可 `python src/tests/test_doctor_asr.py` 单独跑。
conftest 里写清了"要改造成真用例该怎么做"（把自检体包进 `def test_...()`，`sys.exit(1)` 换成 `assert`）。

顺带一个观察：那个自检脚本自己最后输出的是"**共 1 处不符**"——说明它在本地也是红的，
只是被 `sys.exit(1)` 藏起来了，没有被当成失败信号看见。

### W6 · Denia 打包/发布工作流

`.github/workflows/release.yml`（commit `61ba9ac` → 修编码后 `a75677d`）：
`workflow_dispatch` 或 push `v*` 触发 → `tools/make_dist.py --out dist --no-runtime` 组装 →
zip → upload-artifact；tag 触发时用 runner 自带的 `gh release create` 发布。

两个刻意的选择：

- **复用 `tools/make_dist.py` 而不是自己写打包**。这个脚本本身就在做"白名单组装 + 凭据闸 + 资源完整性闸 + 必需文件清单"，
  它退出码非零就代表"这个包不能发"。把 CI 的发布门禁直接建在它上面，比新写一个 `pyinstaller` 步骤更贴近项目真实口径。
- **不引第三方 action**（`softprops/action-gh-release` 这类），发布步骤直接用 runner 预装的 `gh`，少一个供应链面。

### W6 首跑失败与修复：Windows 控制台编码

第一次跑 `package` job 就挂了：

```
UnicodeEncodeError: 'charmap' codec can't encode characters in position 0-3
##[error]Process completed with exit code 1.
```

Windows runner 默认控制台编码不是 UTF-8，`make_dist.py` 打印中文（"凭据/隐私闸""必需文件清单核对"）时直接抛异常。
修复：两个工作流都在顶层加 `PYTHONUTF8: "1"` 与 `PYTHONIOENCODING: "utf-8"`。
这类问题本地永远复现不出来，只有真跑 CI 才会暴露——也说明"补 CI"这件事本身必须先跑通一次。

### W7 · CI 第二版：把"测试"这个词拆开

顺着日志继续挖，发现 `src/tests/` 的 41 个 `.py` 里**只有 5 个含 `def test_`**：

```
真 pytest 用例（5）：test_queue_util / test_rpc_server / test_typing_duplex_pause
                     test_win_shell / test_ws_port_bind
脚本式自检（36）：   test_doctor_*.py、test_config_*.py、test_io_safe.py、test_secret_box.py …
```

36 个是"模块级顺序执行 + 打印 OK/FAIL + 末尾 `sys.exit(1)`"的自检脚本，
它们跟 pytest 的契约根本不同，混在一起的结果就是**收集阶段就中断**。

第二版 CI（commit `9b5f02a`）拆成三条腿：

| job | 做什么 | 门禁强度 |
|---|---|---|
| `syntax` | `compileall` + `check_requirements.py` | 硬门禁 |
| `unit` | 只跑那 5 个真用例 | 硬门禁（现在敢硬了，因为收集不再被脚本炸掉） |
| `self-check` | 逐个执行 12 个不依赖音频/桌面的自检脚本，**按脚本粒度** `::error file=...` 报错 | 观察模式 |

conftest 也换成**按内容判断**而不是手工维护名单：

```python
collect_ignore = sorted(
    p.name for p in _HERE.glob("*.py") if "def test_" not in p.read_text(...)
)
```

以后新增脚本式自检会自动被排除，新增真用例会自动被收集——不用再维护白名单。

---

## 刻意没做的三件

| 项 | 为什么不做 |
|---|---|
| **MARS-408 减重（108.7MB → 40MB）** | 要把 `deliverables/`、根目录 4 张架构图移出并改写 git 历史。历史改写会影响所有 clone 过的人，且与你"绝不删除"的规矩冲突。**需要你明确签字**，我可以出"只移动不删除 + 打 LFS 标记"的温和方案先试 |
| **Denia 发首个 Release** | README「路线 A · 用安装包」缺的是**安装包本身**，不是 Release 外壳。CI 目前只跑测试、不产 artifact。建议下一步给 CI 加 `build` job 产出 zip，绿了再发 `v0.2.0`，否则发了也是空壳 |
| **desktop-tutorial 补 topics** | 建议归档。归档是设置项，不删任何东西 |

---

## 下一轮建议（按投入产出排序）

1. **Denia CI 加 build job + 发 v0.2.0**：让 README 的"路线 A"成立（当前 0 Release 是文档与产品最大的不一致）。
2. **SecAutoMind 三合一**：`SecAutoMind-src` 改名 `secautomind` 作为唯一主入口，官网仓 README 已指向它（今天做的 W1 就是为这一步铺路）。
3. **profile 仓库重写**：删 426 条 pull-shark 打卡 → 换成 5 行 "Selected upstream contributions"（含 Manishearth 的 APPROVED 原文）。
4. **MARS-408 温和减重**：只移素材、不改历史（`.gitattributes` 加 LFS + 新素材进 Release），风险最低。
5. **停批量 PR + 清 58 个 open PR**：这条不需要写代码，但收益最大。

---

## 最终状态（22:50–23:20 全部跑完）

| 产物 | 结果 |
|---|---|
| **Denia Release** | [`v0.2.0`](https://github.com/TrueFurina/Denia/releases/tag/v0.2.0)，资产 `denia-srcpkg-v0.2.0.zip` **16.78MB** |
| **CI（ci.yml）** | 三条腿全绿：`syntax gate` OK / `self-check scripts` OK **22 个跑 22 个过** / `pytest` OK |
| **release.yml** | `make_dist` 三道闸通过 + 自动发布，端到端跑通 |

### CI 迭代四版才绿，过程本身就是结论

| 版本 | 结果 | 被什么打回 |
|---|---|---|
| v1（合并成一个 unit job） | unit 失败 | `test_doctor_asr.py` import 期 `sys.exit(1)` → `INTERNALERROR`，55 个文件 0 个用例执行 |
| v2（conftest 列名单 + 拆 job） | pytest 失败 | 换个文件继续炸：`test_doctor_voice_backend.py` 同款 |
| v3（按内容排除 + 补依赖） | 16 passed / 4 errors | `test_rpc_server.py` 的 `test_parity(api, info: dict)` 要 fixture `info` —— 它们不是用例，是 `main()` 调用的辅助函数 |
| v4（脚本优先 + 假绿修复） | **全绿** | 自己发现的假绿：`Write-Host ::error` 只打注释不设退出码，job 仍是绿的 → 补 `exit 1`；`test_phash.py` 依赖刻意不装的 imagehash → 加入跳过清单 |

三个结论值得记住：

1. **"有 41 个测试文件"和"有 41 个测试"是两件事**。真正自包含的 pytest 模块只有 1 个，22 个脚本才是这个仓库真实回归面。
2. **收集阶段的失败会伪装成"没有测试"**。`INTERNALERROR` + `0 passed` 看起来像"没什么可跑"，实际是全部用例被一个 `sys.exit` 挡在门外。
3. **annotation 不等于失败**。写 `::error` 只是给 PR 加红点，不加 `exit 1` 就是假绿——这种"看起来有门禁"的 CI 比没 CI 更危险。
