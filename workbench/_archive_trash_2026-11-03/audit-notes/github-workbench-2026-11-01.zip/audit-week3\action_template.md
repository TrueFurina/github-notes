# 43 个 open PR：谁在等谁

生成时间：2026-10-28 23:33 ｜ 逐个 `GET /pulls/{num}` 拉 `mergeable_state` + 评论者

## 一句话

**43 个里只有 4 个真的卡在你这边**（3 个冲突 + 1 个落后），6 个已经全绿只差一次点击，
其余 33 个在等维护者——而你唯一能做的是**别去催**。

| mergeable_state | 数量 | 含义 |
|---|---:|---|
| `clean` | 6 | 可直接合，等维护者点击 |
| `blocked` | 16 | 等 review / 缺 label |
| `unstable` | 15 | 检查未过或未完成 |
| `dirty` | 3 | **有冲突，需要你解** |
| `behind` | 1 | 落后于 base，可 rebase |
| `unknown` | 2 | 状态未计算 |

评论分布：**18 个 PR 一条评论都没有**，说明维护者从没打开过；21 个最后一条是你自己发的。

---

## 一、卡在你这边（4 个，唯一需要动手的）

{TD}

{TB}

处置建议：

- `unstructured #4462`（+932/−903）与 `#4464`：两个都已 `dirty`。`#4462` 的 diff 规模说明分支严重落后，
  正确做法是**从最新 master 重做一遍**只保留 `clean_newline` 那部分，而不是继续解冲突；
  `#4464` 只有 +12/−3，解冲突成本低，值得做。
- `opendatahub-io/notebooks #4461`：8 条评论、`dirty`，这条有人在等，优先解。
- `CTFd #3103`：`behind` 但不是冲突，GitHub 能直接合；`daanbreur` 是最后一个说话的人，
  说明维护者在跟。**不要 rebase 也不要 ping**，等就是最优解。

---

## 二、只差一次点击（6 个 clean）

{TC}

这 6 个是资产：`fail2ban #4219` 已经全绿（维护者的 find&replace 质疑你已逐条答完）、
`marketcalls/openalgo #1920` 是安全类修复、两个 awesome 清单收录（`m-fyi`、`ProjectRecon`）价值在曝光。

`TrueFurina/rich#1` 例外：它是对自己 fork 提的 PR，46 天没推上游。**这个由你自己决定**——
要么 rebase 后提到 `Textualize/rich`（你已有 #4214 的讨论基础），要么关掉。

---

## 三、等维护者（33 个，别动）

{TBL}

{TUN}

{TUK}

`unstable` 要分两种情况：`kubeflow/testing #1072` 是刚推的新 commit 在排队（正常）；
其余长期 unstable 多半是 CI 环境问题而非代码问题——这种去修 CI 不如重开一个干净的 PR。

---

## 今天真正该做的三件事

1. **解 `opendatahub-io/notebooks #4461` 的冲突** —— 8 条评论，有人在等，是唯一"有人在等你"的 dirty。
2. **重做 `unstructured #4462`** —— 别解 932 行的冲突，从 master 重开一个只含 `clean_newline` 的 PR。
3. **`TrueFurina/rich#1` 二选一** —— 推上游或关掉，别让它再躺着。

其余 40 个，**最有效的动作是什么都不做**。你已经清掉 20 个噪音，剩下的多数是真在等对方。
