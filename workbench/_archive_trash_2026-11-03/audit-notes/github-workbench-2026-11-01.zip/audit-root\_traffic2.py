import sys, json, time
sys.path.insert(0, r'D:/github/github-audit')
from ghlib import api
t = json.load(open('_traffic.json', encoding='utf-8'))
for n in ['MARS-408','MangDeHenZhi','xihu-sword-ctf-agent','2026-Challenge-Cup-Security-LLM-Triage-Agent','SecAutoMind','physics-scheduler-agent']:
    print('==', n)
    print(' views daily:', [(x['timestamp'][5:10], x['count'], x['uniques']) for x in (t[n]['views'] or {}).get('views',[])])
    print(' clone daily:', [(x['timestamp'][5:10], x['count'], x['uniques']) for x in (t[n]['clones'] or {}).get('clones',[])])
print('--- referrers retry')
for n in ['MARS-408','passive-recon','SecAutoMind']:
    print(n, api(f'/repos/TrueFurina/{n}/traffic/referrers'), api(f'/repos/TrueFurina/{n}/traffic/popular/paths'))
