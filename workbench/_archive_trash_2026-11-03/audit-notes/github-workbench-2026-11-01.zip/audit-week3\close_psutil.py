"""关闭 psutil 两条重复 PR，并各附一条说明。默认 dry-run。"""
import argparse
import json
import sys
import urllib.request

sys.path.insert(0, r"D:/github/github-audit")
from ghlib import api, HEADERS  # noqa: E402

TARGETS = {
    2989: (
        "Closing this in favour of #2985, as I said back in September: #2985 already carries "
        "the same `ENOTTY` handling in `psutil/arch/linux/net.c`, so this one is a duplicate "
        "rather than an independent fix.\n\n"
        "Sorry for leaving it open in the meantime — the follow-through should have happened "
        "when I wrote that comment, not 47 days later.\n\n"
        "（按 9 月 11 日的说明关闭：#2985 已包含同样的 ENOTTY 处理，本 PR 属重复。"
        "拖了 47 天才收尾是我的问题。）"
    ),
    2990: (
        "Closing this: as @KaiErikNiermann pointed out, this duplicates the change in #2983, "
        "and #2983 is itself a pull request, so `Fixes #2983` was the wrong reference — it "
        "should have been a review over there, not a competing PR.\n\n"
        "I'll follow up on #2983 instead.\n\n"
        "（按维护者指出的问题关闭：#2983 本身就是 PR，`Fixes #2983` 是错误引用，"
        "应该去那边 review 而不是另开一个竞争性 PR。）"
    ),
}


def _req(method, path, body=None):
    req = urllib.request.Request(
        "https://api.github.com" + path,
        data=json.dumps(body).encode("utf-8") if body else None,
        headers={**HEADERS, "Content-Type": "application/json"}, method=method)
    try:
        with urllib.request.urlopen(req, timeout=60) as r:
            return json.loads(r.read() or b"{}")
    except Exception as e:  # noqa: BLE001
        detail = getattr(e, "read", lambda: b"")()
        return {"__error": str(e), "detail": detail.decode("utf-8", "ignore")[:200]}


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--yes", action="store_true")
    a = ap.parse_args()
    for num, comment in TARGETS.items():
        pr = api(f"/repos/giampaolo/psutil/pulls/{num}")
        if "__error" in pr:
            print(f"#{num} 读不到：{pr}"); continue
        print(f"#{num} state={pr['state']}  {pr['title'][:70]}")
        if pr["state"] != "open":
            print("   已关闭，跳过"); continue
        if not a.yes:
            print("   [试运行] 将评论并关闭"); continue
        c = _req("POST", f"/repos/giampaolo/psutil/issues/{num}/comments", {"body": comment})
        if c.get("__error"):
            print("   评论失败:", c["__error"], c.get("detail", "")[:120]); continue
        r = _req("PATCH", f"/repos/giampaolo/psutil/pulls/{num}", {"state": "closed"})
        print("   关闭:", r.get("html_url") if not r.get("__error")
              else f"ERROR {r['__error']} {r.get('detail','')[:120]}")


if __name__ == "__main__":
    main()
