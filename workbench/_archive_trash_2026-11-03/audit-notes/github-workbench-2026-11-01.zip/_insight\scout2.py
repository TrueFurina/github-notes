"""补两个精准查询：Python / TypeScript 里「GFI 多 + 活跃」的仓库。"""
import json
import os
import time
import urllib.parse
import urllib.request

TOKEN = os.environ["GITHUB_TOKEN"]
OUT = os.path.dirname(os.path.abspath(__file__))
QS = {
    "py_gfi": "language:python good-first-issues:>10 stars:>2000 pushed:>2026-09-01",
    "ts_gfi": "language:typescript good-first-issues:>15 stars:>4000 pushed:>2026-09-01",
}


def main():
    for name, q in QS.items():
        url = ("https://api.github.com/search/repositories?q=" + urllib.parse.quote(q)
               + "&sort=stars&order=desc&per_page=30")
        req = urllib.request.Request(url, headers={
            "Authorization": "Bearer " + TOKEN,
            "Accept": "application/vnd.github+json",
            "User-Agent": "insight-scout"})
        with urllib.request.urlopen(req, timeout=45) as r:
            data = json.loads(r.read().decode("utf-8"))
        rows = [{
            "full_name": it["full_name"], "stars": it["stargazers_count"],
            "lang": it.get("language"), "pushed": it.get("pushed_at"),
            "desc": (it.get("description") or "")[:120],
            "license": (it.get("license") or {}).get("spdx_id"),
        } for it in data.get("items", [])]
        json.dump(rows, open(os.path.join(OUT, f"q_{name}.json"), "w", encoding="utf-8"),
                  ensure_ascii=False, indent=1)
        print(f"\n=== {name} total={data.get('total_count')} ===")
        for r in rows[:15]:
            print(f"{r['stars']:>7} {r['full_name']:<42} {r['lang'] or '-':<12} "
                  f"{r['pushed'][:10]} {r['license']} {r['desc'][:60]}")
        time.sleep(3)


if __name__ == "__main__":
    main()
