import json
import re

d = json.load(open(r"D:/github/github-audit/audit_data.json", encoding="utf-8"))

DEP = re.compile(r"(^|/)(requirements[\w.-]*\.txt|pyproject\.toml|package\.json|Pipfile|poetry\.lock|"
                 r"setup\.py|setup\.cfg|environment\.ya?ml|Cargo\.toml|go\.mod)$", re.I)
TESTDIR = re.compile(r"(^|/)(tests?|__tests__|spec)/", re.I)
TESTFILE = re.compile(r"(^|/)(test_[\w-]+\.py|[\w-]+_test\.py|conftest\.py|[\w.-]+\.(test|spec)\.(js|ts|tsx|jsx))$", re.I)

rows = []
for r in d:
    p = r["paths"]
    deps = sorted({DEP.search(x).group(2) for x in p if DEP.search(x)})
    tdir = sorted({x for x in p if TESTDIR.search(x)})[:3]
    tfile = [x for x in p if TESTFILE.search(x)]
    r["_deps"] = deps
    r["_tests"] = bool(tdir or tfile)
    r["_ntest"] = len(tfile) + len(tdir)
    r["_gitignore"] = any(x == ".gitignore" for x in p)
    r["_ci_cfg"] = [x for x in p if x.startswith(".github/workflows/")]
    r["_docker"] = any(x.lower().startswith("dockerfile") or x.endswith("docker-compose.yml") for x in p)
    rows.append(r)

hdr = f"{'repo':36}{'rd':>7}{'lic':>13}{'wf':>3}{'tests':>6}{'deps':>34}{'rel':>4}{'sizeMB':>8}{'branches':>9} last"
print(hdr)
print("-" * len(hdr))
for r in sorted(rows, key=lambda x: x["size_kb"]):
    print(f"{r['name'][:35]:36}{r['readme_nonspace']:>7}{str(r.get('license_spdx')):>13}"
          f"{len(r['workflows']):>3}{('Y' if r['_tests'] else '-'):>6}"
          f"{(','.join(r['_deps'])[:33]):>34}{r['release_count_ge']:>4}"
          f"{r['size_kb']/1024:>8.1f}{str(r['branches']):>9} {(r.get('last_commit') or '')[:10]}")

print()
# aggregate
n = len(rows)
print("n=", n)
print("no README:", [r["name"] for r in rows if r["readme_nonspace"] == 0])
print("short README(<500):", [(r["name"], r["readme_nonspace"]) for r in rows if 0 < r["readme_nonspace"] < 500])
print("avg readme nonspace:", round(sum(r["readme_nonspace"] for r in rows) / n))
print("median:", sorted(r["readme_nonspace"] for r in rows)[n // 2])
print("no license:", [r["name"] for r in rows if not r.get("license_spdx")])
print("NOASSERTION:", [r["name"] for r in rows if r.get("license_spdx") == "NOASSERTION"])
print("CI:", sum(1 for r in rows if r["workflows"]))
print("tests:", sum(1 for r in rows if r["_tests"]))
print("no deps:", [(r["name"], r["lang"]) for r in rows if not r["_deps"]])
print("no gitignore:", [r["name"] for r in rows if not r["_gitignore"]])
print("no release:", [r["name"] for r in rows if not r["release_count_ge"]])
print("no desc:", [r["name"] for r in rows if not r["desc"]])
print("no topics:", [r["name"] for r in rows if not r["topics"]])
print("big:", [(r["name"], round(r["size_kb"] / 1024, 1)) for r in rows if r["size_kb"] > 51200])
