import json, os

OUT = "D:/github/_insight"
files = ["candidates.json", "candidates_trend.json", "candidates_pyts.json"]
allrows = {}
for fn in files:
    p = os.path.join(OUT, fn)
    if os.path.exists(p):
        for r in json.load(open(p, encoding="utf-8")):
            allrows[r["repo"]] = r

want = ["apache/airflow", "rtk-ai/rtk", "nexu-io/open-design", "topoteretes/cognee",
        "aws/aws-cdk", "cvat-ai/cvat", "tldr-pages/tldr", "pytorch/pytorch",
        "ueberdosis/tiptap", "nuxt/nuxt", "oven-sh/bun", "excalidraw/excalidraw",
        "OpenHands/OpenHands", "elastic/elasticsearch", "swiftlang/swift",
        "langgenius/dify", "FuelLabs/sway", "PDFMathTranslate/PDFMathTranslate",
        "mermaid-js/mermaid", "microsoft/vscode", "grafana/grafana"]
for w in want:
    r = allrows.get(w)
    if not r:
        print(f"!! missing {w}")
        continue
    print(f"\n{r['repo']} | stars={r['stars']} | GFI={r['gfi']} | HW={r.get('help_wanted', 0)} | "
          f"30d={r['commits_30d']} | {r['lang']} | {r['license']} | CONTRIB={r['contributing']} | "
          f"open_issues={r['open_issues']} | pushed={r['pushed'][:10]}")
    print("  desc:", r.get("desc", ""))
    for t in r.get("gfi_samples", [])[:3]:
        print("   -", t)
