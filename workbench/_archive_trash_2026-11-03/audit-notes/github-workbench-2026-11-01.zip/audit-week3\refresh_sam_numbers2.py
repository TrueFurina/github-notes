"""Finish the material-number refresh for SecAutoMind-src PR #74 (round 2).

Round 1 missed four files because I only edited the locations the gate log listed
at that moment. This pass covers what the latest logs report:

  docs/zh-CN/competition-2026/SecAutoMind_参赛材料合订本_打印版.html:307
  docs/zh-CN/competition-2026/技术报告_SecAutoMind_202609.md:159
  SecAutoMind_PPT/make_template_ppt.py  (:459 :467 :491 :570)
  docs/evidence-package.json            (test_lines / total_lines shifted +4)

The +4 comes from my own SA4000 fix: 3 lines became 6 in limiter_test.go.
So test_lines 56515 -> 56519 and total_lines 199071 -> 199075.
"""

import base64
import json
import sys
import urllib.request
from urllib.parse import quote

sys.path.insert(0, r"D:/github/github-audit")
from ghlib import HEADERS, OWNER, api

REPO = f"{OWNER}/SecAutoMind-src"
BRANCH = "feature/llm-concurrency-guard"

# literal -> replacement, applied to text files
TEXT_FILES = {
    "docs/zh-CN/competition-2026/SecAutoMind_参赛材料合订本_打印版.html": [
        ("Go 882 文件（379 测试）", "Go 884 文件（380 测试）"),
        ("142,432", "142,556"),
    ],
    "docs/zh-CN/competition-2026/技术报告_SecAutoMind_202609.md": [
        ("Go 882 文件（379 测试）", "Go 884 文件（380 测试）"),
        ("142,432", "142,556"),
    ],
    "SecAutoMind_PPT/make_template_ppt.py": [
        ("142,432", "142,556"),
        ("('379', '测试文件'", "('380', '测试文件'"),
        ("379 测试文件", "380 测试文件"),
        ("379 测试", "380 测试"),
    ],
}

# JSON: exact keys only, never a bare-number sweep
JSON_FILE = "docs/evidence-package.json"
JSON_KEYS = [("test_lines", "56515", "56519"),
             ("total_lines", "199071", "199075")]


def put(path, text, sha, message):
    url = f"https://api.github.com/repos/{REPO}/contents/" + quote(path, safe="/")
    body = {"message": message, "branch": BRANCH,
            "content": base64.b64encode(text.encode("utf-8")).decode(), "sha": sha}
    req = urllib.request.Request(
        url, data=json.dumps(body, ensure_ascii=False).encode("utf-8"),
        headers={**HEADERS, "Content-Type": "application/json; charset=utf-8"},
        method="PUT")
    try:
        with urllib.request.urlopen(req, timeout=120) as r:
            return r.status, json.loads(r.read())["commit"]["sha"][:12]
    except urllib.error.HTTPError as e:
        return e.code, e.read().decode("utf-8", "ignore")[:250]


def main():
    dry = "--yes" not in sys.argv
    plan = [(p, pats, False) for p, pats in TEXT_FILES.items()]

    for path, pats, _ in plan:
        cur = api(f"/repos/{REPO}/contents/{path}?ref={BRANCH}")
        if "__error" in cur:
            print(f"[{path}] 读不到 {cur}")
            continue
        text = base64.b64decode(cur["content"]).decode("utf-8")
        new, hits = text, {}
        for old, rep in pats:
            n = new.count(old)
            if n:
                new = new.replace(old, rep)
                hits[old] = n
        print(f"[{path}]")
        print("      ", hits or "（无命中）")
        if new == text:
            continue
        if dry:
            continue
        st, res = put(path, new, cur["sha"],
                      "docs(evidence): finish refreshing corpus counts in competition materials\n\n"
                      "Same drift as the previous commit, in files the first pass missed.")
        print(f"      HTTP {st} {res}")

    cur = api(f"/repos/{REPO}/contents/{JSON_FILE}?ref={BRANCH}")
    if "__error" not in cur:
        text = base64.b64decode(cur["content"]).decode("utf-8")
        new = text
        print(f"[{JSON_FILE}]")
        for key, old, rep in JSON_KEYS:
            pat = '"%s"%s' % (key, "")
            # 只替换该键后面紧跟的那个数字
            import re
            rx = re.compile(r'("%s"\s*:\s*)%s(\s*[,}\]])' % (re.escape(key), re.escape(old)))
            new, n = rx.subn(lambda m: m.group(1) + rep + m.group(2), new)
            print(f"       {key}: {old} -> {rep} ({n} 处)")
        if new != text:
            try:
                json.loads(new)
            except ValueError as e:
                print("      JSON 解析失败，跳过:", e)
                return 1
            if not dry:
                st, res = put(JSON_FILE, new, cur["sha"],
                              "docs(evidence): test_lines/total_lines +4 after the SA4000 fix")
                print(f"      HTTP {st} {res}")
    print("\n" + ("dry-run，加 --yes 写入" if dry else "完成"))


if __name__ == "__main__":
    main()
