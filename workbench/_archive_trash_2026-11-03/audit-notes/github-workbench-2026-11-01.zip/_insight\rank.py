"""Airflow good-first-issue 排序：可上手度评分。

评分维度（都用 issue 元数据 + 正文，不猜）：
  + 未被 assign（没人在做）
  + 正文提到具体文件/路径（可定位改动面）
  + 类型偏「小修/测试/文档/日志」；扣分「RFC/大特性/迁移/重构」
  + 评论数适中（0-3 最好；>8 通常已跑偏成大讨论）
  - 挂着 stale / needs-triage 之外的高风险标签
输出：Top 15，带正文里的文件路径与复现线索。
"""
import json
import os
import re
import urllib.request

TOKEN = os.environ["GITHUB_TOKEN"]
OUT = os.path.dirname(os.path.abspath(__file__))
API = "https://api.github.com"
REPO = "apache/airflow"

SMALL = re.compile(r"(test|doc|typo|log|deprecat|warning|error message|validate|"
                   r"fix|bug|crash|raise|none|empty|timeout|param|option|"
                   r"example|comment|readme|annotation|type hint)", re.I)
BIG = re.compile(r"(RFC|epic|proposal|design|migrat|rewrite|refactor|"
                 r"new provider|support .*operator|architect|roadmap)", re.I)
PATH = re.compile(r"((?:airflow-core|providers|task-sdk|shared|dev|scripts|chart|"
                  r"docs|contributing-docs)[\w./-]*|[\w./-]+\.py|[\w./-]+\.rst|"
                  r"[\w./-]+\.yaml)", re.I)


def get(url):
    req = urllib.request.Request(url, headers={
        "Authorization": "Bearer " + TOKEN,
        "Accept": "application/vnd.github+json",
        "User-Agent": "insight-scout"})
    with urllib.request.urlopen(req, timeout=45) as r:
        return json.loads(r.read().decode("utf-8"))


def main():
    issues = get(f"{API}/repos/{REPO}/issues?state=open&labels=good%20first%20issue"
                 f"&per_page=100&sort=updated&direction=desc")
    issues = [i for i in issues if "pull_request" not in i]
    rows = []
    for it in issues:
        body = it.get("body") or ""
        paths = PATH.findall(body)
        paths = [p for p in paths if len(p) > 5][:6]
        title = it["title"]
        score = 0
        reasons = []
        if not it.get("assignees"):
            score += 2
            reasons.append("未分配")
        else:
            reasons.append("已有人接")
        if paths:
            score += 2
            reasons.append(f"正文点名 {len(paths)} 处路径")
        if SMALL.search(title):
            score += 2
            reasons.append("小修/可测类")
        if BIG.search(title):
            score -= 3
            reasons.append("大特性/RFC")
        c = it.get("comments", 0)
        if 0 <= c <= 3:
            score += 1
            reasons.append(f"评论 {c}")
        elif c > 8:
            score -= 1
        score += 1 if len(body) > 200 else 0
        rows.append({
            "number": it["number"], "title": title, "score": score,
            "comments": c, "assigned": bool(it.get("assignees")),
            "labels": [l["name"] for l in it.get("labels", [])],
            "paths": paths, "reasons": reasons,
            "body_head": re.sub(r"\s+", " ", body)[:220],
            "created": it["created_at"][:10], "updated": it["updated_at"][:10],
        })
    rows.sort(key=lambda r: (-r["score"], -r["number"]))
    json.dump(rows, open(os.path.join(OUT, "airflow_gfi_ranked.json"), "w", encoding="utf-8"),
              ensure_ascii=False, indent=1)
    print(f"issues={len(rows)}")
    for r in rows[:15]:
        print(f"\n[{r['score']}] #{r['number']} {r['title'][:100]}")
        print(f"    labels={r['labels']} comments={r['comments']} assigned={r['assigned']} "
              f"created={r['created']} updated={r['updated']}")
        print(f"    paths={r['paths']}")
        print(f"    body: {r['body_head']}")


if __name__ == "__main__":
    main()
