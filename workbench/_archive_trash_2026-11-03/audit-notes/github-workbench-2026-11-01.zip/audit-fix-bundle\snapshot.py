"""抓取 P0 修复目标的现状文本（只读），存到 fix-bundle/current/。"""
import base64
import json
import os
import sys

sys.path.insert(0, r"D:/github/github-audit")
from ghlib import api, OWNER  # noqa: E402

HERE = os.path.dirname(os.path.abspath(__file__))
OUT = os.path.join(HERE, "current")
os.makedirs(OUT, exist_ok=True)

TARGETS = [
    "AGI-Distiller",
    "passive-recon",
    "DevRadar-GitHub-Trending-Monitor",
    "pikachu",
    "xuandun-cyber-range",
    "2026-Challenge-Cup-Security-LLM-Triage-Agent",
    "xihu-sword-ctf-agent",
]

meta = {}
for repo in TARGETS:
    info = api(f"/repos/{OWNER}/{repo}")
    if "__error" in info:
        print("SKIP", repo, info)
        continue
    meta[repo] = {
        "default_branch": info.get("default_branch"),
        "license": (info.get("license") or {}).get("spdx_id"),
        "license_name": (info.get("license") or {}).get("name"),
        "description": info.get("description"),
        "topics": info.get("topics"),
    }
    for fn in ("README.md", "LICENSE", "LICENSE.md"):
        r = api(f"/repos/{OWNER}/{repo}/contents/{fn}?ref={info['default_branch']}")
        if isinstance(r, dict) and r.get("content") and "__error" not in r:
            raw = base64.b64decode(r["content"]).decode("utf-8", "ignore")
            safe = fn.replace(".", "_")
            p = os.path.join(OUT, f"{repo}__{safe}")
            with open(p, "w", encoding="utf-8") as f:
                f.write(raw)
            print(f"{repo:48} {fn:10} {len(raw):7} chars  sha={r['sha'][:8]}")
            meta[repo].setdefault("files", {})[fn] = {
                "sha": r["sha"], "size": len(raw), "local": p}
    print("  license:", meta[repo]["license"], "| branch:", meta[repo]["default_branch"])

with open(os.path.join(HERE, "current_meta.json"), "w", encoding="utf-8") as f:
    json.dump(meta, f, ensure_ascii=False, indent=1)
print("\nwritten:", os.path.join(HERE, "current_meta.json"))
