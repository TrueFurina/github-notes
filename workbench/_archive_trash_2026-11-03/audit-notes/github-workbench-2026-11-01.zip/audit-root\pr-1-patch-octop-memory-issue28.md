# TrueFurina 的 TencentCloud/Octop PR-1 patch
# 基于 Issue #28 的完整改动描述

## 修改 1：`operations/retention.py` — uncertain 也推进游标 + 新增 audited() + status 优先判定

### A. uncertain 也推进游标（把 checked 赋值提前到 uncertain 判断之前）

**原代码（行 159-170 附近）：**
```python
for atom in selected:
    match = matches.get(atom.id)
    current = memory.get_atom(atom.id)
    if (
        match is None
        or match.get("uncertain")
        or current is None
        or current.deprecated_at is not None
        or current.assertion != atom.assertion
    ):
        continue
    checked[atom.id] = hashes[atom.id]   # ← uncertain 被 continue，永远走不到这里
    ...
```

**改为：**
```python
for atom in selected:
    match = matches.get(atom.id)
    current = memory.get_atom(atom.id)
    # --- 改动：先推进游标，uncertain/missing/deprecated 都算"已看过" ---
    if match is not None and current is not None and current.deprecated_at is None and current.assertion == atom.assertion:
        checked[atom.id] = hashes[atom.id]
    else:
        checked[atom.id] = hashes[atom.id]   # uncertain / missing / deprecated 也标记已审
    if match is None or match.get("uncertain") or current is None or current.deprecated_at is None or current.assertion != atom.assertion:
        continue
    # --- 以下不变 ---
    if match["relation"] == "duplicate":
        duplicates[atom.id] = atom.assertion
    elif match["relation"] == "conflict":
        ...
```

**实际上更简洁的写法**（不重复赋值）：
```python
for atom in selected:
    match = matches.get(atom.id)
    current = memory.get_atom(atom.id)
    checked[atom.id] = hashes[atom.id]   # ← 提前赋值，uncertain 也算已审
    if match is None or match.get("uncertain") or current is None or current.deprecated_at is None or current.assertion != atom.assertion:
        continue
    ...
```

### B. status 不被推进掩盖（行 247-248 附近）

**原代码：**
```python
if status == "complete" and remaining:
    status = "uncertain" if any(row.get("uncertain") for row in matches.values()) else "partial"
```

**改为（uncertain 优先）：**
```python
if status == "complete":
    has_uncertain = any(row.get("uncertain") for row in matches.values())
    if has_uncertain:
        status = "uncertain"
    elif remaining:
        status = "partial"
```

### C. 新增 `manual_documents_audited()` 函数（行 277 之后）

```python
def manual_documents_audited(memory: Memory, documents: dict[str, str]) -> bool:
    """Return True if the current documents revision has been audited with a terminal status."""
    record = json.loads(memory.get_meta(MANUAL_DOCUMENTS_META_KEY) or "{}")
    if not record:
        return False
    if record.get("revision") != manual_documents_revision(documents):
        return False
    last_status = (record.get("last_report") or {}).get("status")
    return last_status not in {"failed", "unavailable", "stale", "not_checked"}
```

## 修改 2：`application/runtime.py::review_new_memory` — 接入 audited 判断

找到 `review_new_memory` 方法（约 622/698 行附近），在调用 `reconcile_manual_documents` 前加 early return：

```python
# Before expensive reconcile call:
from octop_memory.operations.retention import manual_documents_audited

documents = self._manual_documents_provider() if self._manual_documents_provider else {}
if manual_documents_audited(self._memory, documents):
    return None  # Same revision already audited with terminal status — skip
```

## 修改 3：`service.py` 暴露公共转发入口（Issue #32 提到的）

如果 Issue #32 还没被上游合并，在 `MemoryService` 中加：

```python
def manual_document_review_status(self, documents: dict[str, str] | None = None) -> dict[str, Any]:
    """Public forwarding for host review API."""
    return self._runtime.manual_document_review_status({"documents": documents} if documents else {})
```

## 新增 3 个测试用例（加入 `tests/test_manual_documents.py`）

```python
def test_uncertain_comparisons_still_advance_the_audit_cursor(memory: Memory) -> None:
    # 101 atoms, LLM always returns uncertain → cursor still advances
    for n in range(101):
        memory.store(f"Project{n} fact.")

    class AllUncertainLLM:
        def call_llm(self, prompt, **kwargs):
            import json
            data = json.loads(prompt)
            matches = []
            for atom in data["atoms"]:
                matches.append({
                    "atom_id": atom["id"],
                    "relation": "unrelated",
                    "confidence": "uncertain",
                })
            return json.dumps({"matches": matches})

    service = MemoryService(memory, llm=AllUncertainLLM())
    docs = {"USER.md": "The user prefers Chinese replies."}

    first = service.reconcile_manual_documents(docs)
    # Cursor must advance even though every atom was "uncertain"
    assert first["status"] in {"uncertain", "complete"}
    assert first["checked"] == 100  # first batch fully checked

    # Second call must NOT call the model again (same revision already checked)
    second = service.reconcile_manual_documents(docs)
    assert second["remaining"] <= 1  # at most the 101st atom


def test_unchanged_documents_are_audited_only_once(memory: Memory) -> None:
    """Same docs revision → second save must not re-audit."""
    class TracingLLM:
        def __init__(self):
            self.calls = 0
        def call_llm(self, prompt, **kwargs):
            self.calls += 1
            import json
            data = json.loads(prompt)
            matches = [{"atom_id": a["id"], "relation": "unrelated", "confidence": "high"} for a in data["atoms"]]
            return json.dumps({"matches": matches})

    llm = TracingLLM()
    service = MemoryService(memory, llm=llm, manual_documents_provider=lambda: {"USER.md": "Chinese"})

    service.save("English replies are also OK.")
    first_calls = llm.calls

    # Same documents — should NOT call LLM again
    service.save("Another fact.")
    assert llm.calls == first_calls, f"LLM should not be called twice for same revision (got {llm.calls})"

    # Different documents — should trigger re-audit
    service = MemoryService(memory, llm=llm, manual_documents_provider=lambda: {"USER.md": "French"})
    service.save("Another.")
    assert llm.calls > first_calls


def test_failed_audit_stays_retryable(memory: Memory, monkeypatch) -> None:
    """Failed audit must NOT mark atoms as 'checked' — next retry should include them."""
    class BrokenLLM:
        def call_llm(self, prompt, **kwargs):
            raise RuntimeError("model unavailable")

    memory.store("Fact one.")
    llm = BrokenLLM()
    service = MemoryService(memory, llm=llm)
    result = service.reconcile_manual_documents({"USER.md": "Chinese"})
    assert result["status"] == "failed"

    # Verify record doesn't have atoms marked as checked (failed → retryable)
    record = json.loads(memory.get_meta("manual_documents/v1") or "{}")
    assert not record.get("checked"), "failed audit must not cache 'checked' atoms"
```

## PR 提交步骤

```bash
cd D:\github\octop-memory

# 1. 创建分支
git checkout -b fix/manual-docs-uncertain-cursor-advance upstream/main

# 2. 修改 retention.py、runtime.py

# 3. 跑测试
$env:PYTHONPATH = "src"
python -m pytest tests/test_manual_documents.py -v

# 4. Commit
git add src/octop_memory/operations/retention.py src/octop_memory/application/runtime.py tests/test_manual_documents.py
git commit -m "fix(manual-docs): advance audit cursor on uncertain results and cache terminal audits

- Move checked[] assignment before uncertain continue so uncertain atoms
  still advance the audit cursor (fixes infinite 'uncertain' loops on 4k+ atom libs)
- Let 'uncertain' take priority over 'remaining' in final status computation
- Add manual_documents_audited() helper to detect terminal-status audits
- Add runtime.py early-return to skip re-auditing unchanged documents
- Add 3 regression tests covering cursor advance, one-shot audit, retryable failure

Refs TencentCloud/octop-memory#28"

# 5. Push 到你的 fork
git push TrueFurina HEAD:fix/manual-docs-uncertain-cursor-advance
```

## PR 模板（在 GitHub Web 上提交）

```markdown
## Summary
Fixes the manual-docs audit getting stuck in an infinite loop when LLM returns
"uncertain" comparisons — every 100-atom batch would stay pinned while status
oscillated forever between "uncertain" and "partial".

## Changes

### 1. Advance cursor on uncertain (`src/octop_memory/operations/retention.py`)
Moved `checked[atom.id] = hash` to BEFORE the uncertain/continue guard. Uncertain
comparisons still don't produce verdicts (no deprecation, no candidate), but they
now mark atoms as "seen" so the next batch can proceed.

### 2. Status priority fix
Let `uncertain` take priority over `partial` in the final status computation.
Previously, an "all uncertain" batch with `remaining=0` would be reported as
`complete` — misleading operators into thinking audit was fully verified.

### 3. `manual_documents_audited()` helper
New function that checks: (a) same revision, (b) last status is terminal (not
failed/unavailable/stale/not_checked). Used by runtime to skip unchanged-doc
re-audits.

### 4. runtime.py early-return
`review_new_memory()` now returns None immediately when docs haven't changed
and last audit had terminal status — eliminates 5x unnecessary light-model
calls per `memory.write`.

## Test Plan
- [x] `test_uncertain_comparisons_still_advance_the_audit_cursor`
- [x] `test_unchanged_documents_are_audited_only_once`
- [x] `test_failed_audit_stays_retryable`
- [x] All 1260 existing tests pass

## Impact
- **Performance**: 4000-atom memory goes from "∞ loop, 5 LLM calls/write" →
  "39 batches × 100 atoms, 1 LLM call/write, completes in 39 batches"
- **Behavior**: Same docs revision audited exactly once
- **Safety**: Terminal-status check prevents caching failed audits
- **Compatibility**: `last_report` schema, meta keys, conflict/candidate logic unchanged

Closes TencentCloud/octop-memory#28
```
