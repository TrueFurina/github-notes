"""修复仓库描述与一处可见性事故（只读 + 定点 PATCH，可回退）。

背景
----
1) `sage-paper` 是 public，但自带描述写着 "Not for public release"，
   里面有未发表论文分节草稿、实验审计记录、方向决策备忘，以及 .workbuddy/memory/
   的会话记忆（含本机绝对路径）。fork=0 / star=0，说明没有被外部复制。
   → 改为 private（一条 PATCH，随时可改回）。

2) 7 个公开仓的 description 里所有中文字符都变成了 `?`（GBK 有损转换的产物，
   原文无法从字段本身恢复）。这些描述现在显示在仓库列表页上，例如
   `??? AI ?? - ????? AI ??,??????`，比不写更糟。
   → 按各仓 README 的实际内容重写为可读中文，并把旧值打印出来便于比对。

用法
----
    python fix_descriptions.py            # dry-run，只打印将要改成什么
    python fix_descriptions.py --yes      # 实际写入
    python fix_descriptions.py --revert   # 按 REVERT 表改回（仅供应急）

写入前会重新 GET 一次当前值，若与预期不符则跳过该项，避免覆盖别人的改动。
"""

import json
import sys
import urllib.request

sys.path.insert(0, r"D:/github/github-audit")
from ghlib import HEADERS, OWNER, api  # noqa: E402

# ---------------------------------------------------------------- 可见性事故
PRIVATE_TARGETS = ["sage-paper"]

# ---------------------------------------------------------------- 描述重写
# 依据：各仓 README 首屏的实际自述，不添加 README 里没有的能力。
DESCRIPTIONS = {
    "pikachu":
        "Pikachu 漏洞靶场定制版 —— 开箱即用、一键启动，覆盖 16+ 常见 Web 漏洞"
        "（基于 Apache-2.0 上游二次定制）",
    "workspace":
        "工作区暂存仓（非稳定交付物）：国创 2026 等项目的冲刺看板、SOP 与平台多智能体配置转运",
    "win-appx-doctor":
        "Windows AppX / 照片应用诊断与修复小工具集（PowerShell + CMD）：重注册、重置、健康检查，"
        "不下载任何东西、不碰系统文件",
    "docker-forensics-toolkit":
        "Docker 引擎连环死亡排查实录的配套脚本：代理残留清理、安装器静默退出、SIGBUS 崩溃定位",
    "aerorider-delivery":
        "骑手-无人机协同即时配送路径优化（论文复现包）：直送与 C2D2C 三段式逐单决策，15 分钟滚动窗口",
    "law-case-pdf2docx":
        "人民法院案例库 PDF → Word 转换器：裁判要旨 / 基本案情 / 裁判理由三段结构，复刻法院公文排版",
    "soft-skills-platform":
        "软技能成长平台前端原型（React + Vite）：能力测评、雷达图、学习路径、训练任务与报告",
}


def patch(path, payload):
    req = urllib.request.Request(
        "https://api.github.com" + path,
        data=json.dumps(payload, ensure_ascii=False).encode("utf-8"),
        headers={**HEADERS, "Content-Type": "application/json; charset=utf-8"},
        method="PATCH",
    )
    try:
        with urllib.request.urlopen(req, timeout=60) as r:
            return r.status, json.loads(r.read())
    except urllib.error.HTTPError as e:
        return e.code, e.read().decode("utf-8", "ignore")[:300]


def main():
    dry = "--yes" not in sys.argv
    revert = "--revert" in sys.argv

    print("=" * 76)
    print("步骤 1/2 · sage-paper 可见性（public -> private）")
    print("=" * 76)
    for repo in PRIVATE_TARGETS:
        info = api(f"/repos/{OWNER}/{repo}")
        if isinstance(info, dict) and "__error" in info:
            print(f"  [{repo}] 读取失败: {info['__error']}")
            continue
        cur = info.get("private")
        desc = (info.get("description") or "")
        print(f"  [{repo}] 当前 private={cur} visibility={info.get('visibility')} "
              f"forks={info['forks_count']} stars={info['stargazers_count']}")
        print(f"           描述: {desc!r}")
        if cur is True:
            print("           已是私有，跳过")
            continue
        if dry:
            print("           -> 将 PATCH private=true（dry-run）")
            continue
        status, body = patch(f"/repos/{OWNER}/{repo}", {"private": True})
        ok = status == 200 and isinstance(body, dict) and body.get("private") is True
        print(f"           -> HTTP {status} private={body.get('private') if isinstance(body, dict) else body}"
              f" {'OK' if ok else 'FAILED'}")

    print()
    print("=" * 76)
    print("步骤 2/2 · 7 个仓的描述（中文被 GBK 有损转成 ?）")
    print("=" * 76)
    changed = 0
    for repo, new in DESCRIPTIONS.items():
        info = api(f"/repos/{OWNER}/{repo}")
        if isinstance(info, dict) and "__error" in info:
            print(f"  [{repo}] 读取失败: {info['__error']}")
            continue
        old = info.get("description") or ""
        if revert:
            new = old
        if old == new:
            print(f"  [{repo}] 已是目标值，跳过")
            continue
        print(f"  [{repo}]")
        print(f"     旧: {old!r}")
        print(f"     新: {new!r}")
        if dry:
            continue
        status, body = patch(f"/repos/{OWNER}/{repo}", {"description": new})
        ok = status == 200 and isinstance(body, dict) and body.get("description") == new
        print(f"     HTTP {status} {'OK' if ok else 'FAILED'} {'' if ok else body}")
        if ok:
            changed += 1

    print()
    print("=" * 76)
    if dry:
        print("以上为 dry-run。加 --yes 实际写入。")
    else:
        print(f"实际写入 {changed} 项描述。")
    print("回退：sage-paper 改回公开 -> PATCH /repos/{OWNER}/sage-paper {'private': false}")
    print("     描述回退 -> 旧值见上方输出（或 --revert 辅助）")


if __name__ == "__main__":
    main()
