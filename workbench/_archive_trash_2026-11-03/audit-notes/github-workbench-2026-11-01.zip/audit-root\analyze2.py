import json, collections

d = json.load(open("raw.json", encoding="utf-8"))
repos = d["repos"]; own=[r for r in repos if not r.get("fork")]; forks=[r for r in repos if r.get("fork")]

print("=== FORK UPSTREAMS (top) ===")
up = collections.Counter((r.get("parent") or {}).get("full_name", (r.get("source") or {}).get("full_name","?")) for r in forks)
for k,v in up.most_common(25): print(f"{v:3d} {k}")

print("\n=== FORKS: pushed after fork? ===")
active=[r for r in forks if r.get("pushed_at") and r.get("created_at") and r["pushed_at"]>r["created_at"]]
print("forks with own commits:", len(active), "/", len(forks))
for r in sorted(active, key=lambda x:-x["size"])[:10]:
    print(f'  {r["size"]:7d}KB {r["pushed_at"][:10]} {r["full_name"]}')

print("\n=== OWN REPOS DETAIL ===")
for r in sorted(own, key=lambda x: x["pushed_at"], reverse=True):
    print(f'{r["name"][:34]:36s} {str(r["language"])[:10]:11s} {r["size"]:6d}KB c={r["created_at"][:10]} p={r["pushed_at"][:10]} iss={r["open_issues_count"]:2d} '
          f'lic={"Y" if r.get("license") else "-"} top={len(r.get("topics") or [])} desc={"Y" if r.get("description") else "-"}')

print("\n=== SIZE / EMPTY ===")
print("size<100KB:", sum(1 for r in own if r["size"]<100), "size<10KB:", sum(1 for r in own if r["size"]<10))

print("\n=== EVENTS recent 20 ===")
for e in d["events"][:20]:
    print(e["created_at"][:16], e["type"], e["repo"]["name"])
