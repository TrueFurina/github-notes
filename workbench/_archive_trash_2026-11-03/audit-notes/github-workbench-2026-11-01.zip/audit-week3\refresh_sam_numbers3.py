"""Round 3: the four docs the caliber gate still reports (9 spots).

Numbers are replaced with digit boundaries so 1379 / 8821 cannot be touched,
and only inside these four files.
"""

import base64
import json
import re
import sys
import urllib.request
from urllib.parse import quote

sys.path.insert(0, r"D:/github/github-audit")
from ghlib import HEADERS, OWNER, api

REPO = f"{OWNER}/SecAutoMind-src"
BRANCH = "feature/llm-concurrency-guard"

FILES = [
    "docs/规划-移植与优化总纲.md",
    "docs/archive/2026-09/提交前终检清单_20260903.md",
    "docs/zh-CN/competition-2026/提交前硬门槛核查清单.md",
    "docs/zh-CN/competition-2026/PPT数字清单_E1E5_20260905.md",
]

SUBS = [
    (r"142,432", "142,556"),
    (r"(?<!\d)142432(?!\d)", "142556"),
    (r"(?<!\d)882(?!\d)", "884"),
    (r"(?<!\d)379(?!\d)", "380"),
]


def put(path, text, sha):
    url = f"https://api.github.com/repos/{REPO}/contents/" + quote(path, safe="/")
    body = {"message": "docs(evidence): refresh corpus counts (round 3, remaining docs)",
            "branch": BRANCH,
            "content": base64.b64encode(text.encode("utf-8")).decode(), "sha": sha}
    req = urllib.request.Request(
        url, data=json.dumps(body, ensure_ascii=False).encode("utf-8"),
        headers={**HEADERS, "Content-Type": "application/json; charset=utf-8"},
        method="PUT")
    try:
        with urllib.request.urlopen(req, timeout=120) as r:
            return r.status, json.loads(r.read())["commit"]["sha"][:12]
    except urllib.error.HTTPError as e:
        return e.code, e.read().decode("utf-8", "ignore")[:250]


def main():
    dry = "--yes" not in sys.argv
    total = 0
    for path in FILES:
        cur = api(f"/repos/{REPO}/contents/{path}?ref={BRANCH}")
        if "__error" in cur:
            print(f"[{path}] 读不到 {cur}")
            continue
        text = base64.b64decode(cur["content"]).decode("utf-8")
        new, hits = text, {}
        for pat, rep in SUBS:
            new, n = re.subn(pat, rep, new)
            if n:
                hits[pat] = n
                total += n
        print(f"[{path}] {hits}")
        if new == text or dry:
            continue
        st, res = put(path, new, cur["sha"])
        print(f"      HTTP {st} {res}")
    print("\n共", total, "处", "（dry-run）" if dry else "（已写入）")


if __name__ == "__main__":
    main()
