import json
import re

DEP = re.compile(r"(^|/)(requirements[\w.-]*\.txt|pyproject\.toml|package\.json|Pipfile|poetry\.lock|"
                 r"setup\.py|setup\.cfg|environment\.ya?ml|Cargo\.toml|go\.mod)$", re.I)
TESTDIR = re.compile(r"(^|/)(tests?|__tests__|spec)/", re.I)
TESTFILE = re.compile(r"(^|/)(test_[\w-]+\.py|[\w-]+_test\.py|conftest\.py|[\w.-]+\.(test|spec)\.(js|ts|tsx|jsx))$", re.I)

d = {r["name"]: r for r in json.load(open(r"D:/github/github-audit/audit_data.json", encoding="utf-8"))}
for r in d.values():
    p = r["paths"]
    r["_deps"] = sorted({DEP.search(x).group(2) for x in p if DEP.search(x)})
    r["_tests"] = bool(any(TESTDIR.search(x) for x in p) or any(TESTFILE.search(x) for x in p))
    r["_gitignore"] = ".gitignore" in p

# 修正：两座大仓 tree 回退到根目录，tests 漏判
d["SecAutoMind-src"]["_tests"] = True
d["SecAutoMind-src"]["_tests_note"] = "scripts/*_test.py"
d["MARS-408"]["_tests"] = True
d["MARS-408"]["_tests_note"] = "tests/ (1 file)"

# 依赖文件（comment-distillery 故意零依赖）
ZERO_DEP = {"comment-distillery"}

rows = []
for n, r in d.items():
    deps = r["_deps"]
    sev = 0
    tags = []
    if r["readme_nonspace"] == 0:
        sev += 40; tags.append("无README")
    elif r["readme_nonspace"] < 500:
        sev += 25; tags.append("README过短")
    if not r.get("license_spdx"):
        sev += 25; tags.append("无LICENSE")
    elif r.get("license_spdx") == "NOASSERTION":
        sev += 12; tags.append("非标准License")
    if not r["workflows"]:
        sev += 15; tags.append("无CI")
    if not r["_tests"]:
        sev += 10; tags.append("无测试")
    if not deps and n not in ZERO_DEP:
        sev += 12; tags.append("无依赖清单")
    if not r["release_count_ge"]:
        sev += 6; tags.append("无Release")
    if r["size_kb"] > 51200:
        sev += 20; tags.append("超50MB")
    if not r["_gitignore"]:
        sev += 4; tags.append("无.gitignore")
    if not r["desc"]:
        sev += 5; tags.append("无描述")
    if not r["topics"]:
        sev += 3; tags.append("无topics")
    # 权重：有星仓库的规范缺口影响更大
    sev += min(r["stars"], 10)
    rows.append((sev, n, r, tags))

rows.sort(key=lambda x: (-x[0], x[1]))

n = len(rows)
st = {
    "README缺失": sum(1 for _, _, r, _ in rows if r["readme_nonspace"] == 0),
    "README平均字数": round(sum(r["readme_nonspace"] for _, _, r, _ in rows) / n),
    "README中位数": sorted(r["readme_nonspace"] for _, _, r, _ in rows)[n // 2],
    "有CI": sum(1 for _, _, r, _ in rows if r["workflows"]),
    "有LICENSE文件": sum(1 for _, _, r, _ in rows if r.get("license_spdx")),
    "标准License(MIT)": sum(1 for _, _, r, _ in rows if r.get("license_spdx") == "MIT"),
    "NOASSERTION": sum(1 for _, _, r, _ in rows if r.get("license_spdx") == "NOASSERTION"),
    "有tests": sum(1 for _, _, r, _ in rows if r["_tests"]),
    "有依赖清单": sum(1 for _, _, r, _ in rows if r["_deps"]),
    "有Release": sum(1 for _, _, r, _ in rows if r["release_count_ge"]),
    "有.gitignore": sum(1 for _, _, r, _ in rows if r["_gitignore"]),
    "有描述": sum(1 for _, _, r, _ in rows if r["desc"]),
    "有topics": sum(1 for _, _, r, _ in rows if r["topics"]),
    "超50MB": sum(1 for _, _, r, _ in rows if r["size_kb"] > 51200),
}

for k, v in st.items():
    pct = f"  ({v / n * 100:.0f}%)" if isinstance(v, int) and v <= n else ""
    print(f"{k}: {v}{pct}")

print("\n--- TABLE ROWS ---")
for sev, name, r, tags in rows:
    lic = r.get("license_spdx") or "无"
    lic = "自定义" if lic == "NOASSERTION" else lic
    ci = f"{len(r['workflows'])}wf" if r["workflows"] else "无"
    tests = "Y" if r["_tests"] else "无"
    deps = ",".join(x.replace("requirements", "req").replace(".txt", "").replace(".toml", "")
                    for x in r["_deps"]) or ("零依赖" if name in ZERO_DEP else "无")
    rel = r.get("release_tag") or "无"
    print(f"| {name} | {r['readme_nonspace']} | {lic} | {ci} | {tests} | {deps} | {rel} | "
          f"{r['size_kb'] / 1024:.1f} | {'/'.join(tags)} |")

print("\n--- 例外/细节 ---")
for name in ["comment-distillery", "SecAutoMind-src", "MARS-408", "TrueFurina", "passive-recon"]:
    r = d[name]
    print(name, "| branches", r["branches"], "| last", r.get("last_commit", "")[:10],
          "| rel", r.get("release_tag"), r.get("release_date", "")[:10] if r.get("release_date") else "",
          "| wf", r["workflows"], "| tests", r["_tests"], r.get("_tests_note", ""),
          "| deps", r["_deps"])
