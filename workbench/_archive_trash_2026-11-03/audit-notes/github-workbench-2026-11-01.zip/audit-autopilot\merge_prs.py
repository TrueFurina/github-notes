"""按清单合并 PR —— 默认 dry-run，必须显式 --yes 才真合。

安全设计
--------
1. **默认只打印**，不调 merge 接口。
2. 每个 PR 先校验：`state=open`、`mergeable=true`、**不在保护名单**。
   保护名单是"维护者正在讨论/正在复核"的那些，见 PROTECTED。
3. 合完把 sha 打到 stdout，便于事后核对与回滚（GitHub 上 revert 即可）。
4. 不 squash 掉别人的提交历史：仓库允许 squash 就用 squash（这些 PR 都是单 commit，
   等价），否则用 merge。

用法
----
    python autopilot/merge_prs.py TencentCloud/Octop#2495 TencentCloud/Octop#2494
    python autopilot/merge_prs.py TencentCloud/Octop#2495 --yes
"""
from __future__ import annotations

import json
import os
import sys
import urllib.error
import urllib.request

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from ghlib import HEADERS, OWNER, api  # noqa: E402

# 这些不自动合：维护者在等回复、正在复核，或我承诺过等对方表态。
PROTECTED = {
    ("TencentCloud/octop-memory", 29),   # Bosheng0422 正在复核 P1 补丁
    ("TencentCloud/Octop", 2170),        # 维护者有 3 条讨论
    ("TencentCloud/octop-harness", 83),  # 维护者有 3 条讨论
}


def merge(repo: str, num: int, method: str) -> tuple[int, str]:
    body = {"merge_method": method}
    req = urllib.request.Request(
        f"https://api.github.com/repos/{repo}/pulls/{num}/merge",
        data=json.dumps(body).encode(),
        headers={**HEADERS, "Content-Type": "application/json"},
        method="PUT")
    try:
        with urllib.request.urlopen(req, timeout=90) as r:
            d = json.loads(r.read())
        return r.status, f"merged={d.get('merged')} sha={(d.get('sha') or '')[:10]}"
    except urllib.error.HTTPError as e:
        return e.code, e.read().decode("utf-8", "ignore")[:200]


def main() -> int:
    args = [a for a in sys.argv[1:] if not a.startswith("--")]
    do_it = "--yes" in sys.argv
    if not args:
        print("用法: python autopilot/merge_prs.py repo#num [repo#num ...] [--yes]")
        return 1

    ok, skipped = [], []
    for spec in args:
        if "#" not in spec:
            print(f"[SKIP] {spec}: 需要 repo#num 形式，例如 TencentCloud/Octop#2495")
            continue
        repo, num_s = spec.rsplit("#", 1)
        if not num_s.isdigit():
            print(f"[SKIP] {spec}: 编号不是数字")
            continue
        num = int(num_s)
        if (repo, num) in PROTECTED:
            skipped.append((repo, num, "在保护名单：维护者正在讨论/复核"))
            print(f"[SKIP] {repo}#{num}: 保护名单")
            continue

        # 先看权限：对上游仓只有 pull 权限时，merge 接口必然 403/405。
        # 2026-10-31 实测 TencentCloud/Octop 三仓均为 push=false —— 合并只能由维护者做，
        # 这决定了本脚本在绝大多数场景下**注定失败**，所以要提前说清楚，而不是等 API 报错。
        perm = (api(f"/repos/{repo}") or {}).get("permissions") or {}
        if not perm.get("push"):
            print(f"[SKIP] {repo}#{num}: 无 push 权限（只有读），合并只能由维护者点。")
            skipped.append((repo, num, "无 push 权限"))
            continue

        d = api(f"/repos/{repo}/pulls/{num}")
        if not isinstance(d, dict) or "__error" in d:
            skipped.append((repo, num, f"读不到: {d}"))
            print(f"[SKIP] {repo}#{num}: 读不到")
            continue
        if d.get("state") != "open":
            skipped.append((repo, num, f"state={d.get('state')}"))
            print(f"[SKIP] {repo}#{num}: 已不是 open")
            continue
        if d.get("mergeable") is not True:
            skipped.append((repo, num, f"mergeable={d.get('mergeable')}"))
            print(f"[SKIP] {repo}#{num}: mergeable={d.get('mergeable')}（有冲突或未算完）")
            continue

        info = api(f"/repos/{repo}") or {}
        method = "squash" if info.get("allow_squash_merge") else "merge"
        line = (f"{repo}#{num} | {d['title'][:60]} | +{d.get('additions')}/-{d.get('deletions')} "
                f"| method={method}")
        if not do_it:
            print(f"[DRY] {line}")
            ok.append((repo, num, "dry-run"))
            continue
        st, msg = merge(repo, num, method)
        print(f"[{'OK ' if st == 200 else 'ERR'}] {line} -> {st} {msg}")
        (ok if st == 200 else skipped).append((repo, num, msg))

    print(f"\n可合 {len(ok)} · 跳过 {len(skipped)}"
          + ("" if do_it else "  （dry-run，未真正合并；加 --yes 执行）"))
    for repo, num, why in skipped:
        print(f"  skip {repo}#{num}: {why}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
