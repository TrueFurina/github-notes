import json, subprocess, time, urllib.request, urllib.error, http.client

TOKEN = subprocess.run(
    ["powershell", "-NoProfile", "-Command",
     "[Environment]::GetEnvironmentVariable('GITHUB_TOKEN','User')"],
    capture_output=True, text=True).stdout.strip()

H = {"Authorization": "Bearer " + TOKEN, "User-Agent": "raccoon-analyzer",
     "Accept": "application/vnd.github+json", "Connection": "close"}


def get(url, tries=4):
    last = None
    for i in range(tries):
        req = urllib.request.Request(url, headers=H)
        try:
            with urllib.request.urlopen(req, timeout=60) as r:
                chunks = []
                try:
                    while True:
                        b = r.read(65536)
                        if not b:
                            break
                        chunks.append(b)
                except http.client.IncompleteRead as e:
                    chunks.append(e.partial)
                body = b"".join(chunks)
            return json.loads(body) if body else None
        except urllib.error.HTTPError as e:
            last = e.code
            if e.code in (403, 429):
                time.sleep(4 * (i + 1)); continue
            print("HTTP", e.code, url); return {"__error": e.code}
        except Exception as e:
            last = repr(e)
            time.sleep(2 * (i + 1))
    print("FAIL", last, url)
    return None


def paged(url, per=100, cap=1000):
    out, page = [], 1
    while len(out) < cap:
        sep = "&" if "?" in url else "?"
        chunk = get(f"{url}{sep}per_page={per}&page={page}")
        if not isinstance(chunk, list) or not chunk:
            break
        out.extend(chunk)
        if len(chunk) < per:
            break
        page += 1
    return out


USER = "TrueFurina"
data = {}
data["user"] = get("https://api.github.com/user")
data["repos"] = paged("https://api.github.com/user/repos?affiliation=owner&sort=updated")
data["starred"] = paged("https://api.github.com/user/starred", cap=300)
data["events"] = paged(f"https://api.github.com/users/{USER}/events/public", cap=300)
data["orgs"] = get("https://api.github.com/user/orgs")

with open("raw.json", "w", encoding="utf-8") as f:
    json.dump(data, f, ensure_ascii=False)

print("repos:", len(data["repos"]))
print("starred:", len(data["starred"]))
print("events:", len(data["events"]))
print("orgs:", [o.get("login") for o in (data["orgs"] or [])])
