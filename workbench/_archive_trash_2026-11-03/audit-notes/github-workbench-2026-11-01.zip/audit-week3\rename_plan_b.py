"""方案 B：让产品仓接管 `SecAutoMind` 这个名字。默认 dry-run。

执行顺序（不可颠倒：先让官网仓让位，否则名字冲突 422）：
  1. SecAutoMind      -> SecAutoMind-site
  2. SecAutoMind-src  -> SecAutoMind
  3. 更新官网仓 README 里对旧名的引用（3 处）
  4. 更新产品仓 README 里对自身旧名的引用（badge + release 链接，2 处）
  5. 校验：旧 URL 应 301、新 release 附件应可下载、Pages 地址会变成 /SecAutoMind-site/

注意：GitHub Pages 不做重定向。第 1 步之后，https://truefurina.github.io/SecAutoMind/
会变成 /SecAutoMind-site/ ——这是方案 B 的固有代价，脚本不会也不能修复它。

    python rename_plan_b.py          # 只打印步骤
    python rename_plan_b.py --yes    # 执行
"""

import argparse
import base64
import json
import sys
import urllib.request

sys.path.insert(0, r"D:/github/github-audit")
from ghlib import api, HEADERS, OWNER  # noqa: E402

SITE_OLD, SITE_NEW = "SecAutoMind", "SecAutoMind-site"
PROD_OLD, PROD_NEW = "SecAutoMind-src", "SecAutoMind"


def _req(method, path, body=None):
    req = urllib.request.Request(
        "https://api.github.com" + path,
        data=json.dumps(body).encode("utf-8") if body else None,
        headers={**HEADERS, "Content-Type": "application/json"}, method=method)
    try:
        with urllib.request.urlopen(req, timeout=90) as r:
            return json.loads(r.read() or b"{}")
    except Exception as e:  # noqa: BLE001
        detail = getattr(e, "read", lambda: b"")()
        return {"__error": str(e), "detail": detail.decode("utf-8", "ignore")[:300]}


def rename(old, new, dry):
    if dry:
        print(f"  [x] PATCH /repos/{OWNER}/{old}  {{name: {new}}}")
        return True
    r = _req("PATCH", f"/repos/{OWNER}/{old}", {"name": new})
    if r.get("__error"):
        print(f"  改名失败 {old}->{new}: {r['__error']} {r.get('detail','')[:150]}")
        return False
    print(f"  已改名: {r['full_name']}")
    return True


def rewrite_readme(repo, pairs, message, dry):
    info = api(f"/repos/{OWNER}/{repo}/contents/README.md")
    if not (isinstance(info, dict) and info.get("content")):
        print(f"  [{repo}] README 读不到，跳过")
        return
    text = base64.b64decode(info["content"]).decode("utf-8")
    new = text
    for a, b in pairs:
        new = new.replace(a, b)
    if new == text:
        print(f"  [{repo}] README 无引用，跳过")
        return
    print(f"  [{repo}] README 将更新 {sum(text.count(a) for a, _ in pairs)} 处引用")
    if dry:
        return
    r = _req("PUT", f"/repos/{OWNER}/{repo}/contents/README.md", {
        "message": message,
        "content": base64.b64encode(new.encode()).decode(),
        "sha": info["sha"], "branch": "main"})
    print("    commit:", (r.get("commit") or {}).get("sha", "")[:8] if not r.get("__error")
          else f"ERROR {r['__error']} {r.get('detail','')[:120]}")


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--yes", action="store_true")
    a = ap.parse_args()
    dry = not a.yes

    if dry:
        print("DRY RUN —— 不修改任何远端内容\n")
        print("前置检查：")
        clash = api(f"/repos/{OWNER}/{SITE_NEW}")
        print(f"  {SITE_NEW} 是否可用:",
              "可用" if isinstance(clash, dict) and "__error" in clash else "⚠ 已被占用")

    print("\n步骤 1/4 · 官网仓让位")
    if not rename(SITE_OLD, SITE_NEW, dry):
        return 1

    print("\n步骤 2/4 · 产品仓接管名字")
    if not rename(PROD_OLD, PROD_NEW, dry):
        return 1

    print("\n步骤 3/4 · 更新引用")
    if dry:
        print("  （dry-run 下新名字还不存在，下面读到的「读不到」属正常）")
    print("  官网仓（{0}）README：把 {1} 换成 {2}".format(SITE_NEW, PROD_OLD, PROD_NEW))
    rewrite_readme(SITE_NEW, [
        (f"{OWNER}/{PROD_OLD}", f"{OWNER}/{PROD_NEW}"),
        (f"`{PROD_OLD}`", f"`{PROD_NEW}`"),
    ], "docs(readme): point at the renamed source repo", dry)

    print("  产品仓（{0}）README：更新自身 badge 与 release 链接".format(PROD_NEW))
    rewrite_readme(PROD_NEW, [
        (f"{OWNER}/{PROD_OLD}", f"{OWNER}/{PROD_NEW}"),
    ], "docs(readme): update self references after repo rename", dry)

    print("\n步骤 4/4 · 校验（改名后手动跑一次）")
    print("  python verify_rename.py")
    if dry:
        print("\n确认后加 --yes。若官网 github.io 链接已对外发过，请先看 rename-decision.md 的方案 B+。")
    return 0


if __name__ == "__main__":
    sys.exit(main())
