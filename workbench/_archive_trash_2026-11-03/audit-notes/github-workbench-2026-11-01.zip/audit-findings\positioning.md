# TrueFurina / Dream — 个人品牌与定位审计

> 审计对象：github.com/TrueFurina（196 public repos / 170 followers / 231 following / 注册 2025-04-06）
> 数据口径：raw.json 快照（2026-10-28 21:42 +0800）+ traffic API 实测窗口 **2026-10-14 ~ 2026-10-27（14 天）**
> traffic 权限：**未出现 403**，gho_ OAuth token 具备 push 权限，views / clones / popular paths 全部拉取成功；**referrers 端点对本账号所有仓库返回 404（无 referral 记录）**，因此外部来源无法归因，下文所有"来源"判断均标注为推断。

---

## 0. 一句话诊断

**问题不是"没人 star"，是"没人看见"，而且看见的人看到的不是 bio 里那个人。**
14 天全账号 168 次页面浏览（约 12 次/天）、8,713 次 clone，其中 **90.7% 的 clone 集中在 2 个与 bio 定位无关的仓库**（MARS-408 6,577 / MangDeHenZhi 1,324）；真正代表"Agent + 红队安全"的两个项目（SecAutoMind、passive-recon）合计只有 100 次浏览、9 个 star。
流量不缺，缺的是**把已有流量导到正确门面**的那一段；而门面上写的是"AI Agent Security **Product Manager**"，bio 写的是"engineer, code first, buzzwords never"。

---

## 1. 流量实测：谁真的被看/被克隆

窗口 2026-10-14 ~ 10-27，按 views 降序（原创仓库中拉取了 22 个，覆盖全部 ≥3★ 及近期活跃仓库）：

| # | 仓库 | ★ | views | uniq | clones | uniq cloners | 诊断 |
|---|------|--:|------:|-----:|-------:|-------------:|------|
| 1 | **SecAutoMind**（HTML 官网） | 2 | **78** | 23 | 14 | 14 | 全账号最高人工浏览；`/releases/tag/v1.7.28` 单页 13 views / 7 uniq —— **唯一有"下载行为"的仓库** |
| 2 | TrueFurina（profile 仓库） | 4 | 31 | **30** | 65 | 36 | 30 个 uniq 看主页 = 有人来，但没被转化（无 CTA、无置顶逻辑） |
| 3 | **passive-recon** | 7 | **22** | 11 | 20 | 19 | 唯一"浏览→star"效率健康的项目；`README.zh-CN.md` 4 views、discussions 3、issues 2、releases 1 → **读完了、停留了** |
| 4 | AGI-Distiller | 9 | 6 | 2 | 35 | 23 | 星最多但几乎无人看，star 与浏览脱钩 |
| 5 | xihu-sword-ctf-agent | 5 | 5 | 3 | **435** | **123** | clone 是浏览的 87 倍 |
| 6 | 2026-CC-Security-LLM-Triage | 3 | 5 | 3 | 131 | 57 | 同上，clone/浏览 = 26× |
| 7 | cyber-terms-hub | 4 | 5 | 4 | 6 | 6 | 平稳小流量 |
| 8 | mcd-meal-optimizer | 2 | 5 | 3 | 21 | 21 | 比赛带来的短流量 |
| 9 | **MARS-408** | 6 | 4 | 4 | **6,577** | **540** | clone/浏览 = **1,644×**，最大异常 |
| 10 | FDE | 4 | 1 | 1 | 8 | 7 | — |
| 11 | **MangDeHenZhi** | 4 | **0** | 0 | **1,324** | 335 | 14 天零浏览、1,324 次 clone |
| 12 | physics-scheduler-agent | 4 | 0 | 0 | 39 | 28 | 10-23 起才起量（13/11/6 次/日） |
| 其余 10 个 | — | — | 0~3 | 0~3 | 0~8 | 0~8 | 无信号 |

**合计**：168 次浏览、8,713 次 clone。MARS-408 + MangDeHenZhi = 90.7%；再加 xihu-ctf = 95.7%。

### 1.1 两种完全不同的"资产"

**(A) 有人克隆、没人看页面 —— 转化断点在"页面"，不在曝光**
MARS-408（540 uniq）、MangDeHenZhi（335 uniq）、xihu-ctf（123 uniq）、2026-CC（57 uniq）。
clone 远大于 view，说明入口是**直接 `git clone <url>`**，人从未打开仓库页。
日曲线提供了归因线索：MARS-408 在 10-18 单日 2,042 次、10-19 1,072 次，10-23 后骤降到 30 次/日；MangDeHenZhi 峰值 10-17（389 次）后回落。这种"单峰 + 断崖"更像**一次性事件**（课程/群/比赛截止/被转发），而不是镜像站爬虫（镜像通常是每日稳定基线）。
→ 若是真实事件流量：这 540 个人已经拿到了代码，只需在仓库页首屏加一句 ⭐ 就能转化。
→ 若是镜像/爬虫：转化率为零，不必再投入。
**必须先分清**，方法见 §4.3 的验证动作。

**(B) 有人看、星很少 —— 转化断点在"首屏说服力"**
- SecAutoMind：78 views / 2★（28 天窗口外累计），但 release 页有 13 次访问 → **"下载二进制"的需求被验证了，star 没被要求**。
- passive-recon：22 views / 7★，是唯一"看得进去"的项目（子页面有停留），但 README 首屏是一张 21 行的 Features 表，读者要滚 60 行才知道它跟 theHarvester/Amass 有什么区别。

### 1.2 "最值得包装的资产"排序（结论）

| 优先级 | 资产 | 理由 |
|---|---|---|
| ★★★ | **SecAutoMind**（含 -src） | 唯一有下载行为 + 唯一有 release 资产（8 个 tag × 4 assets）+ 与 bio 完全同频 |
| ★★★ | **passive-recon** | 唯一浏览→star 转化健康 + 品类搜索词清晰（passive recon / EASM / OSINT）+ 合规友好可公开演示 |
| ★★ | MARS-408 | 540 个真实 cloner 是账面上最硬的"需求证据"，但**领域（考研 408 教育）与 bio 冲突**，只适合做转化实验，不适合做门面 |
| ★ | xihu-ctf / 2026-CC | 有 clone 量，但 README 已自宣 FROZEN、且有硬伤（见 §2.4），先止血再谈包装 |
| ✗ | AGI-Distiller | 9★ 是账号最高，但 14 天 2 个 uniq 浏览、0 release、版权声明与 MIT 徽章互相打架，投入产出最差 |

---

## 2. 关键词一致性审计：外部看到的是谁？

### 2.1 四个"入口"各自在说什么

| 入口 | 实际关键词 | 与 bio 的关系 |
|---|---|---|
| **bio** | Agent systems engineer / LLM-MARL / LangGraph pipelines / adversarial red-team security / "Code first, buzzwords never" | 基准线：**工程师 + 多智能体 + 红队** |
| **profile README**（14.8KB） | `title: AI Agent Security **Product Manager**`、Governance、Roadmap、Stakeholder communication、"From Zero to One, From One to Secure"、10 个徽章 + 打字机 SVG + yaml 技能块 | **冲突**：身份是 PM，文本密度全是 buzzword |
| **blog**（appmiaoda 域名） | 实际落地页标题：**"芒得职训——AI 岗位胜任力智能服务平台"**，页面无 agent / security / CTF / MARL 任何字样 | **完全脱节**：这是职业培训产品页，不是技术主页 |
| **仓库命名 + topics** | MARS-408 / FDE / MangDeHenZhi / xuandun-cyber-range / xihu-sword-ctf-agent / pikachu / soft-skills-platform / physics-scheduler-agent；高频 topic：python 55、llm 21、mcp 18、ai-agents 17、cli 14、developer-tools 13、**security 仅 7** | **稀释**：命名无体系，topics 指向"泛 AI 工具开发者"，不是红队 |

**外部第一眼看到的关键词（按权重）**：AI Agent Security PM、Governance、MCP、Python、竞赛作品（Challenge Cup / 西湖论剑）、考研 408、职训平台。
**bio 宣称的**：Agent systems engineer、LLM-MARL、LangGraph、adversarial red-team。
**交集**：只有 "AI Agent" 一个词。**"红队安全"在外部几乎不可见——security 只占其 topics 的 7/300，且没有出现在任何一句首屏文案里。**

### 2.2 三处错位（核心）

**错位 1｜身份错位：对外是 PM，对内自认 engineer。**
profile README 第一屏就是 `title: AI Agent Security Product Manager` + `core_competencies: 产品全生命周期管理 / 跨职能团队领导 / 路线图规划 / 干系人沟通`。
一个招聘方或安全社区的人点进来，结论是"这是一个做 AI 安全产品的 PM，顺手写代码"；而 bio 说 "Agent systems engineer… Code first, buzzwords never"。
**最讽刺的一点**：全账号 buzzword 密度最高的文本，正是这句 "buzzwords never" 的主人的主页 README。

**错位 2｜招牌错位：bio 的三块招牌，没有一块有对应的门面仓库。**
- `LLM-MARL`：唯一带 MARL 的是 MARS-408（考研教育场景）和 marl-ecdsa（1★、无 topic、无 README 信号），两者都不是"安全 MARL"；
- `LangGraph pipelines`：MARS-408 的 topic 里有 `langgraph`，但它被归为教育项目，且 14 天 4 次浏览；
- `adversarial red-team security`：真实承载者是 SecAutoMind 与 xihu-ctf，前者被拆成"官网仓库(2★) + -src(1★)"两个入口，后者 README 顶部自宣 **FROZEN（2026-10-23，已被 SecAutoMind 吞并）**。
→ 访客顺着 bio 找证据，找到的是"冻结""源码备份""考研系统"。**bio 承诺的能力，在外部门面上没有一件是"活的、可跑、有版本"的。**

**错位 3｜入口错位：blog 指向一个与 bio 零重合的商业落地页。**
`blog=https://app-a7lm1eejtypt.appmiaoda.com` 打开是"芒得职训——AI 岗位胜任力智能服务平台"。这解释了 MangDeHenZhi（1,324 clone / 0 view）的来源假设：**它可能是这个培训产品的代码仓库，被学员直接 clone**。
后果：GitHub 上唯一的"官网入口"把人送去一个求职培训页，而人本来是想看 agent / 红队项目的。**这是全账号最贵的一个链接位，现在被浪费了。**（替代做法见 §4.4）

### 2.3 附带的一致性硬伤（不属于定位，但直接扣分）

| 位置 | 问题 |
|---|---|
| AGI-Distiller README 首行 | "© 2026 All Rights Reserved. **禁止复制、修改、分发、商用**" + 下一行 `License: MIT` 徽章 + 仓库 license 实际为 `NOASSERTION`。**三者互斥**，任何人看到都会判定"作者不懂开源许可" |
| xihu-sword-ctf-agent README 首屏 | FROZEN 横幅里写着本机路径 `E:\Program\SecAutoMind`；紧接着 3 层"口径更正 / Honesty disclaimer / 0 accepted flags / LLM autonomous solves = 0" | 诚实本身是加分项，但把**内部项目管理笔记**放在访客第一屏，等于把仓库当工作日志 |
| 全账号 | 26/42 无 license、29/42 无 topics、9 个无 description；160 个 fork 中 111 个已归档，仍占据公开仓库列表 | 搜索与推荐系统拿不到任何"这是个安全项目"的信号 |
| 语言 | 42 个原创仓库里 12 个中文 description，bio 全英文；README 中英混排且各仓库策略不一致 | 中文读者与英文读者的第一印象都是"这不是给我写的" |

---

## 3. 竞品对标：同赛道的人靠什么拿星

| 账号 / 仓库 | 规模 | 增长靠什么（可验证事实） | 对 TrueFurina 的启示 |
|---|---|---|---|
| **GreyDGL/PentestGPT** | 16.1k★ / 2.8k fork / 23 contributors | ① USENIX Security 2024 论文 + Distinguished Artifact；② 独立官网 pentestgpt.com（首屏就是 3 个大数字：16.1k★、228.6% 提升、HTB #900）；③ **两段 demo 视频**（install.cast / demo.cast，录的是从 Docker 起到拿 flag）；④ 首屏 benchmark 表（GPT-3.5 35% → GPT-4 47% → PentestGPT 80%）；⑤ 被多个 awesome 列表收录（同仓出现在 2 个 awesome list） | **"信任"由论文+视频+数字三件套构成**，README 只是索引。数字必须放在第一屏 |
| **vxcontrol/pentagi** | 32.4k★ / 5.0k fork | ① 2025-01 建仓，一年到 32k；② `git clone && docker compose up -d` 一条命令到 Web UI；③ 20+ 渗透工具 + 10+ LLM provider + Graphiti 知识图谱（**能力可数**）；④ 每 1–2 天发版；⑤ 被 agentlist / github.locker 等聚合站持续自动收录，日增 79–114★；⑥ 有公司实体与 licences 背书 | **"部署成本可数 + 版本节奏稳定"是安全工具的硬通货**；第三方聚合站是免费的持续曝光渠道 |
| **sansan0/TrendRadar** | 62.7k★ / 24.9k fork / 仅 3 contributors | ① 中文个人开发者，README 首句"最快 30 秒部署"；② Docker + 8 个推送渠道；③ 公众号"硅基茶水间"直接导流；④ fork/issue = 429:1 —— **典型"人人自己跑一份"的工具型项目**；⑤ 后接 MCP，蹭上新协议入口 | **中文个人开发者的最优路径不是论文，是"30 秒能跑 + 一个内容渠道"**；fork 数比 star 更能说明真实使用 |
| **PWhiddy/PokemonRedExperiments** | 7.9k★ / 787 fork | ① 一条 YouTube 视频（训练过程可视化，被澎湃等媒体转写）；② 实时全局地图（每个训练者都能看到自己那一格，天然传播）；③ 后续 arXiv 论文；④ Discord 社群 | **"过程可视化"比架构图更能传播**；把 agent 的推理过程录成 30 秒，就是最好的 demo |
| **punkpeye/awesome-mcp-servers** | 96.9k★，日均 +42★ | 不做工具，做**清单**，占住品类入口位 | 如果想快速拿"领域存在感"，做一个垂直清单（见 §4.4 Lists）比自己再写第 43 个仓库更快 |
| **NYU-LLM-CTF**（对照组） | 173★ / 162★ | benchmark + leaderboard + NeurIPS 论文，规模小但被全行业引用为基线 | **红队 agent 的"权威性"来自"你敢不敢上公开榜"**，不是来自 star 数 |

### 3.1 可直接抄的 3 个动作

1. **把可复现数字搬到首屏第一屏（抄 PentestGPT / PentAGI）。**
   SecAutoMind 现在写的是"91 条 YAML 配方 + 50+ 工具 + 4 agent"——这是**功能数**，不是**效果数**。做一张表：在 NYU_CTF_Bench 公开子集（该榜已公开 Claude/GPT 基线 22% / 19% / 13.5%）上跑 N 题，写 `pass@1`、平均 token、平均耗时、失败类型。**数字低没关系**——他 README 里已经在做"诚实 KPI"，这个风格在安全圈是稀缺资产，只要把诚实从"免责声明"改写成"对比表"。

2. **30 秒 gif + 一行命令（抄 TrendRadar 的"30 秒部署"、PentAGI 的 `docker compose up -d`）。**
   现状：全账号 **0 个 .gif**（AGI-Distiller / passive-recon / SecAutoMind-src / MARS-408 / physics-scheduler / cyber-terms 全部 0 个，只有静态 PNG）。SecAutoMind 已有 Go 单二进制 + 4 个 release assets，把 `docker run` 或 `./secautomind-ai --http` → 登录页 → 自然语言下指令 → **审批弹窗** 这条链路录成 30 秒，是当前成本最低、收益最高的一件事。

3. **一次中文渠道集中投放 + 进 2–3 个 awesome 清单（抄 TrendRadar 的公众号 / PentestGPT 的 awesome 收录）。**
   现状：referrers 全空 = **零外部导流**，所有流量都来自"有人直接搜到"或"有人直接拿到 URL"。
   动作：给 passive-recon 写一篇可复现实测长文（"纯被动 EASM 对某高校的一次完整资产发现"，附真实报告截图），投掘金 / 知乎 / 安全客，文末只放仓库链接；同时向 `awesome-osint`、`awesome-ai-security`、`awesome-security-tools` 提 PR（PentestGPT 就是靠这个持续吃长尾）。

---

## 4. 旗舰仓库方案（只做 2 个 + 1 个实验）

> 选型原则：**已有真实行为证据（下载/克隆/停留） > 现有 star 数**。star 可以刷，release 下载和 README 子页停留不能。

### 4.1 旗舰 A：SecAutoMind —— 合并品牌，做"红队 agent 唯一门面"

**为什么是它**：全账号唯一同时具备 ① 人工浏览最高（78 views / 23 uniq）② 下载行为（release 页 13 views / 7 uniq）③ 真实发版资产（8 个 tag，每个 4 个 assets）④ 与 bio 的 "adversarial red-team security" 完全同频。它现在的问题不是项目不行，是**同一个产品有三个身份**：`SecAutoMind`（HTML 官网，2★，0 topics）、`SecAutoMind-src`（Go 源码，1★，9 topics）、`xihu-sword-ctf-agent`（已自宣并入，5★）。

**README 改哪几段**
| 现在 | 改成 |
|---|---|
| 顶部 `<div align="center">` + 中英文切换 + 一个 CI 徽章 | 三行电梯稿：**一句话是什么 → 一行命令 → 一个能验证的数字**（例：`一条自然语言指令 → 4 agent 协作 → 91 个安全工具 → 全链路审计`；`docker run -p 8080:8080 ghcr.io/truefurina/secautomind`） |
| "Key Features" 6 条平铺（4-agent / decision / 90+ tools / HITL / 8 IM / lightweight） | **一张 vs PentAGI / PentestGPT 的能力对照表**（不贬低，只列差异：单机离线可跑 / HITL 审批粒度 / 审计链 / 是否需要 Docker 集群 / 是否支持国产模型）。差异化的真实卖点是 **"单二进制、离线、给国内乙方/甲方内网用"**，这一点 PentAGI（Go + Docker 集群 + 云 LLM）恰好不覆盖 |
| "8-channel IM integration"（DingTalk/Feishu/WeCom/Telegram/Slack/Discord/QQ/WeChat） | 删到一行 + 一张截图。8 个渠道是**集成清单**，不是卖点，占了首屏黄金位 |
| 缺少"效果"段落 | 新增 **Benchmark** 段：NYU_CTF_Bench 子集 pass@1 / token / 耗时 / 失败归因；以及 **安全边界** 段（HITL 触发条件、越权拦截率）——安全买家先看边界 |

**补什么素材**
1. **90 秒录屏**（必需）：自然语言下指令 → 规划树展开 → **审批弹窗出现并被拒绝一次** → 执行 → 报告。审批弹窗必须露脸，这是企业买家唯一关心的画面。
2. **架构图**（SVG 手绘风，别用自动生成）：4 agent + fact blackboard + 工具层 + 审计层，一张图。
3. **Benchmark 表**（见上）。
4. **安装体积对比**：`单二进制 30MB / 无需 Docker / 离线可用` —— 一句话打掉竞品的部署门槛。

**topics / release 打法**
- topics（`SecAutoMind-src` 现有 9 个偏学术，换成买家会搜的）：
  `ai-agent, autonomous-agents, red-team, penetration-testing, llm-security, prompt-injection, mcp, golang, security-automation, human-in-the-loop, ctf, self-hosted`
- release：现在 **8 个 tag 全部停在 2026-09-30**，而仓库 10-26 还在 push → **版本节奏断了，这是最伤的信号**（PentAGI 是 1–2 天一版）。恢复节奏：语义化 tag（`v1.8.0`）+ release notes 固定三段（`What's new / Breaking / Fixed`）+ 4 个 assets 保持（exe/linux/darwin + sha256）。
- 命名：把 `SecAutoMind-src` 改名为 `secautomind`，站点仓库 README 只留一句 "→ 主仓库在此"，或直接把站点仓库 archive。**一个产品只能有一个入口。**

### 4.2 旗舰 B：passive-recon —— 做"能被搜索到、能被读懂"的门面

**为什么是它**：22 views → 7★，是全账号唯一"浏览→star"效率正常的项目；子页面有真实停留（`README.zh-CN.md` 4 views、discussions 3、issues 2、releases 1）；品类搜索词明确（passive recon / EASM / OSINT / CTEM），且"零接触目标"这一定位在合规敏感的国内 B 端是**天然卖点**；已具备双语 README、CI、15 个 topics —— 底子最好，改造成本最低。

**README 改哪几段**
| 现在 | 改成 |
|---|---|
| 21 行 Features 表（从第 38 行开始，读者要滚很久） | **首屏只留 3 个能力**（15 源交叉验证 / 零接触 / 合规网关 fail-closed），其余折进 `<details>` |
| 缺"为什么不直接用 theHarvester / Amass / Shodan" | 新增 **Why not X** 对比表：4 行 × 4 列（是否被动、是否交叉验证、是否有合规闸门、是否出报告）。**这是本项目唯一的护城河，必须在前 30 行出现** |
| AI 能力（DeepSeek 域名推断 / 风险评分 / 自然语言问资产）排在第 60 行之后的表格里 | 提到 Quick Start 之后、Features 之前。**"agent" 是他的 bio 标签，但 README 里 AI 是附录** |
| Quick Start 两行 `pip install -r requirements.txt`（要求先 clone） | 一行可复制：`pipx install passive-recon && pr collect "Tsinghua University"`，或至少 `uvx --from git+https://github.com/TrueFurina/passive-recon pr collect ...` |

**补什么素材**
1. **60 秒 asciinema/gif**：一条命令 → 15 个数据源并行滚动 → 报告落盘 → 打开 HTML 面板。终端录屏比架构图有效 10 倍（这个项目卖点就是"跑起来很快"）。
2. **架构图**：15 源 → 交叉验证 → 风险评分 → 合规闸门 → 报告；标注"零出站到目标"。
3. **样例报告**（脱敏的 Markdown + 面板截图）放 GitHub Pages，`homepage` 字段现在指向仓库自己 —— **浪费了一个外链位**。
4. **一句免责/授权声明**放首屏底部（安全项目必备，也是专业度信号）。

**topics / release 打法**
- topics：保留 `passive-recon`，删掉过泛的 `python`/`security`，加 `osint-tool, attack-surface-management, external-attack-surface, threat-intelligence, llm-agent, deepseek, compliance`。
- release：现在只有 `v0.1.0`（2026-08-14，**0 个 assets**）。发 `v0.2.0`，assets 里放 **样例报告 zip + 数据源清单 CSV** —— 这是"不用装也能评估"的低门槛钩子。
- **License 必修**：README 徽章写 MIT，仓库 license 实际是 `NOASSERTION`（LICENSE 文件非标准文本）。安全工具被企业法务卡在这一步的概率极高，换成标准 MIT 全文。

### 4.3 实验位（不做旗舰）：MARS-408 的 540 个 cloner 怎么用

不解的问题：**540 个 unique cloner、4 次页面浏览** —— 这些人在哪拿到 URL 的？
- 验证动作（一周内可完成）：
  1. 在 `truefurina.github.io/MARS-408/` 落地页加一个短链 `?src=readme` / `?src=group`，分别投放到 README 与已知传播渠道；
  2. README 首屏加一行：`> 如果这个项目帮你省了时间，点个 ⭐ 让更多人找到它`（现在的 README 14966 字符，**没有一处求 star**）；
  3. 看 clones 日曲线是否随 push 波动：镜像爬虫是稳定基线，事件流量是单峰。当前曲线（10-18 峰值 2042 → 10-23 后 30/日）**更像事件**。
- 若确认为真实事件流量：把 15 秒 gif（LangGraph 规划 → 生成学习计划）放首屏，MARS-408 是唯一有 benchmark 段落的仓库，把表格提到第一屏。
- 仓库体积 111MB，clone 慢本身就是转化流失点，考虑瘦身/LFS。
- **但不要把它做成门面**：考研 408 教育项目与 "red-team agent engineer" 的定位互相稀释，它只适合当"证明我能交付完整系统"的旁证。

### 4.4 立项前先做的一件小事：把 blog 换成技术主页

现在 `blog` → "芒得职训——AI 岗位胜任力智能服务平台"。这是 GitHub 个人页唯一的站外入口，却把人送去培训产品页。
最小改法（不删产品）：新建一个单页（Pages 即可），结构 = 一句话定位 + 3 个旗舰卡片（带星标/下载数）+ 2 篇技术长文 + 联系方式；把 blog 字段指过去，芒得职训放到页面底部"我做过的产品"。
**同一份内容也是 §3.1 第 3 个动作（中文渠道投放）的落地页。**

### 4.5 可直接执行的 checklist

**P0（先做，影响"可信度"，与流量无关）**
- [ ] `SecAutoMind-src` 改名 `secautomind`，站点仓库 README 指向主仓 / 或 archive 站点仓 → 验收：搜索 "SecAutoMind" 只有一个主入口
- [ ] 修 AGI-Distiller 版权矛盾：删掉 "All Rights Reserved 禁止分发"，放标准 MIT 全文 → 验收：仓库页 license 显示 `MIT`
- [ ] passive-recon 换标准 MIT LICENSE 文件 → 验收：license 从 `NOASSERTION` 变 `MIT`
- [ ] 清 xihu-ctf README 首屏：删掉 `E:\Program\SecAutoMind` 本地路径，FROZEN 横幅压成一行，三层"口径更正"收进 `<details>` → 验收：首屏 5 行内能看懂"这是什么、为什么冻结、去哪了"
- [ ] 给 9 个无 description 仓库补一句话；给 29 个无 topics 仓库补 5–8 个 topics（优先 SecAutoMind、MangDeHenZhi、marl-ecdsa、2026-CC）→ 验收：42 个原创仓库 0 个空 description

**P1（旗舰 A：SecAutoMind）**
- [ ] 重写 README 首屏三行（是什么 / 一行命令 / 一个数字）
- [ ] 新增 vs PentAGI / PentestGPT 能力对照表（含"单机离线"差异）
- [ ] 录 90 秒 demo（必须含审批弹窗被拒绝一次）→ 转 gif 放首屏，mp4 挂 release
- [ ] 画架构图 SVG（4 agent + blackboard + 工具层 + 审计层）
- [ ] 跑 NYU_CTF_Bench 子集，出 benchmark 表（pass@1 / token / 耗时 / 失败归因）
- [ ] 补 12 个买家向 topics
- [ ] 发 `v1.8.0`，恢复 release notes 三段式，保持 4 assets
- [ ] 恢复发版节奏（当前断在 2026-09-30，最后一次 push 10-26）

**P2（旗舰 B：passive-recon）**
- [ ] 首屏只留 3 个能力，其余进 `<details>`
- [ ] 新增 "Why not theHarvester / Amass / Shodan" 4×4 对比表
- [ ] AI 能力段上移到 Quick Start 之后
- [ ] Quick Start 换成一行可复制命令
- [ ] 60 秒终端录屏 gif
- [ ] GitHub Pages 放脱敏样例报告，`homepage` 字段指过去（现在指向仓库自己）
- [ ] 发 `v0.2.0`，assets = 样例报告 zip + 数据源清单 CSV
- [ ] topics 增补 7 个

**P3（渠道，解决 referrers 全空）**
- [ ] 写 1 篇 passive-recon 实测长文 → 掘金 / 知乎 / 安全客（文末只放仓库链接）
- [ ] 向 3 个 awesome 清单提 PR（awesome-osint / awesome-ai-security / awesome-security-tools）
- [ ] 换掉 blog 字段，指向技术主页
- [ ] 每周把 release 同步到 2 个聚合站（agentlist / github.locker 这类会自动收录，PentAGI 日增 80+ 星有三成来自这里）

**验收总指标（30 天后回看 traffic）**
- SecAutoMind：views ≥ 200（当前 78/14d）、release 页访问 ≥ 50、新增 star ≥ 20
- passive-recon：views ≥ 80（当前 22/14d）、star ≥ 25
- referrers：从"全 404"变为至少 2 个非空来源

---

## 5. "star 自己 106 个仓库"：风险与替代

### 5.1 事实

- starred 快照 300 条中有 **106 条是自己的仓库（35%）**；补全后的 412 条快照中 120 条（29%）。
- 42 个原创仓库**累计总星 92**。自 star 条目数（106）**大于**全部原创仓库获得的星数（92）—— 也就是说，**账面上可展示的 92 颗星，与"自己点出来的星"是同一量级**，外界无法区分哪颗是真的。
- 叠加信号：`following 231 > followers 170`（典型 follow-for-follow 形态）；近 4 个月新建 38 个仓库（7 月 7、8 月 8、9 月 9、10 月 13）；5 天内 166 次 push + 49 次 PR（多为自建 PR）。

### 5.2 风险（按严重度）

1. **社区观感（最致命，且不可逆）**：任何人点开 Stars 标签，前几屏一半是自己。对**安全从业者**尤其致命——这个圈子对"伪造信号"零容忍，红队岗背调会看 GitHub。一旦被贴上 "star farming"，后续每个真实成绩都会被折价。
2. **被判定 star farming / inauthentic activity 的可能**：GitHub Acceptable Use Policies 明确禁止人为放大互动。**自 star 单独不会封号**，但它会与 follow-for-follow、批量建仓、自 PR 一起进入反滥用信号集。现实后果通常不是封号，而是：不出现在 Trending、搜索降权（shadowban）、被 awesome 列表维护者拒收、被第三方榜单（GitHub.Locker / GStars 这类）标注为低可信。
3. **自我伤害（最容易被忽略）**：他因此**失去了唯一可靠的需求信号**。本次审计里唯一硬证据是 MARS-408 的 540 个 unique cloner，而这个信号差点被"4 次浏览"埋掉。如果星数里混着自 star，他永远无法判断"到底哪个项目有人要"。

### 5.3 替代做法

| 想达到的目的 | 现在的做法 | 替代做法 |
|---|---|---|
| 让访客看到"我做过什么" | 自己 star 自己的仓库（污染 Stars 语义） | **置顶 6 个 repo**，按定位而非星数排序：`SecAutoMind` / `passive-recon` / `MARS-408` / `AGI-Distiller` / `cyber-terms-hub` / `xihu-sword-ctf-agent`。置顶是 GitHub 官方给的策展位，权重远高于 Stars 列表 |
| 收藏 / 归类自己的项目 | star 进 Stars（混在 300 条里） | **Lists**：建 3 个公开清单 —— ① `Red-team agents & papers`（收自己的 SecAutoMind、xihu-ctf + 竞品 PentestGPT/PentAGI 做对标，公开清单本身就是内容）② `MCP servers I actually run` ③ `MARL baselines`。Lists 可被搜索、可分享、长期沉淀，且不污染 star 语义 |
| 展示"项目受欢迎" | profile 徽章 `img.shields.io/github/stars/TrueFurina`（总星 92，含自 star） | 换成**下载/克隆/issue 数**这类不可自刷的指标：release 下载量、fork 数、外部 issue 数。93 个外部 star 里哪怕只有 30 个是真的，也比 92 个说不清来源的更值钱 |
| 建立"领域存在感" | 再建第 43 个仓库 | 做一份**垂直清单仓库**（如 `awesome-redteam-agents`），把竞品和自己的项目一起收录。punkpeye 靠一份清单拿到 96.9k★ —— 成本远低于造工具，且天然获得"领域守门人"位置 |

**清理节奏（不要一次性清空，避免 star 数剧烈波动引起注意）**：
1. 先 unstar **fork 仓库**（这部分最没有展示价值，且占 160 个位置）；
2. 再分批 unstar 原创仓库，每批间隔一两周，**保留 3–5 个作为"我个人最得意的作品"**（这个少量自 star 在社区里是常见且可接受的自我标注）；
3. 同步把 follow 数收敛到 ≤ follower 量级（当前 231 → 目标 ≤170）；
4. 把 111 个已归档 fork 从公开视野清掉（archive 状态仍在列表里占位，能删则删，需保留的转 private）。

---

## 附录：数据与口径

| 项 | 说明 |
|---|---|
| traffic 窗口 | 2026-10-14 ~ 2026-10-27，共 14 天；GitHub 只提供 14 天粒度 |
| 权限 | gho_ OAuth token（本人账号）具备 push 权限，views / clones / popular paths 全部 200；**referrers 对全部仓库 404** |
| 星数 vs 浏览量 | star 是累计值（含 2026-07 以来），views 只有 14 天，**两者不可直接相除**，文中只做相对排序 |
| clone 归因 | MARS-408 / MangDeHenZhi / xihu-ctf 的 clone 来源无法确证（referrers 为空）。日曲线形态（单峰 + 断崖）指向一次性事件流量；镜像站假设未能排除，故结论均标注为推断 |
| 未覆盖 | pinned repos 需 GraphQL（本次未取）；star 的来源账号无法枚举，故"自 star 比例"为快照计数，非逐条归因 |
