import json, os, subprocess, traceback, urllib.request, urllib.error

tok = subprocess.run(["powershell", "-NoProfile", "-Command",
                      "[Environment]::GetEnvironmentVariable('GITHUB_TOKEN','User')"],
                     capture_output=True, text=True).stdout.strip()
H = {"Authorization": "Bearer " + tok, "User-Agent": "github-audit/3",
     "Accept": "application/vnd.github+json"}

for url in ["https://api.github.com/user/repos?affiliation=owner&sort=pushed&per_page=100&page=1",
            "https://api.github.com/user/repos?per_page=100&page=1",
            "https://api.github.com/user/starred?per_page=100&page=2"]:
    print("==", url)
    try:
        req = urllib.request.Request(url, headers=H)
        with urllib.request.urlopen(req, timeout=60) as r:
            raw = r.read()
        print("OK", len(raw))
        d = json.loads(raw)
        print("items", len(d) if isinstance(d, list) else type(d))
    except Exception:
        traceback.print_exc(limit=6)
