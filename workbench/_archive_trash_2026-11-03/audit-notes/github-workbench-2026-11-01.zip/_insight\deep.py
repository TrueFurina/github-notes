"""贡献可行性核验：PR 合并率 / 外部贡献者占比 / 合并耗时 / CLA·DCO 线索。

数据口径：
  - 取最近 100 条「已关闭 PR」（state=closed, sort=updated desc）
  - 合并率 = merged_at 非空 / 100
  - 外部贡献者 = author_association ∈ {CONTRIBUTOR, FIRST_TIME_CONTRIBUTOR, NONE}
  - 合并耗时中位数 = merged PR 的 (merged_at - created_at)
  - CLA/DCO：抓 CONTRIBUTING 正文做关键词匹配（只作线索，不作结论）
"""
import base64
import json
import os
import re
import statistics
import time
import urllib.request
from datetime import datetime

TOKEN = os.environ["GITHUB_TOKEN"]
OUT = os.path.dirname(os.path.abspath(__file__))

REPOS = [
    "apache/airflow", "topoteretes/cognee", "rtk-ai/rtk", "nexu-io/open-design",
    "cvat-ai/cvat", "ueberdosis/tiptap", "aws/aws-cdk", "excalidraw/excalidraw",
    "OpenHands/OpenHands", "elastic/elasticsearch", "langgenius/dify", "grafana/grafana",
]

EXTERNAL = {"CONTRIBUTOR", "FIRST_TIME_CONTRIBUTOR", "MANNEQUIN", "NONE", None}
CLA_RE = re.compile(r"(CLA|Contributor License Agreement|DCO|Developer Certificate of Origin|"
                    r"sign[- ]?off|Signed-off-by)", re.I)


def get(path):
    req = urllib.request.Request("https://api.github.com" + path, headers={
        "Authorization": "Bearer " + TOKEN,
        "Accept": "application/vnd.github+json",
        "User-Agent": "insight-scout",
    })
    with urllib.request.urlopen(req, timeout=45) as r:
        return r.headers, json.loads(r.read().decode("utf-8"))


def contrib_text(full):
    hits = []
    for p in ("CONTRIBUTING.md", ".github/CONTRIBUTING.md", "docs/CONTRIBUTING.md"):
        try:
            _, js = get(f"/repos/{full}/contents/{p}")
            txt = base64.b64decode(js["content"]).decode("utf-8", "ignore")
            hits.append((p, CLA_RE.findall(txt)))
        except Exception:
            pass
    return hits


def parse(dt):
    return datetime.fromisoformat(dt.replace("Z", "+00:00"))


def main():
    rows = []
    for full in REPOS:
        rec = {"repo": full}
        try:
            _, pulls = get(f"/repos/{full}/pulls?state=closed&sort=updated&direction=desc&per_page=100")
        except Exception as e:
            rec["error"] = str(e)
            rows.append(rec)
            continue

        merged = [p for p in pulls if p.get("merged_at")]
        ext = [p for p in merged if p.get("author_association") in EXTERNAL]
        hours = []
        for p in merged:
            try:
                hours.append((parse(p["merged_at"]) - parse(p["created_at"]).replace(
                    tzinfo=parse(p["merged_at"]).tzinfo)).total_seconds() / 3600)
            except Exception:
                pass
        rec.update({
            "closed_sample": len(pulls),
            "merged": len(merged),
            "merge_rate": round(len(merged) / len(pulls), 3) if pulls else None,
            "external_merged": len(ext),
            "external_share": round(len(ext) / len(merged), 3) if merged else None,
            "median_merge_h": round(statistics.median(hours), 1) if hours else None,
        })

        hits = contrib_text(full)
        rec["contrib_files"] = [h[0] for h in hits]
        rec["cla_hits"] = sorted({w for _, ws in hits for w in ws})
        rec["requested_reviewers_sample"] = sum(1 for p in merged if p.get("requested_reviewers"))

        rows.append(rec)
        print(f"{full:<32} closed={rec['closed_sample']:>3} merged={rec['merged']:>3} "
              f"rate={rec['merge_rate']} 外部合并={rec['external_merged']} "
              f"({rec['external_share']}) 中位耗时={rec['median_merge_h']}h "
              f"CLA={rec['cla_hits']}")
        time.sleep(0.5)

    with open(os.path.join(OUT, "contribution_feasibility.json"), "w", encoding="utf-8") as f:
        json.dump(rows, f, ensure_ascii=False, indent=1)


if __name__ == "__main__":
    main()
