"""候选项目画像：可贡献度 + 活跃度（只读）。

对候选清单逐个取：
  - 仓库基础信息（星数 / 语言 / license / 归档 / 最后推送）
  - open good-first-issue 数量（分页 Link 取末页）
  - 近 30 天提交数（分页 Link 取末页）
  - 是否有 CONTRIBUTING（根目录或 .github）
  - 前 5 条 good first issue 标题（可直接上手的入口）
"""
import json
import os
import re
import time
import urllib.request
from datetime import datetime, timedelta, timezone

TOKEN = os.environ.get("GITHUB_TOKEN", "")
OUT = os.path.dirname(os.path.abspath(__file__))

CANDS = [
    # 可贡献型（good-first-issues / help-wanted 榜）
    "excalidraw/excalidraw", "nexu-io/open-design", "pytorch/pytorch", "oven-sh/bun",
    "OpenHands/OpenHands", "mermaid-js/mermaid", "rtk-ai/rtk", "elastic/elasticsearch",
    "swiftlang/swift", "tldr-pages/tldr", "FuelLabs/sway", "nuxt/nuxt",
    "microsoft/vscode", "microsoft/PowerToys", "golang/go", "kubernetes/kubernetes",
    "microsoft/TypeScript", "microsoft/terminal", "ant-design/ant-design",
    "storybookjs/storybook", "astral-sh/uv",
    # FastAPI / Python 生态
    "fastapi/fastapi", "fastapi/full-stack-fastapi-template", "fastapi/sqlmodel",
    "zhanymkanov/fastapi-best-practices", "headroomlabs-ai/headroom",
    "Evil0ctal/Douyin_TikTok_Download_API", "JoeanAmier/XHS-Downloader",
    "microsoft/markitdown", "yt-dlp/yt-dlp",
    # LLM / Agent
    "microsoft/autogen", "agentscope-ai/agentscope", "letta-ai/letta",
    "HKUDS/DeepCode", "lsdefine/GenericAgent", "The-Pocket/PocketFlow",
    "strands-agents/harness-sdk", "Mai-with-u/MaiBot", "NousResearch/hermes-agent",
    # 调度 / 优化 / OR
    "spotify/luigi", "agronholm/apscheduler", "Miksus/rocketry", "jobrunr/jobrunr",
    "Hexagon/croner", "google/or-tools", "ray-project/ray",
    # 中文社区
    "PDFMathTranslate/PDFMathTranslate", "modelscope/FunASR",
]


def api(path, raw=False):
    url = "https://api.github.com" + path
    req = urllib.request.Request(url, headers={
        "Authorization": "Bearer " + TOKEN,
        "Accept": "application/vnd.github+json",
        "User-Agent": "insight-scout",
    })
    with urllib.request.urlopen(req, timeout=45) as r:
        body = r.read().decode("utf-8")
        return r.headers.get("Link", ""), (body if raw else json.loads(body))


def next_url(link):
    m = re.search(r'<([^>]+)>; rel="next"', link or "")
    return m.group(1) if m else None


def count_list(path, max_pages=6):
    """按 Link rel="next" 翻页数条目（GitHub 只给 next，没有 last）。"""
    total, pages, url = 0, 0, "https://api.github.com" + path
    while url and pages < max_pages:
        req = urllib.request.Request(url, headers={
            "Authorization": "Bearer " + TOKEN,
            "Accept": "application/vnd.github+json",
            "User-Agent": "insight-scout",
        })
        with urllib.request.urlopen(req, timeout=45) as r:
            items = json.loads(r.read().decode("utf-8"))
            link = r.headers.get("Link", "")
        total += len(items)
        pages += 1
        if len(items) == 0:
            break
        url = next_url(link)
    return total


def main():
    import sys
    tag = "main"
    cands = CANDS
    if len(sys.argv) > 1:
        tag = sys.argv[1]
        with open(os.path.join(OUT, f"cands_{tag}.json"), encoding="utf-8") as f:
            cands = json.load(f)
    since = (datetime.now(timezone.utc) - timedelta(days=30)).strftime("%Y-%m-%dT%H:%M:%SZ")
    rows = []
    for full in cands:
        rec = {"repo": full}
        try:
            _, info = api(f"/repos/{full}")
            rec.update({
                "stars": info["stargazers_count"],
                "lang": info.get("language"),
                "license": (info.get("license") or {}).get("spdx_id"),
                "archived": info.get("archived"),
                "pushed": info.get("pushed_at"),
                "open_issues": info.get("open_issues_count"),
                "desc": (info.get("description") or "")[:140],
            })
        except Exception as e:
            rec["error"] = f"repo: {e}"
            rows.append(rec)
            continue

        try:
            rec["gfi"] = count_list(
                f"/repos/{full}/issues?state=open&labels=good%20first%20issue&per_page=100")
        except Exception:
            rec["gfi"] = -1

        try:
            rec["help_wanted"] = count_list(
                f"/repos/{full}/issues?state=open&labels=help%20wanted&per_page=100")
        except Exception:
            rec["help_wanted"] = -1

        try:
            rec["commits_30d"] = count_list(
                f"/repos/{full}/commits?since={since}&per_page=100", max_pages=3)
        except Exception:
            rec["commits_30d"] = -1

        rec["contributing"] = False
        for p in ("CONTRIBUTING.md", ".github/CONTRIBUTING.md", "CONTRIBUTING.rst"):
            try:
                api(f"/repos/{full}/contents/{p}")
                rec["contributing"] = True
                break
            except Exception:
                pass

        try:
            _, items = api(f"/repos/{full}/issues?state=open&labels=good%20first%20issue&per_page=5")
            rec["gfi_samples"] = [it["title"][:80] for it in items[:5]]
        except Exception:
            rec["gfi_samples"] = []

        rows.append(rec)
        print(f"{rec.get('stars', 0):>7} GFI={rec.get('gfi', -1):>4} 30d={rec.get('commits_30d', -1):>4} "
              f"{'C' if rec.get('contributing') else '-'} {full}")
        time.sleep(0.35)

    out_name = "candidates.json" if tag == "main" else f"candidates_{tag}.json"
    with open(os.path.join(OUT, out_name), "w", encoding="utf-8") as f:
        json.dump(rows, f, ensure_ascii=False, indent=1)
    print("\n候选数：", len(rows))


if __name__ == "__main__":
    main()
