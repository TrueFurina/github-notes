"""从 100 条里挑「新 + 少讨论 + 未分配」的，排除 workshop 预留与已 stale 的。"""
import json
import re
import os

rows = json.load(open(os.path.join(os.path.dirname(os.path.abspath(__file__)),
                                  "airflow_gfi_ranked.json"), encoding="utf-8"))
rows = [r for r in rows
        if r["created"] >= "2026-01-01" and r["comments"] <= 4 and not r["assigned"]
        and "reserved" not in (r["body_head"] or "").lower()]
rows.sort(key=lambda r: r["updated"], reverse=True)
for r in rows[:18]:
    print(f"#{r['number']:>7} {r['title'][:95]}")
    print(f"        created={r['created']} updated={r['updated']} c={r['comments']} "
          f"labels={[l for l in r['labels'] if l != 'good first issue']}")
    print(f"        paths={r['paths'][:3]}")
