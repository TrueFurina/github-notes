"""把 PR 分支压成「基于最新 master 的单个 DCO 签名 commit」。

维护者 10-09 说过 "Please rebase to master"，10-24 已压成单 commit；这次两处修复又多了 2 个
commit。这里用 Git Data API 重建分支：base = master head，tree = base tree + 两个文件，
commit 带 Signed-off-by，最后强制更新 ref。

    python squash.py          # 只打印将要做的事
    python squash.py --yes    # 执行
"""

import argparse
import base64
import json
import os
import sys
import urllib.request

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, r"D:/github/github-audit")
from ghlib import api, HEADERS  # noqa: E402

FORK = "TrueFurina/testing"
BRANCH = "feat/create-cluster-composite-action"
FILES = {
    ".github/actions/create-cluster/action.yml": "action.yml",
    ".github/actions/create-cluster/kind-config.yaml": "kind-config.yaml",
}
SIGNOFF = "Signed-off-by: Dream <2468001320@qq.com>"
MSG = ("feat: add reusable create-cluster (Kind) composite action\n\n"
       "Adds a composite action that creates a single-control-plane Kind cluster, exports\n"
       "KUBECONFIG for later steps, and lets callers pick the Kubernetes version. The node\n"
       "image follows kubernetes-version unless a pinned kind-node-image is supplied, so the\n"
       "server version under test cannot silently diverge from the requested one.\n\n"
       "Both YAML files carry the year-less Apache-2.0 boilerplate header required by\n"
       "hack/boilerplate (yaml/yml map to the sh template).\n\n" + SIGNOFF)


def _req(method, path, body=None):
    req = urllib.request.Request(
        "https://api.github.com" + path,
        data=json.dumps(body).encode("utf-8") if body else None,
        headers={**HEADERS, "Content-Type": "application/json"}, method=method)
    try:
        with urllib.request.urlopen(req, timeout=60) as r:
            return json.loads(r.read() or b"{}")
    except Exception as e:  # noqa: BLE001
        detail = getattr(e, "read", lambda: b"")()
        return {"__error": str(e), "detail": detail.decode("utf-8", "ignore")[:300]}


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--yes", action="store_true")
    a = ap.parse_args()

    base = api("/repos/kubeflow/testing/git/ref/heads/master")["object"]["sha"]
    base_commit = api(f"/repos/kubeflow/testing/git/commits/{base}")
    base_tree = base_commit["tree"]["sha"]
    cur = api(f"/repos/{FORK}/git/ref/heads/{BRANCH}")["object"]["sha"]
    print(f"master head : {base[:10]}")
    print(f"分支当前 head: {cur[:10]}")

    entries = []
    for path, local in FILES.items():
        text = open(os.path.join(HERE, local), encoding="utf-8").read()
        blob = _req("POST", f"/repos/{FORK}/git/blobs",
                    {"content": base64.b64encode(text.encode()).decode(), "encoding": "base64"})
        if blob.get("__error"):
            print("blob 失败:", blob)
            return 1
        entries.append({"path": path, "mode": "100644", "type": "blob", "sha": blob["sha"]})
        print(f"  blob {path} -> {blob['sha'][:10]}")

    if not a.yes:
        print("\n[试运行] 将创建 tree（base_tree=%s）+ 单个 commit + 强制更新 ref" % base_tree[:10])
        print("确认后加 --yes。")
        return 0

    tree = _req("POST", f"/repos/{FORK}/git/trees",
                {"base_tree": base_tree, "tree": entries})
    if tree.get("__error"):
        print("tree 失败:", tree)
        return 1
    commit = _req("POST", f"/repos/{FORK}/git/commits",
                  {"message": MSG, "tree": tree["sha"], "parents": [base]})
    if commit.get("__error"):
        print("commit 失败:", commit)
        return 1
    print("新 commit:", commit["sha"][:10], "（parent = master head，单 commit）")

    ref = _req("PATCH", f"/repos/{FORK}/git/refs/heads/{BRANCH}",
               {"sha": commit["sha"], "force": True})
    if ref.get("__error"):
        print("更新 ref 失败:", ref)
        return 1
    print("分支已指向:", ref["object"]["sha"][:10], f"（旧 head {cur[:10]} 可用此 sha 回滚）")
    return 0


if __name__ == "__main__":
    sys.exit(main())
