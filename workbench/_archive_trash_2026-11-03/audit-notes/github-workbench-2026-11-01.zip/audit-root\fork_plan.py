import json, collections

forks = json.load(open("forks.json", encoding="utf-8"))
ext = json.load(open("ext_prs.json", encoding="utf-8"))

# 目标上游（我的 PR 所在仓库）
pr_repos = collections.Counter()
for p in ext:
    fn = p["repository_url"].split("/repos/")[-1]
    pr_repos[fn.lower()] += 1

# 同时把本仓库内 PR 也算上（TencentCloud 等）
d = json.load(open("raw.json", encoding="utf-8"))
own_pr = collections.Counter()
prs_all = json.load(open("contrib.json", encoding="utf-8"))["prs"]
for p in prs_all:
    own_pr[p["repository_url"].split("/repos/")[-1].lower()] += 1

keep, drop = [], []
for f in forks:
    up = (f["upstream"] or "").lower()
    n = pr_repos.get(up, 0) + own_pr.get(up, 0)
    f["pr_count"] = n
    (keep if n > 0 else drop).append(f)

print("=== KEEP (有 PR 记录) ===")
for f in sorted(keep, key=lambda x: -x["pr_count"]):
    print(f'  PR={f["pr_count"]:2d}  {f["upstream"]:44s} {f["size_kb"]/1024:8.0f}MB *{f["up_stars"]}')

print(f"\nKEEP={len(keep)}  DROP={len(drop)}")
print("DROP total GB:", round(sum(x["size_kb"] for x in drop)/1e6, 2))

print("\n=== DROP 按体积 TOP20 ===")
for f in sorted(drop, key=lambda x: -x["size_kb"])[:20]:
    print(f'  {f["size_kb"]/1024:8.0f}MB  {f["name"]:34s} <- {f["upstream"]}')

print("\n=== DROP 语言分布 ===")
print(collections.Counter(f["up_lang"] or "None" for f in drop).most_common(10))

json.dump({"keep": keep, "drop": drop}, open("fork_plan.json","w",encoding="utf-8"), ensure_ascii=False, indent=1)