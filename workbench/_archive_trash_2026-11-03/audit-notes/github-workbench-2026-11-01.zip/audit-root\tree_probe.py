import json, subprocess, time, urllib.request, http.client, base64

TOKEN = subprocess.run(["powershell","-NoProfile","-Command",
    "[Environment]::GetEnvironmentVariable('GITHUB_TOKEN','User')"],
    capture_output=True, text=True).stdout.strip()
H = {"Authorization":"Bearer "+TOKEN,"User-Agent":"raccoon","Accept":"application/vnd.github+json","Connection":"close"}

def get(url):
    for i in range(3):
        try:
            r = urllib.request.Request(url, headers=H)
            with urllib.request.urlopen(r, timeout=40) as resp:
                parts=[]
                try:
                    while True:
                        b=resp.read(16384)
                        if not b: break
                        parts.append(b)
                except http.client.IncompleteRead as e:
                    parts.append(e.partial)
                return json.loads(b"".join(parts))
        except urllib.error.HTTPError as e:
            time.sleep(1.5)
        except Exception:
            time.sleep(1.5)
    return None

def tree(fn):
    r = get(f"https://api.github.com/repos/TrueFurina/{fn}/git/trees/HEAD?recursive=1")
    return (r or {}).get("tree", [])

for fn in ["AGI-Distiller","passive-recon","xihu-sword-ctf-agent","SecAutoMind-src","MARS-408"]:
    t = tree(fn)
    files=[x["path"] for x in t if x["type"]=="blob"]
    py=[f for f in files if f.endswith(".py")]
    tests=[f for f in files if "test" in f.lower() and f.endswith(".py")]
    docs=[f for f in files if f.lower().startswith(("docs/","doc/"))]
    print(f'\n=== {fn} === files={len(files)} py={len(py)} tests={len(tests)} docs={len(docs)}')
    # entry points
    entry=[f for f in files if f.split("/")[-1] in ("main.py","__main__.py","cli.py","app.py","run.py","pyproject.toml","setup.py","Dockerfile","requirements.txt")]
    print("  entry/packaging:", entry[:10])
    print("  top dirs:", sorted({f.split("/")[0] for f in files if "/" in f})[:14])
    # total LOC estimate via py file count
    print("  py sample:", [f for f in py][:10])