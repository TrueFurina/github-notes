"""GitHub 账号体检 · 只读单文件版。

把今晚零散的 verify 汇总成一条命令，可随时重跑（不写任何远端内容）：

    python health.py            # 完整体检
    python health.py --brief    # 只看结论行

检查项：
  1. 六个仓库的许可证是否与 README 声明一致
  2. 四个仓库的 Secret Scanning / Push Protection
  3. MARS-408 的 .env.test 是否仍在 HEAD
  4. Denia 的 CI 最近一次结论 + Release 资产
  5. open PR 数量与 mergeable_state 分布
  6. 主页是否残留 AI 工具水印、是否有可验证的贡献表
  7. marl-ecdsa 根 README 的 number_registry 链接是否可达
"""
import argparse
import base64
import sys
from collections import Counter

sys.path.insert(0, r"D:/github/github-audit")
from ghlib import api, api_all, api_raw, OWNER  # noqa: E402

OK, BAD, INFO = "PASS", "FAIL", "INFO"
results = []


def add(state, area, detail):
    results.append((state, area, detail))


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--brief", action="store_true")
    a = ap.parse_args()

    # 1. 许可证一致性
    expect = {
        "AGI-Distiller": "MIT",
        "passive-recon": "MIT",
        "DevRadar-GitHub-Trending-Monitor": "MIT",
        "pikachu": "Apache-2.0",
        "xuandun-cyber-range": "MIT",
        "2026-Challenge-Cup-Security-LLM-Triage-Agent": "MIT",
    }
    for repo, want in expect.items():
        got = (api(f"/repos/{OWNER}/{repo}").get("license") or {}).get("spdx_id")
        add(OK if got == want else BAD, "license", f"{repo}: {got}（期望 {want}）")

    # 1b. 全局不变量：公开仓不该再有"未登记"的自定义许可文本
    #     2026-08-16 那次批量写入的 752 字符 source-available 文本不被 GitHub 识别，
    #     等于仓库页上不显示任何许可标识。2026-10-30 已全部切到标准许可（0 个 NOASSERTION），
    #     所以允许清单清空——今后任何一个 NOASSERTION 都会直接 FAIL，而不是被"预期内"掩盖。
    ALLOW_NOASSERTION = set()
    own = [r for r in api_all("/user/repos?affiliation=owner&sort=pushed", per=25, cap=300)
           if not r["fork"] and not r["private"]]
    na = [(r["name"]) for r in own if (r.get("license") or {}).get("spdx_id") == "NOASSERTION"]
    unexpected = sorted(n for n in na if n not in ALLOW_NOASSERTION)
    add(BAD if unexpected else OK, "license",
        f"公开仓 NOASSERTION {len(na)} 个"
        + (f"，未登记：{unexpected}" if unexpected else "（全部在允许清单内）"))

    # 2. 密钥扫描
    for repo in ("SecAutoMind-src", "xihu-sword-ctf-agent", "aerorider-delivery", "win-appx-doctor"):
        sa = api(f"/repos/{OWNER}/{repo}").get("security_and_analysis") or {}
        scan = sa.get("secret_scanning", {}).get("status")
        push = sa.get("secret_scanning_push_protection", {}).get("status")
        add(OK if scan == push == "enabled" else BAD, "secret-scanning", f"{repo}: {scan}/{push}")

    # 3. .env.test
    r = api(f"/repos/{OWNER}/MARS-408/contents/py-server/iq_run_tmp/.env.test")
    gone = isinstance(r, dict) and "__error" in r
    add(INFO if gone else BAD, "secrets",
        "MARS-408 .env.test 已不在 HEAD（历史仍含旧值 → 需轮换密钥）" if gone
        else "MARS-408 .env.test 仍在仓库中")

    # 4. Denia CI + Release
    runs = (api(f"/repos/{OWNER}/Denia/actions/runs?per_page=1") or {}).get("workflow_runs") or []
    if runs:
        r0 = runs[0]
        add(OK if r0.get("conclusion") == "success" else INFO, "ci",
            f"Denia 最近一次 {r0['name']}: {r0['status']}/{r0.get('conclusion')} ({r0['head_sha'][:7]})")
    rel = api(f"/repos/{OWNER}/Denia/releases?per_page=1")
    if isinstance(rel, list) and rel:
        x = rel[0]
        size = sum(a["size"] for a in x.get("assets") or []) / 1048576
        add(OK if size > 0.1 else BAD, "release",
            f"Denia {x['tag_name']} 资产 {size:.2f}MB")
    else:
        add(BAD, "release", "Denia 没有 Release")

    # 5. open PR
    prs, page = [], 1
    while page <= 3:
        r = api(f"/search/issues?q=author:TrueFurina+type:pr+state:open&per_page=30&page={page}")
        got = (r or {}).get("items") or []
        prs.extend(got)
        if len(got) < 30:
            break
        page += 1
    total = len({(p["repository_url"], p["number"]) for p in prs})
    states = Counter()
    for p in prs[:40]:
        repo = p["repository_url"].split("/repos/")[-1]
        pr = api(f"/repos/{repo}/pulls/{p['number']}")
        if isinstance(pr, dict) and "__error" not in pr:
            states[pr.get("mergeable_state")] += 1
    add(INFO, "open-pr", f"{total} 个；mergeable_state {dict(states)}")

    # 6. 主页
    rd = base64.b64decode(api(f"/repos/{OWNER}/TrueFurina/contents/README.md")["content"]).decode("utf-8")
    add(BAD if "Trae AI Agent" in rd else OK, "profile",
        "残留 AI 工具水印" if "Trae AI Agent" in rd else "无水印")
    add(OK if "Selected upstream contributions" in rd else BAD, "profile",
        "有可验证的上游贡献表" if "Selected upstream contributions" in rd else "缺上游贡献表")

    # 7. marl-ecdsa 链接可达
    #    该文件 485KB，走 JSON 接口会被本机代理截断（表现为 FileNotFoundError，
    #    但**不是 404**），所以用 raw media type 直取正文。
    raw = api_raw(f"/repos/{OWNER}/marl-ecdsa/contents/marl-ecdsa-consensus-chain/number_registry.json")
    add(OK if raw and raw.lstrip().startswith(b"{") else BAD, "links",
        f"marl-ecdsa number_registry.json 可达（{len(raw) if raw else 0} bytes）")

    # 8. 谁在等你回话（今晚发现的最有信号的一项）
    #    mergeable_state 只说明"能不能合"，说明不了"为什么还没合"。
    #    这里找的是：我提的 open PR 里，最后一条评论来自别人（= 球在我这边）。
    BOTS = {"github-actions[bot]", "dependabot[bot]", "codecov[bot]", "coderabbitai[bot]",
            "copilot-pull-request-reviewer[bot]", "openshift-ci[bot]"}
    try:
        prs, page = [], 1
        while page <= 2:
            r = api(f"/search/issues?q=author:{OWNER}+type:pr+state:open"
                    f"&per_page=100&page={page}&sort=updated")
            items = (r or {}).get("items") or []
            prs.extend(items)
            if len(items) < 100:
                break
            page += 1
        waiting = []
        for p in prs:
            if (p.get("comments") or 0) == 0:
                continue
            repo = p["repository_url"].split("/repos/")[-1]
            cs = api(f"/repos/{repo}/issues/{p['number']}/comments?per_page=100")
            if not isinstance(cs, list) or not cs:
                continue
            if cs[-1]["user"]["login"] == OWNER:
                continue
            who = cs[-1]["user"]["login"]
            if who in BOTS or who.endswith("[bot]"):
                continue
            # 单字符/表情之类的 drive-by 评论不算"在等你"（实测遇到过只回 "D" 的）
            if len((cs[-1].get("body") or "").strip()) < 5:
                continue
            waiting.append(f"{repo}#{p['number']}({who}, {cs[-1]['created_at'][:10]})")
        add(INFO if waiting else OK, "waiting",
            f"在等回话 {len(waiting)} 个: {', '.join(waiting[:4])}" if waiting
            else f"在等回话 0 个（{len(prs)} 个 open PR 里没有他人最后发言）")
    except RuntimeError as e:
        add(INFO, "waiting", f"扫描跳过（网络）：{str(e)[:60]}")

    # 输出
    print("=" * 78)
    print("GitHub 体检 ·", OWNER)
    print("=" * 78)
    if not a.brief:
        for state, area, detail in results:
            print(f"  [{state:4}] {area:15} {detail}")
    bad = [r for r in results if r[0] == BAD]
    print(f"\nPASS {sum(1 for r in results if r[0] == OK)} | INFO {sum(1 for r in results if r[0] == INFO)} | FAIL {len(bad)}")
    if bad:
        print("需要处理:")
        for _, area, detail in bad:
            print("  -", area, detail)
    return 1 if bad else 0


if __name__ == "__main__":
    sys.exit(main())
