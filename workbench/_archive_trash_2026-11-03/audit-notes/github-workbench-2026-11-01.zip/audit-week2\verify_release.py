"""核验 Denia 首个 Release 是否真的产出了可下载包。"""
import sys

sys.path.insert(0, r"D:/github/github-audit")
from ghlib import api, OWNER  # noqa: E402

rel = api(f"/repos/{OWNER}/Denia/releases")
if not isinstance(rel, list) or not rel:
    print("[FAIL] 还没有任何 Release")
    sys.exit(1)

for x in rel[:3]:
    assets = x.get("assets") or []
    total = sum(a["size"] for a in assets)
    state = "OK" if any(a["size"] > 100_000 for a in assets) else "FAIL"
    print(f"[{state}] {x['tag_name']:10} {x['name']!r:20} assets={len(assets)} "
          f"总大小={total/1024/1024:.1f}MB draft={x['draft']} pre={x['prerelease']}")
    for a in assets:
        print(f"        - {a['name']}  {a['size']/1024/1024:.2f}MB  下载 {a['download_count']} 次")
    print(f"        {x['html_url']}")
