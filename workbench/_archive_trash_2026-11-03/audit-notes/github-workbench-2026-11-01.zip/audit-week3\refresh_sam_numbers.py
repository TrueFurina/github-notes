"""Refresh the hardcoded corpus numbers in SecAutoMind-src PR #74 materials.

Truth values reported by the repo's own gates (live tree counts):
    go_files 882 -> 884
    test_files 379 -> 380
    non_test_lines 142432 -> 142556
    test_lines 56365 -> 56515
    total_lines 198797 -> 199071

Each file gets explicit literal/regex patterns. A file that yields zero changes
is reported (anchor miss) instead of being written blind.
"""

import base64
import json
import re
import sys
import urllib.request

sys.path.insert(0, r"D:/github/github-audit")
from ghlib import HEADERS, OWNER, api

REPO = f"{OWNER}/SecAutoMind-src"
BRANCH = "feature/llm-concurrency-guard"

LITERALS = [
    ("142,432", "142,556"),
    ("142432", "142556"),
    ("379 测试", "380 测试"),
    # 门禁报告里显示的是渲染后的文本（"379  自动化测试文件"），
    # 但源码里是 <div class="num">379</div><div class="lbl">自动化测试文件
    ('>379</div><div class="lbl">自动化测试文件', '>380</div><div class="lbl">自动化测试文件'),
]

# JSON: only the exact keys, never a bare number sweep.
JSON_KEYS = [
    ("go_files", "882", "884"),
    ("test_files", "379", "380"),
    ("non_test_lines", "142432", "142556"),
    ("test_lines", "56365", "56515"),
    ("total_lines", "198797", "199071"),
]

FILES = [
    "SecAutoMind_PPT/make_champion_ppt.py",
    "SecAutoMind_PPT/make_final_ppt.py",
    "SecAutoMind_PPT/SecAutoMind_PPT制作脚本_纯文字版.md",
    "官网/index.html",
    "docs/evidence-package.json",
]


def patch_text(text, is_json):
    out, hits = text, 0
    if is_json:
        for key, old, new in JSON_KEYS:
            pat = re.compile(r'("%s"\s*:\s*)%s(\s*[,}\]])' % (re.escape(key), re.escape(old)))
            out, n = pat.subn(lambda m: m.group(1) + new + m.group(2), out)
            hits += n
            print(f"      {key}: {old} -> {new}  ({n} 处)")
        return out, hits

    counts = {}
    for old, new in LITERALS:
        n = out.count(old)
        if n:
            out = out.replace(old, new)
            counts[old] = n
            hits += n
    print("      ", counts or "（无命中）")
    return out, hits


def put(path, text, sha, message):
    body = {"message": message, "branch": BRANCH,
            "content": base64.b64encode(text.encode("utf-8")).decode(), "sha": sha}
    from urllib.parse import quote
    url = f"https://api.github.com/repos/{REPO}/contents/" + quote(path, safe="/")
    req = urllib.request.Request(
        url,
        data=json.dumps(body, ensure_ascii=False).encode("utf-8"),
        headers={**HEADERS, "Content-Type": "application/json; charset=utf-8"},
        method="PUT")
    try:
        with urllib.request.urlopen(req, timeout=120) as r:
            return r.status, json.loads(r.read())["commit"]["sha"][:12]
    except urllib.error.HTTPError as e:
        return e.code, e.read().decode("utf-8", "ignore")[:250]


def main():
    dry = "--yes" not in sys.argv
    total = 0
    for path in FILES:
        cur = api(f"/repos/{REPO}/contents/{path}?ref={BRANCH}")
        if "__error" in cur:
            print(f"[{path}] 读不到: {cur}")
            continue
        text = base64.b64decode(cur["content"]).decode("utf-8")
        is_json = path.endswith(".json")
        print(f"[{path}]")
        new, hits = patch_text(text, is_json)
        total += hits
        if hits == 0 or new == text:
            print("      -> 无改动，跳过")
            continue
        if is_json:  # 结构必须仍然合法
            try:
                json.loads(new)
            except ValueError as e:
                print("      -> JSON 解析失败，跳过:", e)
                continue
        if dry:
            continue
        st, res = put(path, new, cur["sha"],
                      "docs(evidence): refresh corpus counts after adding the LLMGuard feature\n\n"
                      "The gates compare material numbers against the live tree. Adding 2 files moved\n"
                      "go_files 882->884, test_files 379->380, non_test_lines 142432->142556,\n"
                      "test_lines 56365->56515, total_lines 198797->199071.")
        print(f"      HTTP {st} {res}")
    print(f"\n共 {total} 处替换  {'（dry-run，加 --yes 写入）' if dry else '（已写入）'}")


if __name__ == "__main__":
    main()
