import sys, base64, json, collections
sys.path.insert(0, r'D:/github/github-audit')
from ghlib import api
rd = api('/repos/TrueFurina/TrueFurina/readme')
t = base64.b64decode(rd['content']).decode('utf-8','ignore') if rd.get('content') else str(rd)
print('PROFILE README len', len(t)); print(t[:3000])
print('=====')
d = json.load(open('raw.json',encoding='utf-8'))
own=[x for x in d['repos'] if not x.get('fork')]
print('own', len(own))
c=collections.Counter(x['created_at'][:7] for x in own)
print('created by month:', sorted(c.items()))
print('archived own:', sum(1 for x in own if x.get('archived')))
st=d['starred']
self_star=[x for x in st if x['owner']['login'].lower()=='truefurina']
print('starred total', len(st), 'self', len(self_star))
print('self starred names:', [x['name'] for x in self_star][:40])
ev=d['events']
print('events types', collections.Counter(e['type'] for e in ev))
print('event span', ev[-1]['created_at'], ev[0]['created_at'])
