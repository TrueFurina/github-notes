import sys, json, time
sys.path.insert(0, r"D:/github/github-audit")
from ghlib import api, OWNER

allprs = []
total = None
for page in range(1, 30):
    got = None
    for attempt in range(4):
        r = api(f"/search/issues?q=author:{OWNER}+type:pr&per_page=30&sort=created&order=desc&page={page}", tries=2)
        if isinstance(r, dict) and "items" in r:
            got = r
            break
        print("retry page", page, attempt, str(r)[:120])
        time.sleep(5)
    if not got:
        print("FAILED page", page)
        break
    total = got["total_count"]
    allprs.extend(got["items"])
    print("page", page, "acc", len(allprs), "/", total, flush=True)
    if len(got["items"]) < 30 or len(allprs) >= total:
        break
    time.sleep(6.5)

print("DONE", len(allprs), "of", total)
json.dump({"total": total, "items": allprs}, open(r"D:/github/github-audit/_collab_all_prs.json", "w", encoding="utf-8"), ensure_ascii=False)
