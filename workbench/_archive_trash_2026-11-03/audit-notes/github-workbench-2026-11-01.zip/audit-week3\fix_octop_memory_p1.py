"""Apply the maintainer's P1 fix to octop-memory #29.

Bosheng0422 reproduced it (2026-10-27, head 689bb4f): the extraction cursor is
persisted *before* candidates are written, so a failed candidate INSERT leaves
the events marked as extracted, they are skipped forever, and a plain retry
cannot recover them.

Their prescribed minimal fix (verified in a temp copy, 7 new assertions,
48 existing tests still passing):
  - next_seen = seen | {event ids}
  - with backend.transaction(): add_candidates(...); _persist_seen_ids(next_seen)
  - let the cursor write fail loudly inside the transaction
  - advance the in-memory `seen` only after the commit
"""

import base64
import json
import sys
import urllib.request

sys.path.insert(0, r"D:/github/github-audit")
from ghlib import HEADERS, api, api_raw

REPO = "TencentCloud/octop-memory"
BRANCH = "fix/memory-batch-extract"      # 先探测真实分支名
FILE = "src/octop_memory/application/runtime.py"

OLD_COMMIT = '''        seen.update(e.id for e in new_events)
        # Persist the cursor so a restart resumes incrementally instead of
        # re-feeding the whole session backlog (#25).
        self._persist_seen_ids(session_id, seen)
        response["candidates"] = len(result.candidates)
        if result.candidates:
            self._memory.add_candidates(result.candidates)'''

NEW_COMMIT = '''        # Candidates and the extraction cursor must commit in ONE transaction.
        # Previously the cursor was persisted first, so a failed candidate write
        # left those events marked as extracted: they were skipped forever and a
        # plain retry could not recover them (#25 review, P1).
        next_seen = seen | {e.id for e in new_events}
        with self._memory.backend.transaction():
            if result.candidates:
                self._memory.add_candidates(result.candidates)
            self._persist_seen_ids(session_id, next_seen, strict=True)
        seen.update(next_seen)
        response["candidates"] = len(result.candidates)'''

OLD_PERSIST = '''    def _persist_seen_ids(self, session_id: str, seen: set[str]) -> None:
        """Persist the extracted-id set so a restart resumes incrementally."""
        try:
            self._memory.set_meta(
                f"{_EXTRACTED_IDS_META_PREFIX}{session_id}",
                json.dumps(sorted(seen), ensure_ascii=False),
            )
        except REPORTABLE_ERRORS:  # pragma: no cover - observability, never load-bearing
            # Persistence is an optimization; a write failure must not fail
            # extraction (the in-memory set still advances this process).
            logger.warning("failed to persist extracted ids", exc_info=True)'''

NEW_PERSIST = '''    def _persist_seen_ids(self, session_id: str, seen: set[str], *,
                          strict: bool = False) -> None:
        """Persist the extracted-id set so a restart resumes incrementally.

        ``strict`` is used on the incremental extraction path: there the write
        must fail loudly so the surrounding transaction also rolls back the
        candidate writes, instead of advancing the cursor past events that were
        never stored (#25 review).
        """
        try:
            self._memory.set_meta(
                f"{_EXTRACTED_IDS_META_PREFIX}{session_id}",
                json.dumps(sorted(seen), ensure_ascii=False),
            )
        except REPORTABLE_ERRORS:
            if strict:
                raise
            # Non-strict callers treat persistence as an optimization: the
            # in-memory set still advances, and a restart simply re-extracts.
            logger.warning("failed to persist extracted ids", exc_info=True)'''


def put(path, text, sha, branch, message):
    body = {"message": message, "branch": branch,
            "content": base64.b64encode(text.encode("utf-8")).decode(), "sha": sha}
    req = urllib.request.Request(
        f"https://api.github.com/repos/{REPO}/contents/{path}",
        data=json.dumps(body, ensure_ascii=False).encode("utf-8"),
        headers={**HEADERS, "Content-Type": "application/json; charset=utf-8"},
        method="PUT")
    try:
        with urllib.request.urlopen(req, timeout=120) as r:
            return r.status, json.loads(r.read())["commit"]["sha"][:12]
    except urllib.error.HTTPError as e:
        return e.code, e.read().decode("utf-8", "ignore")[:300]


def main():
    global REPO
    dry = "--yes" not in sys.argv
    pr = api(f"/repos/{REPO}/pulls/29")
    branch = pr["head"]["ref"]
    head_sha = pr["head"]["sha"]
    head_repo = pr["head"]["repo"]["full_name"]
    print("branch:", branch, "| head:", head_sha[:10])

    cur = api(f"/repos/{head_repo}/contents/{FILE}?ref={head_sha}")
    if "__error" in cur:
        print("读不到:", cur); return 1
    text = base64.b64decode(cur["content"]).decode("utf-8")

    if OLD_COMMIT not in text:
        print("!!! 提交顺序锚点未命中")
        i = text.find("seen.update(e.id for e in new_events)")
        print("  context:", repr(text[max(0, i - 60):i + 400]))
        return 1
    if OLD_PERSIST not in text:
        print("!!! _persist_seen_ids 锚点未命中")
        return 1

    new = text.replace(OLD_COMMIT, NEW_COMMIT, 1).replace(OLD_PERSIST, NEW_PERSIST, 1)
    try:
        compile(new, FILE, "exec")
        print("语法检查: OK")
    except SyntaxError as e:
        print("语法错误:", e.lineno, e.msg); return 1

    print(f"runtime.py {len(text)} -> {len(new)} 字符 "
          f"(+{len(new.splitlines()) - len(text.splitlines())} 行)")
    if dry:
        print("dry-run")
        return 0

    REPO = head_repo
    st, res = put(FILE, new, cur["sha"], branch,
                  "fix(memory): commit candidates and the extraction cursor atomically (#25 review)\n\n"
                  "P1 reproduced by @Bosheng0422: the cursor was persisted before candidates were\n"
                  "written, so a failed candidate INSERT still advanced the cursor -- those events\n"
                  "were skipped permanently and a plain retry could not recover them.\n\n"
                  "Now both writes share one backend transaction, the cursor write raises inside it\n"
                  "(strict=True instead of being swallowed), and the in-memory seen set advances\n"
                  "only after the commit.")
    print("HTTP", st, res)
    return 0 if st == 200 else 1


if __name__ == "__main__":
    sys.exit(main())
