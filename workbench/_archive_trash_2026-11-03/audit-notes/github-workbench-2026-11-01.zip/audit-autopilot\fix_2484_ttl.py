"""把 `Octop #2484` 的 active-turn TTL 从 30 秒改成 900 秒（方案 B）。

依据（见 autopilot/REVIEW-2484-1031.md）：
    ws_channel.py 里没有任何心跳（grep asyncio.sleep|heartbeat|keepalive 零匹配），
    turn 期间只在有 chunk 时推帧，`awaiting_tools`（工具执行中）完全不推。
    于是 30 秒阈值会把正在跑的工具调用判成孤儿，而 `is_turn_active()` 又被
    chat/ws.py:130 用于重连时的 turn_status.active —— 界面会报"空闲"。

改法：只改默认阈值 + 补注释，不动逻辑。900 秒仍能治"泄漏几天"这种量级的问题，
但不会误杀一次正常的慢工具调用。

用法：python autopilot/fix_2484_ttl.py [--yes]
"""
from __future__ import annotations

import base64
import json
import os
import sys
import urllib.error
import urllib.request
from urllib.parse import quote

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from ghlib import HEADERS, api  # noqa: E402

PR = 2484
UPSTREAM = "TencentCloud/Octop"
PATH = "src/octop/infra/gateway/ws/ws_hub.py"

OLD = '    def evict_stale_turns(self, max_quiet_seconds: float = 30.0) -> int:'
NEW = '    def evict_stale_turns(self, max_quiet_seconds: float = 900.0) -> int:'

OLD_DOC = '''        A drop-frame (disconnect, process crash, task cancellation) leaves the
        ``finally`` block in ``WebSocketChannel.handle_inbound`` unreachable,
        so ``mark_turn_idle`` never runs. Repeated calls to this method (lazily
        from :meth:`is_turn_active`) heal the flag leak so that clients no
        longer see ``turn_active=true`` on a fully-idle thread (issue #2456).
        """'''
NEW_DOC = '''        A drop-frame (disconnect, process crash, task cancellation) leaves the
        ``finally`` block in ``WebSocketChannel.handle_inbound`` unreachable,
        so ``mark_turn_idle`` never runs. Repeated calls to this method (lazily
        from :meth:`is_turn_active`) heal the flag leak so that clients no
        longer see ``turn_active=true`` on a fully-idle thread (issue #2456).

        The default is deliberately loose (15 min): ``ws_channel`` pushes frames
        only when the processor emits a chunk, and the ``awaiting_tools`` phase
        is completely silent — a single slow shell/MCP call can exceed a short
        TTL. ``is_turn_active()`` feeds the ``turn_status`` frame sent on
        reconnect (``chat/ws.py``), so evicting a live turn would actively
        report "idle" while it is still running. 15 min still heals a genuine
        leak, without racing normal tool latency. Tighten this only after a
        heartbeat frame exists.
        """'''
NEW_DOC_B = '''        A drop-frame (disconnect, process crash, task cancellation) leaves the
        ``finally`` block in ``WebSocketChannel.handle_inbound`` unreachable,
        so ``mark_turn_idle`` never runs. Repeated calls to this method (lazily
        from :meth:`is_turn_active`) heal the flag leak so that clients no
        longer see ``turn_active=true`` on a fully-idle thread (issue #2456).

        The default is deliberately loose (15 min): ``ws_channel`` pushes frames
        only when the processor emits a chunk, and the ``awaiting_tools`` phase
        is completely silent - a single slow shell/MCP call can exceed a short
        TTL. ``is_turn_active()`` feeds the ``turn_status`` frame sent on
        reconnect (``chat/ws.py``), so evicting a live turn would actively
        report "idle" while it is still running. 15 min still heals a genuine
        leak without racing normal tool latency. Tighten this only after a
        heartbeat frame exists.
        """'''


def main() -> int:
    dry = "--yes" not in sys.argv

    d = api(f"/repos/{UPSTREAM}/pulls/{PR}")
    head_repo = d["head"]["repo"]["full_name"]
    branch = d["head"]["ref"]
    print(f"PR #{PR}: {head_repo} @ {branch} (head {d['head']['sha'][:8]})")

    cur = api(f"/repos/{head_repo}/contents/{quote(PATH, safe='/')}?ref={branch}")
    if not (isinstance(cur, dict) and cur.get("content")):
        print("读不到文件:", cur)
        return 1
    text = base64.b64decode(cur["content"]).decode("utf-8")

    if "max_quiet_seconds: float = 900.0" in text:
        print("已经是 900.0，无需改动")
        return 0
    if OLD not in text:
        print("锚点未命中：")
        for ln in text.splitlines():
            if "max_quiet_seconds" in ln:
                print("  实际:", repr(ln))
        return 1

    new = text.replace(OLD, NEW, 1)
    if OLD_DOC in new:
        new = new.replace(OLD_DOC, NEW_DOC, 1)
    elif NEW_DOC_B in new:
        pass
    else:
        print("  [WARN] docstring 锚点未命中，只改默认值")

    added = len(new.splitlines()) - len(text.splitlines())
    print(f"改动：默认值 30.0 → 900.0；docstring 补充依据（{added:+d} 行）")

    if dry:
        print("\n这是 dry-run。加 --yes 写入。")
        return 0

    body = {"message": "fix(gateway): raise active-turn TTL to 15 min\n\n"
                       "30s races normal tool latency: ws_channel pushes frames only when the\n"
                       "processor emits a chunk, and awaiting_tools is silent, so a single slow\n"
                       "shell/MCP call can look like an orphan. is_turn_active() feeds the\n"
                       "turn_status frame sent on reconnect, so evicting a live turn reports\n"
                       "\"idle\" while it is still running. 15 min still heals a genuine leak;\n"
                       "tighten once a heartbeat frame exists.",
            "content": base64.b64encode(new.encode("utf-8")).decode(),
            "sha": cur["sha"], "branch": branch}
    req = urllib.request.Request(
        f"https://api.github.com/repos/{head_repo}/contents/{quote(PATH, safe='/')}",
        data=json.dumps(body).encode("utf-8"),
        headers={**HEADERS, "Content-Type": "application/json; charset=utf-8"},
        method="PUT")
    try:
        with urllib.request.urlopen(req, timeout=90) as r:
            print("写入 HTTP", r.status, json.loads(r.read())["commit"]["sha"][:12])
    except urllib.error.HTTPError as e:
        print("失败", e.code, e.read().decode("utf-8", "ignore")[:240])
        return 1
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
