import json, collections, datetime as dt

forks = {f["upstream"].lower(): f for f in json.load(open("forks.json", encoding="utf-8"))}
ext = json.load(open("ext_prs.json", encoding="utf-8"))
prs_all = json.load(open("contrib.json", encoding="utf-8"))["prs"]
TODAY = dt.date(2026, 10, 28)

def fn(p): return p["repository_url"].split("/repos/")[-1].lower()
def merged(p): return bool(p.get("pull_request",{}).get("merged_at"))

open_prs = collections.defaultdict(list)
for p in ext + prs_all:
    if p["state"] == "open" and not merged(p):
        open_prs[fn(p)].append(p)

rows = []
for up, ps in open_prs.items():
    f = forks.get(up)
    if not f: continue
    newest = max(p["created_at"] for p in ps)
    age = (TODAY - dt.date.fromisoformat(newest[:10])).days
    rows.append({"upstream": up, "size_mb": round(f["size_kb"]/1024), "open": len(ps),
                 "newest": newest[:10], "age": age, "stars": f["up_stars"], "fork": f["name"]})

stale = [r for r in rows if r["age"] > 45]
fresh = [r for r in rows if r["age"] <= 45]
print(f"有未关闭 PR 的上游: {len(rows)}")
print(f"  活跃 (<45天): {len(fresh)}  体积 {sum(r['size_mb'] for r in fresh)}MB")
print(f"  停滞 (>45天): {len(stale)}  体积 {sum(r['size_mb'] for r in stale)}MB")

print("\n=== 停滞 PR（建议先关 PR 再删 fork）===")
for r in sorted(stale, key=lambda x: -x["size_mb"]):
    print(f'  {r["size_mb"]:6d}MB {r["upstream"]:42s} *{r["stars"]:6d} open={r["open"]} 最新={r["newest"]} ({r["age"]}天)')

print("\n=== 活跃 PR（保留 fork）===")
for r in sorted(fresh, key=lambda x: -x["size_mb"]):
    print(f'  {r["size_mb"]:6d}MB {r["upstream"]:42s} *{r["stars"]:6d} open={r["open"]} 最新={r["newest"]} ({r["age"]}天)')

json.dump({"stale":stale,"fresh":fresh}, open("pr_age.json","w",encoding="utf-8"), ensure_ascii=False, indent=1)