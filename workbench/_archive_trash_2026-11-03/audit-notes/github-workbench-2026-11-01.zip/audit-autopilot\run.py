"""Autopilot 巡检器 · 一次运行做完"确定性"的部分，把判断留给 agent。

设计原则
--------
1. **只读**：除 `snapshots/`、`LEDGER.md` 两个本地文件外不写任何东西，不碰远端。
   任何远端写入都必须由 agent 在明确授权范围内单独执行，并记进 LEDGER。
2. **失败不中断**：每个检查独立 try/except，单项坏了打 `[ERR]` 继续跑，不让一次网络抖动
   让整轮挂机白跑。
3. **可对比**：每轮存一份 JSON 快照，自动和上一份 diff，只报告"变了什么"。
   在多会话并行改同一个账号的情况下，"变化"比"现状"更有信息量。

用法
----
    python autopilot/run.py            # 全量（约 2–4 分钟）
    python autopilot/run.py --quick    # 跳过死链扫描（约 40 秒）
"""
from __future__ import annotations

import base64
import json
import os
import re
import sys
import time
import traceback
import urllib.parse
from datetime import datetime

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.dirname(HERE)
sys.path.insert(0, ROOT)

from ghlib import api, api_all, api_raw, tree_paths, OWNER  # noqa: E402

SNAP_DIR = os.path.join(HERE, "snapshots")
LEDGER = os.path.join(HERE, "LEDGER.md")
DEADLINKS = os.path.join(HERE, "deadlinks.json")
HISTORY = os.path.join(HERE, "history.jsonl")   # 每轮追加一行，用于画增长曲线
DETAILS = os.path.join(HERE, "octop_details.json")

BOTS = {
    "github-actions", "github-actions[bot]", "dependabot", "dependabot[bot]",
    "codecov", "codecov[bot]", "coderabbitai", "coderabbitai[bot]",
    "openshift-ci-robot", "openshift-merge-robot", "k8s-ci-robot",
    "tide", "prow", "google-cla", "CLAassistant", "vercel",
}
TRIO = ["TencentCloud/Octop", "TencentCloud/octop-harness", "TencentCloud/octop-memory"]
KEY_REPOS = ["Denia", "xihu-sword-ctf-agent", "SecAutoMind-src"]
LINK_SCAN_MAX_MB = 30          # 超过这个体积跳过死链扫描（tree 接口会失败，BFS 太慢）
LINK_SCAN_MAX_REPOS = 40
DUPE_MAX_PRS = 25              # 重复检测只看最近 N 个（每个 PR 要拉一次 files，实测 160 个要 9 分钟）

out_lines: list[str] = []


def say(s: str = "") -> None:
    print(s)
    out_lines.append(s)


def section(title: str) -> None:
    say("")
    say("=" * 74)
    say(title)
    say("=" * 74)


def guard(name: str, fn, default=None):
    """跑一个检查；抛异常就记 [ERR] 并返回 default。"""
    try:
        return fn()
    except Exception as e:  # noqa: BLE001
        say(f"  [ERR] {name}: {type(e).__name__}: {str(e)[:160]}")
        if os.environ.get("AUTOPILOT_TRACE"):
            traceback.print_exc()
        return default


# ---------------------------------------------------------------- 基础数据
def own_repos() -> list[dict]:
    repos = api_all("/user/repos?affiliation=owner&sort=pushed", per=25, cap=400)
    return [r for r in repos if not r.get("fork")]


def license_stats(repos: list[dict]) -> dict:
    dist: dict[str, int] = {}
    for r in repos:
        if r["private"]:
            continue
        key = (r.get("license") or {}).get("spdx_id") or "NONE"
        dist[key] = dist.get(key, 0) + 1
    return dist


def open_pr_total() -> int:
    r = api(f"/search/issues?q=author:{OWNER}+type:pr+state:open&per_page=1")
    return (r or {}).get("total_count") or 0


def paged_concurrent(path: str, pages: int = 18, per: int = 20) -> list[dict]:
    """并发分页。串行版（api_all）拉 319 个 open PR 要 3 分钟，并发后约 40 秒。

    这台机器经代理访问 API，单次 1.2–1.6s；页数一多，串行就是纯等待。
    单页失败只影响这一页（降档到 10 重试一次），不拖垮整体。
    """
    from concurrent.futures import ThreadPoolExecutor

    def one(page: int):
        for size in (per, 10):
            try:
                sep = "&" if "?" in path else "?"
                chunk = api(f"{path}{sep}per_page={size}&page={page}")
                return chunk if isinstance(chunk, list) else []
            except Exception:  # noqa: BLE001
                continue
        return []

    out: dict[int, dict] = {}
    with ThreadPoolExecutor(max_workers=8) as ex:
        for chunk in ex.map(one, range(1, pages + 1)):
            for p in chunk:
                out[p["number"]] = p
    return list(out.values())


def trio_prs() -> list[dict]:
    rows = []
    for repo in TRIO:
        prs = paged_concurrent(f"/repos/{repo}/pulls?state=open")
        for p in prs:
            if (p.get("user") or {}).get("login") != OWNER:
                continue
            rows.append({
                "repo": repo, "num": p["number"], "title": p["title"][:90],
                "state": p.get("mergeable_state") or "-",
                "created": p["created_at"][:10], "updated": p["updated_at"][:10],
                "head": p["head"]["sha"][:8],
            })
    return rows


# ---------------------------------------------------------------- 检查 1：谁在等你
def last_speaker(repo: str, num: int) -> tuple[str, str, str]:
    cs = api(f"/repos/{repo}/issues/{num}/comments?per_page=100") or []
    cs = cs if isinstance(cs, list) else []
    for c in reversed(cs):
        login = (c.get("user") or {}).get("login") or ""
        if login in BOTS or login.endswith("[bot]"):
            continue
        body = (c.get("body") or "").strip()
        if len(body) < 5:
            continue
        return login, c.get("created_at", "")[:16], body[:180].replace("\n", " ")
    return "", "", ""


def check_waiting() -> list[dict]:
    found = []
    # PR：author 是自己、state=open、有评论的才去查最后一条
    items, page = [], 1
    while page <= 2:
        r = api(f"/search/issues?q=author:{OWNER}+type:pr+state:open&per_page=100&page={page}")
        got = (r or {}).get("items") or []
        items.extend(got)
        if len(got) < 100:
            break
        page += 1
    # Issue：自己开的、还开着、有评论的
    r = api(f"/search/issues?q=author:{OWNER}+type:issue+state:open&per_page=50&sort=updated")
    targets = [("pr", it) for it in items if it.get("comments")]
    targets += [("issue", it) for it in ((r or {}).get("items") or [])[:40] if it.get("comments")]

    # 并发拉"最后一条评论"：串行时这一项占掉整轮一半时间（每个 PR 一次请求）。
    from concurrent.futures import ThreadPoolExecutor

    def probe(pair):
        kind, it = pair
        repo = it["repository_url"].split("/repos/")[-1]
        who, when, body = last_speaker(repo, it["number"])
        return kind, it, repo, who, when, body

    def safe(pair):
        try:
            return probe(pair)
        except Exception:  # noqa: BLE001
            kind, it = pair
            return kind, it, it["repository_url"].split("/repos/")[-1], "", "", ""

    with ThreadPoolExecutor(max_workers=8) as ex:
        results = list(ex.map(safe, targets))
    for kind, it, repo, who, when, body in results:
        if who and who != OWNER:
            found.append({"kind": kind, "repo": repo, "num": it["number"],
                          "title": it["title"][:80], "by": who, "at": when, "body": body})
    return found


# ---------------------------------------------------------------- 检查 2：重复 PR
def check_dupes(prs: list[dict]) -> list[dict]:
    """同一文件被 2 个以上 open PR 触碰 → 候选，不是结论。

    实测教训（2026-10-30）：同一会话会"一个文件拆成多个窄修复"连发 PR
    （#2627/#2628/#2629 都是 manager.py 里的 suppress(Exception) 收窄，间隔 1 分钟，
    段段不同）。只看文件重叠会把它们报成重复。所以这里附上标题，并按标题相似度
    给一个初判：`疑似同一修复` / `同文件并行修复` —— 最终仍要人（或 agent）读 diff。
    """
    import difflib

    pool = [p for p in prs if p["created"] >= iso_days_ago(10)]
    pool.sort(key=lambda p: p["created"], reverse=True)
    fmap: dict[tuple[str, str], list[dict]] = {}
    for p in pool[:DUPE_MAX_PRS]:
        fl = api(f"/repos/{p['repo']}/pulls/{p['num']}/files?per_page=50") or []
        for f in (fl if isinstance(fl, list) else []):
            fmap.setdefault((p["repo"], f["filename"]), []).append(
                {"num": p["num"], "title": p["title"], "created": p["created"]})
    out = []
    for (repo, path), items in fmap.items():
        if len(items) < 2:
            continue
        items.sort(key=lambda x: x["created"])
        sim = 0.0
        if len(items) == 2:
            sim = difflib.SequenceMatcher(None, items[0]["title"], items[1]["title"]).ratio()
        else:
            sim = difflib.SequenceMatcher(
                None, items[0]["title"], items[-1]["title"]).ratio()
        out.append({"repo": repo, "path": path,
                    "prs": [i["num"] for i in items],
                    "titles": [i["title"] for i in items],
                    "verdict": "疑似同一修复" if sim >= 0.80 else "同文件并行修复（分段不同）"})
    out.sort(key=lambda x: -len(x["prs"]))
    return out


def iso_days_ago(n: int) -> str:
    from datetime import timedelta
    return (datetime.now() - timedelta(days=n)).strftime("%Y-%m-%d")


# ---------------------------------------------------------------- 检查 3：死链与徽章
MD_LINK = re.compile(r"(?<!\!)\[([^\]]{0,80})\]\(([^)\s]{1,300})\)")
BADGE_WF = re.compile(r"actions/workflows/([^/\s)]+)/badge")
# 行内代码里的路径：`docs/xxx.md`、`tools/check_all.py`、`number_registry.json`
# 这是"写了路径但点不开"的高发区（marl-ecdsa 的 number_registry.json 就属于这类：
# 不是 markdown 链接，而是正文里的 `xxx.json`，所以链接扫描抓不到）。
CODE_SPAN = re.compile(r"`([^`\n]{2,120})`")
PATHISH = re.compile(r"^[\w\u4e00-\u9fa5][\w\u4e00-\u9fa5./\-]*$")
PATH_EXT = (".md", ".py", ".json", ".yml", ".yaml", ".toml", ".txt", ".html",
            ".sh", ".ps1", ".bat", ".js", ".ts", ".go", ".ini", ".cfg", ".nsi")
# 行内路径的"高精度"子集：只留文档/源码类，且必须带目录。
# 上一版不限类型，31 个仓报出 137 条，绝大多数是运行时产物（data/*.db、output/、
# dist/）和评分分数（`10/15`）、外部仓引用（`torvalds/linux`）——噪音太多就无法行动。
DOC_EXT = (".md", ".html", ".py", ".nsi", ".sh", ".ps1")
RUNTIME_DIRS = ("data/", "output/", "dist/", "logs/", "tmp/", "workspace/",
                ".cache/", "回收站", "build/", "node_modules/")


def check_links(repos: list[dict]) -> dict:
    """README 里的相对链接是否指向真实存在的文件；徽章指向的 workflow 是否真实存在。"""
    dead, bad_badge, skipped, inline, style = [], [], [], [], []
    pool = [r for r in repos if not r["private"]]
    pool.sort(key=lambda r: r["size"])
    scanned = 0
    for r in pool:
        if scanned >= LINK_SCAN_MAX_REPOS:
            break
        name = r["name"]
        if r["size"] / 1024 > LINK_SCAN_MAX_MB:
            skipped.append(f"{name}（{r['size'] // 1024}MB）")
            continue
        rd = guard(f"readme {name}", lambda: api(f"/repos/{OWNER}/{name}/readme"), None)
        if not (isinstance(rd, dict) and rd.get("content")):
            continue
        try:
            text = base64.b64decode(rd["content"]).decode("utf-8", "ignore")
        except Exception:  # noqa: BLE001
            continue
        scanned += 1
        paths = guard(f"tree {name}", lambda: tree_paths(name), None)
        pathset = set(paths or [])

        # 3a 徽章 → workflow 文件
        for wf in set(BADGE_WF.findall(text)):
            key = f".github/workflows/{wf}"
            hit = api(f"/repos/{OWNER}/{name}/contents/{urllib.parse.quote(key, safe='/')}")
            if isinstance(hit, dict) and ("__error" in hit or not hit.get("sha")):
                bad_badge.append({"repo": name, "workflow": key})

        def exists(t: str) -> bool:
            if not t:
                return True
            t = t.rstrip("/")
            if t in pathset:
                return True
            return any(p.startswith(t + "/") for p in pathset)

        # 3b markdown 相对链接（高置信度：点了就是 404）
        if not pathset:
            continue
        for _label, target in MD_LINK.findall(text):
            t = target.strip()
            if not t or t.startswith(("#", "http://", "https://", "mailto:", "tel:")):
                continue
            t = urllib.parse.unquote(t.split("#")[0].split("?")[0])
            while t.startswith("./"):      # ./LICENSE 与 LICENSE 是同一个文件
                t = t[2:]
            t = t.lstrip("/")
            if not t or t in (".", "..") or t.startswith("../"):
                continue
            if not exists(t):
                dead.append({"repo": name, "link": t})

        # 3c 「见 `xxx`」类承诺：README 指名让人去看某个文件，那文件必须存在。
        # 只查行内代码**不是**链接，所以不能当死链报；但"让你去看的文件不在"是真问题
        # （marl-ecdsa 的 `number_registry.json` 当初就属这类：写在正文，点开 404）。
        for m in CODE_SPAN.finditer(text):
            s = m.group(1).strip()
            ctx = text[max(0, m.start() - 14):m.start()]
            if not re.search(r"(见|详见|参见|参考|详见文档|入口在)", ctx):
                continue
            # 假阳性 1：这个 span 是 markdown 链接的显示文本（紧随其后就是 "](..."），
            # 真正的目标在链接里，已经由 3b 校验过。
            if text[m.end():m.end() + 2] == "](":
                continue
            # 假阳性 2：命令行里的脚本路径（python scripts/x.py），相对于子目录而非仓库根。
            if re.search(r"(python|pip|node|uv|[a-z]sh)\s+$", ctx):
                continue
            if not PATHISH.match(s) or len(s) < 4:
                continue
            if s.startswith(("http", "-", "~", "!", "#", ">", "$", "\\")):
                continue
            if "..." in s or "<" in s or "*" in s or "|" in s:
                continue
            if re.match(r"^\d+\.\d+/", s) or re.match(r"^\d+/\d+$", s):
                continue
            if not (("/" in s) or s.endswith(PATH_EXT)):
                continue
            while s.startswith("./"):
                s = s[2:]
            s = s.lstrip("/").rstrip("/")
            if not s or s.lower().startswith(RUNTIME_DIRS) or exists(s):
                continue
            # 同名文件存在于别的目录 → 不是断链，只是"相对子目录"的写法（如 README 在根、
            # 但脚本在 ctf_agent/scripts/ 下）。单列为风格项，不算缺失。
            base = s.rsplit("/", 1)[-1]
            if any(p.rsplit("/", 1)[-1] == base for p in pathset):
                style.append({"repo": name, "path": s})
                continue
            inline.append({"repo": name, "path": s})
    return {"dead": dead, "bad_badge": bad_badge, "skipped": skipped,
            "scanned": scanned, "inline": inline, "style": style}


# ---------------------------------------------------------------- 检查 4：关键仓 CI
def check_ci() -> dict:
    res = {}
    for repo in KEY_REPOS:
        runs = api(f"/repos/{OWNER}/{repo}/actions/runs?per_page=3")
        wf = (runs or {}).get("workflow_runs") or []
        if wf:
            r = wf[0]
            res[repo] = {"name": r["name"], "status": r["status"],
                         "conclusion": r.get("conclusion"), "sha": r["head_sha"][:7],
                         "at": r["created_at"][:16], "url": r["html_url"]}
        rel = api(f"/repos/{OWNER}/{repo}/releases?per_page=1")
        if isinstance(rel, list) and rel:
            res.setdefault(repo, {})["release"] = {
                "tag": rel[0]["tag_name"],
                "assets": [(a["name"], round(a["size"] / 1048576, 2)) for a in rel[0]["assets"]],
            }
    return res


# ---------------------------------------------------------------- 快照与 diff
def snapshot_path() -> str:
    return os.path.join(SNAP_DIR, "latest.json")


def load_prev() -> dict:
    p = snapshot_path()
    if not os.path.exists(p):
        return {}
    try:
        return json.load(open(p, encoding="utf-8"))
    except Exception:  # noqa: BLE001
        return {}


def diff_scalars(prev: dict, cur: dict) -> list[str]:
    lines = []
    for k, v in cur.items():
        if k in ("at", "quick"):      # 时间戳不是"变化"，跳过
            continue
        if isinstance(v, (int, float, str)) and k in prev and prev[k] != v:
            lines.append(f"{k}: {prev[k]} → {v}")
    return lines


def diff_list(key: str, prev: list, cur: list, keyfn=None) -> list[str]:
    def k(x):
        return json.dumps(x, sort_keys=True, ensure_ascii=False) if keyfn is None else keyfn(x)
    prev_keys = {k(x) for x in (prev or [])}
    new = [x for x in (cur or []) if k(x) not in prev_keys]
    if new:
        return [f"{key} 新增 {len(new)} 条"]
    return []


def main() -> int:
    fast = "--fast" in sys.argv          # 跳过死链与重复检测，约 90 秒
    quick = fast or "--quick" in sys.argv
    t0 = time.time()
    say(f"Autopilot 巡检 · {datetime.now().strftime('%Y-%m-%d %H:%M')} · 模式={'quick' if quick else 'full'}")

    repos = guard("own_repos", own_repos, []) or []
    say(f"自有仓 {len(repos)} 个（公开 {sum(1 for r in repos if not r['private'])}）")

    # 单独重扫重复 PR 用：python autopilot/run.py --dupes
    if "--dupes" in sys.argv:
        section("重复 / 冲突 PR（只跑这一项）")
        prs = guard("trio_prs", trio_prs, []) or []
        dupes = guard("dupes", lambda: check_dupes(prs), []) or []
        say(f"  本人 open {len(prs)} 个 | 重叠组 {len(dupes)}")
        for d in dupes:
            say(f"    {d['repo'].split('/')[-1]:14} {d['path'][:46]:46} "
                f"← {', '.join('#%d' % n for n in d['prs'])}  【{d['verdict']}】")
            for t in d["titles"][:3]:
                say(f"        {t[:80]}")
        say(f"\n耗时 {time.time() - t0:.1f}s")
        return 0

    # 单独重扫死链用：python autopilot/run.py --links
    if "--links" in sys.argv:
        section("README 死链 / 徽章")
        links = guard("links", lambda: check_links(repos), {}) or {}
        say(f"  扫描 {links.get('scanned', 0)} 仓，跳过 {len(links.get('skipped', []))}："
            f"{', '.join(links.get('skipped', [])[:4])}")
        say(f"  死链 {len(links.get('dead', []))} 条")
        for d in links.get("dead") or []:
            say(f"    {d['repo'][:30]:30} → {d['link'][:70]}")
        say(f"  徽章指向缺失 {len(links.get('bad_badge', []))} 条")
        for b in links.get("bad_badge") or []:
            say(f"    {b['repo'][:30]:30} → {b['workflow']}")
        inl = links.get("inline") or []
        sty = links.get("style") or []
        say(f"  「见 xxx」但文件不存在 {len(inl)} 条"
            f"（另有 {len(sty)} 条只是相对子目录写法，不算问题）")
        for x in inl[:20]:
            say(f"    {x['repo'][:28]:28} → {x['path'][:66]}")
        json.dump(links.get("dead") or [], open(DEADLINKS, "w", encoding="utf-8"),
                  ensure_ascii=False, indent=1)
        say(f"\n耗时 {time.time() - t0:.1f}s")
        return 0

    snap: dict = {"at": datetime.now().isoformat(timespec="seconds"), "quick": quick}

    section("1. 账号面")
    snap["open_pr"] = guard("open_pr", open_pr_total, -1)
    snap["licenses"] = guard("licenses", lambda: license_stats(repos), {})
    noassert = [r["name"] for r in repos
                if not r["private"] and (r.get("license") or {}).get("spdx_id") == "NOASSERTION"]
    snap["noassertion"] = noassert
    say(f"  open PR        {snap['open_pr']}")
    say(f"  许可分布       {snap['licenses']}")
    say(f"  NOASSERTION    {noassert or '0 个（干净）'}")

    section("2. 谁在等你（PR + Issue）")
    waiting = guard("waiting", check_waiting, []) or []
    snap["waiting"] = waiting
    say(f"  需要你回话     {len(waiting)} 个")
    for w in waiting:
        say(f"    [{w['kind']}] {w['repo']}#{w['num']} 由 {w['by']} 于 {w['at']}")
        say(f"        {w['title']}")
        say(f"        「{w['body'][:120]}」")

    section("3. 重复 / 冲突 PR（Octop 三仓）")
    prs = guard("trio_prs", trio_prs, []) or []
    if fast:
        dupes = []
        say("  （--fast：跳过文件重叠检测，只保留数量）")
    else:
        dupes = guard("dupes", lambda: check_dupes(prs), []) or []
    snap["trio_open"] = len(prs)
    snap["trio_keys"] = [f"{p['repo']}#{p['num']}" for p in prs]
    snap["dupes"] = dupes
    say(f"  本人 open      {len(prs)} 个")
    say(f"  文件重叠组     {len(dupes)} 组")
    for d in dupes[:8]:
        nums = ", ".join(f"#{n}" for n in d["prs"])
        say(f"    {d['repo'].split('/')[-1]:14} {d['path'][:46]:46} ← {nums}  【{d['verdict']}】")
        if d["verdict"].startswith("疑似"):
            for t in d["titles"][:3]:
                say(f"        {t[:78]}")

    section("4. 关键仓 CI / Release")
    ci = guard("ci", check_ci, {}) or {}
    snap["ci"] = ci
    for repo, v in ci.items():
        say(f"  {repo:22} {v.get('name', '-'):6} {v.get('status', '-'):10} "
            f"{str(v.get('conclusion')):9} {v.get('sha', ''):8} {v.get('at', '')}")
        if v.get("release"):
            say(f"  {'':22} release {v['release']['tag']} assets={v['release']['assets']}")

    if quick:
        say("\n  （--quick/--fast：跳过死链扫描）")
        snap["links"] = {"skipped": ["--quick"]}
    else:
        section("5. README 死链 / 徽章（只扫 <30MB 的公开仓）")
        links = guard("links", lambda: check_links(repos), {}) or {}
        snap["links"] = links
        say(f"  扫描仓数       {links.get('scanned', 0)}"
            f"（跳过 {len(links.get('skipped', []))}：{', '.join(links.get('skipped', [])[:4]) or '无'}）")
        say(f"  死链           {len(links.get('dead', []))} 条")
        for d in (links.get("dead") or [])[:15]:
            say(f"    {d['repo'][:28]:28} → {d['link'][:70]}")
        say(f"  徽章指向缺失   {len(links.get('bad_badge', []))} 条")
        for b in (links.get("bad_badge") or [])[:10]:
            say(f"    {b['repo'][:28]:28} → {b['workflow']}")

    # ------------------------------------------------------------ diff
    section("6. 与上一轮相比（变化优先于现状）")
    prev = load_prev()
    changes: list[str] = []
    if not prev:
        say("  首轮快照，无基线")
    else:
        say(f"  上一轮：{prev.get('at', '?')}")
        changes += diff_scalars(prev, snap)
        for key in ("waiting", "noassertion"):
            changes += diff_list(key, prev.get(key) or [], snap.get(key) or [])
        # dupes 里带标题，标题变化不该算"新增"；只比 repo+path+PR 号
        changes += diff_list("dupes", prev.get("dupes") or [], snap.get("dupes") or [],
                             keyfn=lambda d: f"{d.get('repo')}|{d.get('path')}|{d.get('prs')}")
        pv = ((prev.get("links") or {}).get("dead") or [])
        cv = (snap.get("links") or {}).get("dead") or []
        if pv or cv:
            changes += diff_list("dead", pv, cv)
        pc = prev.get("ci") or {}
        for repo, v in (snap.get("ci") or {}).items():
            old = (pc.get(repo) or {}).get("conclusion")
            if old and old != v.get("conclusion"):
                changes.append(f"CI {repo}: {old} → {v.get('conclusion')}")
        for c in changes:
            say(f"  · {c}")
        if not changes:
            say("  无变化")

        # 增长速率预警：数量本身没意义，"每轮新增多少"才是
        d_trio = (snap.get("trio_open") or 0) - (prev.get("trio_open") or 0)
        if prev.get("at") and d_trio > 8:
            try:
                t0p = datetime.fromisoformat(prev["at"])
                hours = max((datetime.now() - t0p).total_seconds() / 3600, 0.05)
                say(f"  [ALERT] trio 本轮 +{d_trio}（{hours:.1f}h，约 {d_trio / hours:.0f} 个/小时）")
                say("          → 这个速率下 PR 列表已失去可读性，维护者侧会被读成 flooding。")
                say("          → 不新增 PR、不关闭；只在报告里如实记录速率。")
            except Exception:  # noqa: BLE001
                say(f"  [ALERT] trio 本轮 +{d_trio}")

    # ------------------------------------------------------------ 落盘
    if not quick:
        try:
            json.dump(snap.get("links", {}).get("dead") or [],
                      open(DEADLINKS, "w", encoding="utf-8"), ensure_ascii=False, indent=1)
        except Exception:  # noqa: BLE001
            pass
    try:
        os.makedirs(SNAP_DIR, exist_ok=True)
        json.dump(snap, open(snapshot_path(), "w", encoding="utf-8"),
                  ensure_ascii=False, indent=1)
    except Exception as e:  # noqa: BLE001
        say(f"  [ERR] 写快照: {e}")

    # ------------------------------------------------------------ 历史与增速
    section("7. 队列增速（这个账号最该被追踪的量）")
    hist = []
    if os.path.exists(HISTORY):
        for ln in open(HISTORY, encoding="utf-8"):
            try:
                hist.append(json.loads(ln))
            except Exception:  # noqa: BLE001
                pass
    now_row = {"at": snap["at"], "open_pr": snap.get("open_pr"),
               "trio_open": snap.get("trio_open"), "waiting": len(waiting),
               "dupes": len(dupes), "dead": len((snap.get("links") or {}).get("dead") or [])}
    try:
        with open(HISTORY, "a", encoding="utf-8") as fh:
            fh.write(json.dumps(now_row, ensure_ascii=False) + "\n")
    except Exception as e:  # noqa: BLE001
        say(f"  [ERR] 写历史: {e}")

    # 缓存里 mergeable=true 的数量（来自 octop_review.py，可能略旧，标明即可）
    # 只统计本轮仍在 open 集合里的 PR：旧快照里的已关闭条目会让这个数字虚高
    mergeable_n = None
    stale_n = 0
    try:
        det = json.load(open(DETAILS, encoding="utf-8"))
        open_keys = set(snap.get("trio_keys") or [])
        if open_keys:
            hit = {k: v for k, v in det.items() if k in open_keys}
            stale_n = sum(1 for k in open_keys if k not in det)
            mine = [v for v in hit.values() if v.get("state")]
            mergeable_n = sum(1 for v in mine if v.get("mergeable") is True)
    except Exception:  # noqa: BLE001
        pass

    prev_rows = hist[-3:]
    for row in prev_rows:
        op = row.get("open_pr")
        say(f"  {row.get('at', '?')[:16]}  open_pr={op if op is not None else '?'}  "
            f"trio={row.get('trio_open')}")
    if len(prev_rows) >= 2:
        first, last = prev_rows[0], prev_rows[-1]
        try:
            t0p = datetime.fromisoformat(first["at"])
            t1p = datetime.fromisoformat(last["at"])
            hours = max((t1p - t0p).total_seconds() / 3600, 0.05)
            d_trio = (last.get("trio_open") or 0) - (first.get("trio_open") or 0)
            say(f"  最近 {hours:.1f}h：trio {first.get('trio_open')} → {last.get('trio_open')}"
                f"（+{d_trio}，约 {d_trio / hours:.0f} 个/小时）")
        except Exception:  # noqa: BLE001
            pass
    if mergeable_n is not None:
        extra = f"，另有 {stale_n} 个本轮无缓存记录" if stale_n else ""
        say(f"  其中 mergeable=true（缓存，仅计仍 open 的）：{mergeable_n} 个{extra} —— "
            f"**这个账号没有 push 权限，这些只能等维护者点**")

    say("")
    say(f"耗时 {time.time() - t0:.1f}s ｜ 结论：等待 {len(waiting)} · 重叠 {len(dupes)} 组"
        f" · 死链 {len((snap.get('links') or {}).get('dead') or [])}"
        f" · 变化 {len(changes)}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
