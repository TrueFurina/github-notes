import json, subprocess, time, urllib.request, http.client, collections

TOKEN = subprocess.run(["powershell","-NoProfile","-Command",
    "[Environment]::GetEnvironmentVariable('GITHUB_TOKEN','User')"],
    capture_output=True, text=True).stdout.strip()
H = {"Authorization":"Bearer "+TOKEN,"User-Agent":"raccoon","Accept":"application/vnd.github+json","Connection":"close"}

def get(url):
    for i in range(4):
        try:
            r = urllib.request.Request(url, headers=H)
            with urllib.request.urlopen(r, timeout=60) as resp:
                parts=[]
                try:
                    while True:
                        b=resp.read(65536)
                        if not b: break
                        parts.append(b)
                except http.client.IncompleteRead as e:
                    parts.append(e.partial)
                return json.loads(b"".join(parts))
        except Exception:
            time.sleep(2)
    return None

for fn in ["SecAutoMind-src"]:
    t=get(f"https://api.github.com/repos/TrueFurina/{fn}/git/trees/HEAD?recursive=1") or {}
    tree=t.get("tree",[])
    print(fn,"entries:",len(tree),"truncated:",t.get("truncated"))
    blobs={x["path"]: x.get("size",0) for x in tree if x["type"]=="blob"}
    agg=collections.Counter()
    for p,s in blobs.items():
        agg[p.split("/")[0] if "/" in p else "(root)"]+=s
    print("dir sizes:")
    for k,v in agg.most_common(10): print(f'  {k:28s} {v/1e6:8.1f} MB')
    sha=collections.defaultdict(list)
    for x in tree:
        if x["type"]=="blob" and x["path"].endswith(".py"): sha[x["sha"]].append(x["path"])
    d={k:v for k,v in sha.items() if len(v)>1}
    print("py total:",sum(1 for p in blobs if p.endswith('.py')),"dup groups:",len(d),"files in dups:",sum(len(v) for v in d.values()))
    # root-level layout
    print("root entries:", sorted({p.split("/")[0] for p in blobs})[:30])
    # check tests location
    tp=[p for p in blobs if p.split("/")[-1].startswith("test_")]
    print("test_ files:",len(tp), tp[:6])