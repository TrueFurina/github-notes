import json, collections
d=json.load(open("raw.json",encoding="utf-8"))
own=[r for r in d["repos"] if not r.get("fork")]
pub=[r for r in own if not r.get("private")]
priv=[r for r in own if r.get("private")]
print("own:",len(own),"public:",len(pub),"private:",len(priv))
print("private names:", [r["name"] for r in priv])
for n in ["2026-crypto-math-challenge","MangDeZhiXun","SecAutoMind-src","MARS-408"]:
    r=next((x for x in own if x["name"]==n),None)
    if r: print(n,"private=",r.get("private"),"visibility=",r.get("visibility"))
print("\nstars by visibility: public", sum(r["stargazers_count"] for r in pub), "private", sum(r["stargazers_count"] for r in priv))
print("\nforks upstream unknown count:", sum(1 for r in d["repos"] if r.get("fork") and not r.get("parent")))
# description language mix
import re
zh=sum(1 for r in pub if re.search(r'[\u4e00-\u9fff]', r.get("description") or ""))
print("public repos with Chinese desc:", zh, "/", len(pub))