"""从队列里挑出"最老且无冲突"的 PR，生成一份可直接点完的清单。

只读 + 只写本地 md，不合并、不评论。
依据 `octop_details.json` 缓存（由 octop_review.py 生成），不重复打 API 取详情。

用法：
    python autopilot/merge_shortlist.py [数量=25]
"""
from __future__ import annotations

import json
import os
import sys
from concurrent.futures import ThreadPoolExecutor
from datetime import datetime

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, os.path.dirname(HERE))

from ghlib import api, OWNER  # noqa: E402

TRIO = ["TencentCloud/Octop", "TencentCloud/octop-harness", "TencentCloud/octop-memory"]
CACHE = os.path.join(HERE, "octop_details.json")
OUT = os.path.join(HERE, f"MERGE-SHORTLIST-{datetime.now():%m%d}.md")


def listing(repo: str, pages: int = 16, per: int = 20) -> list[dict]:
    def one(page: int):
        try:
            c = api(f"/repos/{repo}/pulls?state=open&per_page={per}&page={page}")
            return c if isinstance(c, list) else []
        except Exception:  # noqa: BLE001
            return []

    out: dict[int, dict] = {}
    with ThreadPoolExecutor(max_workers=8) as ex:
        for chunk in ex.map(one, range(1, pages + 1)):
            for p in chunk:
                out[p["number"]] = p
    return list(out.values())


def main() -> int:
    want = int(sys.argv[1]) if len(sys.argv) > 1 and sys.argv[1].isdigit() else 25
    cache = json.load(open(CACHE, encoding="utf-8")) if os.path.exists(CACHE) else {}

    rows = []
    for repo in TRIO:
        for p in listing(repo):
            if (p.get("user") or {}).get("login") != OWNER:
                continue
            key = f"{repo}#{p['number']}"
            c = cache.get(key) or {}
            rows.append({
                "repo": repo, "num": p["number"], "title": p["title"],
                "created": p["created_at"][:10],
                "age": (datetime.now() - datetime.strptime(p["created_at"][:10], "%Y-%m-%d")).days,
                "mergeable": c.get("mergeable"),
                "state": c.get("state") or "?",
                "add": c.get("add"), "del": c.get("del"),
                "files": c.get("files"), "comments": c.get("comments"),
            })

    ready = [r for r in rows if r["mergeable"] is True]
    ready.sort(key=lambda r: -r["age"])
    pick = ready[:want]

    lines = [
        f"# 可合并清单 · 最老 {len(pick)} 个",
        "",
        f"生成时间：{datetime.now():%Y-%m-%d %H:%M} ｜ 依据 `mergeable=true`（无冲突），按创建时间从老到新",
        f"队列共 {len(rows)} 个本人 open PR，其中 `mergeable=true` {len(ready)} 个。",
        "",
        "> 判断依据：`mergeable=true` 表示与 base 无冲突。这三个仓的 `mergeable_state=unstable`",
        "> 是因为**没有任何 commit status**（GitHub 默认报 pending），不是检查失败。",
        "",
        "| # | 仓库 | PR | 标题 | 规模 | 年龄 | 评论 |",
        "|---:|---|---|---|---|---:|---:|",
    ]
    for i, r in enumerate(pick, 1):
        t = r["title"].replace("|", "\\|")[:64]
        size = f"+{r['add']}/−{r['del']}" if r["add"] is not None else "?"
        lines.append(
            f"| {i} | {r['repo'].split('/')[-1]} | [#{r['num']}](https://github.com/{r['repo']}/pull/{r['num']}) "
            f"| {t} | {size} | {r['age']}d | {r['comments'] if r['comments'] is not None else '?'} |")

    by_repo: dict[str, int] = {}
    for r in pick:
        by_repo[r["repo"].split("/")[-1]] = by_repo.get(r["repo"].split("/")[-1], 0) + 1

    # 有讨论的不能当"点一下就行"：维护者可能正在看，或提过问题。
    talkative = [r for r in pick if (r["comments"] or 0) >= 2]
    lines += ["", "## 有讨论，先读再合（不在这批「无脑合」的范围）", ""]
    if talkative:
        lines += ["| PR | 评论 | 为什么要先读 |", "|---|---:|---|"]
        for r in talkative:
            why = "维护者在等回复/正在复核" if (r["comments"] or 0) >= 2 else "有讨论"
            if r["repo"].endswith("octop-memory") and r["num"] == 29:
                why = "Bosheng0422 正在复核 P1 补丁（head 86f0308），等他表态"
            lines.append(f"| [#{r['num']}](https://github.com/{r['repo']}/pull/{r['num']}) "
                         f"（{r['repo'].split('/')[-1]}） | {r['comments']} | {why} |")
    else:
        lines.append("_（无）_")

    lines += [
        "",
        "## 分布",
        "",
        " · ".join(f"{k} {v} 个" for k, v in by_repo.items()),
        "",
        "## 怎么用",
        "",
        "1. 从第 1 条开始，逐条点开 → 看 diff 是否符合标题 → 点 Merge。",
        "2. 遇到标题与 diff 不符的，**跳过并记下来**，不要因为「反正没有冲突」就合。",
        "3. 批量合并可用 `python autopilot/merge_prs.py <编号...> --yes`（默认 dry-run，",
        "   会先校验 `mergeable=true`，不合格的直接拒绝）。",
        "",
        "> 本文件只读生成：没有合并、没有评论。",
    ]
    open(OUT, "w", encoding="utf-8").write("\n".join(lines) + "\n")
    print(f"写入 {OUT}")
    print(f"队列 {len(rows)} | 可合 {len(ready)} | 本次列出最老 {len(pick)}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
