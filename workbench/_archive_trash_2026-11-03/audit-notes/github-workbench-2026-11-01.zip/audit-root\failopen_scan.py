import json, subprocess, urllib.request, urllib.error, http.client, base64, re, os, sys

TOKEN = subprocess.run(["powershell","-NoProfile","-Command",
    "[Environment]::GetEnvironmentVariable('GITHUB_TOKEN','User')"],
    capture_output=True, text=True).stdout.strip()
H = {"Authorization":"Bearer "+TOKEN,"User-Agent":"r",
     "Accept":"application/vnd.github+json","Connection":"close"}

def get(u, tries=3):
    for i in range(tries):
        try:
            r = urllib.request.Request(u, headers=H)
            with urllib.request.urlopen(r, timeout=45) as resp:
                parts = []
                try:
                    while True:
                        b = resp.read(65536)
                        if not b: break
                        parts.append(b)
                except http.client.IncompleteRead as e:
                    parts.append(e.partial)
                return json.loads(b"".join(parts))
        except urllib.error.HTTPError as e:
            return {"__http": e.code}
        except Exception:
            pass
    return None

# fail-open 凭据模式：getenv/env.get/process.env 带了非空默认值
PATTERNS = [
    # Python: os.getenv("X", "默认值") / os.environ.get
    (r"os\.getenv\(\s*['\"]([A-Za-z0-9_]*(?:PASS|PASSWORD|SECRET|KEY|TOKEN|PWD)[A-Za-z0-9_]*)['\"]\s*,\s*['\"]([^'\"]{1,60})['\"]",
     "py-default"),
    (r"os\.environ\.get\(\s*['\"]([A-Za-z0-9_]*(?:PASS|PASSWORD|SECRET|KEY|TOKEN|PWD)[A-Za-z0-9_]*)['\"]\s*,\s*['\"]([^'\"]{1,60})['\"]",
     "py-default"),
    # 硬编码赋值
    (r"^\s*(?:const\s+)?([A-Za-z0-9_]*(?:password|passwd|secret|api_key|apikey|token))\s*[:=]\s*['\"]([^'\"]{6,80})['\"]",
     "hardcoded"),
]

# 明显是占位符的值，排除
PLACEHOLDER = re.compile(
    r"^(your|xxx|changeme|placeholder|example|<|\.\.\.|dummy|test-|fake|todo|none|null|$)",
    re.I)

def scan_text(text):
    hits = []
    for pat, kind in PATTERNS:
        for m in re.finditer(pat, text, re.M | re.I):
            name, val = m.group(1), m.group(2)
            if PLACEHOLDER.match(val.strip()):
                continue
            # 值必须看起来像真实默认值（不是空、不是表达式）
            if not val.strip() or val.strip() in ("None", "null", "0"):
                continue
            hits.append((kind, name, val))
    return hits

d = json.load(open("raw.json", encoding="utf-8"))
own = [r for r in d["repos"] if not r.get("fork") and not r.get("private")]
print(f"扫描 {len(own)} 个公开仓库\n", flush=True)

TARGET_EXT = (".py", ".js", ".ts", ".tsx", ".jsx", ".go", ".java", ".yaml", ".yml", ".env.example", ".toml")
SKIP_DIR = re.compile(r"(node_modules|\.venv|dist/|build/|__pycache__|\.git/|vendor/|site-packages)")

results = []
for i, r in enumerate(own, 1):
    fn = r["full_name"]
    name = r["name"]
    t = get(f"https://api.github.com/repos/{fn}/git/trees/HEAD?recursive=1")
    if not t or "__http" in t:
        print(f"[{i:2d}] {name:36s} tree 读取失败", flush=True)
        continue
    tree = t.get("tree", [])
    cands = [x for x in tree if x["type"] == "blob"
             and x["path"].endswith(TARGET_EXT)
             and not SKIP_DIR.search(x["path"])
             and x.get("size", 0) < 300_000]
    # 只查可能含配置的文件：优先 config/settings/env/security/main
    prio = [x for x in cands if re.search(r"(config|setting|env|security|auth|main|app|server|const|secret)", x["path"], re.I)]
    scan = prio[:12] if prio else cands[:5]
    found = []
    for x in scan:
        c = get(f"https://api.github.com/repos/{fn}/contents/{x['path']}")
        if not c or not isinstance(c, dict) or not c.get("content"):
            continue
        try:
            text = base64.b64decode(c["content"]).decode("utf-8", "replace")
        except Exception:
            continue
        found.extend([(x["path"],) + h for h in scan_text(text)])
    if found:
        results.append((name, fn, found))
        print(f"[{i:2d}] {name:36s} ⚠ {len(found)} 处", flush=True)
    else:
        print(f"[{i:2d}] {name:36s} -", flush=True)

print("\n" + "=" * 78)
print("命中明细")
print("=" * 78)
for name, fn, found in results:
    print(f"\n[{name}] https://github.com/{fn}")
    for path, kind, var, val in found:
        # 只显示值的前 3 位
        masked = val[:3] + "***" if len(val) > 3 else "***"
        print(f"  {kind:10s} {var:28s} = {masked:12s}  @ {path}")

json.dump(results, open("failopen_scan.json", "w", encoding="utf-8"), ensure_ascii=False, indent=1)
print(f"\n共 {len(results)} 个仓库命中")
