"""清理自己发错的评论（如邮件自动回复被粘进维护者线程）。

默认 dry-run。只允许删除**自己**发的评论，且必须显式 --yes。

    python fix_reputation.py show kubeflow/testing#1072:6444802667
    python fix_reputation.py delete-comment kubeflow/testing#1072:6444802667          # 试运行
    python fix_reputation.py delete-comment kubeflow/testing#1072:6444802667 --yes    # 真删
"""

import argparse
import json
import sys
import urllib.request

sys.path.insert(0, r"D:/github/github-audit")
from ghlib import api, HEADERS  # noqa: E402

ME = "TrueFurina"


def _req(method, path):
    req = urllib.request.Request("https://api.github.com" + path,
                                 headers=HEADERS, method=method)
    try:
        with urllib.request.urlopen(req, timeout=60) as r:
            return {"status": r.status}
    except Exception as e:  # noqa: BLE001
        detail = getattr(e, "read", lambda: b"")()
        return {"__error": str(e), "detail": detail.decode("utf-8", "ignore")[:200]}


def parse(target):
    """owner/repo#123:456 → (repo, pr, comment_id)"""
    if ":" not in target or "#" not in target:
        raise SystemExit("格式应为 owner/repo#PR:COMMENT_ID")
    prpart, comment = target.rsplit(":", 1)
    repo, num = prpart.rsplit("#", 1)
    return repo, int(num), int(comment)


def fetch_comment(repo, cid):
    return api(f"/repos/{repo}/issues/comments/{cid}")


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("cmd", choices=["show", "delete-comment"])
    ap.add_argument("target")
    ap.add_argument("--yes", action="store_true")
    a = ap.parse_args()

    repo, pr, cid = parse(a.target)
    c = fetch_comment(repo, cid)
    if "__error" in c:
        print("读不到评论:", c)
        return 1
    if c.get("user", {}).get("login") != ME:
        print(f"拒绝：这条评论作者是 {c.get('user', {}).get('login')}，不是你自己")
        return 1

    body = (c.get("body") or "").replace("\n", " ")
    print(f"仓库: {repo}   评论 id={cid}   PR: {c.get('issue_url', '').rsplit('/', 1)[-1]}")
    print(f"作者: {c['user']['login']}   时间: {c['created_at']}")
    print(f"链接: {c['html_url']}")
    print(f"内容: {body[:200]}{'...' if len(body) > 200 else ''}")

    if a.cmd == "show":
        return 0

    if not a.yes:
        print("\n[试运行] 将执行: DELETE /repos/%s/issues/comments/%s" % (repo, cid))
        print("确认后加 --yes。")
        return 0

    r = _req("DELETE", f"/repos/{repo}/issues/comments/{cid}")
    if r.get("__error"):
        print("删除失败:", r["__error"], r.get("detail", "")[:150])
        return 1
    print("已删除（HTTP", r.get("status"), "）")
    return 0


if __name__ == "__main__":
    sys.exit(main())
