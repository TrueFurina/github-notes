"""Open the last three NOASSERTION repos (explicitly authorized: "通通放开").

mcd-meal-optimizer                        -> MIT   (competition entry, sole author)
2025-Challenge-Cup-CyberRange-AI-Arena    -> MIT   (competition entry, sole author)
sage-paper-public                         -> CC-BY-4.0 (content: manuscript working set)

Also rewrites the README "License & Usage Notice" block if present, so the
repo never says "All Rights Reserved" next to an MIT/CC file again.
"""

import base64
import json
import sys
import urllib.request

sys.path.insert(0, r"D:/github/github-audit")
from ghlib import HEADERS, OWNER, api

YEAR = "2026"
HOLDER = "TrueFurina"

TARGETS = [
    ("mcd-meal-optimizer", "mit"),
    ("2025-Challenge-Cup-CyberRange-AI-Arena", "mit"),
    ("sage-paper-public", "cc-by-4.0"),
]

OLD_BLOCK = """## License & Usage Notice

**Source-Available · All Rights Reserved**

This project is source-available and all rights are reserved by the author. The code is provided for **viewing and evaluation purposes only** — access does not grant any right to copy, modify, redistribute, use commercially, or create derivative works. Unauthorized reuse may carry legal risk. Contact the author for explicit written permission before any other use.

**本仓库为「源码可查、权利保留」项目（source-available / all-rights-reserved）。代码仅供查看与评估，未授权任何复制、再分发、修改、商用或衍生创作。擅自借用代码存在法律风险；如有需要请先联系作者获取明确书面许可。**"""

NEW_BLOCK = {
    "mit": """## License

[MIT](LICENSE) © 2026 TrueFurina

可自由使用、修改、分发与商用。若用于学术论文或竞赛作品，欢迎注明来源与仓库链接
（这是礼貌请求，不构成 MIT 之外的额外限制）。""",
    "cc-by-4.0": """## License

[CC BY 4.0](LICENSE) © 2026 TrueFurina

可自由复制、分发、修改与商用，**但须保留署名**——注明来源与本仓库链接。
This work is licensed under a Creative Commons Attribution 4.0 International License.""",
}

_bodies = {}


def body(key):
    if key not in _bodies:
        _bodies[key] = api(f"/licenses/{key}")["body"]
    return _bodies[key]


def put(repo, path, text, sha, branch, message):
    payload = {"message": message, "branch": branch,
               "content": base64.b64encode(text.encode("utf-8")).decode()}
    if sha:
        payload["sha"] = sha
    req = urllib.request.Request(
        f"https://api.github.com/repos/{OWNER}/{repo}/contents/{path}",
        data=json.dumps(payload, ensure_ascii=False).encode("utf-8"),
        headers={**HEADERS, "Content-Type": "application/json; charset=utf-8"},
        method="PUT")
    try:
        with urllib.request.urlopen(req, timeout=120) as r:
            return r.status, json.loads(r.read())["commit"]["sha"][:12]
    except urllib.error.HTTPError as e:
        return e.code, e.read().decode("utf-8", "ignore")[:240]


def main():
    dry = "--yes" not in sys.argv
    for repo, key in TARGETS:
        info = api(f"/repos/{OWNER}/{repo}")
        if "__error" in info:
            print(f"[{repo}] 读取失败 {info}"); continue
        cur = (info.get("license") or {}).get("spdx_id")
        branch = info["default_branch"]
        want = "MIT" if key == "mit" else "CC-BY-4.0"
        print(f"[{repo}] {cur} -> {want} (branch {branch})")

        text = body(key)
        if key == "mit":
            text = text.replace("Copyright (c) [year] [fullname]",
                                f"Copyright (c) {YEAR} {HOLDER}")

        old = api(f"/repos/{OWNER}/{repo}/contents/LICENSE")
        sha = old["sha"] if isinstance(old, dict) and old.get("sha") else None
        print(f"      LICENSE {len(text)} 字符, {'覆盖' if sha else '新建'}")
        if not dry:
            st, res = put(repo, "LICENSE", text, sha, branch,
                          f"chore(license): switch to {want}\n\n"
                          f"原为 752 字符的自定义 source-available 文本，GitHub 不识别"
                          f"（spdx=NOASSERTION），仓库页不显示任何许可标识。改用标准 {want} 全文。")
            print(f"      HTTP {st} {res}")

        rd = api(f"/repos/{OWNER}/{repo}/readme")
        if isinstance(rd, dict) and rd.get("content"):
            rt = base64.b64decode(rd["content"]).decode("utf-8", "ignore")
            if OLD_BLOCK in rt:
                nt = rt.replace(OLD_BLOCK, NEW_BLOCK[key], 1)
                print("      README 替换互斥许可段")
                if not dry:
                    st, res = put(repo, "README.md", nt, rd["sha"], branch,
                                  f"docs(readme): align license section with {want}")
                    print(f"      README HTTP {st} {res}")
            else:
                print("      README 无互斥段落，跳过")
    print("\n" + ("dry-run，加 --yes 写入" if dry else "完成"))


if __name__ == "__main__":
    main()
