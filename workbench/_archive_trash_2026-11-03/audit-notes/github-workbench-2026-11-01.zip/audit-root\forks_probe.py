import json, subprocess, time, urllib.request, http.client

TOKEN = subprocess.run(["powershell","-NoProfile","-Command",
    "[Environment]::GetEnvironmentVariable('GITHUB_TOKEN','User')"],
    capture_output=True, text=True).stdout.strip()
H = {"Authorization":"Bearer "+TOKEN,"User-Agent":"raccoon","Accept":"application/vnd.github+json","Connection":"close"}

def get(url):
    for i in range(2):
        try:
            r = urllib.request.Request(url, headers=H)
            with urllib.request.urlopen(r, timeout=30) as resp:
                parts=[]
                try:
                    while True:
                        b=resp.read(16384)
                        if not b: break
                        parts.append(b)
                except http.client.IncompleteRead as e:
                    parts.append(e.partial)
                return json.loads(b"".join(parts))
        except urllib.error.HTTPError as e:
            if e.code == 404: return {"__404":1}
            time.sleep(1.5)
        except Exception:
            time.sleep(1.5)
    return None

d = json.load(open("raw.json", encoding="utf-8"))
forks = [r for r in d["repos"] if r.get("fork")]
print("forks:", len(forks), flush=True)

out=[]
for i,r in enumerate(forks):
    info = get(f'https://api.github.com/repos/{r["full_name"]}')
    parent = (info or {}).get("parent") or {}
    out.append({
        "name": r["name"],
        "size_kb": r["size"],
        "pushed": r["pushed_at"][:10],
        "created": r["created_at"][:10],
        "upstream": parent.get("full_name"),
        "up_stars": parent.get("stargazers_count"),
        "up_lang": parent.get("language"),
        "up_desc": (parent.get("description") or "")[:120],
        "up_archived": parent.get("archived"),
    })
    if (i+1) % 40 == 0:
        print("  ...", i+1, flush=True)
        json.dump(out, open("forks.json","w",encoding="utf-8"), ensure_ascii=False, indent=1)

json.dump(out, open("forks.json","w",encoding="utf-8"), ensure_ascii=False, indent=1)
missing = sum(1 for x in out if not x["upstream"])
print("done. missing upstream:", missing)
print("total GB:", round(sum(x["size_kb"] for x in out)/1e6, 2))