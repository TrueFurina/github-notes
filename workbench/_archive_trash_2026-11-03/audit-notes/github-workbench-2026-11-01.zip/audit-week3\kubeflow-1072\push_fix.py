"""把 kubeflow #1072 的两处修复推到自己的 fork 分支（默认 dry-run）。

针对维护者 2026-10-27 的两条意见：
  1. Kubernetes 版本选择：`kubernetes-version` 之前只喂给 kubectl，集群实际版本由
     `kind-node-image` 的默认值决定 → 改为「未显式给镜像时，镜像由版本推导」。
  2. 缺 license header：kubeflow 的 boilerplate 校验把 yaml/yml 映射到 sh 模板，
     新增文件必须是无年份版本。

    python push_fix.py            # 只校验 + 打印 diff
    python push_fix.py --yes      # 真推（commit 带 DCO sign-off）
"""

import argparse
import base64
import difflib
import json
import os
import sys
import urllib.request

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, r"D:/github/github-audit")
from ghlib import api, HEADERS  # noqa: E402

FORK = "TrueFurina/testing"
BRANCH = "feat/create-cluster-composite-action"
FILES = {
    ".github/actions/create-cluster/action.yml": "action.yml",
    ".github/actions/create-cluster/kind-config.yaml": "kind-config.yaml",
}
SIGNOFF = "Signed-off-by: Dream <2468001320@qq.com>"
HEADER = open(os.path.join(HERE, "HEADER.txt"), encoding="utf-8").read()


def _req(method, path, body=None):
    req = urllib.request.Request(
        "https://api.github.com" + path,
        data=json.dumps(body).encode("utf-8") if body else None,
        headers={**HEADERS, "Content-Type": "application/json"}, method=method)
    try:
        with urllib.request.urlopen(req, timeout=60) as r:
            return json.loads(r.read() or b"{}")
    except Exception as e:  # noqa: BLE001
        detail = getattr(e, "read", lambda: b"")()
        return {"__error": str(e), "detail": detail.decode("utf-8", "ignore")[:300]}


def check_local(local_name, text):
    """header 是否逐字匹配 + YAML 能否解析。"""
    problems = []
    head = "\n".join(text.splitlines()[:13]) + "\n"
    if head != HEADER:
        problems.append("前 13 行与官方 boilerplate.sh.txt 不一致")
    try:
        import yaml
        yaml.safe_load(text)
    except ImportError:
        pass
    except Exception as e:  # noqa: BLE001
        problems.append(f"YAML 解析失败: {e}")
    return problems


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--yes", action="store_true")
    a = ap.parse_args()

    ok = True
    for remote_path, local in FILES.items():
        with open(os.path.join(HERE, local), encoding="utf-8") as f:
            new = f.read()
        problems = check_local(local, new)
        cur = api(f"/repos/{FORK}/contents/{remote_path}?ref={BRANCH}")
        old = base64.b64decode(cur["content"]).decode("utf-8") if isinstance(cur, dict) and cur.get("content") else ""
        sha = cur.get("sha") if isinstance(cur, dict) else None

        print("=" * 74)
        print(f"{remote_path}  (本地 {len(new)} 字节 / 远端 {len(old)} 字节, sha={str(sha)[:8]})")
        print("  校验:", "通过" if not problems else "；".join(problems))
        ok &= not problems

        d = list(difflib.unified_diff(old.splitlines(), new.splitlines(),
                                      fromfile="remote", tofile="local", lineterm="", n=1))
        for ln in d[:26]:
            print("   ", ln[:150])
        if len(d) > 26:
            print(f"    ... 省略 {len(d)-26} 行")

        if not a.yes:
            continue
        if new == old:
            print("    已是目标内容，跳过")
            continue
        msg = ("fix: derive Kind node image from kubernetes-version; add boilerplate headers\n\n"
               "The node image default silently decided the cluster version, so overriding only\n"
               "kubernetes-version still produced a v1.37.0 cluster. An explicitly pinned image\n"
               "still wins; otherwise kindest/node is derived from the version input.\n\n"
               "Both new YAML files now carry the year-less Apache-2.0 boilerplate header\n"
               "required by hack/boilerplate (yaml/yml use the sh template).\n\n" + SIGNOFF)
        r = _req("PUT", f"/repos/{FORK}/contents/{remote_path}", {
            "message": msg, "content": base64.b64encode(new.encode()).decode(),
            "sha": sha, "branch": BRANCH})
        print("    推送:", (r.get("commit") or {}).get("sha", "")[:12] if not r.get("__error")
              else f"ERROR {r['__error']} {r.get('detail','')[:150]}")

    if not a.yes:
        print("\n校验%s。确认后加 --yes 推到你自己的 fork 分支。" % ("通过" if ok else "未通过，先修"))
    return 0 if ok else 1


if __name__ == "__main__":
    sys.exit(main())
