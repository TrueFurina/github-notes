import base64, json, os, urllib.request

TOKEN = os.environ["GITHUB_TOKEN"]
for p in ["airflow-core/src/airflow/observability/metrics/otel_logger.py",
          "shared/observability/src/airflow_shared/observability/metrics/otel_logger.py"]:
    req = urllib.request.Request(f"https://api.github.com/repos/apache/airflow/contents/{p}",
                                 headers={"Authorization": "Bearer " + TOKEN,
                                          "Accept": "application/vnd.github+json",
                                          "User-Agent": "insight-scout"})
    try:
        js = json.loads(urllib.request.urlopen(req, timeout=30).read().decode())
        txt = base64.b64decode(js["content"]).decode("utf-8", "ignore")
        print(f"\n### {p}  ({len(txt)} chars)")
        print("\n".join(txt.splitlines()[:45]))
    except Exception as e:
        print(f"{p}: {e}")
