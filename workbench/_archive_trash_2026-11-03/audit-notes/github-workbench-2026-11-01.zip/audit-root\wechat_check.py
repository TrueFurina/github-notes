import json, subprocess, urllib.request, http.client, base64, re

TOKEN = subprocess.run(["powershell","-NoProfile","-Command",
    "[Environment]::GetEnvironmentVariable('GITHUB_TOKEN','User')"],
    capture_output=True, text=True).stdout.strip()
H = {"Authorization":"Bearer "+TOKEN,"User-Agent":"raccoon","Accept":"application/vnd.github+json","Connection":"close"}

def get(url):
    try:
        r = urllib.request.Request(url, headers=H)
        with urllib.request.urlopen(r, timeout=40) as resp:
            parts=[]
            try:
                while True:
                    b=resp.read(16384)
                    if not b: break
                    parts.append(b)
            except http.client.IncompleteRead as e:
                parts.append(e.partial)
            return json.loads(b"".join(parts))
    except urllib.error.HTTPError as e:
        return {"__http": e.code}

# 1) 微信支付配置文件是否公开可读
c = get("https://api.github.com/repos/TrueFurina/MangDeZhiXun/contents/WECHAT_PAY_CONFIG.md")
if c and c.get("content"):
    txt = base64.b64decode(c["content"]).decode("utf-8","replace")
    print("WECHAT_PAY_CONFIG.md 公开可读, 大小", len(txt), "字符")
    print("--- 内容（已脱敏：仅显示键名与值的长度/前缀）---")
    for line in txt.splitlines():
        s=line.strip()
        if not s: continue
        m=re.match(r'^([A-Za-z_][A-Za-z0-9_]*)\s*[:=]\s*(.+)$', s)
        if m:
            k,v=m.group(1),m.group(2).strip().strip('"').strip("'").strip('`')
            if re.search(r'KEY|TOKEN|SECRET|ID|MCH|SERIAL|APIV', k, re.I) and v:
                ph = bool(re.search(r'your|xxx|changeme|placeholder|example|<|\*\*\*', v, re.I))
                print(f'  {k:26s} {"PLACEHOLDER" if ph else f"REAL len={len(v)} head={v[:3]}***"}')
        elif s.startswith("#"):
            print("  #", s[1:].strip()[:60])
    print("--- 原始行数 ---", len(txt.splitlines()))
else:
    print("WECHAT_PAY_CONFIG.md:", c)

# 2) 该文件提交历史
h = get("https://api.github.com/repos/TrueFurina/MangDeZhiXun/commits?path=WECHAT_PAY_CONFIG.md&per_page=10")
if isinstance(h,list):
    print("\n提交次数:", len(h))
    for x in h[:5]:
        print("  ", x["commit"]["author"]["date"][:10], x["commit"]["message"][:60])

# 3) physics-scheduler-agent 那个告警
c2 = get("https://api.github.com/repos/TrueFurina/physics-scheduler-agent/contents/docs/安全风险清单-公开链接数据暴露-20261015.md")
if c2 and c2.get("content"):
    t2 = base64.b64decode(c2["content"]).decode("utf-8","replace")
    print("\nphysics 告警文件大小:", len(t2))
    for line in t2.splitlines():
        if re.search(r'appid|app_id|wx[0-9a-f]{10,}|corpid|secret', line, re.I):
            print("  >", line.strip()[:110])