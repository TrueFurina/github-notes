"""把 CLA/DCO 关键词所在上下文打印出来，避免「没有 CLA」被正则误判成「要 CLA」。"""
import base64
import os
import re
import urllib.request

TOKEN = os.environ["GITHUB_TOKEN"]
REPOS = ["topoteretes/cognee", "rtk-ai/rtk", "nexu-io/open-design", "ueberdosis/tiptap",
         "aws/aws-cdk", "elastic/elasticsearch", "langgenius/dify", "grafana/grafana"]
PAT = re.compile(r"(CLA|Contributor License Agreement|DCO|Developer Certificate of Origin)",
                 re.I)


def fetch(full, path):
    req = urllib.request.Request(
        f"https://api.github.com/repos/{full}/contents/{path}",
        headers={"Authorization": "Bearer " + TOKEN,
                 "Accept": "application/vnd.github+json",
                 "User-Agent": "insight-scout"})
    with urllib.request.urlopen(req, timeout=45) as r:
        return base64.b64decode(__import__("json").loads(r.read().decode())["content"]).decode("utf-8", "ignore")


for full in REPOS:
    for p in ("CONTRIBUTING.md", ".github/CONTRIBUTING.md", "docs/CONTRIBUTING.md"):
        try:
            txt = fetch(full, p)
        except Exception:
            continue
        print(f"\n### {full} / {p}")
        lines = txt.splitlines()
        for i, line in enumerate(lines):
            if PAT.search(line):
                lo, hi = max(0, i - 1), min(len(lines), i + 2)
                print("   ...", " | ".join(l.strip() for l in lines[lo:hi])[:260])
        break
