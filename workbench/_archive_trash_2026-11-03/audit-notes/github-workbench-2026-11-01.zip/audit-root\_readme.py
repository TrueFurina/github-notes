import sys, base64
sys.path.insert(0, r'D:/github/github-audit')
from ghlib import api
for n in ['passive-recon','SecAutoMind-src','AGI-Distiller','xihu-sword-ctf-agent']:
    rd = api(f'/repos/TrueFurina/{n}/readme')
    if isinstance(rd, dict) and rd.get('content'):
        t = base64.b64decode(rd['content']).decode('utf-8', 'ignore')
    else:
        t = str(rd)
    print('='*20, n, rd.get('name') if isinstance(rd, dict) else '')
    print('\n'.join(t.splitlines()[:60]))
