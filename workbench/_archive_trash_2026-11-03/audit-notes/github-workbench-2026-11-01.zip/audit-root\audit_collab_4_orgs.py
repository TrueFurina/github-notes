import sys, json
sys.path.insert(0, r"D:/github/github-audit")
from ghlib import api, api_all, OWNER

res = {}
for org in ["Circle1507", "MARL-ECDSA-Consensus"]:
    o = api(f"/orgs/{org}")
    repos = api_all(f"/orgs/{org}/repos", per=30)
    members = api_all(f"/orgs/{org}/members", per=30)
    mem = api(f"/orgs/{org}/memberships/{OWNER}")
    pub = api_all(f"/orgs/{org}/public_members", per=30)
    res[org] = {
        "org": o,
        "repos": [{k: r.get(k) for k in ("name", "full_name", "description", "private", "fork", "stargazers_count", "forks_count", "language", "pushed_at", "created_at", "archived", "default_branch")} for r in repos],
        "members": [m["login"] for m in members],
        "public_members": [m["login"] for m in pub],
        "my_membership": mem,
    }
    print("=" * 30, org)
    print("name/desc:", o.get("name"), "|", o.get("description"))
    print("created", o.get("created_at"), "public_repos", o.get("public_repos"), "followers", o.get("followers"))
    print("blog", o.get("blog"), "loc", o.get("location"), "email", o.get("email"))
    print("repos:", [(r["full_name"], r.get("stargazers_count"), (r.get("description") or "")[:50]) for r in repos])
    print("members:", [m["login"] for m in members], "public:", [m["login"] for m in pub])
    print("my membership:", mem)
json.dump(res, open(r"D:/github/github-audit/_collab_orgs.json", "w", encoding="utf-8"), ensure_ascii=False, indent=1)
