# 43 个 open PR：谁在等谁

生成时间：2026-10-28 23:33 ｜ 逐个 `GET /pulls/{num}` 拉 `mergeable_state` + 评论者

## 一句话

**43 个里只有 4 个真的卡在你这边**（3 个冲突 + 1 个落后），6 个已经全绿只差一次点击，
其余 33 个在等维护者——而你唯一能做的是**别去催**。

| mergeable_state | 数量 | 含义 |
|---|---:|---|
| `clean` | 6 | 可直接合，等维护者点击 |
| `blocked` | 16 | 等 review / 缺 label |
| `unstable` | 15 | 检查未过或未完成 |
| `dirty` | 3 | **有冲突，需要你解** |
| `behind` | 1 | 落后于 base，可 rebase |
| `unknown` | 2 | 状态未计算 |

评论分布：**18 个 PR 一条评论都没有**，说明维护者从没打开过；21 个最后一条是你自己发的。

---

## 一、卡在你这边（4 个，唯一需要动手的）

### dirty · 有冲突（3 个）

| 仓库 | # | 最后发言 | 评论 | 更新 | 标题 |
|---|---:|---|---:|---|---|
| `Unstructured-IO/unstructured` | [#4464](https://github.com/Unstructured-IO/unstructured/pull/4464) | TrueFurina | 1 | 2026-10-24 | fix: switch `skip_infer_table_types` default to `None` |
| `Unstructured-IO/unstructured` | [#4462](https://github.com/Unstructured-IO/unstructured/pull/4462) | mi7ak2020-stack | 1 | 2026-10-10 | feat: add `clean_newline` to concatenate words wrapped across li |
| `opendatahub-io/notebooks` | [#4461](https://github.com/opendatahub-io/notebooks/pull/4461) | TrueFurina | 8 | 2026-09-11 | ci: migrate local action/workflow references from ./ to $/ self- |

### behind · 落后于 base（1 个）

| 仓库 | # | 最后发言 | 评论 | 更新 | 标题 |
|---|---:|---|---:|---|---|
| `CTFd/CTFd` | [#3103](https://github.com/CTFd/CTFd/pull/3103) | daanbreur | 3 | 2026-10-24 | fix: pass challenge read() output to view template renderer |

处置建议：

- `unstructured #4462`（+932/−903）与 `#4464`：两个都已 `dirty`。`#4462` 的 diff 规模说明分支严重落后，
  正确做法是**从最新 master 重做一遍**只保留 `clean_newline` 那部分，而不是继续解冲突；
  `#4464` 只有 +12/−3，解冲突成本低，值得做。
- ~~`opendatahub-io/notebooks #4461`：有人在等，优先解。~~ **判断已更正，见文末**。
- `CTFd #3103`：`behind` 但不是冲突，GitHub 能直接合；`daanbreur` 是最后一个说话的人，
  说明维护者在跟。**不要 rebase 也不要 ping**，等就是最优解。

---

## 二、只差一次点击（6 个 clean）

### clean · 已可合并（6 个）

| 仓库 | # | 最后发言 | 评论 | 更新 | 标题 |
|---|---:|---|---:|---|---|
| `jd/tenacity` | [#712](https://github.com/jd/tenacity/pull/712) | mergify[bot] | 5 | 2026-10-07 | fix: wait_exponential with zero multiplier no longer overflows i |
| `marketcalls/openalgo` | [#1920](https://github.com/marketcalls/openalgo/pull/1920) | TrueFurina | 4 | 2026-10-04 | security: add no-store headers to API-key responses |
| `fail2ban/fail2ban` | [#4219](https://github.com/fail2ban/fail2ban/pull/4219) | TrueFurina | 4 | 2026-10-03 | fix: replace bare except with except Exception |
| `m-fyi/awesome-claude-skills` | [#2](https://github.com/m-fyi/awesome-claude-skills/pull/2) | —（无人看过） | 0 | 2026-09-26 | add comment-distillery |
| `ProjectRecon/awesome-ai-agents-security` | [#104](https://github.com/ProjectRecon/awesome-ai-agents-security/pull/104) | TrueFurina | 1 | 2026-09-16 | Add xihu-sword-ctf-agent to Red Teaming section |
| `TrueFurina/rich` | [#1](https://github.com/TrueFurina/rich/pull/1) | —（无人看过） | 0 | 2026-09-11 | fix: Columns(width=...) no longer raises ZeroDivisionError when  |

这 6 个是资产：`fail2ban #4219` 已经全绿（维护者的 find&replace 质疑你已逐条答完）、
`marketcalls/openalgo #1920` 是安全类修复、两个 awesome 清单收录（`m-fyi`、`ProjectRecon`）价值在曝光。

`TrueFurina/rich#1` 例外：它是对自己 fork 提的 PR，46 天没推上游。**这个由你自己决定**——
要么 rebase 后提到 `Textualize/rich`（你已有 #4214 的讨论基础），要么关掉。

---

## 三、等维护者（33 个，别动）

### blocked · 等 review / label（16 个）

| 仓库 | # | 最后发言 | 评论 | 更新 | 标题 |
|---|---:|---|---:|---|---|
| `verialabs/ctf-agent` | [#11](https://github.com/verialabs/ctf-agent/pull/11) | —（无人看过） | 0 | 2026-10-25 | feat(skills): wire skill playbooks into the prompt and mount the |
| `verialabs/ctf-agent` | [#10](https://github.com/verialabs/ctf-agent/pull/10) | —（无人看过） | 0 | 2026-10-25 | refactor(runner): 拆分 425 行上帝模块为 5 个可测模块 |
| `verialabs/ctf-agent` | [#9](https://github.com/verialabs/ctf-agent/pull/9) | —（无人看过） | 0 | 2026-10-24 | fix: 修复容器题「有脑无手」SPOF——靶机地址获取阻塞到就绪 + 双通道注入 |
| `PyGithub/PyGithub` | [#3577](https://github.com/PyGithub/PyGithub/pull/3577) | TrueFurina | 3 | 2026-10-24 | feat: add immutable releases configuration methods to Repository |
| `arrow-py/arrow` | [#1343](https://github.com/arrow-py/arrow/pull/1343) | TrueFurina | 2 | 2026-10-17 | fix: treat explicit tzinfo=None in arrow.get() like an omitted t |
| `loopbackio/loopback-next` | [#11767](https://github.com/loopbackio/loopback-next/pull/11767) | —（无人看过） | 0 | 2026-10-17 | docs: explain why interdependent tests are bad |
| `python-attrs/attrs` | [#1616](https://github.com/python-attrs/attrs/pull/1616) | TrueFurina | 3 | 2026-10-03 | fix: compare `Attribute` instances by identity in `include`/`exc |
| `ComposioHQ/awesome-claude-skills` | [#2002](https://github.com/ComposioHQ/awesome-claude-skills/pull/2002) | TrueFurina | 1 | 2026-10-03 | Add Comment Distillery: distill crowd text into an evidence-cite |
| `agno-agi/agno` | [#9838](https://github.com/agno-agi/agno/pull/9838) | TrueFurina | 2 | 2026-10-02 | fix: cap Gemini media URL download size to prevent memory exhaus |
| `boto/boto3` | [#4836](https://github.com/boto/boto3/pull/4836) | TrueFurina | 1 | 2026-10-02 | fix: DynamoDB placeholder generation no longer overwrites caller |
| `corsairdev/corsair` | [#1250](https://github.com/corsairdev/corsair/pull/1250) | TrueFurina | 8 | 2026-09-29 | docs(posthog): add plugin-docs.yaml for overview examples |
| `codepath/pathreview-archive-aug2026` | [#75](https://github.com/codepath/pathreview-archive-aug2026/pull/75) | —（无人看过） | 0 | 2026-09-29 | docs: add example curl commands to API reference |
| `petgraph/petgraph` | [#1043](https://github.com/petgraph/petgraph/pull/1043) | —（无人看过） | 0 | 2026-09-16 | fix(visit): grow FixedBitSet visit map instead of panicking when |
| `uiri/toml` | [#460](https://github.com/uiri/toml/pull/460) | —（无人看过） | 0 | 2026-09-12 | fix: parse inline tables in string arrays without IndexError |
| `python-attrs/attrs` | [#1618](https://github.com/python-attrs/attrs/pull/1618) | —（无人看过） | 0 | 2026-09-03 | fix: rewrite __class__ closure cells of methods hidden in decora |
| `protectai/modelscan` | [#371](https://github.com/protectai/modelscan/pull/371) | —（无人看过） | 0 | 2026-08-27 | build: make NumPy an optional dependency |

### unstable · 检查未过或未完成（15 个）

| 仓库 | # | 最后发言 | 评论 | 更新 | 标题 |
|---|---:|---|---:|---|---|
| `kubeflow/testing` | [#1072](https://github.com/kubeflow/testing/pull/1072) | TrueFurina | 9 | 2026-10-28 | feat: add reusable create-cluster (Kind) composite action |
| `TencentCloud/octop-harness` | [#116](https://github.com/TencentCloud/octop-harness/pull/116) | —（无人看过） | 0 | 2026-10-28 | fix(teams): isolate inbox worker from caller's contextvars (#115 |
| `TencentCloud/Octop` | [#2376](https://github.com/TencentCloud/Octop/pull/2376) | TrueFurina | 1 | 2026-10-28 | fix(utils): bound download filename by UTF-8 bytes to avoid over |
| `TencentCloud/Octop` | [#2369](https://github.com/TencentCloud/Octop/pull/2369) | TrueFurina | 1 | 2026-10-28 | docs: fix wizard password path in .env.example (post-#2174) |
| `TencentCloud/octop-memory` | [#33](https://github.com/TencentCloud/octop-memory/pull/33) | —（无人看过） | 0 | 2026-10-28 | fix(manual-docs): advance audit cursor on uncertain results |
| `TencentCloud/Octop` | [#2372](https://github.com/TencentCloud/Octop/pull/2372) | TrueFurina | 1 | 2026-10-28 | fix(env): 未闭合引号不再吞掉 ~/.octop/env 后续变量 (#2269) |
| `TencentCloud/octop-harness` | [#83](https://github.com/TencentCloud/octop-harness/pull/83) | TrueFurina | 3 | 2026-10-28 | feat(tool_guard): detect Windows and PowerShell attack commands |
| `TencentCloud/octop-memory` | [#29](https://github.com/TencentCloud/octop-memory/pull/29) | Bosheng0422 | 1 | 2026-10-27 | fix(memory): batch extraction and persist the extracted cursor ( |
| `TrueFurina/SecAutoMind-src` | [#74](https://github.com/TrueFurina/SecAutoMind-src/pull/74) | —（无人看过） | 0 | 2026-10-26 | feat(llmchannel): 新增 LLM 调用全局并发护栏 LLMGuard |
| `TencentCloud/octop-memory` | [#30](https://github.com/TencentCloud/octop-memory/pull/30) | —（无人看过） | 0 | 2026-10-26 | fix(storage): honor rejected candidates when deduplicating re-sc |
| `TencentCloud/octop-harness` | [#106](https://github.com/TencentCloud/octop-harness/pull/106) | —（无人看过） | 0 | 2026-10-25 | fix(llm): bound OpenAI-compatible requests with a default timeou |
| `TencentCloud/Octop` | [#2170](https://github.com/TencentCloud/Octop/pull/2170) | TrueFurina | 3 | 2026-10-24 | docs: complete the ~/.octop layout tree and note the wizard pass |
| `TencentCloud/Octop` | [#2371](https://github.com/TencentCloud/Octop/pull/2371) | —（无人看过） | 0 | 2026-10-23 | fix(cli): 跨文件系统导出备份不再因 EXDEV 失败 (#2321) |
| `httpie/cli` | [#1952](https://github.com/httpie/cli/pull/1952) | TrueFurina | 2 | 2026-10-17 | feat: show request items separators in naked invocation usage |
| `dask/dask` | [#12576](https://github.com/dask/dask/pull/12576) | TrueFurina | 3 | 2026-10-17 | Add `mode` parameter to `dask.array.linalg.qr` |

### unknown · GitHub 尚未算出合并状态（2 个）

| 仓库 | # | 最后发言 | 评论 | 更新 | 标题 |
|---|---:|---|---:|---|---|
| `TrueFurina/xihu-sword-ctf-agent` | [#28](https://github.com/TrueFurina/xihu-sword-ctf-agent/pull/28) | —（无人看过） | 0 | 2026-10-24 | [无任务:测试] core.bare 判据补 29 条用例（实现已随 02e6f998 进 main） |
| `Trustpoint-Project/trustpoint` | [#901](https://github.com/Trustpoint-Project/trustpoint/pull/901) | TrueFurina | 1 | 2026-10-17 | docs: improve .env.example with per-variable explanations |

`unstable` 要分两种情况：`kubeflow/testing #1072` 是刚推的新 commit 在排队（正常）；
其余长期 unstable 多半是 CI 环境问题而非代码问题——这种去修 CI 不如重开一个干净的 PR。

---

## 今天真正该做的三件事

1. **解 `opendatahub-io/notebooks #4461` 的冲突** —— 8 条评论，有人在等，是唯一"有人在等你"的 dirty。
2. **重做 `unstructured #4462`** —— 别解 932 行的冲突，从 master 重开一个只含 `clean_newline` 的 PR。
3. **`TrueFurina/rich#1` 二选一** —— 推上游或关掉，别让它再躺着。

其余 40 个，**最有效的动作是什么都不做**。你已经清掉 20 个噪音，剩下的多数是真在等对方。

---

## 进展（23:37–23:45）

### `unstructured #4464` 已修好

| | 之前 | 现在 |
|---|---|---|
| mergeable_state | `dirty` | `clean` 冲突已消（`mergeable: true`） |
| 规模 | +12/−3，4 个 hunk | **+8/−2，1 个文件，1 个 DCO commit** |
| head | `4b05adf` | `82f3514` |

**根因不是冲突难解，是夹带了已过时的改动。** 原 PR 的 4 个 hunk 里有一个是给 JSON/NDJSON 路径补
`encoding=encoding`——而 `main` 第 271 行**已经这么写了**。那个 hunk 在跟上游的同一处代码打架，
这才是两个月一直 dirty 的原因。删掉它，剩下正是 issue #3063 要的三行。

说明已发：[#issuecomment-6473433057](https://github.com/Unstructured-IO/unstructured/pull/4464#issuecomment-6473433057)
回滚点：分支旧 head `4b05adfbfd`（`PATCH refs/heads/... {"sha": "...", "force": true}`）。

### 剩下两个 dirty 的判断没变

- `unstructured #4462`（+932/−903）：不是解冲突，是**从 master 重做只保留 `clean_newline`**。
  这个改动本身是大特性，需要完整跑测试，不适合在没跑通测试的情况下推。
- `opendatahub-io/notebooks #4461`（8 条评论）：有人在等，但改动涉及 workflow 作用域，需先看讨论。

---

## 更正：`opendatahub-io/notebooks #4461` 不是"有人在等"

我把它列为"唯一有人在等的 dirty"，错了。实际状态：

```
labels: do-not-merge/hold · needs-rebase · ok-to-test · tide/merge-method-squash · size/l · review-requested
```

维护者 **jiridanek（2026-09-01）**：

> **/hold** I'm a fan of this, but IntelliJ does not resolve the `$/` paths for autocompletion, so I'd rather wait for that feature.

也就是说：

- 8 条评论里 6 条是 bot（openshift-ci ×2、github-actions、coderabbit、codecov），1 条是维护者的 `/hold`，1 条是本人的回应。
- 这是**在等上游工具支持**，不是等代码修改。
- 我查了 JetBrains 官方文档（2025.2 英文版 + 中文版），GitHub Actions 功能清单里**没有** `$/` 自引用路径的解析或补全。

**结论：什么都不做。** 27 个文件、27 个 commit 的 rebase 是纯浪费，而且带着 `do-not-merge/hold` 去 rebase，在维护者眼里就是"没读我的评论"。

唯一值得做的时机是：JetBrains 宣布支持 `$/` 之后，在 PR 里贴一条 changelog 链接，问一句是否解除 hold。那时候的评论是"信息"，不是"催更"。
