import json, subprocess, time, urllib.request, urllib.error, http.client

TOKEN = subprocess.run(["powershell","-NoProfile","-Command",
    "[Environment]::GetEnvironmentVariable('GITHUB_TOKEN','User')"],
    capture_output=True, text=True).stdout.strip()
H = {"Authorization":"Bearer "+TOKEN,"User-Agent":"raccoon","Accept":"application/vnd.github+json","Connection":"close"}

def get(url, tries=6):
    for i in range(tries):
        try:
            req = urllib.request.Request(url, headers=H)
            with urllib.request.urlopen(req, timeout=60) as r:
                parts=[]
                try:
                    while True:
                        b=r.read(32768)
                        if not b: break
                        parts.append(b)
                except http.client.IncompleteRead as e:
                    parts.append(e.partial)
                body=b"".join(parts)
            return json.loads(body)
        except Exception as e:
            print("retry", i, repr(e)[:80], url[-30:]); time.sleep(3)
    return None

data = json.load(open("raw.json", encoding="utf-8"))
have = {(s["id"]) for s in data["starred"]}
added = 0
for page in (2,3,4,5):
    chunk = get(f"https://api.github.com/user/starred?per_page=100&page={page}")
    if not chunk: continue
    for s in chunk:
        if s["id"] not in have:
            data["starred"].append(s); have.add(s["id"]); added += 1
    if len(chunk) < 100: break

json.dump(data, open("raw.json","w",encoding="utf-8"), ensure_ascii=False)
print("starred total:", len(data["starred"]), "added:", added)
