import json, subprocess, time, urllib.request, urllib.error, http.client

TOKEN = subprocess.run(["powershell","-NoProfile","-Command",
    "[Environment]::GetEnvironmentVariable('GITHUB_TOKEN','User')"],
    capture_output=True, text=True).stdout.strip()
H = {"Authorization":"Bearer "+TOKEN,"User-Agent":"raccoon","Accept":"application/vnd.github+json","Connection":"close"}

def get(url, tries=3):
    for i in range(tries):
        try:
            req = urllib.request.Request(url, headers=H)
            with urllib.request.urlopen(req, timeout=45) as r:
                parts=[]
                try:
                    while True:
                        b=r.read(16384)
                        if not b: break
                        parts.append(b)
                except http.client.IncompleteRead as e:
                    parts.append(e.partial)
                body=b"".join(parts)
            return json.loads(body)
        except Exception as e:
            print("retry", i, repr(e)[:60], url[-24:], flush=True); time.sleep(2)
    return None

data = json.load(open("raw.json", encoding="utf-8"))
have = {s["id"] for s in data["starred"]}
for page in range(1, 21):
    chunk = get(f"https://api.github.com/user/starred?per_page=25&page={page}")
    if not chunk:
        print("stop at page", page, flush=True); break
    new = [s for s in chunk if s["id"] not in have]
    for s in new:
        data["starred"].append(s); have.add(s["id"])
    print("page", page, "got", len(chunk), "new", len(new), "total", len(data["starred"]), flush=True)
    if len(chunk) < 25: break

json.dump(data, open("raw.json","w",encoding="utf-8"), ensure_ascii=False)
print("FINAL starred:", len(data["starred"]), flush=True)
