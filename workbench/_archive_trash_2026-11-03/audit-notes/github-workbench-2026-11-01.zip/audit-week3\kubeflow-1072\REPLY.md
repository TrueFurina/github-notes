# kubeflow/testing #1072 · 待发布回复稿

推到 fork 之后（`push_fix.py --yes`），把下面这段贴到 PR，替换掉草稿里的 commit sha。
**不要在贴完这条之后再加任何 ping。** 维护者 10-27 已经明确只差这两点，改完就该等。

---

Thanks @juliusvonkohout — both points are addressed in `<SHA>`.

**1. Kubernetes version selection.** You were right that the version input was decorative.
`kubernetes-version` only fed `kubectl_version`, while the cluster's server version was decided
by the `kind-node-image` default. Overriding the version alone still produced a v1.37.0 cluster,
which is the exact failure mode the action is supposed to prevent.

Fixed by making the image follow the version unless it is pinned explicitly:

```yaml
kind-node-image:
  default: ""            # was: kindest/node:v1.37.0@sha256:...
node_image: ${{ inputs.kind-node-image || format('kindest/node:{0}', inputs.kubernetes-version) }}
```

- Default path: `kubernetes-version: v1.36.0` → `kindest/node:v1.36.0`, kubectl `v1.36.0`. One input, one cluster version.
- Pinned path: set `kind-node-image` to a `tag@sha256:...` and it wins, so digest pinning is still available for supply-chain reasons.
- Both input descriptions now say which one wins.

**2. License headers.** Both new YAML files now start with the year-less Apache-2.0 header copied
verbatim from `hack/boilerplate/boilerplate.sh.txt`. I used the `sh` template deliberately:
`boilerplate.py` maps `yaml`/`yml` to the `sh` stem (`EXTENSION_TEMPLATES`, line ~62), so the
year-less hash-comment header is the one the new-file check expects.

**What I verified and what I did not.** YAML parses and the header matches the template
byte-for-byte. I could **not** exercise real cluster creation — no Docker on my side either —
so this is not evidence that the Kind bootstrap works, only that the two review points are gone.
If you want the cluster path covered, the composite action's only moving parts are
`node_image`/`version`/`config`, and a smoke job that creates a cluster with
`kubernetes-version: v1.36.0` and asserts `kubectl version --short` would close that gap.

---

## 为什么这段这么写

| 写法 | 原因 |
|---|---|
| 先复述你的判断（"the version input was decorative"） | 承认对方发现的问题，比"已修复"三个字有用 |
| 给出根因链条（version → kubectl only → image default 决定集群版本） | 证明不是照着意见改字符串，而是真理解了 |
| 明确写"我没有验证什么" | 维护者最反感把"没测"说成"测过了"；主动划边界反而加分 |
| 提一个具体的补测方案 | 把"要不要加测试"的球踢回去，且方案是可执行的 |
| 结尾不加 ping | `zola`、`Octop #2170` 两次都栽在催更上 |
