"""第 2 周执行器：零文档仓补 README、Denia 补 CI、补齐 description / topics。

    python apply_week2.py plan
    python apply_week2.py apply all --yes
    python apply_week2.py apply W1 --yes
    python apply_week2.py verify
"""
import argparse
import base64
import json
import os
import sys
import urllib.request

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, r"D:/github/github-audit")
sys.path.insert(0, HERE)

import specs_week2 as S  # noqa: E402
from ghlib import api, HEADERS  # noqa: E402

OWNER = "TrueFurina"


def _req(method, path, body=None):
    req = urllib.request.Request(
        "https://api.github.com" + path,
        data=json.dumps(body).encode("utf-8") if body is not None else None,
        headers={**HEADERS, "Content-Type": "application/json"},
        method=method)
    try:
        with urllib.request.urlopen(req, timeout=60) as r:
            return json.loads(r.read() or b"{}")
    except Exception as e:  # noqa: BLE001
        detail = getattr(e, "read", lambda: b"")()
        return {"__error": str(e), "detail": detail.decode("utf-8", "ignore")[:300]}


def repo_info(repo):
    return api(f"/repos/{OWNER}/{repo}")


def get_file(repo, path):
    info = repo_info(repo)
    if "__error" in info:
        return None, None, None
    branch = info["default_branch"]
    r = api(f"/repos/{OWNER}/{repo}/contents/{path}?ref={branch}")
    if isinstance(r, dict) and r.get("content") and "__error" not in r:
        return base64.b64decode(r["content"]).decode("utf-8"), r["sha"], branch
    return None, None, branch


def put_file(repo, path, text, sha, branch, message, dry):
    if dry:
        return "dry-run"
    body = {"message": message, "branch": branch,
            "content": base64.b64encode(text.encode("utf-8")).decode("ascii")}
    if sha:
        body["sha"] = sha
    r = _req("PUT", f"/repos/{OWNER}/{repo}/contents/{path}", body)
    if r.get("__error"):
        return f"ERROR {r['__error']} {r.get('detail','')[:120]}"
    return "commit " + (r.get("commit") or {}).get("sha", "")[:7]


def w1_readmes(dry):
    print("\n===== W1 零文档仓补 README（只新增，不覆盖）=====")
    for repo, text in S.README_NEW.items():
        old, sha, branch = get_file(repo, "README.md")
        if old is not None:
            print(f"  [{repo}] 已有 README（{len(old)} 字符），跳过 —— 不覆盖你的内容")
            continue
        print(f"  [{repo}] 新建 README.md，{len(text)} 字符，{len(text.splitlines())} 行")
        print("    " + put_file(repo, "README.md", text, None, branch,
                                "docs: add README (what this repo is / relation to main repo / caveats)",
                                dry))


def w2_denia_ci(dry):
    print("\n===== W2 Denia 补首个 CI =====")
    repo = "Denia"
    old, sha, branch = get_file(repo, S.DENIA_CI_PATH)
    if old == S.DENIA_CI:
        print("  已有相同内容，跳过")
        return
    action = "覆盖" if old else "新建"
    print(f"  [{repo}/{S.DENIA_CI_PATH}] {action}，{len(S.DENIA_CI.splitlines())} 行")
    print("    结构: syntax(硬门禁 compileall) + unit(观察模式 pytest 55 个用例) + requirements 校验")
    print("    " + put_file(repo, S.DENIA_CI_PATH, S.DENIA_CI, sha, branch,
                            "ci: add first GitHub Actions workflow\n\n"
                            "syntax 为硬门禁（compileall），unit 先以观察模式跑通 55 个用例，"
                            "连续 3 次全绿后再去掉 continue-on-error。", dry))


def w5_denia_conftest(dry):
    print("\n===== W5 Denia 测试收集隔离（conftest）=====")
    repo, path = "Denia", S.DENIA_CONFTEST_PATH
    old, sha, branch = get_file(repo, path)
    if old == S.DENIA_CONFTEST:
        print("  已有相同内容，跳过")
        return
    print(f"  [{repo}/{path}] {'覆盖' if old else '新建'}，排除 test_doctor_asr.py / _dlg_voice_harness.py")
    print("    " + put_file(repo, path, S.DENIA_CONFTEST, sha, branch,
                            "test: keep script-style self-checks out of pytest collection\n\n"
                            "test_doctor_asr.py 在 import 阶段调用 sys.exit(1)，"
                            "会让 pytest 以 INTERNALERROR 中断整个收集。\n"
                            "用 collect_ignore 显式排除，脚本仍可单独运行。", dry))


def w6_denia_release(dry):
    import specs_release as R
    print("\n===== W6 Denia 打包/发布工作流 =====")
    old, sha, branch = get_file(R.REPO, R.PATH)
    if old == R.YAML:
        print("  已有相同内容，跳过")
        return
    print(f"  [{R.REPO}/{R.PATH}] {'覆盖' if old else '新建'}")
    print("    触发: workflow_dispatch 或 push tag v*；发布用 runner 自带 gh CLI（不引第三方 action）")
    print("    " + put_file(R.REPO, R.PATH, R.YAML, sha, branch,
                            "ci: add release workflow (make_dist + gh release create)\n\n"
                            "复用 tools/make_dist.py 的白名单组装与三道闸；tag v* 时用 gh CLI 发 Release。",
                            dry))


def w7_ci_v2(dry):
    import specs_ci2 as C
    print("\n===== W7 Denia CI 第二版（区分用例与自检脚本）=====")
    for path, text, note in (
        ("src/tests/conftest.py", C.CONFTEST,
         "test: skip script-style self-checks by content, not by hand-kept list"),
        (".github/workflows/ci.yml", C.CI,
         "ci: split pytest cases from self-check scripts\n\n"
         "src/tests 下 41 个文件只有 5 个含 def test_，其余是 import 期 sys.exit 的自检脚本，"
         "被收集会让 pytest INTERNALERROR 中断整个会话。"),
    ):
        old, sha, branch = get_file("Denia", path)
        if old == text:
            print(f"  [{path}] 已是目标内容，跳过")
            continue
        print(f"  [Denia/{path}] {'覆盖' if old else '新建'}")
        print("    " + put_file("Denia", path, text, sha, branch, note, dry))


def w8_ci_v3(dry):
    import specs_ci3 as C
    print("\n===== W8 Denia CI 第三版（以脚本为主，pytest 兜纯用例）=====")
    for path, text, note in (
        ("src/tests/conftest.py", C.CONFTEST,
         "test: exclude scripts and main()-driven hybrid files from collection"),
        (".github/workflows/ci.yml", C.CI,
         "ci: run test_*.py as scripts; pytest only standalone modules\n\n"
         "src/tests 里多数 test_* 是需要 info 字典的辅助函数（fixture 'info' not found），"
         "原生用法是 python src/tests/xxx.py。"),
    ):
        old, sha, branch = get_file("Denia", path)
        if old == text:
            print(f"  [{path}] 已是目标内容，跳过")
            continue
        print(f"  [Denia/{path}] {'覆盖' if old else '新建'}")
        print("    " + put_file("Denia", path, text, sha, branch, note, dry))


def w3_descriptions(dry):
    print("\n===== W3 补 description =====")
    for repo, desc in S.DESCRIPTIONS.items():
        info = repo_info(repo)
        cur = info.get("description")
        if cur == desc:
            print(f"  [{repo}] 已是目标值，跳过")
            continue
        print(f"  [{repo}] {cur!r} -> {desc!r}")
        if not dry:
            r = _req("PATCH", f"/repos/{OWNER}/{repo}", {"description": desc})
            print("    结果:", r.get("description") if not r.get("__error")
                  else f"ERROR {r['__error']} {r.get('detail','')[:100]}")


def w4_topics(dry):
    print("\n===== W4 补 topics =====")
    for repo, topics in S.TOPICS.items():
        if repo in S.TOPICS_SKIP:
            continue
        info = repo_info(repo)
        cur = info.get("topics") or []
        if set(cur) >= set(topics):
            print(f"  [{repo}] 已覆盖，跳过")
            continue
        print(f"  [{repo}] {len(cur)} -> {len(topics)} 个: {', '.join(topics)}")
        if not dry:
            r = _req("PUT", f"/repos/{OWNER}/{repo}/topics", {"names": topics})
            print("    结果:", r.get("names") if not r.get("__error")
                  else f"ERROR {r['__error']} {r.get('detail','')[:100]}")


PLANNERS = {"W1": w1_readmes, "W2": w2_denia_ci, "W3": w3_descriptions,
            "W4": w4_topics, "W5": w5_denia_conftest, "W6": w6_denia_release,
            "W7": w7_ci_v2, "W8": w8_ci_v3}


def verify():
    print("=" * 74)
    ok = True
    for repo in S.README_NEW:
        txt, _, _ = get_file(repo, "README.md")
        good = bool(txt)
        ok &= good
        print(f"  [{'OK' if good else 'FAIL'}] README {repo:38} {len(txt or '')} 字符")
    txt, _, _ = get_file("Denia", S.DENIA_CI_PATH)
    print(f"  [{'OK' if txt else 'FAIL'}] CI Denia/{S.DENIA_CI_PATH}")
    ok &= bool(txt)
    for repo in S.DESCRIPTIONS:
        cur = repo_info(repo).get("description")
        print(f"  [{'OK' if cur else 'FAIL'}] desc {repo:40} {'有' if cur else '空'}")
        ok &= bool(cur)
    for repo in S.TOPICS:
        if repo in S.TOPICS_SKIP:
            continue
        n = len(repo_info(repo).get("topics") or [])
        print(f"  [{'OK' if n else 'FAIL'}] topics {repo:38} {n} 个")
        ok &= bool(n)
    print("\n结论:", "全部通过" if ok else "有未通过项")
    return 0 if ok else 1


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("cmd", choices=["plan", "apply", "verify"])
    ap.add_argument("which", nargs="?", default="all")
    ap.add_argument("--yes", action="store_true")
    a = ap.parse_args()
    if a.cmd == "verify":
        return verify()
    if a.cmd == "apply" and not a.yes:
        print("拒绝执行：apply 需要 --yes。先跑 `plan`。")
        return 1
    dry = a.cmd == "plan"
    keys = list(PLANNERS) if a.which == "all" else [x.strip().upper() for x in a.which.split(",")]
    if dry:
        print("DRY RUN —— 不写远端")
    for k in keys:
        if k in PLANNERS:
            PLANNERS[k](dry)
    return 0


if __name__ == "__main__":
    sys.exit(main())
