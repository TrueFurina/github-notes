"""把 xuandun / 2026-CC 的 LICENSE 换成标准 MIT 全文。

依据：两仓贡献者都只有 TrueFurina（4 / 12 commits），README 与徽章已对外声明 MIT，
LICENSE 文件却是 All Rights Reserved —— 与另外三个仓同样的矛盾，处理方式一致。

版权行沿用各自 README 里已经写明的持有人，不擅自改成个人名。

    python apply_license_final.py            # 预览
    python apply_license_final.py --yes      # 执行
"""

import argparse
import base64
import json
import os
import sys
import urllib.request

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, r"D:/github/github-audit")
from ghlib import api, HEADERS, OWNER  # noqa: E402

TARGETS = {
    # repo: (版权行, README 里对应的持有人说法)
    "xuandun-cyber-range": ("Copyright (c) 2026 玄盾 XUANDUN", "© 2026 玄盾 XUANDUN"),
    "2026-Challenge-Cup-Security-LLM-Triage-Agent":
        ("Copyright (c) 2026 Minjiang University Team", "© Minjiang University Team"),
}

MIT = open(os.path.join(HERE, "files", "LICENSE-MIT.txt"), encoding="utf-8").read()


def _put(repo, text, sha, message):
    body = {"message": message,
            "content": base64.b64encode(text.encode("utf-8")).decode("ascii"),
            "sha": sha, "branch": "main"}
    req = urllib.request.Request(f"https://api.github.com/repos/{OWNER}/{repo}/contents/LICENSE",
                                 data=json.dumps(body).encode("utf-8"),
                                 headers={**HEADERS, "Content-Type": "application/json"},
                                 method="PUT")
    try:
        with urllib.request.urlopen(req, timeout=60) as r:
            return json.loads(r.read())["commit"]["sha"][:12]
    except Exception as e:  # noqa: BLE001
        return "ERROR %s %s" % (e, getattr(e, "read", lambda: b"")().decode("utf-8", "ignore")[:150])


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--yes", action="store_true")
    a = ap.parse_args()
    for repo, (copyright_line, readme_holder) in TARGETS.items():
        info = api(f"/repos/{OWNER}/{repo}/contents/LICENSE")
        if not (isinstance(info, dict) and info.get("content")):
            print(f"[{repo}] LICENSE 读不到，跳过")
            continue
        cur = base64.b64decode(info["content"]).decode("utf-8", "ignore")
        new = MIT.replace("Copyright (c) [year] [fullname]", copyright_line)
        print(f"\n[{repo}]")
        print(f"  当前: {len(cur)} 字符，首行 {cur.splitlines()[0][:50]!r}")
        print(f"  目标: {len(new)} 字符，版权行 {copyright_line!r}（对齐 README 的 {readme_holder!r}）")
        if cur.strip() == new.strip():
            print("  已是目标内容，跳过")
            continue
        if not a.yes:
            print("  [预览] 未写入")
            continue
        print("  commit:", _put(repo, new, info["sha"],
                                "chore(license): replace source-available text with standard MIT\n\n"
                                "README 与徽章已声明 MIT，LICENSE 文件却是 All Rights Reserved。"))


if __name__ == "__main__":
    main()
