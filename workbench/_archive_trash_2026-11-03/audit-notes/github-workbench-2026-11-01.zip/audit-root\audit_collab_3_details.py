import sys, json, time
sys.path.insert(0, r"D:/github/github-audit")
from ghlib import api

TARGETS = [
    ("langgenius/dify", 40801),
    ("seanmonstar/reqwest", 3100),
    ("unicode-rs/unicode-segmentation", 183),
    ("CodeGraphContext/CodeGraphContext", 1758),
    ("CodeGraphContext/CodeGraphContext", 1676),
    ("CodeGraphContext/CodeGraphContext", 1698),
    ("MARL-ECDSA-Consensus/MARL-ECDSA-Consensus", 4),
    ("MARL-ECDSA-Consensus/MARL-ECDSA-Consensus", 3),
    ("kubeflow/testing", 1072),
    ("kubeflow/testing", 1071),
    ("TencentCloud/Octop", 2170),
    ("TencentCloud/octop-harness", 83),
    ("TencentCloud/Octop", 2375),
    ("TencentCloud/Octop", 2373),
    ("verialabs/ctf-agent", 10),
    ("benoitc/gunicorn", 3683),
    ("Unstructured-IO/unstructured", 4463),
    ("agno-agi/agno", 9837),
    ("pallets/jinja", 2250),
    ("fastapi/fastapi", 16262),
]

out = {}
for repo, num in TARGETS:
    pr = api(f"/repos/{repo}/pulls/{num}")
    cms = api(f"/repos/{repo}/issues/{num}/comments")
    rev = api(f"/repos/{repo}/pulls/{num}/reviews")
    rec = {
        "repo": repo, "num": num,
        "title": (pr or {}).get("title"),
        "state": (pr or {}).get("state"),
        "merged": (pr or {}).get("merged"),
        "merged_at": (pr or {}).get("merged_at"),
        "created_at": (pr or {}).get("created_at"),
        "additions": (pr or {}).get("additions"),
        "deletions": (pr or {}).get("deletions"),
        "changed_files": (pr or {}).get("changed_files"),
        "body": ((pr or {}).get("body") or "")[:1500],
        "comments": [
            {"user": (c.get("user") or {}).get("login"),
             "assoc": c.get("author_association"),
             "body": (c.get("body") or "")[:700]}
            for c in (cms if isinstance(cms, list) else [])
        ],
        "reviews": [
            {"user": (r.get("user") or {}).get("login"),
             "state": r.get("state"),
             "body": (r.get("body") or "")[:500]}
            for r in (rev if isinstance(rev, list) else [])
        ],
    }
    out[f"{repo}#{num}"] = rec
    print(f"{repo}#{num} merged={rec['merged']} +{rec['additions']}/-{rec['deletions']} files={rec['changed_files']} comments={len(rec['comments'])} reviews={len(rec['reviews'])}")
    time.sleep(0.4)

json.dump(out, open(r"D:/github/github-audit/_collab_pr_details.json", "w", encoding="utf-8"), ensure_ascii=False, indent=1)
print("saved", len(out))
