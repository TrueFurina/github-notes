"""从可合并清单里挑出「最保守的 10 个」——文件不与队列里其他 PR 重叠。

为什么需要这层筛选
------------------
`mergeable=true` 只说明"此刻与 base 无冲突"。但如果同一个文件被队列里另外 7 个 PR 同时改，
合掉一个之后，剩下 6 个立刻变成 `dirty`——**合一个制造六个冲突**，队列反而更难收。

所以这里按"文件独占度"排序：
1. 只保留 `mergeable=true`；
2. 拉出每个 PR 改动的文件；
3. 计算每个文件的"竞争者数量"（队列里还有几个 PR 改同一文件）；
4. 优先选竞争者最少的，且彼此之间文件不重叠；
5. 取 10 个。

只读 + 只写本地 md。缓存 `files_cache.json`，重复跑不重复打 API。

用法：python autopilot/starter10.py [数量=10]
"""
from __future__ import annotations

import json
import os
import sys
from concurrent.futures import ThreadPoolExecutor
from datetime import datetime

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, os.path.dirname(HERE))

from ghlib import api, OWNER  # noqa: E402

TRIO = ["TencentCloud/Octop", "TencentCloud/octop-harness", "TencentCloud/octop-memory"]
DETAILS = os.path.join(HERE, "octop_details.json")
FILES = os.path.join(HERE, "files_cache.json")
OUT = os.path.join(HERE, f"MERGE-STARTER-{datetime.now():%m%d}.md")

PROTECTED = {
    ("TencentCloud/octop-memory", 29),
    ("TencentCloud/Octop", 2170),
    ("TencentCloud/octop-harness", 83),
}


def listing(repo: str, pages: int = 16, per: int = 20) -> list[dict]:
    def one(page: int):
        try:
            c = api(f"/repos/{repo}/pulls?state=open&per_page={per}&page={page}")
            return c if isinstance(c, list) else []
        except Exception:  # noqa: BLE001
            return []

    out: dict[int, dict] = {}
    with ThreadPoolExecutor(max_workers=8) as ex:
        for chunk in ex.map(one, range(1, pages + 1)):
            for p in chunk:
                out[p["number"]] = p
    return list(out.values())


def main() -> int:
    want = int(sys.argv[1]) if len(sys.argv) > 1 and sys.argv[1].isdigit() else 10
    details = json.load(open(DETAILS, encoding="utf-8")) if os.path.exists(DETAILS) else {}
    files_cache = json.load(open(FILES, encoding="utf-8")) if os.path.exists(FILES) else {}

    rows = []
    for repo in TRIO:
        for p in listing(repo):
            if (p.get("user") or {}).get("login") != OWNER:
                continue
            key = f"{repo}#{p['number']}"
            d = details.get(key) or {}
            rows.append({"key": key, "repo": repo, "num": p["number"], "title": p["title"],
                         "created": p["created_at"][:10],
                         "age": (datetime.now() - datetime.strptime(p["created_at"][:10], "%Y-%m-%d")).days,
                         "mergeable": d.get("mergeable"),
                         "add": d.get("add"), "del": d.get("del")})
    cand = [r for r in rows if r["mergeable"] is True and (r["repo"], r["num"]) not in PROTECTED]
    print(f"open {len(rows)} | 可合且非保护 {len(cand)} | 拉文件列表（含保护名单，用于算竞争度）…")

    def fetch(r):
        if r["key"] in files_cache:
            return r, files_cache[r["key"]]
        try:
            fl = api(f"/repos/{r['repo']}/pulls/{r['num']}/files?per_page=100")
            paths = [f["filename"] for f in fl] if isinstance(fl, list) else []
        except Exception:  # noqa: BLE001
            paths = []
        return r, paths

    with ThreadPoolExecutor(max_workers=8) as ex:
        pairs = list(ex.map(fetch, rows))
    for r, paths in pairs:
        r["files"] = paths
        if paths:
            files_cache[r["key"]] = paths
    json.dump(files_cache, open(FILES, "w", encoding="utf-8"), ensure_ascii=False)

    # 每个文件被队列里几个 PR 改动 —— **必须按全量算**：保护名单里的 PR 也是竞争者。
    # 踩过的坑：#34 与受保护的 #29 同改 runtime.py，只统计候选集时竞争度算成 1，
    # 于是 #34 被选进"独占"清单，合它等于抢先覆盖维护者正在复核的 #29。
    contention: dict[str, int] = {}
    for r in rows:
        for f in r["files"]:
            contention[f] = contention.get(f, 0) + 1

    protected_files = {f for r in rows if (r["repo"], r["num"]) in PROTECTED for f in r["files"]}
    cand = [r for r in cand if not (set(r["files"]) & protected_files)]

    def worst(r):
        return max([contention.get(f, 0) for f in r["files"]] or [99])

    def total(r):
        return sum(contention.get(f, 0) for f in r["files"])

    # 只保留"所有文件竞争者都是 1"的（独占），按年龄从老到新
    solo = [r for r in cand if r["files"] and worst(r) == 1]
    solo.sort(key=lambda r: -r["age"])

    picked, used_files = [], set()
    for r in solo:
        if used_files & set(r["files"]):
            continue
        picked.append(r)
        used_files |= set(r["files"])
        if len(picked) >= want:
            break

    lines = [
        f"# 起步 10 个（文件独占，不会连锁制造冲突）",
        "",
        f"生成时间：{datetime.now():%Y-%m-%d %H:%M}",
        f"队列 {len(rows)} 个 · `mergeable=true` 且非保护 {len(cand)} 个 · "
        f"其中**改动的文件没有其他 open PR 同时碰** 的 {len(solo)} 个",
        "",
        "## 为什么按这个顺序合",
        "",
        "`mergeable=true` 只代表「此刻」无冲突。若一个文件被队列里另外 N 个 PR 同时改，",
        "合掉一个之后其余立刻变 `dirty`——**合一个制造 N 个冲突**。下面这些 PR 改的文件，",
        "在队列里**没有第二个 PR 碰**，所以合掉它们不会让任何别的 PR 失效。",
        "",
        "| # | 仓库 | PR | 标题 | 文件 | 规模 | 年龄 |",
        "|---:|---|---|---|---|---:|---:|",
    ]
    for i, r in enumerate(picked, 1):
        t = r["title"].replace("|", "\\|")[:60]
        fl = ", ".join(os.path.basename(f) for f in r["files"][:2])
        if len(r["files"]) > 2:
            fl += f" +{len(r['files']) - 2}"
        size = f"+{r['add']}/−{r['del']}" if r["add"] is not None else "?"
        lines.append(f"| {i} | {r['repo'].split('/')[-1]} | "
                     f"[#{r['num']}](https://github.com/{r['repo']}/pull/{r['num']}) "
                     f"| {t} | {fl} | {size} | {r['age']}d |")

    rest = [r for r in solo if r not in picked][:10]
    lines += ["", f"## 备选（同样独占，若上面有跳过可替补）", ""]
    if rest:
        lines += ["| 仓库 | PR | 标题 | 文件 |", "|---|---|---|---|"]
        for r in rest:
            t = r["title"].replace("|", "\\|")[:58]
            lines.append(f"| {r['repo'].split('/')[-1]} | "
                         f"[#{r['num']}](https://github.com/{r['repo']}/pull/{r['num']}) | {t} | "
                         f"{', '.join(os.path.basename(f) for f in r['files'][:2])} |")
    else:
        lines.append("_（无）_")

    lines += [
        "",
        "## 执行",
        "",
        "```bash",
        "python autopilot/merge_prs.py \\",
        *[f"  {r['repo']}#{r['num']} \\" for r in picked],
        "  --yes",
        "```",
        "",
        "不加 `--yes` 就是 dry-run：会逐个校验 `state=open` / `mergeable=true` / 保护名单再报告。",
        "",
        "> 本文件只读生成：没有合并、没有评论。",
    ]
    open(OUT, "w", encoding="utf-8").write("\n".join(lines) + "\n")
    print(f"写入 {OUT}")
    print(f"独占候选 {len(solo)} | 本次选出 {len(picked)}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
