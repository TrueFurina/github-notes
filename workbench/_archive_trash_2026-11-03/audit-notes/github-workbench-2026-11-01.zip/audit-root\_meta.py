import sys, json
sys.path.insert(0, r'D:/github/github-audit')
from ghlib import api
names = ['AGI-Distiller','passive-recon','MARS-408','xihu-sword-ctf-agent','SecAutoMind','SecAutoMind-src','cyber-terms-hub','physics-scheduler-agent','FDE','MangDeHenZhi','DevRadar-GitHub-Trending-Monitor']
for n in names:
    r = api(f'/repos/TrueFurina/{n}')
    rel = api(f'/repos/TrueFurina/{n}/releases?per_page=5')
    rd = api(f'/repos/TrueFurina/{n}/readme')
    size = rd.get('size') if isinstance(rd, dict) and 'size' in rd else None
    nrel = len(rel) if isinstance(rel, list) else rel
    print(f"{n:38s} star={r.get('stargazers_count'):3} fork={r.get('forks_count'):3} iss={r.get('open_issues_count'):3} watch={r.get('subscribers_count'):2} size={r.get('size'):6}KB lic={(r.get('license') or {}).get('spdx_id')} rel={nrel} readme={size} home={r.get('homepage')} topics={len(r.get('topics') or [])} created={r.get('created_at','')[:10]}")
