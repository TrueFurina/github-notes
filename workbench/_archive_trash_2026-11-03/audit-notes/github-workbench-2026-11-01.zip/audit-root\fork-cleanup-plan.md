# fork 清理执行清单

生成日期 2026-10-28 · 当前 160 个 fork / 5155 MB · 目标 12 个 / 149 MB

> 删除 fork **不会**删除已提交的 PR，贡献图与 Star 均不受影响。

## A 组：立即删除（116 个，2807 MB）

这些上游没有你任何未关闭的 PR，fork 已无用途。

| 体积MB | fork 名 | 上游 | 上游星 |
|---:|---|---|---:|
| 480.6 | `dify` | langgenius/dify | 159807 |
| 345.3 | `docling` | docling-project/docling | 69739 |
| 177.3 | `opensre` | Tracer-Cloud/opensre | 12563 |
| 134.4 | `kana-dojo` | lingdojo/kana-dojo | 3736 |
| 120.6 | `zola` | getzola/zola | 17559 |
| 117.5 | `100LinesOfPythonCode` | sumanth-0/100LinesOfPythonCode | 55 |
| 99.2 | `sqlalchemy` | sqlalchemy/sqlalchemy | 12269 |
| 88.0 | `haxe` | HaxeFoundation/haxe | 6951 |
| 79.9 | `ipython` | ipython/ipython | 16794 |
| 72.6 | `cargo` | rust-lang/cargo | 15645 |
| 61.9 | `cobbler` | cobbler/cobbler | 2778 |
| 61.6 | `faststream` | ag2ai/faststream | 5387 |
| 57.4 | `marm-memory` | Lyellr88/marm-memory | 424 |
| 55.0 | `gitfichas` | jtemporal/gitfichas | 93 |
| 54.1 | `fastapi` | fastapi/fastapi | 104241 |
| 51.6 | `atomcode` | atomgit-atomcode/atomcode | 207 |
| 51.0 | `pontoon` | mozilla/pontoon | 1674 |
| 48.9 | `rich` | Textualize/rich | 57668 |
| 42.3 | `aiohttp` | aio-libs/aiohttp | 16595 |
| 41.0 | `CodeGraphContext` | CodeGraphContext/CodeGraphContext | 4360 |
| 40.9 | `pytest` | pytest-dev/pytest | 14653 |
| 36.2 | `celery` | celery/celery | 29089 |
| 31.3 | `railtracks` | RailtownAI/railtracks | 234 |
| 31.3 | `scrapy` | scrapy/scrapy | 65087 |
| 29.4 | `autosubmit` | BSC-ES/autosubmit | 42 |
| 26.8 | `yottacode` | yottadynamics/yottacode | 7 |
| 20.0 | `clap` | clap-rs/clap | 16804 |
| 18.3 | `peewee` | coleifer/peewee | 11997 |
| 16.4 | `spiderfoot` | smicallef/spiderfoot | 23938 |
| 15.1 | `free-llm-api-hub` | pacocartones/free-llm-api-hub | 110 |
| 14.3 | `briefcase` | beeware/briefcase | 3374 |
| 14.1 | `TorBot` | DedSecInside/TorBot | 5133 |
| 14.0 | `Tiger-Scale-V3` | TigerTag-Project/Tiger-Scale-V3 | 27 |
| 13.3 | `requests` | psf/requests | 54589 |
| 13.0 | `mongodb-odm` | doctrine/mongodb-odm | 1098 |
| 12.4 | `NeuroWealth-Frontend` | Neurowealth/NeuroWealth-Frontend | 3 |
| 12.2 | `apprise` | caronc/apprise | 17659 |
| 11.5 | `Stepik-Python-Grader` | ArtVsMark/Stepik-Python-Grader | 3 |
| 10.6 | `aobench` | MSKazemi/aobench | 10 |
| 10.3 | `agentregistry` | agentregistry-dev/agentregistry | 532 |
| 9.8 | `Nettacker` | OWASP/Nettacker | 5693 |
| 9.3 | `pythonlings` | abhiksark/pythonlings | 24 |
| 8.1 | `tortoise-orm` | tortoise/tortoise-orm | 5638 |
| 7.9 | `hflow` | Hebbian-Robotics/hflow | 304 |
| 7.0 | `server-client-python` | tableau/server-client-python | 719 |
| 6.8 | `killpy` | Tlaloc-Es/killpy | 132 |
| 6.8 | `jinja` | pallets/jinja | 11809 |
| 6.6 | `linkding` | sissbruecker/linkding | 11354 |
| 6.2 | `frameguard` | 488315/frameguard | 1 |
| 5.9 | `gunicorn` | benoitc/gunicorn | 10714 |
| 5.9 | `vtl` | vlang/vtl | 171 |
| 5.9 | `icalendar` | collective/icalendar | 1188 |
| 5.6 | `goldener` | goldener-data/goldener | 15 |
| 5.5 | `Zappa` | Miserlou/Zappa | 11813 |
| 4.6 | `time` | time-rs/time | 1347 |
| 4.5 | `huey` | coleifer/huey | 6056 |
| 4.4 | `django-extensions` | django-extensions/django-extensions | 6805 |
| 4.3 | `composable-data-stack` | RonaldHensbergen/composable-data-stack | 8 |
| 3.0 | `type-fest` | sindresorhus/type-fest | 17475 |
| 3.0 | `pyramid_fullauth` | fizyk/pyramid_fullauth | 29 |
| 3.0 | `json` | serde-rs/json | 5658 |
| 2.8 | `requests-html` | psf/requests-html | 13804 |
| 2.7 | `reqwest` | seanmonstar/reqwest | 11891 |
| 2.4 | `loguru` | Delgan/loguru | 24154 |
| 2.4 | `VoxForge` | Brohammad/VoxForge | 4 |
| 2.1 | `parking_lot` | Amanieu/parking_lot | 3434 |
| 2.1 | `skillware` | ARPAHLS/skillware | 170 |
| 2.1 | `flipper` | quangshuynh/flipper | 7 |
| 2.0 | `unicode-segmentation` | unicode-rs/unicode-segmentation | 683 |
| 2.0 | `user-scanner` | kaifcodec/user-scanner | 5498 |
| 1.7 | `daedalus` | Nitjsefnie-Harness-Commons/daedalus | 3 |
| 1.6 | `contoso-universe-gen` | PesanteAnalytics/contoso-universe-gen | 3 |
| 1.6 | `ZeroSMTP` | msgwing/ZeroSMTP | 5 |
| 1.5 | `awesome-osint` | jivoi/awesome-osint | 30522 |
| 1.5 | `fluxcast` | IlyaP358/fluxcast | 453 |
| 1.5 | `Swasthya-Sathi-AI` | SunnyAgrwl05/Swasthya-Sathi-AI | 10 |
| 1.3 | `Perihelion` | Perihelion-Protocol/Perihelion | 2 |
| 1.3 | `pyjwt` | jpadilla/pyjwt | 5721 |
| 1.2 | `Agronaut` | Rekin226/Agronaut | 5 |
| 1.1 | `mover-git` | quangshuynh/mover-git | 2 |
| 1.1 | `flask-restful` | flask-restful/flask-restful | 6906 |
| 1.0 | `audiobard` | oscarbol09/audiobard | 4 |
| 1.0 | `prd-maker` | jcmaker/prd-maker | 14 |
| 1.0 | `repomin` | fly1d/repomin | 2 |
| 0.9 | `AynOps` | AynOps/AynOps | 29 |
| 0.9 | `AutoRecon` | AutoRecon/AutoRecon | 6139 |
| 0.8 | `wicked_pdf` | mileszs/wicked_pdf | 3572 |
| 0.8 | `Graphlib` | RANDOMFNP/GraphDB | 4 |
| 0.8 | `raglogs` | LAA-Software-Engineering/raglogs | 7 |
| 0.8 | `CFPropertyList` | TECLIB/CFPropertyList | 457 |
| 0.8 | `secret-guard` | taksh1507/secret-guard | 5 |
| 0.7 | `website` | Create-Python-App/website | 2 |
| 0.7 | `gorequest` | parnurzeal/gorequest | 3512 |
| 0.6 | `create-python-app` | Create-Python-App/create-python-app | 3 |
| 0.5 | `steam-value-lookup` | quangshuynh/steam-value-lookup | 2 |
| 0.5 | `rescueloop` | ostapondo/rescueloop | 2 |
| 0.4 | `term_mcp_deepseek` | OthmaneBlial/term_mcp_deepseek | 18 |
| 0.4 | `rai-toolkit` | wandb/rai-toolkit | 40 |
| 0.3 | `Photon` | s0md3v/Photon | 13309 |
| 0.3 | `bookwork` | AndrewMcClain/bookwork | 1 |
| 0.3 | `edaprep` | bijay-odyssey/edaprep | 16 |
| 0.3 | `ai-business-workflow` | ikilic-tech/ai-business-workflow | 2 |
| 0.3 | `agent-tools-mcp-hub` | tarunjandra/agent-tools-mcp-hub | 8 |
| 0.3 | `E.D.I.T.H` | Tiyatrotist/E.D.I.T.H | 6 |
| 0.2 | `create-vlang-app` | Create-Vlang-App/create-vlang-app | 5 |
| 0.2 | `critique` | BistaDinesh03/critique | 9 |
| 0.2 | `100-times-ai-heroes` | masa-san-jp/100-times-ai-heroes | 2 |
| 0.2 | `cva-templates` | Create-Vlang-App/cva-templates | 1 |
| 0.2 | `voxcpm2-api` | shiftbloom-studio/voxcpm2-api | 7 |
| 0.1 | `federated-agent-memory` | camorazrushimoe/federated-agent-memory | 2 |
| 0.1 | `cluster` | blokkaDev/cluster | 5 |
| 0.0 | `Net-Diagnostic-Scripts` | Icedm/Net-Diagnostic-Scripts | 1 |
| 0.0 | `.github-1` | Create-Vlang-App/.github | 2 |
| 0.0 | `aur-package` | Create-Vlang-App/aur-package | 1 |
| 0.0 | `.github` | Create-Python-App/.github | 1 |
| 0.0 | `homebrew-tap` | Create-Vlang-App/homebrew-tap | 1 |

## B 组：先关闭停滞 PR，再删除（32 个，2198 MB）

PR 已挂起 45 天以上，维护者无响应。关闭自己的 PR 是礼貌且干净的做法，之后即可删除 fork。

| 体积MB | fork 名 | 上游 | 上游星 | 挂起天数 |
|---:|---|---|---:|---:|
| 460.1 | `loopback-next` | loopbackio/loopback-next | 5102 | 62 |
| 364.8 | `openalgo` | marketcalls/openalgo | 2926 | 62 |
| 309.1 | `agno` | agno-agi/agno | 42932 | 60 |
| 265.3 | `notebooks` | opendatahub-io/notebooks | 35 | 62 |
| 231.5 | `unstructured` | Unstructured-IO/unstructured | 15631 | 60 |
| 139.8 | `trustpoint` | Trustpoint-Project/trustpoint | 43 | 62 |
| 131.0 | `dask` | dask/dask | 13937 | 60 |
| 76.7 | `corsair` | corsairdev/corsair | 15705 | 61 |
| 45.0 | `CTFd` | CTFd/CTFd | 6894 | 62 |
| 40.3 | `psutil` | giampaolo/psutil | 11311 | 61 |
| 22.8 | `PyGithub` | PyGithub/PyGithub | 7810 | 46 |
| 22.5 | `testing` | kubeflow/testing | 61 | 62 |
| 22.1 | `boto3` | boto/boto3 | 9923 | 61 |
| 14.0 | `blackbird` | antoniaci/blackbird | 9349 | 76 |
| 12.6 | `fail2ban` | fail2ban/fail2ban | 18900 | 75 |
| 6.9 | `wulo-x` | Ayo-faks/wulo-x | 1 | 62 |
| 6.8 | `cli` | httpie/cli | 38678 | 47 |
| 5.6 | `modelscan` | protectai/modelscan | 789 | 62 |
| 5.1 | `attrs` | python-attrs/attrs | 5863 | 55 |
| 4.4 | `git-secret` | sobolevn/git-secret | 4058 | 62 |
| 4.1 | `winston` | winstonjs/winston | 24529 | 61 |
| 2.2 | `arrow` | arrow-py/arrow | 9054 | 61 |
| 2.0 | `nagios` | sous-chefs/nagios | 125 | 62 |
| 1.0 | `Practice-Modern-JavaScript` | abhisekp/Practice-Modern-JavaScript | 13 | 61 |
| 0.7 | `tenacity` | jd/tenacity | 8813 | 46 |
| 0.5 | `feedletter` | smtpfast/feedletter | 3 | 61 |
| 0.5 | `GHunt` | mxrch/GHunt | 19753 | 76 |
| 0.4 | `pathreview` | codepath/pathreview-archive-aug2026 | 1 | 62 |
| 0.4 | `toml` | uiri/toml | 1138 | 46 |
| 0.1 | `QWENTUS` | Aryan27-max/QWENTUS | 2 | 61 |
| 0.0 | `barycenters-go` | barycenters-systems/barycenters-go | 1 | 61 |
| 0.0 | `awesome-ai-agents-security` | ProjectRecon/awesome-ai-agents-security | 78 | 63 |

## C 组：保留（12 个，149 MB）

| 体积MB | fork 名 | 上游 | 上游星 |
|---:|---|---|---:|
| 97.6 | `petgraph` | petgraph/petgraph | 4041 |
| 34.3 | `Octop` | TencentCloud/Octop | 11241 |
| 4.8 | `aho-corasick` | BurntSushi/aho-corasick | 1306 |
| 4.1 | `awesome-claude-skills` | ComposioHQ/awesome-claude-skills | 78156 |
| 1.7 | `octop-harness` | TencentCloud/octop-harness | 125 |
| 1.7 | `proc-macro2` | dtolnay/proc-macro2 | 946 |
| 1.5 | `octop-memory` | TencentCloud/octop-memory | 84 |
| 1.4 | `termcolor` | BurntSushi/termcolor | 492 |
| 1.0 | `thiserror` | dtolnay/thiserror | 5584 |
| 0.8 | `semver` | dtolnay/semver | 674 |
| 0.1 | `ctf-agent` | verialabs/ctf-agent | 890 |
| 0.0 | `awesome-claude-skills-1` | m-fyi/awesome-claude-skills | 3 |
