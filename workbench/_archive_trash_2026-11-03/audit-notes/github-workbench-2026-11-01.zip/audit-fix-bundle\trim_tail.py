"""收尾：删掉 F3 改造后残留的尾部孤立分隔线（`---`）。"""
import sys

sys.path.insert(0, r"D:/github/github-audit")
import os

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)
from apply_p0 import fetch, put  # noqa: E402

REPOS = ["xuandun-cyber-range", "2026-Challenge-Cup-Security-LLM-Triage-Agent"]

for repo in REPOS:
    old, sha, branch = fetch(repo, "README.md")
    if old is None:
        print(repo, "抓取失败")
        continue
    lines = old.split("\n")
    while lines and not lines[-1].strip():
        lines.pop()
    removed = 0
    while lines and lines[-1].strip() in ("---", "***", "___"):
        lines.pop()
        removed += 1
        while lines and not lines[-1].strip():
            lines.pop()
    if not removed and len(lines) == len(old.split("\n")):
        print(f"[{repo}] 无需处理")
        continue
    new = "\n".join(lines) + "\n"
    r = put(repo, "README.md", new, sha, branch,
            "style(readme): drop trailing horizontal rule left by license cleanup",
            dry=False)
    print(f"[{repo}] 删除尾部孤立的 --- :", r)
