import json, subprocess, urllib.request, urllib.error, http.client, base64, re, time

TOKEN = subprocess.run(["powershell","-NoProfile","-Command",
    "[Environment]::GetEnvironmentVariable('GITHUB_TOKEN','User')"],
    capture_output=True, text=True).stdout.strip()
H = {"Authorization":"Bearer "+TOKEN,"User-Agent":"r",
     "Accept":"application/vnd.github+json","Connection":"close"}

def get(u, tries=3):
    for i in range(tries):
        try:
            r = urllib.request.Request(u, headers=H)
            with urllib.request.urlopen(r, timeout=50) as resp:
                parts = []
                try:
                    while True:
                        b = resp.read(65536)
                        if not b: break
                        parts.append(b)
                except http.client.IncompleteRead as e:
                    parts.append(e.partial)
                return json.loads(b"".join(parts))
        except urllib.error.HTTPError as e:
            if e.code == 404: return {"__http": 404}
            time.sleep(1.5)
        except Exception:
            time.sleep(1.5)
    return None

# 直接匹配原始文本，不走复杂正则，减少漏匹配
NEEDLES = re.compile(
    r"(os\.getenv|os\.environ\.get|process\.env\.|getenv|GetEnv|Environment\.GetEnvironmentVariable)",
    re.I)

# 提取 getenv 调用参数
GETENV = re.compile(
    r"""(?:os\.getenv|os\.environ\.get|getenv)\(\s*
        (?P<q1>['"])(?P<name>[A-Za-z0-9_]+)(?P=q1)
        \s*,\s*
        (?P<q2>['"])(?P<default>[^'"]{0,80})(?P=q2)""",
    re.X)

def is_secretish(name):
    return bool(re.search(r"(PASS|PWD|SECRET|KEY|TOKEN|CRED|AUTH)", name, re.I))

def is_placeholder(v):
    if not v.strip(): return True
    return bool(re.match(r"^(your|xxx|change|placeholder|example|dummy|todo|none|null|<|\$\{|\.\.\.)", v.strip(), re.I))

d = json.load(open("raw.json", encoding="utf-8"))
own = [r for r in d["repos"] if not r.get("fork") and not r.get("private")]

EXT = (".py", ".js", ".ts", ".tsx", ".jsx", ".go", ".java", ".yml", ".yaml", ".toml", ".env.example")
SKIP = re.compile(r"(node_modules/|\.venv/|/dist/|/build/|__pycache__/|/vendor/|\.min\.)")

report = []
for idx, r in enumerate(own, 1):
    fn, name = r["full_name"], r["name"]
    t = get(f"https://api.github.com/repos/{fn}/git/trees/HEAD?recursive=1")
    if not t or "__http" in t:
        print(f"[{idx:2d}] {name:34s} SKIP(tree)", flush=True)
        continue

    files = [x for x in t["tree"]
             if x["type"] == "blob"
             and x["path"].endswith(EXT)
             and not SKIP.search(x["path"])
             and x.get("size", 0) < 400_000]

    # 全量扫：不再抽样，但按大小排序控制总量
    files.sort(key=lambda x: x.get("size", 0))
    cap = 120
    scan = files[:cap]
    hits = []
    for x in scan:
        c = get(f"https://api.github.com/repos/{fn}/contents/{x['path']}")
        if not isinstance(c, dict) or not c.get("content"):
            continue
        try:
            text = base64.b64decode(c["content"]).decode("utf-8", "replace")
        except Exception:
            continue
        for m in GETENV.finditer(text):
            nm, dv = m.group("name"), m.group("default")
            if is_secretish(nm) and not is_placeholder(dv):
                hits.append((x["path"], nm, dv))
    cov = f"{len(scan)}/{len(files)}"
    if hits:
        report.append({"repo": name, "full": fn, "cov": cov, "hits": hits})
        print(f"[{idx:2d}] {name:34s} ⚠ {len(hits):2d} 处  (扫 {cov})", flush=True)
    else:
        print(f"[{idx:2d}] {name:34s} -       (扫 {cov})", flush=True)

print("\n" + "=" * 78)
for item in report:
    print(f"\n[{item['repo']}] https://github.com/{item['full']}  (覆盖 {item['cov']})")
    for path, nm, dv in item["hits"]:
        print(f"   {nm:32s} 默认值长度={len(dv):2d}  @ {path}")

json.dump(report, open("failopen_full.json", "w", encoding="utf-8"), ensure_ascii=False, indent=1)
print(f"\n命中仓库: {len(report)}")
