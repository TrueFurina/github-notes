"""Denia CI 第三版：以"脚本"为第一公民，pytest 只兜真正的用例模块。

推导过程（都是 CI 日志逼出来的，不是猜的）：

1. `src/tests/` 41 个 .py，36 个没有 `def test_` → import 期 sys.exit，直接炸收集；
2. 剩下 5 个里有 4 个定义 `def main()`，且 `test_*` 函数签名带 `info: dict` 参数
   （`fixture 'info' not found`）——它们是脚本里的辅助函数，被 main() 调用，不是用例；
3. 所以这个仓库的测试原生用法是 `python src/tests/xxx.py`，退出码即结论。

结论：CI 以"逐个跑脚本"为主，pytest 只收集不含 main() 的纯用例模块。
"""

CONFTEST = '''"""pytest 收集策略。

`src/tests/` 下的文件分三类，只有第三类该进 pytest：

1. **纯自检脚本** —— 模块级顺序执行、打印 OK/FAIL、末尾 `sys.exit(1)`；
2. **带 main() 的混合文件** —— 定义 `def main()` 自己调度，里面的 `test_*` 往往
   只是辅助函数（例如 `test_parity(api, info: dict)` 需要 info 字典，
   pytest 会把它当 fixture 请求，报 `fixture 'info' not found`）；
3. **纯 pytest 用例模块** —— 有 `def test_`、没有 `def main()`，用例自包含。

第 1、2 类被 pytest import 时，要么抛 SystemExit 中断整个会话，要么满屏 fixture 报错。
所以按"内容特征"动态排除，而不是人工维护名单：

    没有 def test_   → 排除（脚本）
    有 def main()    → 排除（自己的调度器，脚本用法才是原生用法）
    其余             → 收集

这两类文件请直接当脚本跑，退出码即结论：

    python src/tests/test_rpc_server.py

要把某个文件改造成真用例：删掉 `def main()` 与 `sys.exit`，让 `def test_*` 自包含，
改完会自动被收集。
"""

import pathlib

_HERE = pathlib.Path(__file__).parent


def _is_script(path: pathlib.Path) -> bool:
    if path.suffix != ".py":
        return False
    try:
        text = path.read_text(encoding="utf-8", errors="ignore")
    except OSError:
        return True
    return ("def test_" not in text) or ("def main(" in text)


collect_ignore = sorted(p.name for p in _HERE.glob("*.py") if _is_script(p))
'''

CI = """name: ci

on:
  push:
    branches: [master]
  pull_request:
  workflow_dispatch:

permissions:
  contents: read

# Windows runner 默认控制台编码不是 UTF-8；项目里的中文输出会抛
# UnicodeEncodeError: 'charmap' codec ...（2026-10-28 实测）。
env:
  PYTHONUTF8: "1"
  PYTHONIOENCODING: "utf-8"

concurrency:
  group: ci-${{ github.ref }}
  cancel-in-progress: true

jobs:
  syntax:
    name: syntax gate
    runs-on: windows-latest
    steps:
      - uses: actions/checkout@v4
      - uses: actions/setup-python@v5
        with:
          python-version: "3.12"
      - name: byte-compile (hard gate)
        run: python -m compileall -q src main.py tools
      - name: validate requirements syntax (advisory)
        continue-on-error: true
        run: python tools/check_requirements.py

  self-check:
    name: self-check scripts
    needs: syntax
    runs-on: windows-latest
    env:
      # 需要音频设备 / 桌面会话 / 外设，Windows runner 上没有，跑必红；
      # test_phash.py 需要 imagehash（项目刻意不装，避免拖入 109MB 的 scipy），
      # 它自己在缺依赖时会明确报缺。这些请在真机上跑，不靠 CI 判定。
      SKIP: >-
        test_asr_event_flow.py test_asr_voice_pipeline.py test_dialogue_voice_chain.py
        test_doctor.py test_doctor_asr.py test_doctor_voice_backend.py
        test_doctor_llm_channel.py test_doctor_config_warn.py
        test_autostart.py test_setup_hint.py test_wake_word.py
        test_perception_indicator.py
        test_pet_backend.py test_pet_shell_fallback.py test_pet_shell_selfheal.py
        test_pet_state.py
        test_phash.py
    steps:
      - uses: actions/checkout@v4
      - uses: actions/setup-python@v5
        with:
          python-version: "3.12"
      - name: install deps
        run: |
          python -m pip install --upgrade pip
          python -m pip install PyYAML httpx numpy websockets requests rich psutil Pillow mss ollama dashscope pywebview sounddevice
      - name: run every test_*.py as a script
        shell: pwsh
        run: |
          $skip = @($env:SKIP -split '\\s+' | Where-Object { $_ })
          $ran = 0; $failed = @()
          foreach ($f in Get-ChildItem src/tests/test_*.py | Sort-Object Name) {
            if ($skip -contains $f.Name) { Write-Host "::group::跳过 $($f.Name)（需音频/桌面）"; Write-Host "::endgroup::"; continue }
            $ran++
            Write-Host "::group::$($f.Name)"
            python $f.FullName
            if ($LASTEXITCODE -ne 0) {
              Write-Host "::error file=src/tests/$($f.Name)::自检失败（exit $LASTEXITCODE）"
              $failed += $f.Name
            }
            Write-Host "::endgroup::"
          }
          Write-Host ""
          Write-Host ("执行 {0} 个，通过 {1}，失败 {2}" -f $ran, ($ran - $failed.Count), $failed.Count)
          if ($failed.Count -gt 0) {
            Write-Host ("失败清单: " + ($failed -join ', '))
            # 只打 annotation 不退出码 = 假绿。这里必须让 job 真红。
            exit 1
          }

  pytest:
    name: pytest (standalone modules only)
    needs: syntax
    runs-on: windows-latest
    steps:
      - uses: actions/checkout@v4
      - uses: actions/setup-python@v5
        with:
          python-version: "3.12"
      - name: install deps
        run: |
          python -m pip install --upgrade pip
          python -m pip install pytest PyYAML httpx numpy websockets requests rich psutil Pillow mss ollama dashscope pywebview sounddevice
      - name: pytest
        run: python -m pytest src/tests -q -p no:cacheprovider
"""
