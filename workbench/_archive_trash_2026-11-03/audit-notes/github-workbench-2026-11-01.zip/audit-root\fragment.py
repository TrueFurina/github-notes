import json, subprocess, urllib.request, urllib.parse, http.client, collections

TOKEN = subprocess.run(["powershell","-NoProfile","-Command",
    "[Environment]::GetEnvironmentVariable('GITHUB_TOKEN','User')"],
    capture_output=True, text=True).stdout.strip()
H = {"Authorization":"Bearer "+TOKEN,"User-Agent":"raccoon","Accept":"application/vnd.github+json","Connection":"close"}

def get(u):
    for i in range(3):
        try:
            r = urllib.request.Request(u, headers=H)
            with urllib.request.urlopen(r, timeout=45) as resp:
                parts=[]
                try:
                    while True:
                        b=resp.read(32768)
                        if not b: break
                        parts.append(b)
                except http.client.IncompleteRead as e:
                    parts.append(e.partial)
                return json.loads(b"".join(parts))
        except urllib.error.HTTPError as e:
            if e.code==404: return {"__http":404}
        except Exception:
            pass
    return None

# 1) SecAutoMind vs SecAutoMind-src 对比
print("=== SecAutoMind (流量最高) vs SecAutoMind-src (真实代码) ===")
for name in ["SecAutoMind","SecAutoMind-src"]:
    r = get(f"https://api.github.com/repos/TrueFurina/{name}")
    t = get(f"https://api.github.com/repos/TrueFurina/{name}/git/trees/HEAD?recursive=1") or {}
    tree = t.get("tree",[])
    files=[x for x in tree if x["type"]=="blob"]
    print(f'\n[{name}]')
    print(f'  size={r.get("size")}KB stars={r.get("stargazers_count")} desc={(r.get("description") or "")[:70]}')
    print(f'  homepage={r.get("homepage")} topics={len(r.get("topics") or [])} license={bool(r.get("license"))}')
    print(f'  files={len(files)} 总字节={sum(x.get("size",0) for x in files)/1e6:.2f}MB')
    top=sorted({x["path"].split("/")[0] for x in files})
    print(f'  顶层={top[:12]}')
    print(f'  有无真代码: py={sum(1 for x in files if x["path"].endswith(".py"))} '
          f'js={sum(1 for x in files if x["path"].endswith(".js"))} '
          f'html={sum(1 for x in files if x["path"].endswith(".html"))}')

# 2) 仓库名族谱：识别同一项目的多仓分裂
d = json.load(open("raw.json", encoding="utf-8"))
own = [r for r in d["repos"] if not r.get("fork")]
print("\n=== 潜在同名族谱（同一项目的多个仓库）===")
groups = {
    "SecAutoMind": ["SecAutoMind","SecAutoMind-src"],
    "MangDe*": [r["name"] for r in own if r["name"].startswith("Mang")],
    "xihu*": [r["name"] for r in own if r["name"].startswith("xihu")],
    "marl-ecdsa*": [r["name"] for r in own if r["name"].startswith("marl")],
    "2026-Challenge*": [r["name"] for r in own if "Challenge-Cup" in r["name"]],
    "sage-paper*": [r["name"] for r in own if r["name"].startswith("sage")],
}
for g, names in groups.items():
    names=[n for n in names if any(r["name"]==n for r in own)]
    if len(names)>1:
        print(f'\n  [{g}] {len(names)} 个')
        for n in names:
            r=next(x for x in own if x["name"]==n)
            print(f'    {n:38s} {r["size"]:7d}KB *{r["stargazers_count"]:2d} '
                  f'{"PRIVATE" if r.get("private") else "public "} desc={"Y" if r.get("description") else "-"}')