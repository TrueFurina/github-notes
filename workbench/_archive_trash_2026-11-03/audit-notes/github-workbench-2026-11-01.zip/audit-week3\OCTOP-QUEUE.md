# Octop 三仓 39 个 open PR：排队诊断与合并顺序

生成时间：2026-10-29 22:25 ｜ 数据：`GET /repos/{repo}/pulls?state=open` + 逐个 `/pulls/{n}` + `/files`

---

## 0. 先把数字修正

| 来源 | 数字 | 为什么不准 |
|---|---:|---|
| 昨晚搜索接口 `search/issues` | 15 | 搜索对 `repo:` 限定索引不全 |
| 昨晚我从搜索接口估的 | 47→71 | 同上 |
| **逐个列表接口实拉** | **39** | 这才是真的 |

| 仓库 | 仓库 open PR 总数 | 其中本人 |
|---|---:|---:|
| `TencentCloud/Octop` | 120 | 20 |
| `TencentCloud/octop-harness` | 40 | 13 |
| `TencentCloud/octop-memory` | 14 | 6 |
| **合计** | 174 | **39** |

顺带记一笔：`api_all` 在遇到代理抖动时会静默返回半截列表，害我第一遍算出 `octop-harness` 本人 PR = 0。
已改成网络失败即抛异常（见 INDEX 十九）。**统计类脚本少算还不出声，比报错更危险。**

---

## 1. 39 个全是 `unstable`，但不是基础设施卡住

抽样 5 个 PR 查 `check-runs` 和分支保护：

```
Octop #2495   combined status: pending | statuses: 0 | check-runs: 1 (GITHUB_OPENSOURCE_SCAN_PIPELINE success)
Octop #2490   同上
octop-harness #2371  statuses: 0 | check-runs: 0
octop-memory  #29    statuses: 0 | check-runs: 0

分支保护 required_status_checks:
  Octop          enforcement_level=off, contexts=[]
  octop-harness  enforcement_level=everyone, contexts=[]
  octop-memory   enforcement_level=everyone, contexts=[]
```

`combined status: pending` 配 `statuses: 0` 只是 GitHub 在"零个 commit status"时的默认值，
**没有任何必需检查被配进去**。也就是说：

> **技术上没有任何东西阻止合并。** 39 个 PR 卡住，纯粹是因为维护者的注意力。

这个结论很重要，因为它决定了该做什么：不是去修 CI，而是**把队列变得"十分钟能看完一个"**。

---

## 2. 队列里至少有 4 组是同一个修复开了两个 PR

按文件重叠算出来的，不是我猜的：

| 仓库 | 文件 | PR 组 | 判断 |
|---|---|---|---|
| Octop | `src/octop/infra/utils/env_file.py` | **#2372**（+57/−6，3 文件，10-23）<br>**#2491**（+15/−0，1 文件，10-28） | **同一个修复**：未闭合引号吞掉后续变量 |
| Octop | `src/octop/cli/commands/backup.py` | **#2371**（+156/−1，3 文件，10-23）<br>**#2490**（+7/−1，1 文件，10-28） | **同一个修复**：跨文件系统 EXDEV |
| octop-harness | `src/octop_harness/llm/session_header.py` | **#122**（+11/−14，10-28）<br>**#132**（+7/−1，10-28） | **同一个修复**：ContextVar 跨上下文 |
| Octop | `src/octop/infra/agents/manager.py` | **#2482**（+31/−8）<br>**#2493**（+24/−0） | 都改 icon_url/color 兜底，**疑似重复** |

另有两组三连叠加（不是重复，但**互相冲突**，必须串行）：

| 仓库 | 文件 | PR |
|---|---|---|
| octop-harness | `security/tool_guard/rules/dangerous_shell_commands.yaml` | **#83**（+199/−1，10-18）、**#121**（+2/−1）、**#128**（+133/−1） |
| Octop | `src/octop/infra/agents/manager.py` | #2482、#2486、#2493 |

还有三个 PR 都改 `CHANGELOG.md`（Octop #2371/#2372/#2376、harness #83/#106、memory #29/#30）——
**共享同一个文件意味着它们彼此永远冲突**，后合的一定要 rebase。

---

## 3. 建议的合并顺序

原则：**先合"一个文件、十行以内、不跟任何人抢文件"的**，让维护者连续三次"点一下就行"，
把关系建立起来；再合叠加组，每组串行推。

### 第一批（三天内，各合一个，分散在三个仓库）

| PR | 规模 | 为什么选它 |
|---|---|---|
| [`Octop #2495`](https://github.com/TencentCloud/Octop/pull/2495) | +9/−2，1 文件 | OAuth 回调丢 query 参数，属认证路径上的真实缺陷，影响面最大 |
| [`octop-harness #127`](https://github.com/TencentCloud/octop-harness/pull/127) | +5/−1，1 文件 | 非 UTF-8 的 `.env` 被当成"未配置"，会让用户以为配置丢了 |
| [`octop-memory #36`](https://github.com/TencentCloud/octop-memory/pull/36) | +6/−0，1 文件 | router 默认召回源少一个来源，一行改动 |

挑这三个的额外理由：**分别落在三个不同的仓库**，不会让同一个维护者在一天内看到三条通知。
`jubaoliang` 上周刚合过 #2174，先给他一个"一屏能看完"的印象，比一次推五个强。

### 第二批：先合重复里的一个，另一个关掉

> ⚠️ **这一节我第一版写反了，已按实际 diff 修正。** 原方案是"留小的关大的"，
> 但读完 diff 发现**小的那个恰恰都没测试**——照原方案会关掉唯一带回归测试的 PR。
> 判断依据必须是内容，不是体积。

| 保留 | 关闭 | 理由 |
|---|---|---|
| **`Octop #2372`**（+57/−6，含 `tests/unit/test_env_file.py` +25） | `#2491`（+15/−0，无测试） | 同一个 #2269。#2372 有三项回归测试、作者实测 `16 passed`，还额外去掉残留的半开引号；#2491 只是窄化的护栏 |
| **`Octop #2371`**（+156/−1，含 `tests/unit/backup/test_backup_cli.py` **+110**） | `#2490`（+7/−1，无测试） | 同一个 #2321。#2371 有 `_atomic_move_to()`：同文件系统原子 replace、EXDEV 时先复制到**目标侧**临时文件再 `os.replace`、失败保留已有备份；#2490 只是 `import shutil` 加 7 行 |
| **`octop-harness #132`**（+7/−1，单文件） | `#122`（+11/−14，2 文件） | 同一个 #89，两处 `reset(token)` 的容错写法等价。#122 还顺手重构了 `agent.py` 的 `aclosing`，而 `agent.py` 同时被 #123/#125 改——这份重构更适合单独开 PR |

关闭时都写了"被 #xxx 取代"并指过去，不是只点 close。

### 第二批之外：`#2482` vs `#2493` 不是重复，别乱关

两个都在修 #2467（CLI 建的 agent `icon_url`/`color` 为 NULL，导致 team dispatch 的
`agent_list` 把成员丢掉），但**策略不同**：

| PR | 做法 |
|---|---|
| `#2482`（+31/−8） | 从**模板**解析：`self._expert_catalog.get(spec.template_name)` 取 `icon_url/icon_name/color/welcome_message` |
| `#2493`（+24/−0） | 从 **persona MBTI** 推导，最后无条件兜底成空串 `""`，直接保证非 NULL |

两个插入位置都在 `create()` 里、都在 `extract_profile_from_config()` 之后，所以**同时合会打架**。
正确做法不是关一个，而是合成一个：**先用 #2493 的空串兜底消除症状（`agent_list` 不再丢人），
再把 #2482 的模板解析作为增强叠上去**（有模板时给出真图标，而不是空串）。

---

## 3.5 执行记录（2026-10-29 22:32）

| PR | 动作 | 结果 |
|---|---|---|
| `Octop #2491` | 关闭 + 说明 | `closed_at 14:32Z`，评论 id `6499510996` |
| `Octop #2490` | 关闭 + 说明 | `closed_at 14:32Z`，评论 id `6499513925` |
| `octop-harness #122` | 关闭 + 说明 | `closed_at 14:32Z`，评论 id `6499516944` |

队列 **39 → 36**（Octop 20→18、harness 13→12、memory 6）。
脚本 `week3/close_dupes.py` 默认 dry-run，且带一条保护：**保留对象若不是 open 状态就拒绝关闭**，
避免出现"关掉了却没有替代品"。

**没做的事**：没有给第一批那三个 PR 补"本地验证记录"。我无法真的跑他们的代码，
编一段"已验证"的评论比不写更糟。要给 reviewer 省时间，正确方式是补可执行的复现命令，
而这需要先 clone 下来真跑——不是今晚能顺手做完的。


### 第三批：叠加组必须串行

- tool_guard 三连：**先 #121（+2/−1，最小）→ 再 #128 → 最后 #83**。
  #83 是 10-18 的老 PR，+199 行一次性改规则表，reviewer 最难入口；把它放最后，
  等前两个小改动证明了这条规则的写法，再推大的。
- `manager.py` 三连：先 #2493（+24/−0，纯新增兜底）→ #2482 → #2486。

### 建议保持不动的

- `Octop #2170`（docs，3 条评论，10-18）：维护者已经看过并回过话，等着就行。
- `Octop #2369`（+1/−1，docs）：一行文档修正，随时合，不占名额。
- `octop-memory #29`（+332/−9，6 文件，最后一条评论是 **Bosheng0422**）：**这是唯一有维护者
  实质参与的一个**，别催、也别改，等他的意见。

---

## 4. 一个反直觉的建议

现在 39 个 PR 分散在 174 个 open PR 的池子里，维护者**看不到你**。

与其再开新的，不如做一件成本极低的事：**给第一批那三个 PR 各补一条"我本地怎么验的"评论**，
写清命令、输入、输出三行。这不会让合并变快，但会让后来 review 的人在三十秒内决定"可以合"。

反面教训就在你自己的历史里：`kubeflow #1072` 那次能推进，是因为维护者已经把条件写成了
"版本选择 + license header"两条，而不是因为你 ping 得勤。**给可执行的信息，不给提醒。**
