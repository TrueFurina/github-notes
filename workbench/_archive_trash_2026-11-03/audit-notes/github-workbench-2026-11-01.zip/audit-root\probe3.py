import json, subprocess, time, urllib.request, http.client, collections, urllib.parse, re

TOKEN = subprocess.run(["powershell","-NoProfile","-Command",
    "[Environment]::GetEnvironmentVariable('GITHUB_TOKEN','User')"],
    capture_output=True, text=True).stdout.strip()
H = {"Authorization":"Bearer "+TOKEN,"User-Agent":"raccoon","Accept":"application/vnd.github+json","Connection":"close"}

def get(url, raw=False):
    for i in range(3):
        try:
            r = urllib.request.Request(url, headers=H)
            with urllib.request.urlopen(r, timeout=40) as resp:
                parts=[]
                try:
                    while True:
                        b=resp.read(16384)
                        if not b: break
                        parts.append(b)
                except http.client.IncompleteRead as e:
                    parts.append(e.partial)
                body=b"".join(parts)
                return body.decode("utf-8","replace") if raw else json.loads(body)
        except Exception as e:
            if i==2: return None
            time.sleep(2)

# external PRs (excluding own repos)
q = urllib.parse.quote("is:pr author:TrueFurina -user:TrueFurina")
ext=[]
for page in (1,2,3):
    d=get(f"https://api.github.com/search/issues?q={q}&per_page=50&page={page}")
    if not d or "items" not in d: break
    ext.extend(d["items"])
    if len(d["items"])<50: break
print("EXTERNAL PRs:", len(ext), "total:", (d or {}).get("total_count"))
m=[i for i in ext if i.get("pull_request",{}).get("merged_at")]
print("external merged:", len(m))
for i in ext:
    st = "MERGED" if i.get("pull_request",{}).get("merged_at") else i["state"].upper()
    print(f'  {st:7s} {i["repository_url"].split("/repos/")[-1]:36s} {i["created_at"][:10]} {i["title"][:55]}')

print("\n=== REPO QUALITY PROBE ===")
d=json.load(open("raw.json",encoding="utf-8"))
own=[r for r in d["repos"] if not r.get("fork")]
tgt=sorted(own,key=lambda x:(-x["stargazers_count"],-x["size"]))[:12]
for r in tgt:
    fn=r["full_name"]
    wf=get(f"https://api.github.com/repos/{fn}/contents/.github/workflows")
    wfn=[x["name"] for x in wf] if isinstance(wf,list) else []
    rel=get(f"https://api.github.com/repos/{fn}/releases?per_page=5")
    reln=len(rel) if isinstance(rel,list) else 0
    readme=get(f"https://api.github.com/repos/{fn}/readme", raw=True)
    rl=0
    if readme:
        try: rl=len(json.loads(readme).get("content",""))
        except Exception: rl=0
    tst=get(f"https://api.github.com/repos/{fn}/contents/tests")
    has_t = isinstance(tst,list) or (isinstance(tst,dict) and tst.get("type")=="file")
    print(f'{r["name"][:30]:32s} *{r["stargazers_count"]:2d} CI={len(wfn):2d}{wf and wfn[:3] or ""} rel={reln} tests={"Y" if has_t else "-"} readme_b64={rl}')