"""按 LICENSE-DECISION.md 的分组批量替换许可证（默认 dry-run）。

分组见 LICENSE-DECISION.md，这里只做映射，不做判断：

    tools     4 个排错工具/脚本      -> MIT
    papers    3 个论文复现包        -> MIT
    flagship  MARS-408              -> MIT
    optional  4 个有星的应用         -> MIT（需你确认再跑）
    content   3 个内容/落地页        -> CC-BY-4.0
    private   sage-paper-public     -> 转私有（不换许可）

许可全文一律从 GET /licenses/{key} 取，不手打。MIT 的
`Copyright (c) [year] [fullname]` 占位符用各仓 README 里已有的 © 持有人替换；
README 没有则退化为 TrueFurina，并在输出里标注"默认持有人"。

用法：
    python apply_license_batch.py tools papers           # dry-run
    python apply_license_batch.py tools papers --yes
"""

import base64
import json
import re
import sys
import urllib.request

sys.path.insert(0, r"D:/github/github-audit")
from ghlib import HEADERS, OWNER, api  # noqa: E402

YEAR = "2026"
DEFAULT_HOLDER = "TrueFurina"

GROUPS = {
    "tools": ["win-appx-doctor", "docker-forensics-toolkit",
              "wsl-docker-recovery", "workbuddy-vivo-fix"],
    "papers": ["aerorider-delivery", "AeroRider", "marl-ecdsa"],
    "flagship": ["MARS-408"],
    "optional": ["MangDeHenZhi", "FDE", "soft-skills-platform", "AI-Arena"],
    "content": ["cyber-terms-hub", "TrueFurina", "SecAutoMind"],
    "private": ["sage-paper-public"],
}

LICENSE_OF_GROUP = {
    "tools": "mit", "papers": "mit", "flagship": "mit", "optional": "mit",
    "content": "cc-by-4.0", "private": None,
}

_cache = {}


def license_body(key):
    if key not in _cache:
        _cache[key] = api(f"/licenses/{key}")["body"]
    return _cache[key]


def holder_for(repo):
    """从 README 里找已写明的版权持有人，找不到用默认值。"""
    r = api(f"/repos/{OWNER}/{repo}/readme")
    if not (isinstance(r, dict) and r.get("content")):
        return DEFAULT_HOLDER, False
    t = base64.b64decode(r["content"]).decode("utf-8", "ignore")
    m = re.search(r"©\s*\d{4}\s*([^\n，,。|*<]{2,40})", t)
    if m:
        name = m.group(1).strip(" )）")
        if name:
            return name, False
    return DEFAULT_HOLDER, True


def build(repo, key):
    body = license_body(key)
    if key == "mit":
        holder, fallback = holder_for(repo)
        text = body.replace("Copyright (c) [year] [fullname]",
                            f"Copyright (c) {YEAR} {holder}")
        return text, f"MIT / 持有人 {holder}" + ("（默认值）" if fallback else "")
    return body, f"{key} / 全文 {len(body)} 字符"


def put(repo, path, text, sha, branch, message):
    payload = {"message": message,
               "content": base64.b64encode(text.encode("utf-8")).decode(),
               "branch": branch}
    if sha:
        payload["sha"] = sha
    req = urllib.request.Request(
        f"https://api.github.com/repos/{OWNER}/{repo}/contents/{path}",
        data=json.dumps(payload, ensure_ascii=False).encode("utf-8"),
        headers={**HEADERS, "Content-Type": "application/json; charset=utf-8"},
        method="PUT")
    try:
        with urllib.request.urlopen(req, timeout=120) as r:
            return r.status, json.loads(r.read())["commit"]["sha"][:12]
    except urllib.error.HTTPError as e:
        return e.code, e.read().decode("utf-8", "ignore")[:260]


def patch_repo(repo, payload):
    req = urllib.request.Request(
        f"https://api.github.com/repos/{OWNER}/{repo}",
        data=json.dumps(payload, ensure_ascii=False).encode("utf-8"),
        headers={**HEADERS, "Content-Type": "application/json; charset=utf-8"},
        method="PATCH")
    try:
        with urllib.request.urlopen(req, timeout=60) as r:
            return r.status, json.loads(r.read())
    except urllib.error.HTTPError as e:
        return e.code, e.read().decode("utf-8", "ignore")[:260]


def main():
    args = [a for a in sys.argv[1:] if not a.startswith("--")]
    dry = "--yes" not in sys.argv
    groups = args or list(GROUPS)
    unknown = [g for g in groups if g not in GROUPS]
    if unknown:
        print("未知分组:", unknown, "| 可选:", list(GROUPS))
        return 1

    changed = 0
    for g in groups:
        key = LICENSE_OF_GROUP[g]
        print("=" * 74)
        print(f"分组 {g}  ->  {key or '转私有'}   ({len(GROUPS[g])} 个)")
        print("=" * 74)
        for repo in GROUPS[g]:
            info = api(f"/repos/{OWNER}/{repo}")
            if isinstance(info, dict) and "__error" in info:
                print(f"  [{repo}] 读取失败: {info['__error']}")
                continue
            cur = (info.get("license") or {}).get("spdx_id")
            branch = info["default_branch"]

            if key is None:  # 转私有
                if info.get("private"):
                    print(f"  [{repo}] 已是私有，跳过")
                    continue
                print(f"  [{repo}] private={info.get('private')} -> 将转私有")
                if dry:
                    continue
                st, b = patch_repo(repo, {"private": True})
                ok = st == 200 and isinstance(b, dict) and b.get("private") is True
                print(f"      HTTP {st} private={b.get('private') if isinstance(b, dict) else b}"
                      f" {'OK' if ok else 'FAILED'}")
                changed += 1 if ok else 0
                continue

            want = "MIT" if key == "mit" else "CC-BY-4.0"
            if cur == want:
                print(f"  [{repo}] 已是 {cur}，跳过")
                continue

            text, note = build(repo, key)
            old = api(f"/repos/{OWNER}/{repo}/contents/LICENSE")
            sha = old["sha"] if isinstance(old, dict) and old.get("sha") else None
            action = "覆盖" if sha else "新建"
            print(f"  [{repo}] {action} LICENSE ({cur} -> {want}) · {note}")
            print(f"      {len(text)} 字符")
            if dry:
                continue
            st, res = put(
                repo, "LICENSE", text, sha, branch,
                f"chore(license): switch to {want}\n\n"
                f"原先是一份 752 字符的自定义 source-available 文本，GitHub 不识别"
                f"（spdx=NOASSERTION），仓库列表与搜索结果里不显示任何许可标识，"
                f"等于意图没传达。改用标准 {want} 全文，使授权可被机器识别。\n"
                f"依据见 LICENSE-DECISION.md。")
            print(f"      HTTP {st} commit={res}")
            changed += 1 if st == 200 else 0

    print()
    print(f"{'dry-run，加 --yes 写入' if dry else f'写入 {changed} 项'}")


if __name__ == "__main__":
    main()
