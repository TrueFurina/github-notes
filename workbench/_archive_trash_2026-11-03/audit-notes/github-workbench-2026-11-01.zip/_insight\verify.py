"""对 Top 候选做落地核验：issue 正文全文 + 代码搜索定位改动点/测试文件。"""
import json
import os
import re
import urllib.request

TOKEN = os.environ["GITHUB_TOKEN"]
API = "https://api.github.com"
REPO = "apache/airflow"
ISSUES = [74590, 68279, 64649, 72592, 42492, 58968]
SEARCHES = [
    "workload_identity_impersonation_path",
    "BedrockCreateKnowledgeBaseOperator",
    "otel_logger OR get_otel_logger",
]


def get(url):
    req = urllib.request.Request(url, headers={
        "Authorization": "Bearer " + TOKEN,
        "Accept": "application/vnd.github+json",
        "User-Agent": "insight-scout"})
    with urllib.request.urlopen(req, timeout=45) as r:
        return json.loads(r.read().decode("utf-8"))


for n in ISSUES:
    it = get(f"{API}/repos/{REPO}/issues/{n}")
    body = re.sub(r"\s+", " ", it.get("body") or "")
    print(f"\n=== #{n} {it['title']}")
    print(f"    labels={[l['name'] for l in it['labels']]} "
          f"comments={it['comments']} assignee={[a['login'] for a in it['assignees']]}")
    print(f"    url={it['html_url']}")
    print(f"    body: {body[:700]}")

for q in SEARCHES:
    url = (f"{API}/search/code?q=" + urllib.parse.quote(q + f" repo:{REPO}")
           + "&per_page=10")
    try:
        data = get(url)
        print(f"\n[code search] {q} total={data.get('total_count')}")
        for it in data.get("items", [])[:8]:
            print("   ", it["path"])
    except Exception as e:
        print(f"\n[code search] {q} FAIL: {e}")
