import json, os, urllib.request

TOKEN = os.environ["GITHUB_TOKEN"]
P = ["providers/cncf/kubernetes/src/airflow/providers/cncf/kubernetes/operators/pod.py",
     "providers/cncf/kubernetes/tests/unit/cncf/kubernetes/operators/test_pod.py"]
for p in P:
    req = urllib.request.Request(f"https://api.github.com/repos/apache/airflow/contents/{p}",
                                 headers={"Authorization": "Bearer " + TOKEN,
                                          "Accept": "application/vnd.github+json",
                                          "User-Agent": "insight-scout"})
    try:
        js = json.loads(urllib.request.urlopen(req, timeout=30).read().decode())
        print(f"OK {js['size']}B {p}")
    except Exception as e:
        print(f"MISS {p} ({e})")
