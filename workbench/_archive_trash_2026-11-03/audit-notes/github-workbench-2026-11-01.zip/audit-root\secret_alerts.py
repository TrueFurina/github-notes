import json, subprocess, time, urllib.request, http.client

TOKEN = subprocess.run(["powershell","-NoProfile","-Command",
    "[Environment]::GetEnvironmentVariable('GITHUB_TOKEN','User')"],
    capture_output=True, text=True).stdout.strip()
H = {"Authorization":"Bearer "+TOKEN,"User-Agent":"raccoon",
     "Accept":"application/vnd.github+json","Connection":"close"}

def get(url):
    try:
        r = urllib.request.Request(url, headers=H)
        with urllib.request.urlopen(r, timeout=40) as resp:
            parts=[]
            try:
                while True:
                    b=resp.read(16384)
                    if not b: break
                    parts.append(b)
            except http.client.IncompleteRead as e:
                parts.append(e.partial)
            return json.loads(b"".join(parts))
    except urllib.error.HTTPError as e:
        return {"__http": e.code}
    except Exception as e:
        return {"__err": repr(e)[:60]}

d=json.load(open("raw.json",encoding="utf-8"))
own=[r for r in d["repos"] if not r.get("fork")]
print("扫描自有仓库:", len(own))

all_alerts={}
for r in own:
    fn=r["full_name"]
    a=get(f"https://api.github.com/repos/{fn}/secret-scanning/alerts?state=open&per_page=100")
    if isinstance(a,list) and a:
        all_alerts[fn]=a
        print(f'\n!!! {fn} 开放告警 {len(a)} 条')
        for x in a:
            print(f'    类型={x.get("secret_type_display_name")} 状态={x.get("state")} '
                  f'文件={x.get("secret",{}).get("")if False else x.get("first_location_detected",{}).get("path","?")} '
                  f'创建={x.get("created_at","")[:10]} 有效性={x.get("validity","?")}')
    elif isinstance(a,dict) and a.get("__http")==404:
        pass  # 未启用
    elif isinstance(a,dict) and a.get("__http")==403:
        print(f'  {fn}: 403 无权限')

print("\n=== 有开放告警的仓库数:", len(all_alerts))
json.dump(all_alerts, open("secret_alerts.json","w",encoding="utf-8"), ensure_ascii=False, indent=1)

print("\n=== 扫描能力状态 ===")
for name in ["MangDeZhiXun","physics-scheduler-agent","SecAutoMind-src"]:
    s=get(f"https://api.github.com/repos/TrueFurina/{name}")
    if isinstance(s,dict) and "security_and_analysis" in s:
        print(f'  {name}: {json.dumps(s["security_and_analysis"],ensure_ascii=False)[:220]}')