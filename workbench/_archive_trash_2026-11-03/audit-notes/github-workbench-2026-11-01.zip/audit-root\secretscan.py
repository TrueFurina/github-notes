import json, subprocess, time, urllib.request, http.client, base64, urllib.parse

TOKEN = subprocess.run(["powershell","-NoProfile","-Command",
    "[Environment]::GetEnvironmentVariable('GITHUB_TOKEN','User')"],
    capture_output=True, text=True).stdout.strip()
H = {"Authorization":"Bearer "+TOKEN,"User-Agent":"raccoon","Accept":"application/vnd.github+json","Connection":"close"}

def get(url):
    for i in range(3):
        try:
            r = urllib.request.Request(url, headers=H)
            with urllib.request.urlopen(r, timeout=45) as resp:
                parts=[]
                try:
                    while True:
                        b=resp.read(16384)
                        if not b: break
                        parts.append(b)
                except http.client.IncompleteRead as e:
                    parts.append(e.partial)
                return json.loads(b"".join(parts))
        except urllib.error.HTTPError as e:
            return {"__http": e.code}
        except Exception:
            time.sleep(2)
    return None

# 1) decode JWT payload of the anon key WITHOUT printing the key
c = get("https://api.github.com/repos/TrueFurina/MangDeZhiXun/contents/.env")
txt = base64.b64decode(c["content"]).decode("utf-8","replace")
for line in txt.splitlines():
    if line.strip().startswith("VITE_SUPABASE_ANON_KEY"):
        key = line.split("=",1)[1].strip().strip('"')
        try:
            p = key.split(".")[1]
            p += "=" * (-len(p) % 4)
            claims = json.loads(base64.urlsafe_b64decode(p))
            print("JWT claims -> role:", claims.get("role"), "| iss:", claims.get("iss"), "| exp:", claims.get("exp"))
        except Exception as e:
            print("jwt decode failed", e)

# 2) search public repos for other .env files
q = urllib.parse.quote("user:TrueFurina filename:.env")
res = get(f"https://api.github.com/search/code?q={q}&per_page=30")
if isinstance(res, dict) and "items" in res:
    print("\n.env files in public repos:", res.get("total_count"))
    for it in res["items"]:
        print("  ", it["repository"]["full_name"], it["path"])
else:
    print("\ncode search unavailable:", res)

# 3) search for common secret filenames
for pat in ["filename:.env.local","filename:id_rsa","filename:credentials.json"]:
    r = get(f"https://api.github.com/search/code?q={urllib.parse.quote('user:TrueFurina '+pat)}&per_page=10")
    if isinstance(r, dict) and "items" in r:
        print(pat, "->", r.get("total_count"), [i["path"] for i in r["items"][:5]])
    else:
        print(pat, "-> unavailable", r)