"""核对改动点与测试文件是否存在 + 定位 SnowflakeHook 的转发位置。"""
import json
import os
import urllib.parse
import urllib.request

TOKEN = os.environ["GITHUB_TOKEN"]
API = "https://api.github.com"
REPO = "apache/airflow"

PATHS = [
    "providers/snowflake/src/airflow/providers/snowflake/hooks/snowflake.py",
    "providers/snowflake/tests/unit/snowflake/hooks/test_snowflake.py",
    "providers/google/src/airflow/providers/google/cloud/hooks/dataflow.py",
    "providers/google/tests/unit/google/cloud/hooks/test_dataflow.py",
    "providers/apache/beam/src/airflow/providers/apache/beam/hooks/beam.py",
    "airflow-core/src/airflow/models/dagrun.py",
    "airflow-core/tests/unit/models/test_dagrun.py",
    "airflow-core/src/airflow/observability/metrics/otel_logger.py",
    "task-sdk/src/airflow/sdk/observability/metrics/otel_logger.py",
    "shared/observability/tests/observability/metrics/test_otel_logger.py",
]


def get(url):
    req = urllib.request.Request(url, headers={
        "Authorization": "Bearer " + TOKEN,
        "Accept": "application/vnd.github+json",
        "User-Agent": "insight-scout"})
    with urllib.request.urlopen(req, timeout=45) as r:
        return json.loads(r.read().decode("utf-8"))


for p in PATHS:
    try:
        js = get(f"{API}/repos/{REPO}/contents/{p}")
        print(f"OK   {js['size']:>8}B  {p}")
    except Exception as e:
        print(f"MISS           {p}")

try:
    data = get(f"{API}/search/code?q=" + urllib.parse.quote(
        f"SnowflakeHook repo:{REPO}") + "&per_page=10")
    print(f"\n[code] SnowflakeHook total={data.get('total_count')}")
    for it in data.get("items", [])[:8]:
        print("   ", it["path"])
except Exception as e:
    print("SnowflakeHook search FAIL:", e)
