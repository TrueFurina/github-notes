import base64
import json
import sys
import time

sys.path.insert(0, r"D:/github/github-audit")
from ghlib import api, OWNER

raw = json.load(open(r"D:/github/github-audit/raw.json", encoding="utf-8"))
repos = [r for r in raw["repos"]
         if r.get("owner", {}).get("login", "").lower() == OWNER.lower()
         and not r.get("fork")]

out = []
for i, r in enumerate(repos, 1):
    n = r["name"]
    rec = {
        "name": n,
        "size_kb": r.get("size") or 0,
        "desc": r.get("description"),
        "topics": r.get("topics") or [],
        "homepage": r.get("homepage"),
        "lang": r.get("language"),
        "stars": r.get("stargazers_count") or 0,
        "private": r.get("private"),
        "archived": r.get("archived"),
        "default_branch": r.get("default_branch"),
        "created": r.get("created_at"),
        "pushed": r.get("pushed_at"),
        "license_api": (r.get("license") or {}).get("spdx_id"),
    }

    # README
    rd = api(f"/repos/{OWNER}/{n}/readme")
    if isinstance(rd, dict) and rd.get("content") and "__error" not in rd:
        try:
            txt = base64.b64decode(rd["content"]).decode("utf-8", "replace")
            rec["readme_file"] = rd.get("name")
            rec["readme_chars"] = len(txt)
            rec["readme_nonspace"] = len("".join(txt.split()))
            rec["readme_bytes"] = rd.get("size")
            rec["readme_head"] = txt[:400]
        except Exception as e:
            rec["readme_err"] = str(e)
    else:
        rec["readme_file"] = None
        rec["readme_chars"] = 0
        rec["readme_nonspace"] = 0

    # LICENSE
    lic = api(f"/repos/{OWNER}/{n}/license")
    if isinstance(lic, dict) and "__error" not in lic and lic.get("license"):
        rec["license_spdx"] = lic["license"].get("spdx_id")
        rec["license_name"] = lic["license"].get("name")
        rec["license_file"] = lic.get("name")
        rec["license_path"] = lic.get("path")
    else:
        rec["license_spdx"] = None
        rec["license_name"] = None
        rec["license_file"] = None

    # file tree
    paths = []
    if rec["size_kb"] <= 40000:
        br = rec["default_branch"] or "main"
        tr = api(f"/repos/{OWNER}/{n}/git/trees/{br}?recursive=1")
        if isinstance(tr, dict) and isinstance(tr.get("tree"), list):
            paths = [t["path"] for t in tr["tree"] if t.get("type") == "blob"]
            rec["tree_truncated"] = tr.get("truncated")
    if not paths:
        c = api(f"/repos/{OWNER}/{n}/contents/")
        if isinstance(c, list):
            paths = [x["name"] for x in c]
            rec["tree_fallback"] = "contents-root"
    rec["paths"] = paths[:4000]
    rec["nfiles"] = len(paths)

    # workflows
    wf = api(f"/repos/{OWNER}/{n}/contents/.github/workflows")
    if isinstance(wf, list):
        yml = [x["name"] for x in wf if x["name"].lower().endswith((".yml", ".yaml"))]
        rec["workflows"] = yml
    else:
        rec["workflows"] = []

    # releases
    rel = api(f"/repos/{OWNER}/{n}/releases?per_page=1")
    if isinstance(rel, list) and rel:
        rec["release_count_ge"] = 1
        rec["release_tag"] = rel[0].get("tag_name")
        rec["release_date"] = rel[0].get("published_at")
        rec["release_assets"] = sum(a.get("size", 0) for a in (rel[0].get("assets") or [])) // 1024
    else:
        rec["release_count_ge"] = 0

    # last commit
    cm = api(f"/repos/{OWNER}/{n}/commits?per_page=1")
    if isinstance(cm, list) and cm:
        rec["last_commit"] = cm[0]["commit"]["committer"]["date"]
        rec["last_msg"] = (cm[0]["commit"]["message"] or "").splitlines()[0][:80]
    else:
        rec["last_commit"] = None

    # branches
    b = api(f"/repos/{OWNER}/{n}/branches?per_page=100")
    rec["branches"] = len(b) if isinstance(b, list) else None

    out.append(rec)
    print(f"[{i}/{len(repos)}] {n:38} readme={rec.get('readme_nonspace',0):<7} "
          f"lic={rec.get('license_spdx')} wf={len(rec['workflows'])} files={rec['nfiles']}", flush=True)
    time.sleep(0.15)

json.dump(out, open(r"D:/github/github-audit/audit_data.json", "w", encoding="utf-8"),
          ensure_ascii=False, indent=1)
print("saved", len(out))
