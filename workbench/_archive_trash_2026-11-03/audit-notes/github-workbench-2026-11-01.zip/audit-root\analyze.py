import json, collections, datetime as dt

d = json.load(open("raw.json", encoding="utf-8"))
repos, starred, events = d["repos"], d["starred"], d["events"]
user = d["user"]

own = [r for r in repos if not r.get("fork")]
forks = [r for r in repos if r.get("fork")]
archived = [r for r in own if r.get("archived")]

print("=== BASIC ===")
print("login", user["login"], "| repos", len(repos), "| own", len(own), "| forks", len(forks), "| archived", len(archived))
print("stars total", sum(r["stargazers_count"] for r in own), "| forks total", sum(r["forks_count"] for r in own))

print("\n=== TOP BY STARS ===")
for r in sorted(own, key=lambda x: -x["stargazers_count"])[:18]:
    print(f'{r["stargazers_count"]:4d}* {r["forks_count"]:3d}f {r["language"] or "-":12s} {r["name"][:42]:44s} upd={r["updated_at"][:10]} desc={(r["description"] or "")[:70]}')

print("\n=== LANGUAGES (own) ===")
for k, v in collections.Counter(r["language"] or "None" for r in own).most_common(15):
    print(f"{k:14s} {v}")

print("\n=== TOPICS ===")
tc = collections.Counter(t for r in own for t in (r.get("topics") or []))
print(tc.most_common(30))

print("\n=== HYGIENE ===")
def pct(n, tot=len(own)): return f"{n} ({100*n/max(tot,1):.0f}%)"
print("with description:", pct(sum(1 for r in own if r.get("description"))))
print("with topics:", pct(sum(1 for r in own if r.get("topics"))))
print("with license:", pct(sum(1 for r in own if r.get("license"))))
print("with homepage:", pct(sum(1 for r in own if r.get("homepage"))))
print("has_issues off:", pct(sum(1 for r in own if not r.get("has_issues"))))
print("zero stars repos:", pct(sum(1 for r in own if r["stargazers_count"] == 0)))

print("\n=== ACTIVITY: created month ===")
cm = collections.Counter(r["created_at"][:7] for r in own)
for k in sorted(cm): print(k, "#" * min(cm[k], 40), cm[k])

print("\n=== ACTIVITY: pushed month ===")
pm = collections.Counter(r["pushed_at"][:7] for r in own)
for k in sorted(pm)[-14:]: print(k, "#" * min(pm[k], 40), pm[k])

print("\n=== EVENT TYPES ===")
print(collections.Counter(e["type"] for e in events).most_common())

print("\n=== EVENT REPOS (last 300) ===")
print(collections.Counter(e["repo"]["name"] for e in events).most_common(12))

print("\n=== STARRED TOPICS ===")
st = collections.Counter(t for s in starred for t in (s.get("topics") or []))
print(st.most_common(30))
print("\n=== STARRED LANGS ===")
print(collections.Counter(s.get("language") or "None" for s in starred).most_common(12))

print("\n=== REPOS IN ORGS? ===")
print(collections.Counter((r.get("owner") or {}).get("login") for r in repos).most_common())
