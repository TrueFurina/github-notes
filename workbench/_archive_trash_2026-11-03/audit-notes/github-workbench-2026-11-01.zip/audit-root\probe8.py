import json, subprocess, time, urllib.request, http.client, collections

TOKEN = subprocess.run(["powershell","-NoProfile","-Command",
    "[Environment]::GetEnvironmentVariable('GITHUB_TOKEN','User')"],
    capture_output=True, text=True).stdout.strip()
H = {"Authorization":"Bearer "+TOKEN,"User-Agent":"raccoon","Accept":"application/vnd.github+json","Connection":"close"}

def get(url):
    for i in range(3):
        try:
            r = urllib.request.Request(url, headers=H)
            with urllib.request.urlopen(r, timeout=45) as resp:
                parts=[]
                try:
                    while True:
                        b=resp.read(16384)
                        if not b: break
                        parts.append(b)
                except http.client.IncompleteRead as e:
                    parts.append(e.partial)
                return json.loads(b"".join(parts))
        except Exception:
            time.sleep(2)
    return None

ext=json.load(open("ext_prs.json",encoding="utf-8"))
repos=sorted({i["repository_url"] for i in ext})
cache={}
for u in repos:
    fn=u.split("/repos/")[-1]
    r=get(f"https://api.github.com/repos/{fn}")
    if isinstance(r,dict) and "stargazers_count" in r:
        cache[fn]=r["stargazers_count"]

def band(s):
    if s>=10000: return "10k+"
    if s>=1000: return "1k-10k"
    if s>=100: return "100-1k"
    if s>=10: return "10-100"
    return "<10"

b=collections.Counter(band(cache.get(i["repository_url"].split("/repos/")[-1],0)) for i in ext)
print("PR target repo star bands:", dict(b))
merged=[i for i in ext if i.get("pull_request",{}).get("merged_at")]
bm=collections.Counter(band(cache.get(i["repository_url"].split("/repos/")[-1],0)) for i in merged)
print("merged by band:", dict(bm))
big=[(i["repository_url"].split("/repos/")[-1], cache.get(i["repository_url"].split("/repos/")[-1]), bool(i.get("pull_request",{}).get("merged_at"))) for i in ext if cache.get(i["repository_url"].split("/repos/")[-1],0)>=1000]
print("\nPRs to repos >=1k stars:")
for x in big: print("  ", x)
json.dump(cache, open("repo_stars.json","w"))