"""P0 止血改动定义（第 1 周 6 项）。

每条改动都是"锚点式"替换：只在命中预期文本时生效，命中不到就跳过并报告，
因此重复执行安全（幂等），不会误伤被改动过的内容。
"""

OWNER = "TrueFurina"
COPYRIGHT = "Copyright (c) 2026 TrueFurina"

# ---------------------------------------------------------------- F1 许可证
# 三个头部仓 README 已对外承诺 MIT，LICENSE 却是 All Rights Reserved。
# 方向选择：改 LICENSE 而不是改 README（README 已挂徽章、已被外部引用）。
F1_MIT_REPOS = [
    "AGI-Distiller",
    "passive-recon",
    "DevRadar-GitHub-Trending-Monitor",
]

# ---------------------------------------------------------------- F2 pikachu
# 上游 = zhuifengshaonianhanlu/pikachu（4,578★，Apache-2.0）。
# 派生作品必须保留 Apache-2.0 与上游署名 —— 改 MIT 反而是错的。
PIKACHU_UPSTREAM = "https://github.com/zhuifengshaonianhanlu/pikachu"
PIKACHU_REPO = "pikachu"

NOTICE_PIKACHU = """Pikachu（定制版）
Copyright (c) 2026 TrueFurina

This product is a modified derivative of Pikachu 漏洞测试平台:
    https://github.com/zhuifengshaonianhanlu/pikachu
    Copyright (c) zhuifengshaonianhanlu
    Licensed under the Apache License, Version 2.0

本仓库为上述上游项目的二次定制版本。上游原始代码、静态资源
（assets/、pkxss/ 等）之版权与许可归原作者所有，按 Apache-2.0 保留；
本仓库的定制部分（Docker Compose、Windows 一键启动脚本、数据库自动初始化等）
同样以 Apache-2.0 授权发布。

Changes made from the upstream project (2026):
  - 新增 docker/ 与 docker-compose 一键启动
  - 新增 Windows 一键启动脚本与 PHPStudy 联动
  - 新增数据库首次访问自动初始化引导
  - 目录结构与默认配置调整

Apache-2.0 full text: see LICENSE
"""

# (repo, old, new) —— old 必须逐字命中，否则跳过
PIKACHU_README_EDITS = [
    (
        '<img src="https://img.shields.io/badge/license-MIT-green" alt="License"/>',
        '<img src="https://img.shields.io/badge/license-Apache_2.0-blue" alt="License"/>',
    ),
    (
        "> ✅ 优化数据库配置，首次访问自动引导安装",
        "> ✅ 优化数据库配置，首次访问自动引导安装\n"
        "\n"
        f"本仓库是 [zhuifengshaonianhanlu/pikachu]({PIKACHU_UPSTREAM})（Apache-2.0）的"
        "**二次定制版本**，上游原始代码与素材的版权归原作者所有；"
        "定制部分的授权与改动说明见 [NOTICE](NOTICE) 与 [LICENSE](LICENSE)。",
    ),
    (
        "| 🆓 完全免费开源 | ✅ MIT 协议 | ✅ 同 |",
        "| 🆓 完全免费开源 | ✅ Apache-2.0 协议 | ✅ 同 |",
    ),
    (
        "本项目基于 **MIT 许可证** 开源，详见 [LICENSE](LICENSE) 文件。",
        "本项目基于 **Apache License 2.0** 开源，详见 [LICENSE](LICENSE) 与 [NOTICE](NOTICE)。\n"
        f"上游项目：[zhuifengshaonianhanlu/pikachu]({PIKACHU_UPSTREAM})（Apache-2.0），"
        "本仓库的改动清单见 NOTICE。",
    ),
]

# 结尾重复的 "All Rights Reserved" 段落（与 MIT/Apache 互斥），整段删除
ALL_RIGHTS_BLOCK_MARKERS = (
    "## License & Usage Notice",
    "**Source-Available · All Rights Reserved**",
)


def find_block(text: str, start_marker: str, end_marker: str = None):
    """整段删除以 start_marker 为标题的章节，直到下一个标题 / `---` / 文件末尾。

    连同章节前紧邻的 `---` 分隔线与空行一起删掉，避免留下孤立分隔线。
    """
    lines = text.split("\n")
    start = None
    for i, ln in enumerate(lines):
        if ln.strip() == start_marker:
            start = i
            break
    if start is None:
        return None

    end = len(lines)
    for j in range(start + 1, len(lines)):
        s = lines[j].strip()
        if s.startswith("#") or s == "---":
            end = j
            break

    # 回退掉章节内末尾的空行
    while end > start + 1 and not lines[end - 1].strip():
        end -= 1

    # 前置分隔线一并删除
    cut_from = start
    k = start - 1
    while k >= 0 and not lines[k].strip():
        k -= 1
    if k >= 0 and lines[k].strip() == "---":
        cut_from = k

    tail = lines[end:]
    if tail:
        if lines[end].strip() != "---":
            tail = ["---", ""] + tail
    return "\n".join(lines[:cut_from] + tail)


# ---------------------------------------------------------------- F3 去重许可段
# 同一篇 README 里既写 [MIT](LICENSE) 又写 All Rights Reserved，只留前者。
F3_DEDUPE_REPOS = [
    "xuandun-cyber-range",
    "2026-Challenge-Cup-Security-LLM-Triage-Agent",
]

# ---------------------------------------------------------------- F4 xihu 首屏
XIHU_REPO = "xihu-sword-ctf-agent"
# 首屏 4 行的 FROZEN 横幅（含两处本机路径 E:\Program\SecAutoMind）压成 2 行
XIHU_FROZEN_START = "> 🔒 **FROZEN / 已冻结"
XIHU_FROZEN_END = "> `E:\\Program\\SecAutoMind\\docs\\merge_xhlj_roadmap_20261023.md`"
XIHU_NEW_FROZEN = """> 🔒 **FROZEN / 已冻结（2026-10-23）**：本仓库能力已全量并入 **SecAutoMind**，此处转为**只读知识库**（攻击链、writeup、验证脚本、基准数据仍可参考复用）。不再作为参赛主体或维护对象，不再提交新功能；后续能力发展在 SecAutoMind 进行。Bug 级修复仅以支撑赛事复盘为限。迁移路线图见 [SecAutoMind](https://github.com/TrueFurina/SecAutoMind) 仓库内 `docs/` 说明。"""
# 两段超长声明收进 <details>（内容逐字保留）
XIHU_DETAILS_START = "> ⚠️ **Honesty disclaimer"
XIHU_DETAILS_END = "> 🔴 **口径更正 / Figure correction"
XIHU_DETAILS_SUMMARY = "<summary>⚠️ 口径说明与历史更正（Honesty disclaimer / Figure correction，点开看）</summary>"

# ---------------------------------------------------------------- F5 .env.test
ENV_TEST_REPO = "MARS-408"
ENV_TEST_PATH = "py-server/iq_run_tmp/.env.test"
ENV_TEST_SAFE = """# 本文件曾包含本地测试用的会话密钥与管理员口令，已清空为占位。
# 真实值请通过环境变量注入（Windows: setx AUTH_SECRET "..."），不要提交入库。
# 字段含义与生成方式见 py-server/.env.example。
HF_HUB_OFFLINE=1
TRANSFORMERS_OFFLINE=1
VECTORDB_DATA_DIR=./data/vectordb
AUTH_SECRET=
ADMIN_USERNAME=
ADMIN_PASSWORD=
"""

GITIGNORE_APPEND = """
# 测试环境变量文件（含会话密钥，禁止入库）
.env.test
*.env.test
"""

# ---------------------------------------------------------------- F6 扫描开关
F6_REPOS = [
    "SecAutoMind-src",
    "xihu-sword-ctf-agent",
    "aerorider-delivery",
    "win-appx-doctor",
]


# ------------------------------------------------------- F1B README 版权行纠偏
# LICENSE 已改 MIT，但 AGI-Distiller README 第 3 行仍写 "All Rights Reserved + 禁止…"。
# MIT 不允许附加"禁止商用/禁止竞赛使用"的限制，只能降级为"礼貌请求（注明来源）"。
F1B_EDITS = {
    "AGI-Distiller": [(
        "> **版权声明 Copyright**：© 2026 All Rights Reserved. 未经作者书面许可，禁止复制、修改、分发、商用、用于各类学科竞赛。",
        "> **版权与许可 Copyright & License**：© 2026 TrueFurina，本项目以 [MIT 许可证](LICENSE) 发布——可自由使用、修改、分发与商用。"
        "用于学科竞赛或论文时，欢迎注明来源与仓库链接（此为礼貌请求，不构成 MIT 之外的额外限制）。",
    )],
}
