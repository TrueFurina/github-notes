# 第 41 轮任务清单（已完成）

目标：按 [spec.md](./spec.md) 修复 `validate_remote_browser_bookmarks` 的大小写敏感 scheme 过滤，开最小补丁 PR。

## [x] T1 基线准备（本地快照）
- 拉 develop 原文：`src/octop/infra/users/preferences.py`（11043 B）与 `tests/unit/users/test_preferences.py`（5676 B），
  均与快照逐字节一致。

## [x] T2 先写测试（红）
- 在 `tests/unit/users/test_preferences.py` 追加 `test_validate_accepts_uppercase_scheme`。
- 基线：`1 failed, 13 passed`，失败断言 `assert [] == ['HTTPS://example.com/path', 'Http://second.test']`。

## [x] T3 打补丁
- `src/octop/infra/users/preferences.py:96` 改为 `if not url.lower().startswith(("http://", "https://")):`（+1/−1）。
- 未改 `url.py`、未改 `browser/stream.py`。

## [x] T4 验证（绿）
- `pytest tests/unit/users/test_preferences.py tests/unit/utils/test_url.py` → 19 passed。
- `ruff check` → All checks passed!；`ruff format --check` → 2 files already formatted。

## [x] T5 清理
- 补丁文件导出到 `D:/github/_r41/preferences.py`、`D:/github/_r41/test_preferences.py`。
- 快照两文件已按 develop 原文复原（逐字节校验 True）。

## [x] T6 开 PR
- `Octop #2720`，分支 `fix/bookmark-scheme-case` 0c56c6a2ff4f，base `develop`。
- dry-run 显示 `preferences.py +0/-0 行数差`、`test_preferences.py +11`；真开成功。

## [x] T7 复核
- `pulls/2720`：state=open，mergeable=true，mergeable_state=unstable（零 status 良性），+12/−1，2 文件，
  0 review / 0 comment；文件清单仅 `preferences.py`（+1/−1）与 `test_preferences.py`（+11/−0）。

## [x] T8 台账
- 向 `D:/github/github-audit/autopilot/LEDGER.md` 追加 `## 2026-11-01 13:57 — PR 线第 41 轮`（已回读校验无乱码/吞字符）。

## [x] T9 中文总结
- 已在回话中给出：PR 号 / 缺陷 / 证据 / 验证 / 限制 / 下一方向。
