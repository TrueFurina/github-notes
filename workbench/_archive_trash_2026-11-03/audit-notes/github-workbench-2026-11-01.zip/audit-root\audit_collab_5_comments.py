import sys, json, time
sys.path.insert(0, r"D:/github/github-audit")
from ghlib import api, OWNER

d = json.load(open(r"D:/github/github-audit/_collab_prs.json", encoding="utf-8"))
items = [i for i in d["commented"] if not i["repository_url"].split("/repos/")[1].lower().startswith("truefurina/")]
print("external commented issues:", len(items))

rows = []
for i in items:
    repo = i["repository_url"].split("/repos/")[1]
    num = i["number"]
    cs = api(f"/repos/{repo}/issues/{num}/comments?per_page=30")
    if not isinstance(cs, list):
        print("skip", repo, num, str(cs)[:80]); continue
    mine = [c for c in cs if (c.get("user") or {}).get("login") == OWNER]
    others = [c for c in cs if (c.get("user") or {}).get("login") != OWNER]
    my_last = mine[-1]["created_at"] if mine else None
    replies_after = [c for c in others if my_last and c["created_at"] > my_last]
    rows.append({
        "repo": repo, "num": num, "title": i["title"], "state": i["state"],
        "is_pr": "pull_request" in i,
        "total_comments": len(cs),
        "my_comments": len(mine),
        "my_first": mine[0]["created_at"] if mine else None,
        "my_chars": sum(len(c.get("body") or "") for c in mine),
        "my_sample": (mine[0].get("body") or "")[:400] if mine else "",
        "reply_after_me_by": sorted({(c["user"]["login"], c.get("author_association")) for c in replies_after}),
        "participants": sorted({(c["user"]["login"], c.get("author_association")) for c in cs}),
    })
    time.sleep(0.25)

rows.sort(key=lambda r: r["my_first"] or "")
json.dump(rows, open(r"D:/github/github-audit/_collab_comments.json", "w", encoding="utf-8"), ensure_ascii=False, indent=1)
print("saved", len(rows))
print("with maintainer reply after me:", sum(1 for r in rows if r["reply_after_me_by"]))
