# GitHub 账号体检与建言报告 · TrueFurina / Dream

- 审计时间：2026-10-28
- 审计方式：`GITHUB_TOKEN`（用户级环境变量，OAuth `gho_`）→ GitHub REST API 只读拉取 + 4 个并发 agent 分维度分析
- 数据快照：`D:/github/github-audit/raw.json`（2026-10-28 21:42）
- **本次未做任何写操作**：未改远端文件、未删仓库、未运行仓库内代码、未使用仓库里既有的 `delete-*.sh` / `delete-archived.ps1` 脚本

---

## 0. 一句话结论

**你不缺代码量，也不缺文档能力（README 平均 5,435 字，远高于个人项目均值）。缺的是三样东西：合规授权、工程闭环、以及把流量导到正确门面的那一段路。**

三个数字概括现状：

| 数字 | 含义 |
|---|---|
| **92** | 42 个原创仓库累计总星数，最高 9★ |
| **8,713 / 168** | 14 天内全账号被 clone 8,713 次，但只有 168 次页面浏览（约 12 次/天） |
| **27.5%** | 对外部仓库的 PR 合并率（200 个外部 PR 合了 55 个）。自建 PR 合并率 80.2%，但其中 588 个是自己批自己的 |

---

## 1. 账号画像（客观事实）

| 项 | 值 |
|---|---|
| 登录名 / 昵称 | `TrueFurina` / Dream |
| 公司 / 地区 | DBAPPSecurity / China |
| bio | Agent systems engineer——LLM-MARL, LangGraph pipelines, adversarial red-team security. Code first, buzzwords never. |
| 注册时间 | 2025-04-06（账号 1 年 6 个月） |
| 公开仓库 | 196（API 口径）→ 实际拉到 202：**原创 42 + fork 160**，其中 **111 个已归档** |
| 关注关系 | 170 followers / 231 following |
| 语言分布（原创） | Python 29、HTML 3、JS 2、Java 1、TS 1、PHP 1、PowerShell 1、Batchfile 1 |
| 组织 | `Circle1507`（member，6 人 Unity/C# 小组）、`MARL-ECDSA-Consensus`（admin，自己建的单人组织） |
| 近 6 天活动 | 300 events：Push 166、PR 49、IssueComment 25；峰值时段 UTC 21-22 与 13-14（北京时间 05-06、21-22） |

**技术主线非常清楚**：LLM Agent / MARL / 安全红队。头部项目 `SecAutoMind`（红队 agent）、`passive-recon`（被动 EASM）、`xihu-sword-ctf-agent`（CTF agent）、`marl-ecdsa`（MARL+区块链共识）、`MARS-408`（考研 408 教育 agent）。这条线本身是稀缺的——安全 + agent 双栈的公开作品在国内个人账号里很少。

---

## 2. 四个维度的体检结果

### 2.1 工程闭环（42 个原创仓库）

| 指标 | 数值 | 判读 |
|---|---|---|
| README 缺失 | 5（12%） | 全在材料仓 |
| README 平均字数 | **5,435 字**（中位 3,768） | 文档投入不低，短板不在这 |
| 有 LICENSE | 16（38%），**标准 MIT 仅 6（14%）** | 62% 裸奔 |
| 有 CI | 12（29%），**真正跑测试仅 7（17%）** | 有徽章无内容的情况存在 |
| 有 tests | 21（50%） | 测试意识 > 自动化意识 |
| 发过 Release | **5（12%）** | 37 个仓没有任何分发通道 |
| 体积 > 50MB | 2（MARS-408 108.7MB、SecAutoMind-src 88MB） | 占 42 仓总体积 47.3%，且无 LFS |
| 有 topics / homepage | 13（31%）/ 4（10%） | 可发现性几乎没经营 |

**最严重的单一问题：README 说 MIT，LICENSE 文件写"All Rights Reserved"。** 这已经不是规范问题，是授权错误——下游按 README 判定可商用，实际许可禁止：

| 仓库 | README 声明 | LICENSE 实际 |
|---|---|---|
| AGI-Distiller（9★，最高） | `License: MIT` 徽章 + 链接 | All Rights Reserved |
| passive-recon（7★） | `license-MIT` 徽章 + 正文写 MIT | All Rights Reserved |
| DevRadar-GitHub-Trending-Monitor | 徽章 + "see the LICENSE file" | All Rights Reserved |
| pikachu | "🆓 完全免费开源 ✅ MIT 协议" | All Rights Reserved |
| xuandun-cyber-range | `## 📜 许可证 [MIT](./LICENSE)` | 同文件末尾又写 License & Usage Notice |
| 2026-Challenge-Cup-Security-LLM-Triage-Agent | `## 🤝 License [MIT](LICENSE)` | 紧随其后 License & Usage Notice |

另有一个法律风险项：`pikachu` 自述"Pikachu 漏洞靶场定制版"，文件树与上游 `zhuifengshaonianhanlu/pikachu`（4,578★，**Apache-2.0**）高度一致（289 文件、`assets/` 原样保留），但全文找不到上游署名与原始许可。**修正：此前的初版建议写"换回 MIT 全文"是错的**——派生自 Apache-2.0 的作品必须继续用 Apache-2.0 并保留署名、声明改动，改成 MIT 反而违反上游许可。

**还有两处"文档承诺了、产品没兑现"**：
- `Denia`（825 文件、当日仍在提交、最活跃的桌面应用）README「快速开始 · 路线 A · 用安装包」指向的下载入口不存在——该仓 0 Release、0 CI。
- `SecAutoMind-src` 的 Release tag 名居然是 `main`，不是版本号。

### 2.2 开源协作（802 个 PR 的真相）

| 维度 | 数值 |
|---|---|
| PR 总数 / 已合并 | 802 / 643（80.2%） |
| 其中目标为自有仓库 | 602（自审自合 588，含 426 条 `pull-shark progress entry` 打卡） |
| **真实对外 PR** | **200 个，覆盖 140 个仓库，merged 55 → 27.5%** |
| 8 月单日峰值 | 57 个（模板批量，`bare except` 类 24 个只合了 3 个） |
| 评论过的议题 | 139 个，其中外部议题 64 个，**由他人发起的仅 8 个** |
| 他人议题中有维护者回复 | 4 个 |

**真实的、简历级的上游贡献（这批很硬，别浪费）：**

| PR | 内容 | 状态 | 证据强度 |
|---|---|---|---|
| `unicode-rs/unicode-segmentation #183` | 修 `GraphemeCursor` 三处 panic（+27/−5） | ✅ merged | 维护者 **Manishearth**（rust-analyzer 作者）亲自 APPROVED 并致谢 |
| `CodeGraphContext #1676` | 给 Cassandra/MySQL ingestor 加 SSL 校验（+1214/−315，25 文件） | ✅ merged | 维护者实测 trial-merge 后合并；该仓累计 4 个 merged，已获 CONTRIBUTOR |
| `TencentCloud/Octop #2171 → #2174` | 我提 issue 指出向导密码迁移缺陷 + **逐行给出 4 处该改的测试行号**，维护者据此修复 | ✅ #2174 merged | 维护者 jubaoliang："Looks merge-ready for #2171"；changelog 署名 #2171 |
| `seanmonstar/reqwest #3100` | 去掉 base64 `simd-unsafe` 默认特性，恢复 `forbid(unsafe_code)` | ✅ merged | reqwest 作者本人 APPROVED |
| `Unstructured-IO/unstructured #4463` | `Text` 元素 None 归一化，修 TypeError（含测试） | ✅ merged | 维护者 APPROVED |

**必须知道的负面证据（不改就会持续复利）：**

| 事件 | 对方原话 |
|---|---|
| `pallets/jinja` | 维护者只回一个链接：palletsprojects.com/contributing/llm-ai，PR 关闭（Pallets 全线封口） |
| `fastapi/fastapi`（5 个 PR） | YuriiMotov：**"please stop or you will be banned"** |
| `getzola/zola` | Keats 贴 CONTRIBUTING.md#L38-L39（"LLM usage is not accepted… use your own words"）后关闭 |
| `CTFd/CTFd #2889` | ColdHeat：**"If you're going to vibe the discussion, you can vibe your own solution."** |
| `CodeGraphContext #1758` | 合并后维护者指出 diff 里夹带了 PR 描述没写的改动（64 条 CONTAINS 容差），已回滚 |
| `kubeflow/testing #1072` | PR 评论里混进了邮件自动回复「您好，来件已收到。谢谢！」 |

**两个组织都不能当社区影响力写**：`Circle1507` 6 人小组本人只有 1 次提交（参与度最低）；`MARL-ECDSA-Consensus` 是自己建的 admin 组织，里面的 MEMBER 身份是自授的。

### 2.3 个人品牌与流量（最反直觉的部分）

14 天实测：**168 次浏览 / 8,713 次 clone**。流量不是没有，是全部堆在错的地方：

| 仓库 | ★ | views | clones | uniq cloners | clone/浏览 |
|---|---:|---:|---:|---:|---:|
| MARS-408（考研 408 教育） | 6 | **4** | **6,577** | 540 | **1,644×** |
| MangDeHenZhi | 4 | **0** | **1,324** | 335 | ∞ |
| xihu-sword-ctf-agent | 5 | 5 | 435 | 123 | 87× |
| SecAutoMind（红队 agent 官网） | 2 | **78** | 14 | 14 | 0.18 |
| passive-recon | 7 | 22 | 20 | 19 | 0.9 |

两种资产的转化断点完全不同：
- **有人克隆、没人看页面**（MARS-408、MangDeHenZhi）：入口是直接 `git clone`，人从没打开过仓库页。540 个真实 cloner 已经拿到代码，首屏加一句 ⭐ 就能转化。但要注意 MARS-408 是 10-18 单日 2,042 次、10-23 后骤降到 30 次/日——典型一次性事件（课程/群/截止日），需先分清是真人还是镜像爬虫。
- **有人看、星很少**（SecAutoMind、passive-recon）：这是**首屏说服力**问题。SecAutoMind 的 release 页有 13 views / 7 uniq——"下载二进制"的需求已被验证，只是没人提醒他们点 star。

**三处身份错位：**
1. bio 写 "engineer, code first, buzzwords never"，profile README 却写 `title: AI Agent Security **Product Manager**` + Governance/Roadmap/Stakeholder communication。
2. `blog` 字段指向 `appmiaoda` 域名的「芒得职训——AI 岗位胜任力智能服务平台」，页面里没有任何 agent / security / CTF / MARL 字样。**GitHub 个人页唯一的站外入口，现在在给培训产品导流。**
3. 头部项目被拆成三个身份：`SecAutoMind`（官网 HTML，2★）、`SecAutoMind-src`（源码，88MB）、`xihu-sword-ctf-agent`（已自宣并入）。

**star 数据的存在性问题**：300 条 star 快照里 106 条是 star 自己的仓库（补全后 120/412），而 42 个原创仓累计总星只有 92——**自己点出来的星比自己挣到的星还多**。叠加 `following 231 > followers 170`、5 天 166 次 push + 49 次 PR、profile 仓库里 426 条 pull-shark 打卡，审核者第一眼看到的就是这些。

### 2.4 安全与泄密（好消息 + 3 个待办）

**结论：未发现高置信泄露，可直接利用的真实密钥 0 条。** 扫描 25 个仓库 / 9,444 条文件路径 / 约 500 个文件正文，原始正则 19 条命中经复核后高置信 0、中 3、低 5 类。

| 风险 | 位置 | 建议 |
|---|---|---|
| 中 · 明文会话密钥字段 | `MARS-408/py-server/iq_run_tmp/.env.test`（public）`AUTH_SECRET=test-****`、`ADMIN_PASSWORD=adm****` | 30 分钟内确认是否与任何部署环境同值；同值立即轮换，不同值删文件 + 加 `.gitignore` |
| 中 · 学生 PII | `MangDeHenZhi-materials/06-学生信息/*.xlsx`（private，495 人名单/分班/宿舍） | 涉《个人信息保护法》敏感信息，private 只降概率不消除风险；建议迁出 GitHub |
| 中 · Secret Scanning 告警未处理 | `physics-scheduler-agent` alert #1（微信 AppID `wx31****c69e`，open） | 确认 `app_secret` 从未进入仓库后标记 won't fix，否则换 secret |
| 低中 · 内网信息 | `AI-Arena` README/ROADMAP 4 处：`172.16.***.99` + "SSH ed25519 免密" | 删 IP 与免密说明 |
| 配置缺口 | `SecAutoMind-src`、`xihu-sword-ctf-agent`、`aerorider-delivery`、`win-appx-doctor` 未开 Secret Scanning / Push Protection | 一条 PATCH 开启（命令见 `findings/secrets-risk.md` §5.2） |

顺带一句：你的密钥卫生其实高于平均——`Denia` 有 DPAPI 落盘的 `secret_box`，`MARS-408` 有 `_strip_secrets()` 与 `/api/config` 掩码，`MARS-408` 还接了 gitleaks pre-commit。**问题是这套防线只在 1 个仓库里生效。**

---

## 3. 30 天行动路线（按"先止血、再放大"排序）

### 第 1 周 · 止血（约 4 小时，全部是文本改动，零风险）

| # | 动作 | 具体文件 | 验收 |
|---|---|---|---|
| 1 | 三个头部仓 LICENSE 换成标准 MIT 全文（保留 `Copyright (c) 2026 TrueFurina`） | `AGI-Distiller/LICENSE`、`passive-recon/LICENSE`、`DevRadar-…/LICENSE` | 仓库页 license 显示 MIT，不再是 NOASSERTION |
| 2 | `pikachu`：删掉"All Rights Reserved"整段 + MIT 徽章，改 **Apache-2.0**（上游是 `zhuifengshaonianhanlu/pikachu`，Apache-2.0）；新增 `NOTICE` 写上游署名与改动清单 | `pikachu/README.md`、`pikachu/LICENSE`、`pikachu/NOTICE` | 全文只有一种授权表述，且与上游一致 |
| 3 | 同一篇 README 里既写 `[MIT](LICENSE)` 又写 License & Usage Notice 的，只留一段 | `xuandun-cyber-range/README.md`、`2026-Challenge-Cup-Security-LLM-Triage-Agent/README.md` | 同上 |
| 4 | 处理 MARS-408 的 `.env.test` + 关闭 / 处理 physics-scheduler-agent 的 alert #1 | 见 2.4 | 无明文会话密钥字段；告警清零 |
| 5 | 清 `xihu-sword-ctf-agent` 首屏：删本机路径 `E:\Program\SecAutoMind`，FROZEN 横幅压成一行，三层"口径更正"收进 `<details>` | README 首屏 | 5 行内看懂"是什么/为什么冻结/去哪了" |
| 6 | 4 个仓开启 Secret Scanning + Push Protection | `SecAutoMind-src`、`xihu-sword-ctf-agent`、`aerorider-delivery`、`win-appx-doctor` | security_and_analysis 双 enabled |

### 第 2 周 · 补闭环（这才是"能不能被依赖"的分水岭）

| # | 动作 | 说明 |
|---|---|---|
| 7 | `Denia` 补 CI + 发首个 Release | `ci.yml`：matrix py3.10/3.12 + windows-latest，跑 `compileall` + 现有 tests + `agent_pro/selftest.py`；打 `v0.2.0` 附安装包，让 README 的"路线 A"成立 |
| 8 | `MARS-408` 补 LICENSE（建议 Apache-2.0）+ 减重 | 4 张架构图/`deliverables/` 移到首个 Release 附件；`.gitattributes` 加 LFS；108.7MB → 目标 40MB 内 |
| 9 | `SecAutoMind-src` 减重 + 版本化 | `SecAutoMind_PPT/`、`assets/`、`knowledge_base/` 外置到 Release；tag 从 `main` 改成 `v1.8.0` |
| 10 | 5 个零 README 仓补 3 段说明 | `MangDeHenZhi-materials`、`workspace`、`marl-ecdsa-competition-materials`、`xihu-ctf-deliverables`、`SecAutoMind` —— 每仓只写「这是什么 / 与主仓关系 / 如何引用」 |
| 11 | 9 个空 description + 29 个无 topics 一次性补齐 | 优先 SecAutoMind、MangDeHenZhi、marl-ecdsa、2026-CC |
| 12 | `marl-ecdsa` README 从 259 字扩到能讲清方法 | 3.9MB、有 CI 有 Release 的参赛主仓，文档最短，最不该 |

### 第 3-4 周 · 放大（把已有的硬资产变成可见影响力）

| # | 动作 | 为什么 |
|---|---|---|
| 13 | **合并 SecAutoMind 三个身份**：`SecAutoMind-src` 改名 `secautomind` 作为唯一主入口，官网仓 README 指向主仓或归档 | 搜索 "SecAutoMind" 只应有一个入口 |
| 14 | SecAutoMind README 首屏三行改成「是什么 / 一行命令 / 一个数字」，加 vs PentAGI、PentestGPT 对照表（含"单机离线"差异） | 现在是 91 条配方 / 50+ 工具这类**功能数**，不是**效果数** |
| 15 | 录 90 秒 demo（登录 → 自然语言下指令 → **审批弹窗被拒绝一次**）→ gif 放首屏，mp4 挂 release | 全账号 0 个 .gif。这是当前成本最低、收益最高的一件事 |
| 16 | 跑 NYU_CTF_Bench 公开子集，出 benchmark 表（pass@1 / token / 耗时 / 失败归因） | 红队 agent 的权威性来自"敢上公开榜"，数字低没关系，你 README 本来就在做诚实 KPI |
| 17 | profile 仓库重写：删掉 426 条 pull-shark 打卡，换成 5 行 "Selected upstream contributions" 表（带对方 APPROVED 原话） | 审核者点进来第一眼现在是刷徽章 |
| 18 | 加一节 "Contribution policy"：不用 LLM 生成 issue/PR 正文、单仓库优先、docs-only PR 不自荐 | 把 jinja/fastapi/zola 三次踩坑转成方法论输出 |
| 19 | **冻结**批量 PR；58 个 open PR 逐一二选一（关闭附结论 / 补齐测试） | 只保留还有技术含量的：`psutil #2989/#2990`、`attrs #1616/#1618`，各补最小复现脚本 + 平台输出矩阵 |
| 20 | `Octop` 把 `#2375` 与 `wxhking` 的 `#2299` 合并成一个 PR（补三条传输单测）；关掉 `#2170`、`#2369` 两个已被 #2174 推翻的 docs PR | 已验证的打法：issue 驱动维护者合并 |
| 21 | 换 `blog` 字段 → 一个单页技术主页（一句话定位 + 3 个旗舰卡片 + 2 篇长文）；芒得职训放页面底部"我做过的产品" | 现在最贵的链接位在给培训产品导流 |
| 22 | 自 star 停止扩散，改用 Lists 收藏 + 置顶 6 个仓库 | 桌面可展示的 92 星 < 自己点出的 106 星，这个比值会被看出来 |

**30 天后回看指标**：SecAutoMind views ≥ 200（现 78/14d）、release 页 ≥ 50、新增 star ≥ 20；passive-recon views ≥ 80（现 22/14d）、star ≥ 25；referrers 从"全空"变为至少 2 个非空来源。

---

## 4. 如果只做三件事

1. **修掉 AGI-Distiller / passive-recon / DevRadar 的 README↔LICENSE 互斥**（20★ 的三个仓，是账号 92★ 的 22%，也是被外部引用最可能的三处，而现在是错的）。
2. **把 SecAutoMind 合成一个门面 + 首屏放一个可验证数字 + 90 秒 demo**（唯一有真实下载行为、与 bio 完全同频的资产）。
3. **停批量 PR、清理 58 个 open、把 5 个真贡献做成索引**（`unicode-segmentation #183` 有 Manishearth 亲批，这一条比 800 个自动 PR 都有说服力）。

---

## 5. 本轮产出与方法

| 文件 | 内容 | 由谁产出 |
|---|---|---|
| `fetch2.py` / `ghlib.py` | 抗代理截断的抓取器（per_page≤30）、共享 API 助手 | 主 agent |
| `summarize.py` | 账号画像摘要 | 主 agent |
| `findings/repo-audit.md` | 42 仓逐仓工程质量审计（含 42 行明细表） | agent `repo-audit` |
| `findings/collab.md` | 802 个 PR / 139 议题 / 2 个组织的协作图谱与声誉风险 | agent `collab-audit` |
| `findings/positioning.md` | 14 天 traffic 实测、关键词一致性、5 个竞品对标、旗舰方案 | agent `positioning` |
| `findings/secrets-risk.md` | 25 仓 9,444 路径泄密扫描、扫描覆盖与局限 | agent `secrets-audit` |

**已知局限（别看漏）**：① 只扫 default branch 当前快照，Git 历史未做全量扫描（历史里删过的 `.env` 需本地 `gitleaks detect` 确认）；② MARS-408 的 3 个 `*.zip`（59MB）与 `dev.db` 是扫描盲区；③ traffic 的 referrers 端点全部 404，外部导流无法归因；④ 大仓库文件树因代理 500KB 截断采用 BFS 枚举，路径数少于 git 实际条目（内容等价）。

**关于仓库里已有的脚本**：`delete-archived.ps1`、`delete_forks.sh`、`delete-tierA.sh`、`fix-selfstar.ps1`、`fix-license.ps1` 等都在，我**一个都没运行**。按你的规矩不做任何删除；归档类操作（archive）如需执行，我会先列出清单等你确认。
