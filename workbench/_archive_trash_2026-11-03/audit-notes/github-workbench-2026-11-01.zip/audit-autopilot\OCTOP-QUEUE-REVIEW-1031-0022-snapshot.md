# Octop 三仓 open PR 队列体检

生成时间：2026-10-31 00:22 ｜ 数据源：`/repos/{repo}/pulls?state=open` 逐个取详情
范围：`TencentCloud/Octop`、`octop-harness`、`octop-memory` 中**本人**提交且仍 open 的 PR

## 一句话

**222 个 open PR 里，221 个 `mergeable=true`（无冲突，技术上是"点一下就能合"），
1 个有冲突，27 个开了 ≥3 天零评论（维护者没打开过）。**

## 先说清楚 `mergeable_state=unstable` 是怎么回事

这三个仓 `unstable` 占绝大多数（本报告里 221 个），但它**不是"检查失败"**：

```
mergeable=true
combined status = pending，但 statuses 数量 = 0
check-runs = GITHUB_OPENSOURCE_SCAN_PIPELINE → completed / success
分支保护 required_status_checks.contexts = []（三仓都是空）
```

GitHub 在"零个 commit status"时把 combined status 报成 `pending`，于是 `mergeable_state`
标成 `unstable`。**换句话说：它表示"没有 CI 在报状态"，不是"CI 挂了"。**

本次抽查了 10 个 `unstable` 的 PR：其中 **10 个**确认"无失败检查 + 零 status"，
其余可能是并发抖动或确有失败。样本不大，所以下面按"无冲突"而不是"检查全绿"来分组。

## 分布

| 维度 | 数值 |
|---|---|
| 总计 | **222** |
| `mergeable=true`（无冲突） | **221** |
| `mergeable=false`（有冲突） | 1 |
| 其中 `mergeable_state=unstable` | 221 |
| `behind` / `blocked` | 0 / 0 |
| 草稿 | 0 |
| 零评论且 ≥3 天 | **27** |

按仓库：Octop 148, octop-harness 68, octop-memory 6

按 `mergeable_state` 原始计数：{'unstable': 221, 'dirty': 1}

## A. 无冲突，可合（221）

技术门槛已经没了，缺的只是维护者的一次点击。**优先级最高**——每合一个，队列少一个。

| 仓库 | # | 标题 | 规模 | 年龄 | 空闲 | 评论 |
|---|---:|---|---|---:|---:|---:|
| Octop | [#2170](https://github.com/TencentCloud/Octop/pull/2170) | docs: complete the ~/.octop layout tree and note the wizard pa | +13/−0 | 13d | 7d | 3 |
| octop-harness | [#83](https://github.com/TencentCloud/octop-harness/pull/83) | feat(tool_guard): detect Windows and PowerShell attack command | +199/−1 | 13d | 3d | 3 |
| Octop | [#2376](https://github.com/TencentCloud/Octop/pull/2376) | fix(utils): bound download filename by UTF-8 bytes to avoid ov | +77/−1 | 8d | 3d | 1 |
| Octop | [#2372](https://github.com/TencentCloud/Octop/pull/2372) | fix(env): 未闭合引号不再吞掉 ~/.octop/env 后续变量 (#2269) | +57/−6 | 8d | 3d | 1 |
| Octop | [#2371](https://github.com/TencentCloud/Octop/pull/2371) | fix(cli): 跨文件系统导出备份不再因 EXDEV 失败 (#2321) | +156/−1 | 8d | 3d | 1 |
| Octop | [#2369](https://github.com/TencentCloud/Octop/pull/2369) | docs: fix wizard password path in .env.example (post-#2174) | +1/−1 | 8d | 3d | 1 |
| octop-memory | [#29](https://github.com/TencentCloud/octop-memory/pull/29) | fix(memory): batch extraction and persist the extracted cursor | +348/−12 | 6d | 2d | 2 |
| octop-memory | [#30](https://github.com/TencentCloud/octop-memory/pull/30) | fix(storage): honor rejected candidates when deduplicating re- | +38/−13 | 5d | 3d | 1 |
| Octop | [#2495](https://github.com/TencentCloud/Octop/pull/2495) | fix(oauth): preserve existing query params on authorization_en | +9/−2 | 3d | 3d | 0 |
| Octop | [#2494](https://github.com/TencentCloud/Octop/pull/2494) | fix(grep_safety): search only target file path, not parent dir | +3/−0 | 3d | 3d | 0 |
| Octop | [#2493](https://github.com/TencentCloud/Octop/pull/2493) | fix(manager): guarantee non-NULL icon_url/color on agent creat | +24/−0 | 3d | 3d | 0 |
| Octop | [#2489](https://github.com/TencentCloud/Octop/pull/2489) | fix(cron): auto-approve HITL so unattended scheduled runs do n | +94/−20 | 3d | 3d | 0 |
| Octop | [#2488](https://github.com/TencentCloud/Octop/pull/2488) | fix(backup): exclude SQLite sidecar files from workspace archi | +28/−0 | 3d | 3d | 0 |
| Octop | [#2487](https://github.com/TencentCloud/Octop/pull/2487) | fix(db): safely deserialize legacy TEXT credential_blob rows | +67/−5 | 3d | 3d | 0 |
| Octop | [#2486](https://github.com/TencentCloud/Octop/pull/2486) | fix: artifact path result-first + CLI agent persona defaults | +30/−6 | 3d | 3d | 0 |
| Octop | [#2485](https://github.com/TencentCloud/Octop/pull/2485) | fix(cli): make octop init --force safe - backup instead of del | +76/−41 | 3d | 3d | 0 |
| Octop | [#2484](https://github.com/TencentCloud/Octop/pull/2484) | Fix active-turn flag leak with TTL-based stale eviction (issue | +51/−4 | 3d | 3d | 0 |
| Octop | [#2483](https://github.com/TencentCloud/Octop/pull/2483) | fix(cron): preserve interval deadline on metadata-only PATCH e | +31/−5 | 3d | 3d | 0 |
| Octop | [#2482](https://github.com/TencentCloud/Octop/pull/2482) | fix(agent): resolve icon_url/color from template for CLI-creat | +31/−8 | 3d | 3d | 0 |
| Octop | [#2481](https://github.com/TencentCloud/Octop/pull/2481) | fix(cli): gracefully handle missing bundled plugin catalog in  | +31/−5 | 3d | 3d | 0 |
| Octop | [#2480](https://github.com/TencentCloud/Octop/pull/2480) | fix(thread-artifacts): prefer tool result path over request ar | +12/−6 | 3d | 3d | 0 |
| octop-harness | [#132](https://github.com/TencentCloud/octop-harness/pull/132) | fix(session_header): catch ValueError on ContextVar reset acro | +7/−1 | 3d | 3d | 0 |
| octop-harness | [#129](https://github.com/TencentCloud/octop-harness/pull/129) | fix(docker): preserve leading dots in relative paths (issue #4 | +9/−2 | 3d | 3d | 0 |
| octop-harness | [#128](https://github.com/TencentCloud/octop-harness/pull/128) | fix(tool_guard): add Windows PowerShell attack detection rules | +133/−1 | 3d | 3d | 0 |
| octop-harness | [#127](https://github.com/TencentCloud/octop-harness/pull/127) | fix(runtime): treat a non-UTF-8 workspace .env as unreadable | +5/−1 | 3d | 3d | 0 |
| octop-harness | [#126](https://github.com/TencentCloud/octop-harness/pull/126) | fix: enforce workspace sandbox isolation for absolute paths | +62/−6 | 3d | 3d | 0 |
| octop-harness | [#125](https://github.com/TencentCloud/octop-harness/pull/125) | fix(mcp): use live config dict for MCPToolMiddleware server_na | +8/−7 | 3d | 3d | 0 |
| octop-harness | [#124](https://github.com/TencentCloud/octop-harness/pull/124) | fix(decision): remove system-prompt text mutation in _relocate | +8/−9 | 3d | 3d | 0 |
| octop-harness | [#123](https://github.com/TencentCloud/octop-harness/pull/123) | Add LoopGuardMiddleware to break repeated identical tool-call  | +264/−26 | 3d | 3d | 0 |
| octop-harness | [#121](https://github.com/TencentCloud/octop-harness/pull/121) | fix(tool_guard): add defense_evasion threat category + re-file | +2/−1 | 3d | 3d | 0 |
| octop-harness | [#116](https://github.com/TencentCloud/octop-harness/pull/116) | fix(teams): isolate inbox worker from caller's contextvars (#1 | +22/−1 | 3d | 3d | 0 |
| octop-memory | [#36](https://github.com/TencentCloud/octop-memory/pull/36) | fix(router): add episode to default recall sources | +6/−0 | 3d | 3d | 0 |
| octop-memory | [#35](https://github.com/TencentCloud/octop-memory/pull/35) | fix(hermes): pass llm and extraction config blocks through bri | +6/−0 | 3d | 3d | 0 |
| octop-memory | [#34](https://github.com/TencentCloud/octop-memory/pull/34) | fix(extract): batch event feed + persist cursor across restart | +156/−26 | 3d | 3d | 0 |
| octop-memory | [#33](https://github.com/TencentCloud/octop-memory/pull/33) | fix(manual-docs): advance audit cursor on uncertain results | +2/−8 | 3d | 3d | 0 |
| Octop | [#2607](https://github.com/TencentCloud/Octop/pull/2607) | fix(skills): narrow suppress(Exception) around proc.wait to sp | +1/−1 | 2d | 2d | 0 |
| Octop | [#2606](https://github.com/TencentCloud/Octop/pull/2606) | fix(ldap): narrow _safe_unbind suppress(Exception) to LDAPExce | +1/−1 | 2d | 2d | 0 |
| Octop | [#2605](https://github.com/TencentCloud/Octop/pull/2605) | fix(xlsx): suppress PermissionError during soffice shim temp c | +1/−1 | 2d | 2d | 0 |
| Octop | [#2604](https://github.com/TencentCloud/Octop/pull/2604) | fix(agently): add missing_ok=True to confirmation-file unlinks | +2/−2 | 2d | 2d | 0 |
| Octop | [#2603](https://github.com/TencentCloud/Octop/pull/2603) | fix(backup): make _clear_local_workspace resilient to concurre | +2/−2 | 2d | 2d | 0 |

_（共 221 个，此处列前 40）_


## B. 有冲突，需要 rebase 或重开（1）

`mergeable=false` 意味着和 base 打架。要么 rebase，要么关掉重开一个干净的。
**放着不动最糟**：占用名额，且每次 base 前进都更难解。

| 仓库 | # | 标题 | 规模 | 年龄 | 空闲 | 评论 |
|---|---:|---|---|---:|---:|---:|
| octop-harness | [#106](https://github.com/TencentCloud/octop-harness/pull/106) | fix(llm): bound OpenAI-compatible requests with a default time | +34/−0 | 6d | 3d | 1 |


## C. 零评论且 ≥3 天（27）

维护者从没打开过。它们不是"被拒绝"，是**没有被看见**。对这批，提高单条质量的收益
远大于再开新的。

| 仓库 | # | 标题 | 规模 | 年龄 | 空闲 | 评论 |
|---|---:|---|---|---:|---:|---:|
| Octop | [#2495](https://github.com/TencentCloud/Octop/pull/2495) | fix(oauth): preserve existing query params on authorization_en | +9/−2 | 3d | 3d | 0 |
| Octop | [#2494](https://github.com/TencentCloud/Octop/pull/2494) | fix(grep_safety): search only target file path, not parent dir | +3/−0 | 3d | 3d | 0 |
| Octop | [#2493](https://github.com/TencentCloud/Octop/pull/2493) | fix(manager): guarantee non-NULL icon_url/color on agent creat | +24/−0 | 3d | 3d | 0 |
| Octop | [#2489](https://github.com/TencentCloud/Octop/pull/2489) | fix(cron): auto-approve HITL so unattended scheduled runs do n | +94/−20 | 3d | 3d | 0 |
| Octop | [#2488](https://github.com/TencentCloud/Octop/pull/2488) | fix(backup): exclude SQLite sidecar files from workspace archi | +28/−0 | 3d | 3d | 0 |
| Octop | [#2487](https://github.com/TencentCloud/Octop/pull/2487) | fix(db): safely deserialize legacy TEXT credential_blob rows | +67/−5 | 3d | 3d | 0 |
| Octop | [#2486](https://github.com/TencentCloud/Octop/pull/2486) | fix: artifact path result-first + CLI agent persona defaults | +30/−6 | 3d | 3d | 0 |
| Octop | [#2485](https://github.com/TencentCloud/Octop/pull/2485) | fix(cli): make octop init --force safe - backup instead of del | +76/−41 | 3d | 3d | 0 |
| Octop | [#2484](https://github.com/TencentCloud/Octop/pull/2484) | Fix active-turn flag leak with TTL-based stale eviction (issue | +51/−4 | 3d | 3d | 0 |
| Octop | [#2483](https://github.com/TencentCloud/Octop/pull/2483) | fix(cron): preserve interval deadline on metadata-only PATCH e | +31/−5 | 3d | 3d | 0 |
| Octop | [#2482](https://github.com/TencentCloud/Octop/pull/2482) | fix(agent): resolve icon_url/color from template for CLI-creat | +31/−8 | 3d | 3d | 0 |
| Octop | [#2481](https://github.com/TencentCloud/Octop/pull/2481) | fix(cli): gracefully handle missing bundled plugin catalog in  | +31/−5 | 3d | 3d | 0 |
| Octop | [#2480](https://github.com/TencentCloud/Octop/pull/2480) | fix(thread-artifacts): prefer tool result path over request ar | +12/−6 | 3d | 3d | 0 |
| octop-harness | [#132](https://github.com/TencentCloud/octop-harness/pull/132) | fix(session_header): catch ValueError on ContextVar reset acro | +7/−1 | 3d | 3d | 0 |
| octop-harness | [#129](https://github.com/TencentCloud/octop-harness/pull/129) | fix(docker): preserve leading dots in relative paths (issue #4 | +9/−2 | 3d | 3d | 0 |
| octop-harness | [#128](https://github.com/TencentCloud/octop-harness/pull/128) | fix(tool_guard): add Windows PowerShell attack detection rules | +133/−1 | 3d | 3d | 0 |
| octop-harness | [#127](https://github.com/TencentCloud/octop-harness/pull/127) | fix(runtime): treat a non-UTF-8 workspace .env as unreadable | +5/−1 | 3d | 3d | 0 |
| octop-harness | [#126](https://github.com/TencentCloud/octop-harness/pull/126) | fix: enforce workspace sandbox isolation for absolute paths | +62/−6 | 3d | 3d | 0 |
| octop-harness | [#125](https://github.com/TencentCloud/octop-harness/pull/125) | fix(mcp): use live config dict for MCPToolMiddleware server_na | +8/−7 | 3d | 3d | 0 |
| octop-harness | [#124](https://github.com/TencentCloud/octop-harness/pull/124) | fix(decision): remove system-prompt text mutation in _relocate | +8/−9 | 3d | 3d | 0 |
| octop-harness | [#123](https://github.com/TencentCloud/octop-harness/pull/123) | Add LoopGuardMiddleware to break repeated identical tool-call  | +264/−26 | 3d | 3d | 0 |
| octop-harness | [#121](https://github.com/TencentCloud/octop-harness/pull/121) | fix(tool_guard): add defense_evasion threat category + re-file | +2/−1 | 3d | 3d | 0 |
| octop-harness | [#116](https://github.com/TencentCloud/octop-harness/pull/116) | fix(teams): isolate inbox worker from caller's contextvars (#1 | +22/−1 | 3d | 3d | 0 |
| octop-memory | [#36](https://github.com/TencentCloud/octop-memory/pull/36) | fix(router): add episode to default recall sources | +6/−0 | 3d | 3d | 0 |
| octop-memory | [#35](https://github.com/TencentCloud/octop-memory/pull/35) | fix(hermes): pass llm and extraction config blocks through bri | +6/−0 | 3d | 3d | 0 |
| octop-memory | [#34](https://github.com/TencentCloud/octop-memory/pull/34) | fix(extract): batch event feed + persist cursor across restart | +156/−26 | 3d | 3d | 0 |
| octop-memory | [#33](https://github.com/TencentCloud/octop-memory/pull/33) | fix(manual-docs): advance audit cursor on uncertain results | +2/−8 | 3d | 3d | 0 |


## D. 时间轴两端

最老的 12 个：

| 仓库 | # | 标题 | 规模 | 年龄 | 空闲 | 评论 |
|---|---:|---|---|---:|---:|---:|
| Octop | [#2170](https://github.com/TencentCloud/Octop/pull/2170) | docs: complete the ~/.octop layout tree and note the wizard pa | +13/−0 | 13d | 7d | 3 |
| octop-harness | [#83](https://github.com/TencentCloud/octop-harness/pull/83) | feat(tool_guard): detect Windows and PowerShell attack command | +199/−1 | 13d | 3d | 3 |
| Octop | [#2376](https://github.com/TencentCloud/Octop/pull/2376) | fix(utils): bound download filename by UTF-8 bytes to avoid ov | +77/−1 | 8d | 3d | 1 |
| Octop | [#2372](https://github.com/TencentCloud/Octop/pull/2372) | fix(env): 未闭合引号不再吞掉 ~/.octop/env 后续变量 (#2269) | +57/−6 | 8d | 3d | 1 |
| Octop | [#2371](https://github.com/TencentCloud/Octop/pull/2371) | fix(cli): 跨文件系统导出备份不再因 EXDEV 失败 (#2321) | +156/−1 | 8d | 3d | 1 |
| Octop | [#2369](https://github.com/TencentCloud/Octop/pull/2369) | docs: fix wizard password path in .env.example (post-#2174) | +1/−1 | 8d | 3d | 1 |
| octop-harness | [#106](https://github.com/TencentCloud/octop-harness/pull/106) | fix(llm): bound OpenAI-compatible requests with a default time | +34/−0 | 6d | 3d | 1 |
| octop-memory | [#29](https://github.com/TencentCloud/octop-memory/pull/29) | fix(memory): batch extraction and persist the extracted cursor | +348/−12 | 6d | 2d | 2 |
| octop-memory | [#30](https://github.com/TencentCloud/octop-memory/pull/30) | fix(storage): honor rejected candidates when deduplicating re- | +38/−13 | 5d | 3d | 1 |
| Octop | [#2495](https://github.com/TencentCloud/Octop/pull/2495) | fix(oauth): preserve existing query params on authorization_en | +9/−2 | 3d | 3d | 0 |
| Octop | [#2494](https://github.com/TencentCloud/Octop/pull/2494) | fix(grep_safety): search only target file path, not parent dir | +3/−0 | 3d | 3d | 0 |
| Octop | [#2493](https://github.com/TencentCloud/Octop/pull/2493) | fix(manager): guarantee non-NULL icon_url/color on agent creat | +24/−0 | 3d | 3d | 0 |


最新的 12 个（增速参考）：

| 仓库 | # | 标题 | 规模 | 年龄 | 空闲 | 评论 |
|---|---:|---|---|---:|---:|---:|
| Octop | [#2667](https://github.com/TencentCloud/Octop/pull/2667) | fix(octop): guard Path.stat() with OSError in backup store (th | +13/−3 | 1d | 1d | 0 |
| Octop | [#2666](https://github.com/TencentCloud/Octop/pull/2666) | fix(octop): add is_dir + OSError guard for agently_cli attachm | +6/−1 | 1d | 1d | 0 |
| Octop | [#2665](https://github.com/TencentCloud/Octop/pull/2665) | fix(octop): guard credential marker reads and backup file read | +25/−13 | 1d | 1d | 0 |
| Octop | [#2664](https://github.com/TencentCloud/Octop/pull/2664) | fix(octop): guard slim_control endpoint read with OSError and  | +7/−1 | 1d | 1d | 0 |
| Octop | [#2663](https://github.com/TencentCloud/Octop/pull/2663) | fix(octop): guard glob/rglob with OSError in backup, ollama ma | +20/−4 | 1d | 1d | 0 |
| Octop | [#2662](https://github.com/TencentCloud/Octop/pull/2662) | fix(octop): guard rglob with OSError in plugin manager fingerp | +10/−2 | 1d | 1d | 0 |
| Octop | [#2661](https://github.com/TencentCloud/Octop/pull/2661) | fix(octop): guard glob/rglob with OSError in expert catalog di | +10/−2 | 1d | 1d | 0 |
| Octop | [#2660](https://github.com/TencentCloud/Octop/pull/2660) | fix(octop): guard Path.glob() with OSError in session logs, av | +20/−4 | 1d | 1d | 0 |
| Octop | [#2659](https://github.com/TencentCloud/Octop/pull/2659) | fix(octop): guard Path.iterdir() with OSError in teams router  | +10/−2 | 1d | 1d | 0 |
| Octop | [#2658](https://github.com/TencentCloud/Octop/pull/2658) | fix(octop): guard Path.iterdir() with OSError in skill_package | +12/−2 | 1d | 1d | 0 |
| Octop | [#2657](https://github.com/TencentCloud/Octop/pull/2657) | fix(octop): guard log_dir.iterdir() with OSError in server log | +10/−2 | 1d | 1d | 0 |
| Octop | [#2656](https://github.com/TencentCloud/Octop/pull/2656) | Guard Path.iterdir() with OSError in browser_media and skill_p | +16/−5 | 1d | 1d | 0 |


## 建议（只建议，不执行）

1. **先合 A 组的 221 个**（至少先把 A 组里最老的 20 个）。理由：不需要任何人改代码，
   纯粹是"点一下"；合掉之后队列可读性立刻改善。
2. **B 组 1 个二选一**：能 rebase 的 rebase，改不动的关掉并写一句原因。
3. **C 组 27 个先别动**：它们的问题是"没被看见"。
4. **停止新增**。当前增速下（约 50–90 个/小时），任何"再提一个更小的 PR"都在稀释前面的努力。

> 本文件是只读体检的产物：没有关闭、没有评论、没有推送。
