import json, subprocess, urllib.request, urllib.error, base64

TOKEN = subprocess.run(["powershell","-NoProfile","-Command",
    "[Environment]::GetEnvironmentVariable('GITHUB_TOKEN','User')"],
    capture_output=True, text=True).stdout.strip()
H = {"Authorization":"Bearer "+TOKEN,"User-Agent":"r","Accept":"application/vnd.github+json"}

def get(u):
    r = urllib.request.Request(u, headers=H)
    try:
        with urllib.request.urlopen(r, timeout=40) as resp:
            return resp.status, json.loads(resp.read())
    except urllib.error.HTTPError as e:
        return e.code, None

REPO = "TrueFurina/MARS-408"
PATH = "py-server/iq_run_tmp/.env.test"

# 1) 该文件出现在几个 commit 里
s, c = get(f"https://api.github.com/repos/{REPO}/commits?path={PATH}&per_page=100")
commits = [x["sha"] for x in c] if isinstance(c, list) else []
print("该文件涉及的 commit 数:", len(commits))

# 2) 仓库总 commit 数（重写影响面）
s, allc = get(f"https://api.github.com/repos/{REPO}/commits?per_page=1")
import re
# 用 Link 头拿总数——改为直接查 pages
total = None
r = urllib.request.Request(f"https://api.github.com/repos/{REPO}/commits?per_page=1", headers=H)
with urllib.request.urlopen(r, timeout=40) as resp:
    link = resp.headers.get("Link","")
m = re.search(r'[?&]page=(\d+)>; rel="last"', link)
if m:
    total = int(m.group(1))
print("仓库总 commit 数:", total)

# 3) 是否有 fork / 被引用（重写影响面）
s, repo = get(f"https://api.github.com/repos/{REPO}")
for k in ["forks_count", "stargazers_count", "watchers_count", "size"]:
    print(f"  {k:20s} {repo.get(k)}")

# 4) 该文件所在目录是否还有别的敏感内容
s, tree = get(f"https://api.github.com/repos/{REPO}/git/trees/HEAD?recursive=1")
iq = [x["path"] for x in (tree or {}).get("tree",[]) if "iq_run_tmp" in x["path"]]
print("\niq_run_tmp 目录现存文件:", iq if iq else "（空/已删除）")

# 5) 历史中是否还有其他 .env 类文件
env_hist = [x["path"] for x in (tree or {}).get("tree",[]) if ".env" in x["path"] or x["path"].endswith((".pem",".key",".p12"))]
print("当前树中 env/密钥类文件:", env_hist if env_hist else "无")