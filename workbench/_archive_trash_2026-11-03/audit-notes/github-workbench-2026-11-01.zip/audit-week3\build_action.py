"""把 open43.json 渲染成 WEEK3-ACTION.md。

本文件刻意只含 ASCII：中文模板放在 action_template.md（UTF-8），
避免经 shell 传中文时被 cp936 转码成 mojibake。
"""
import json

rows = json.load(open("open43.json", encoding="utf-8"))
by = {}
for r in rows:
    by.setdefault(r.get("mergeable_state") or "unknown", []).append(r)

NOBODY = "\u2014\uff08\u65e0\u4eba\u770b\u8fc7\uff09"


def tbl(key, note):
    rs = sorted(by.get(key, []), key=lambda x: x["updated"], reverse=True)
    lines = ["### " + note + "\uff08" + str(len(rs)) + " \u4e2a\uff09",
             "",
             "| \u4ed3\u5e93 | # | \u6700\u540e\u53d1\u8a00 | \u8bc4\u8bba | \u66f4\u65b0 | \u6807\u9898 |",
             "|---|---:|---|---:|---|---|"]
    for r in rs:
        last = NOBODY if r["last"] == "-" else r["last"]
        t = r["title"].replace("|", "/")[:64]
        link = "https://github.com/" + r["repo"] + "/pull/" + str(r["num"])
        lines.append("| `" + r["repo"] + "` | [#" + str(r["num"]) + "](" + link + ") | "
                     + last + " | " + str(r["comments"]) + " | " + r["updated"] + " | " + t + " |")
    return "\n".join(lines)


pairs = [
    ("{TD}", tbl("dirty", "dirty \u00b7 \u6709\u51b2\u7a81")),
    ("{TB}", tbl("behind", "behind \u00b7 \u843d\u540e\u4e8e base")),
    ("{TC}", tbl("clean", "clean \u00b7 \u5df2\u53ef\u5408\u5e76")),
    ("{TBL}", tbl("blocked", "blocked \u00b7 \u7b49 review / label")),
    ("{TUN}", tbl("unstable", "unstable \u00b7 \u68c0\u67e5\u672a\u8fc7\u6216\u672a\u5b8c\u6210")),
    ("{TUK}", tbl("unknown", "unknown \u00b7 GitHub \u5c1a\u672a\u7b97\u51fa\u5408\u5e76\u72b6\u6001")),
]

doc = open("action_template.md", encoding="utf-8").read()
for k, v in pairs:
    doc = doc.replace(k, v)
open("WEEK3-ACTION.md", "w", encoding="utf-8").write(doc)
print("written", len(doc), "chars;", len(doc.splitlines()), "lines")
