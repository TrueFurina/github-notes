"""Fix case-mismatched README link in OWNER/physics-scheduler-agent.

README points at docs/PRD-V1.0.md but the file on disk is docs/PRD-v1.0.md.
On GitHub, paths are case-sensitive -> dead link. We only rewrite the link text
to point at the real file. No file is created, nothing is deleted.

Verification after write: re-fetch README from the API, confirm the new link,
confirm target path exists in the default-branch tree.
"""
import base64
import json
import sys
import urllib.request

sys.path.insert(0, r"D:/github/github-audit")
from ghlib import api, HEADERS, OWNER  # noqa: E402

REPO = OWNER + "/physics-scheduler-agent"
OLD = "docs/PRD-V1.0.md"
NEW = "docs/PRD-v1.0.md"


def put(path, payload):
    url = "https://api.github.com" + path
    data = json.dumps(payload).encode()
    req = urllib.request.Request(url, data=data, headers=HEADERS, method="PUT")
    req.add_header("Content-Type", "application/json")
    with urllib.request.urlopen(req, timeout=60) as r:
        return json.loads(r.read())


def main():
    branch = api("/repos/" + REPO)["default_branch"]
    meta = api("/repos/%s/contents/README.md?ref=%s" % (REPO, branch))
    if "__error" in meta:
        print("[FAIL] cannot read README meta:", meta)
        return 1
    raw = base64.b64decode(meta["content"]).decode("utf-8")
    if OLD not in raw:
        print("[SKIP] README no longer contains", OLD)
        return 0
    if NEW in raw:
        print("[SKIP] already fixed")
        return 0
    new_text = raw.replace(OLD, NEW)
    changed = [ln for ln in new_text.splitlines() if NEW in ln]
    print("[before] lines with old link:", sum(1 for ln in raw.splitlines() if OLD in ln))
    print("[after ] ", changed)
    res = put("/repos/%s/contents/README.md" % REPO, {
        "message": "docs(readme): fix case of PRD link (PRD-v1.0.md)",
        "content": base64.b64encode(new_text.encode()).decode(),
        "sha": meta["sha"],
        "branch": branch,
    })
    sha = (res.get("commit") or {}).get("sha")
    print("[commit]", sha)
    # verify
    check = api("/repos/%s/contents/README.md?ref=%s" % (REPO, branch))
    txt = base64.b64decode(check["content"]).decode("utf-8")
    print("[verify] new link present:", NEW in txt, "| old link gone:", OLD not in txt)
    tree = api("/repos/%s/git/trees/%s?recursive=1" % (REPO, branch))
    paths = {x["path"] for x in tree.get("tree", [])}
    print("[verify] target exists:", NEW in paths)
    return 0


if __name__ == "__main__":
    sys.exit(main())
