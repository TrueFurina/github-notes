"""Shared GitHub API helper for audit sub-agents.

Known constraint: the local proxy truncates responses larger than ~500KB,
so every list endpoint MUST use per_page<=30. Always page explicitly.

Usage:
    import sys; sys.path.insert(0, r"D:/github/github-audit")
    from ghlib import api, api_all, token, OWNER

    me  = api("/user")
    repos = api_all("/user/repos?affiliation=owner&sort=pushed")
"""
import json
import os
import subprocess
import time
import urllib.error
import urllib.request
from http.client import IncompleteRead

HERE = os.path.dirname(os.path.abspath(__file__))
OWNER = "TrueFurina"


def token() -> str:
    tok = os.environ.get("GITHUB_TOKEN", "").strip()
    if tok:
        return tok
    return subprocess.run(
        ["powershell", "-NoProfile", "-Command",
         "[Environment]::GetEnvironmentVariable('GITHUB_TOKEN','User')"],
        capture_output=True, text=True).stdout.strip()


TOKEN = token()
HEADERS = {
    "Authorization": "Bearer " + TOKEN,
    "User-Agent": "github-audit-agent/1.0",
    "Accept": "application/vnd.github+json",
    "X-GitHub-Api-Version": "2022-11-28",
}


def api(path: str, tries: int = 4):
    """GET api.github.com<path>. Returns parsed JSON, or {'__error': ...}.

    错误约定（改过一版，因为旧版会把网络故障伪装成"文件不存在"）：
      {'__error': 404}          -> 真的不存在
      {'__error': 'network'}    -> 重试耗尽仍失败（连接被掐断/响应被截断/非 JSON）
      {'__error': <其他 HTTP>}  -> 服务端明确报错

    注意：本机代理会截断约 500KB 以上的响应，urllib 在 Windows 上表现为
    `FileNotFoundError [Errno 2] No such file or directory`——**这不是 404**。
    大文件请用 api_raw()，它走 raw media type，不受 JSON 包装影响。
    """
    url = path if path.startswith("http") else "https://api.github.com" + path
    # 路径含中文/空格时必须百分号编码，否则 urllib 抛 UnicodeEncodeError，
    # 表现为"网络失败"——极易被误判成资源不存在。
    if not url.isascii():
        from urllib.parse import quote
        url = quote(url, safe=":/?&=%#+@[]{}()!$'*,;~")
    last = None
    for i in range(tries):
        try:
            req = urllib.request.Request(url, headers=HEADERS)
            with urllib.request.urlopen(req, timeout=60) as r:
                raw = b""
                while True:
                    try:
                        chunk = r.read(32768)
                    except IncompleteRead as e:
                        raw += getattr(e, "partial", b"") or b""
                        break
                    if not chunk:
                        break
                    raw += chunk
            if not raw:
                return None
            try:
                return json.loads(raw)
            except ValueError as e:  # 截断后必然是坏 JSON
                last = f"{type(e).__name__} (truncated? {len(raw)} bytes)"
                time.sleep(2 + i)
                continue
        except urllib.error.HTTPError as e:
            if e.code in (403, 429):
                time.sleep(6 * (i + 1))
                continue
            if e.code == 404:
                return {"__error": 404}
            print(f"HTTP {e.code} {url}")
            return {"__error": e.code}
        except Exception as e:
            # FileNotFoundError / ConnectionResetError / 超时 都归到这里：
            # 语义一律是"这次没拿到"，不是"资源不存在"。
            last = f"{type(e).__name__} {e}"
            time.sleep(2 + i)
    print(f"NET {last} {url}")
    return {"__error": "network", "detail": last}


def api_raw(path: str, tries: int = 3):
    """取文件原文（bytes），走 raw media type。

    大文件（如 496KB 的 number_registry.json）走 JSON 接口会被代理截断，
    这里让服务端直接回正文，少一层 base64 包装。
    """
    url = path if path.startswith("http") else "https://api.github.com" + path
    # 路径含中文/空格时必须百分号编码，否则 urllib 抛 UnicodeEncodeError，
    # 表现为"网络失败"——极易被误判成资源不存在。
    if not url.isascii():
        from urllib.parse import quote
        url = quote(url, safe=":/?&=%#+@[]{}()!$'*,;~")
    h = dict(HEADERS)
    h["Accept"] = "application/vnd.github.raw"
    for i in range(tries):
        try:
            with urllib.request.urlopen(urllib.request.Request(url, headers=h), timeout=120) as r:
                return r.read()
        except urllib.error.HTTPError as e:
            if e.code == 404:
                return None
            time.sleep(3 * (i + 1))
        except Exception:
            time.sleep(3 * (i + 1))
    return None


def api_all(path: str, per: int = 25, cap: int = 500, strict: bool = True):
    """分页拉取列表接口。`path` 可已带查询串。

    strict=True（默认）：某一页网络失败重试 3 次仍不行就 **抛异常**。
    这一点是刻意的——旧版直接 break 返回半截列表，会把"代理抖动"伪装成
    "只有这么几条"，统计类脚本（health.py 的许可分布、PR 计数）会静默少算。

    strict=False：保持旧的"能拿多少算多少"行为，仅在明确知道可容忍缺失时使用。
    """
    sep = "&" if "?" in path else "?"
    out, page = [], 1
    while len(out) < cap:
        chunk, last = None, None
        for attempt in range(3):
            chunk = api(f"{path}{sep}per_page={per}&page={page}")
            if isinstance(chunk, list):
                break
            if isinstance(chunk, dict) and chunk.get("__error") == "network":
                last = chunk.get("detail")
                time.sleep(3 * (attempt + 1))
                continue
            break
        if not isinstance(chunk, list):
            if strict and isinstance(chunk, dict) and chunk.get("__error") == "network":
                raise RuntimeError(f"api_all: 网络失败，{path} 第 {page} 页（{last}）。"
                                   f"已取到 {len(out)} 条，拒绝返回不完整结果。")
            break
        if not chunk:
            break
        out.extend(chunk)
        if len(chunk) < per:
            break
        page += 1
    return out


def tree_paths(repo: str, branch: str = None, owner: str = "TrueFurina"):
    """列出仓库全部文件路径，大仓库自动降级。

    大仓库（如 88MB 的 SecAutoMind-src、108MB 的 MARS-408）调
    `/git/trees/{branch}?recursive=1` 会失败（代理/接口限制，表现为 FileNotFoundError），
    这时逐个目录 BFS 枚举，避免误判成"目录不存在"。
    """
    if branch is None:
        branch = api(f"/repos/{owner}/{repo}")["default_branch"]
    t = api(f"/repos/{owner}/{repo}/git/trees/{branch}?recursive=1")
    if isinstance(t, dict) and "__error" not in t and t.get("tree"):
        return [e["path"] for e in t["tree"] if e.get("type") == "blob"]

    out, queue = [], [""]
    while queue:
        d = queue.pop(0)
        from urllib.parse import quote
        sub = quote(d, safe="/")
        r = api(f"/repos/{owner}/{repo}/contents/{sub}?ref={branch}" if d
                else f"/repos/{owner}/{repo}/contents?ref={branch}")
        if not isinstance(r, list):
            continue
        for item in r:
            if item["type"] == "dir":
                queue.append(item["path"])
            elif item["type"] == "file":
                out.append(item["path"])
    return out


def write_finding(name: str, text: str) -> str:
    d = os.path.join(HERE, "findings")
    os.makedirs(d, exist_ok=True)
    p = os.path.join(d, name)
    with open(p, "w", encoding="utf-8") as f:
        f.write(text)
    return p


if __name__ == "__main__":
    r = api("/rate_limit")
    print("rate:", r["rate"])
    print("token len:", len(TOKEN))
