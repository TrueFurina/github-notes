# 🚀 TencentCloud/Octop PR 动手指南

> 来源：GitHub API 直接验证 · 5 个可落地 PR · 预计总工作量 2-3 天

## 前置准备

```powershell
# Clone 你的 fork 到本地
cd D:\github
git clone https://github.com/TrueFurina/octop-memory.git
cd octop-memory
git remote add upstream https://github.com/TencentCloud/octop-memory.git
git fetch upstream
git checkout -b fix/memory-audit-cursor-advance upstream/main
```

---

## PR-1：octop-memory — 修复 manual-docs 审计循环

**Target**: TencentCloud/octop-memory  
**Upstream Issue**: [#28](https://github.com/TencentCloud/octop-memory/issues/28)  
**Title**: `fix(memory): advance audit cursor on uncertain reviews and dedupe same-revision documents`  
**Estimated effort**: 0.5-1 天

### 问题
manual-docs 审计遇到 `uncertain` 结论时游标不推进，导致同批文档反复进入审计队列。

### 修改点（推测，需 clone 后验证）
```python
# 1. 在审计循环中：uncertain 也推进游标，但标记
# memory/audit.py
if result.confidence < THRESHOLD:
    audit_history.append({"doc_id": doc_id, "uncertain": True, "revision_hash": doc.revision_hash})
    cursor.advance()  # ← 关键修复
else:
    cursor.advance()

# 2. ManualDocumentStore 层新增 revision 去重键
# memory/store.py
def upsert(self, doc: Document):
    key = (doc.doc_id, doc.revision_hash)
    if self.exists(key) and self.status(key) in ("extracted", "uncertain"):
        return  # 已审过，跳过
    super().upsert(doc)
```

### 提交规范
```powershell
git add memory/audit.py memory/store.py tests/
git commit -m "fix(memory): advance audit cursor on uncertain reviews

- Treat uncertain review as cursor-advancing
- Add (doc_id, revision_hash) dedupe key
- Fixes #28"
git push origin fix/memory-audit-cursor-advance
```

### PR 描述模板
```markdown
## Summary
Fixes the manual-docs audit loop getting stuck on `uncertain` reviews.

## Changes
1. Advance cursor on uncertain results instead of re-scanning same documents
2. Deduplicate same-revision documents in ManualDocumentStore

## Related
Closes #28

## Test Plan
- [ ] Audit loop terminates correctly with uncertain documents
- [ ] Same revision document skipped on re-extract
- [ ] Cursor position persisted across sessions
```

---

## PR-2：Octop 主仓库 — good first issue 标签 + 贡献指南

**Target**: TencentCloud/Octop  
**Upstream Issues**: 239 条 open issues，0 条 `good first issue`  
**Title**: `docs: add good-first-issue taxonomy and CONTRIBUTING checklist`  
**Estimated effort**: 0.5 天（纯文档 + label 操作）

### 步骤
1. 在 GitHub 上打开 https://github.com/TencentCloud/Octop/issues?q=label%3Aenhancement
2. 筛选 5-8 条低复杂度 enhancement（单函数改动、有明确测试）
3. 对每条 issue 执行 `label:good-first-issue`
4. 提 PR 更新 CONTRIBUTING.md，加新人 checklist

### Checklist 内容建议
```markdown
## First-time Contributor Checklist

- [ ] Fork the repo, clone locally, add upstream remote
- [ ] Create branch from `main`: `git checkout -b feat/my-change upstream/main`
- [ ] Run `ruff check .` and `ruff format .` before commit
- [ ] Add/update tests — pytest baseline constraints (#1933)
- [ ] PR description must include `Closes #NNN`
- [ ] Use Conventional Commits format (feat/fix/docs/refactor)
- [ ] Keep PR < 500 lines — split large changes
```

---

## PR-3：octop-harness — Codex Responses API 超时链

**Target**: TencentCloud/octop-harness  
**Upstream Issue**: [#106](https://github.com/TencentCloud/octop-harness/issues/106)  
**Title**: `fix(llm): adaptive timeout ladder and exponential backoff for Responses API`  
**Estimated effort**: 1-2 天

### 修改思路（参考 SecAutoMind 的 openai.go 适配逻辑）
```go
// providers/codex.go 或类似位置
type TimeoutLadder struct {
    Fast   time.Duration  // 10s — normal response
    Medium time.Duration  // 30s — thinking
    Slow   time.Duration  // 60s — complex task
}

func (t *TimeoutLadder) Adapt(lastLatency time.Duration) time.Duration {
    if lastLatency > 45*time.Second { return t.Slow }
    if lastLatency > 15*time.Second { return t.Medium }
    return t.Fast
}

func (c *CodexClient) Fallback(ctx context.Context, req *Request) (*Response, error) {
    // 先试 Responses API，失败自动回退 Chat Completions
    resp, err := c.ResponsesAPI(ctx, req)
    if err != nil && IsCodexCompatError(err) {
        return c.ChatCompletions(ctx, req.ToChatFormat())
    }
    return resp, err
}
```

---

## PR-4：Octop 主仓库 — DeepSeek/Yuanbao Search 中文文档

**Target**: TencentCloud/Octop  
**Upstream Issues**: [#2180](https://github.com/TencentCloud/Octop/issues/2180) (DeepSeek Search) · [#2275](https://github.com/TencentCloud/Octop/issues/2275) (Yuanbao Search)  
**Title**: `docs: add .env.example and zh-CN docs for DeepSeek/Yuanbao Search`  
**Estimated effort**: 0.25 天

### 检查项
- `.env.example` 是否有 `DEEPSEEK_SEARCH_API_KEY=` 模板？
- `docs/README.zh-CN.md` 是否有中文配置说明？
- 两者都缺 → 提 PR 补齐

---

## PR-5：Octop 主仓库 — PR Body 自动校验

**Target**: TencentCloud/Octop  
**Title**: `ci: auto-check PR body for linked issue reference`  
**Estimated effort**: 0.25 天

### GitHub Actions YAML
```yaml
# .github/workflows/pr-check.yml
name: PR Checklist
on: [pull_request_target]
jobs:
  check:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/github-script@v7
        with:
          script: |
            const body = context.payload.pull_request.body || "";
            const hasIssue = /(Closes|Refs|Fixes)\s+#\d+/.test(body);
            if (!hasIssue) {
              await github.rest.issues.addLabels({
                owner: context.repo.owner,
                repo: context.repo.repo,
                issue_number: context.issue.number,
                labels: ["needs-issue"]
              });
            }
```

---

## 推荐执行顺序

```
Week 1:
  Day 1-2: PR-2 (good-first-issue labels + CONTRIBUTING)
  Day 3-4: PR-1 (octop-memory cursor fix)
  Day 5:   Open PRs, start clone + verify code for PR-3

Week 2:
  Day 1-2: PR-3 (timeout ladder)
  Day 3:   PR-4 (docs)
  Day 4:   PR-5 (PR check CI)
```

---

## 关键提醒

1. **不要同时做多个 PR** — 一个被合并后再开下一个，避免冲突
2. **Octop 维护者看 PR #2109 的 commit 历史** — 他们自己在用 Conventional Commits 和 PR guidelines，所以你的 PR 必须严格遵守
3. **Octop 主仓库 open issues 中 0 条 good-first-issue** — 你做 PR-2 相当于成为第一个帮忙做社区治理的贡献者，维护者大概率会快速合并
4. **ctf-agent 上游已基本归档** — 放弃，不投入任何精力
