"""按分诊结果关闭 open PR —— 默认 dry-run，绝不批量静默执行。

用法：
    python close_prs.py list                       # 列出分诊表里"建议关闭"的全部
    python close_prs.py close octop#2170           # 试运行：打印将要做什么
    python close_prs.py close octop#2170 --yes     # 真的关闭（会附一条结论评论）
    python close_prs.py close owner/repo#123 --yes

安全约束：
  * 没有 --yes 一律不写远端；
  * 保留名单（psutil / attrs / kubeflow / unstructured / Octop 近期修复）里的 PR 拒绝关闭；
  * 每次必须显式点名，不支持 all / --force 之类的批量开关。
"""

import argparse
import json
import os
import sys
import urllib.request

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, r"D:/github/github-audit")
from ghlib import api, HEADERS  # noqa: E402

ROWS = os.path.join(HERE, "pr_rows.json")

# 明确不让关的：有真实技术含量、还在活跃窗口
PROTECTED = {
    ("giampaolo/psutil", 2989), ("giampaolo/psutil", 2990),
    ("python-attrs/attrs", 1616), ("python-attrs/attrs", 1618),
    ("kubeflow/testing", 1072),
    ("Unstructured-IO/unstructured", 4462), ("Unstructured-IO/unstructured", 4464),
    ("TencentCloud/Octop", 2474), ("TencentCloud/Octop", 2375),
    ("TencentCloud/Octop", 2376), ("TencentCloud/octop-harness", 116),
}

DEFAULT_COMMENT = (
    "Closing this myself: the change is either superseded by later commits, "
    "or was a batch-scan template without a minimal reproduction. "
    "Happy to reopen with a repro script and platform output matrix if it is still relevant.\n\n"
    "（自主关闭：内容已被后续改动覆盖，或属缺少最小复现的批量改动。若仍相关，欢迎补复现后重开。）"
)


def _req(method, path, body=None):
    req = urllib.request.Request(
        "https://api.github.com" + path,
        data=json.dumps(body).encode("utf-8") if body else None,
        headers={**HEADERS, "Content-Type": "application/json"}, method=method)
    try:
        with urllib.request.urlopen(req, timeout=60) as r:
            return json.loads(r.read() or b"{}")
    except Exception as e:  # noqa: BLE001
        detail = getattr(e, "read", lambda: b"")()
        return {"__error": str(e), "detail": detail.decode("utf-8", "ignore")[:200]}


def load_rows():
    if not os.path.exists(ROWS):
        print("缺少 pr_rows.json，先跑 week3 的分诊脚本")
        return []
    with open(ROWS, encoding="utf-8") as f:
        return json.load(f)


def parse_target(s):
    """octop#2170 / tencentcloud/octop#2170 / Shorthand 别名 → (repo, num)"""
    alias = {"octop": "TencentCloud/Octop", "harness": "TencentCloud/octop-harness",
             "memory": "TencentCloud/octop-memory"}
    if "#" not in s:
        raise SystemExit(f"格式应为 owner/repo#123，收到：{s}")
    repo, num = s.rsplit("#", 1)
    repo = alias.get(repo.lower(), repo)
    return repo, int(num)


def cmd_list():
    rows = load_rows()
    todo = [r for r in rows if r["action"] == "关闭"]
    todo.sort(key=lambda r: -r["idle"])
    print(f"分诊表建议关闭：{len(todo)} 个\n")
    for r in todo:
        flag = "  [受保护，跳过]" if (r["repo"], r["num"]) in PROTECTED else ""
        print(f"  {r['repo']}#{r['num']:<6} idle={r['idle']:>3}d  {r['title'][:60]}{flag}")
    print("\n关闭示例： python close_prs.py close octop#2170 --yes")


def cmd_close(target, comment, yes):
    repo, num = parse_target(target)
    if (repo, num) in PROTECTED:
        print(f"拒绝：{repo}#{num} 在保护名单里（有真实技术含量，应补复现而非关闭）")
        return 1

    info = api(f"/repos/{repo}/pulls/{num}")
    if "__error" in info:
        print(f"读不到 {repo}#{num}：{info}")
        return 1
    print(f"[目标] {repo}#{num}  state={info['state']}  title={info['title'][:70]}")
    if info["state"] != "open":
        print("已经是关闭状态，跳过")
        return 0

    if not yes:
        print("\n[试运行] 将执行：")
        print(f"   1) POST /repos/{repo}/issues/{num}/comments  （一条结论评论）")
        print(f"   2) PATCH /repos/{repo}/pulls/{num}  {{'state':'closed'}}")
        print("\n确认后加 --yes 重跑。")
        return 0

    c = _req("POST", f"/repos/{repo}/issues/{num}/comments", {"body": comment})
    if c.get("__error"):
        print("评论失败:", c["__error"], c.get("detail", "")[:150])
        return 1
    r = _req("PATCH", f"/repos/{repo}/pulls/{num}", {"state": "closed"})
    if r.get("__error"):
        print("关闭失败:", r["__error"], r.get("detail", "")[:150])
        return 1
    print("已关闭:", r.get("html_url"))
    return 0


def main():
    ap = argparse.ArgumentParser()
    sub = ap.add_subparsers(dest="cmd", required=True)
    sub.add_parser("list")
    p = sub.add_parser("close")
    p.add_argument("target")
    p.add_argument("--yes", action="store_true")
    p.add_argument("--comment", default=DEFAULT_COMMENT)
    a = ap.parse_args()
    if a.cmd == "list":
        return cmd_list()
    return cmd_close(a.target, a.comment, a.yes)


if __name__ == "__main__":
    sys.exit(main())
