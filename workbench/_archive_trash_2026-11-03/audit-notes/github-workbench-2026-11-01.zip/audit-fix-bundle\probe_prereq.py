import base64
import json
import sys

sys.path.insert(0, r"D:/github/github-audit")
from ghlib import api, OWNER  # noqa: E402

print("== upstream pikachu license ==")
for full in ("xianzhi-2017/pikachu", "xianzhi-2017/Pikachu"):
    r = api(f"/repos/{full}")
    if isinstance(r, dict) and "__error" not in r:
        lic = r.get("license")
        print(full, "->", (lic or {}).get("spdx_id"), "|", (lic or {}).get("name"),
              "| stars", r.get("stargazers_count"), "| fork", r.get("fork"))
        break
    print(full, "->", r)

print("\n== MARS-408 .gitignore (head) ==")
r = api(f"/repos/{OWNER}/MARS-408/contents/.gitignore")
if isinstance(r, dict) and r.get("content"):
    txt = base64.b64decode(r["content"]).decode("utf-8", "ignore")
    print("sha:", r["sha"], "len:", len(txt))
    print(txt[:1200])
    print("... env mentions:", [l for l in txt.splitlines() if "env" in l.lower()][:10])

print("\n== MARS-408 .env.test ==")
r = api(f"/repos/{OWNER}/MARS-408/contents/py-server/iq_run_tmp/.env.test")
if isinstance(r, dict) and r.get("content"):
    txt = base64.b64decode(r["content"]).decode("utf-8", "ignore")
    print("sha:", r["sha"], "len:", len(txt))
    for line in txt.splitlines():
        k = line.split("=")[0]
        print("  ", k + "=<redacted>" if "=" in line else line)

print("\n== secret scanning state ==")
for repo in ("SecAutoMind-src", "xihu-sword-ctf-agent", "aerorider-delivery", "win-appx-doctor"):
    info = api(f"/repos/{OWNER}/{repo}")
    sa = (info.get("security_and_analysis") or {}) if isinstance(info, dict) else {}
    print(f"{repo:26}", {k: v.get("status") for k, v in sa.items()})
