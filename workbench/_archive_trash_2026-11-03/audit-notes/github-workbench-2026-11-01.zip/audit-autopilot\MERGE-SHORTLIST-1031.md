# 可合并清单 · 最老 25 个

生成时间：2026-10-31 00:26 ｜ 依据 `mergeable=true`（无冲突），按创建时间从老到新
队列共 224 个本人 open PR，其中 `mergeable=true` 221 个。

> 判断依据：`mergeable=true` 表示与 base 无冲突。这三个仓的 `mergeable_state=unstable`
> 是因为**没有任何 commit status**（GitHub 默认报 pending），不是检查失败。

| # | 仓库 | PR | 标题 | 规模 | 年龄 | 评论 |
|---:|---|---|---|---|---:|---:|
| 1 | Octop | [#2170](https://github.com/TencentCloud/Octop/pull/2170) | docs: complete the ~/.octop layout tree and note the wizard pass | +13/−0 | 13d | 3 |
| 2 | octop-harness | [#83](https://github.com/TencentCloud/octop-harness/pull/83) | feat(tool_guard): detect Windows and PowerShell attack commands | +199/−1 | 13d | 3 |
| 3 | Octop | [#2376](https://github.com/TencentCloud/Octop/pull/2376) | fix(utils): bound download filename by UTF-8 bytes to avoid over | +77/−1 | 8d | 1 |
| 4 | Octop | [#2372](https://github.com/TencentCloud/Octop/pull/2372) | fix(env): 未闭合引号不再吞掉 ~/.octop/env 后续变量 (#2269) | +57/−6 | 8d | 1 |
| 5 | Octop | [#2371](https://github.com/TencentCloud/Octop/pull/2371) | fix(cli): 跨文件系统导出备份不再因 EXDEV 失败 (#2321) | +156/−1 | 8d | 1 |
| 6 | Octop | [#2369](https://github.com/TencentCloud/Octop/pull/2369) | docs: fix wizard password path in .env.example (post-#2174) | +1/−1 | 8d | 1 |
| 7 | octop-memory | [#29](https://github.com/TencentCloud/octop-memory/pull/29) | fix(memory): batch extraction and persist the extracted cursor ( | +348/−12 | 6d | 2 |
| 8 | octop-memory | [#30](https://github.com/TencentCloud/octop-memory/pull/30) | fix(storage): honor rejected candidates when deduplicating re-sc | +38/−13 | 5d | 1 |
| 9 | Octop | [#2495](https://github.com/TencentCloud/Octop/pull/2495) | fix(oauth): preserve existing query params on authorization_endp | +9/−2 | 3d | 0 |
| 10 | Octop | [#2494](https://github.com/TencentCloud/Octop/pull/2494) | fix(grep_safety): search only target file path, not parent dir s | +3/−0 | 3d | 0 |
| 11 | Octop | [#2493](https://github.com/TencentCloud/Octop/pull/2493) | fix(manager): guarantee non-NULL icon_url/color on agent create | +24/−0 | 3d | 0 |
| 12 | Octop | [#2489](https://github.com/TencentCloud/Octop/pull/2489) | fix(cron): auto-approve HITL so unattended scheduled runs do not | +94/−20 | 3d | 0 |
| 13 | Octop | [#2488](https://github.com/TencentCloud/Octop/pull/2488) | fix(backup): exclude SQLite sidecar files from workspace archive | +28/−0 | 3d | 0 |
| 14 | Octop | [#2487](https://github.com/TencentCloud/Octop/pull/2487) | fix(db): safely deserialize legacy TEXT credential_blob rows | +67/−5 | 3d | 0 |
| 15 | Octop | [#2486](https://github.com/TencentCloud/Octop/pull/2486) | fix: artifact path result-first + CLI agent persona defaults | +30/−6 | 3d | 0 |
| 16 | Octop | [#2485](https://github.com/TencentCloud/Octop/pull/2485) | fix(cli): make octop init --force safe - backup instead of delet | +76/−41 | 3d | 0 |
| 17 | Octop | [#2484](https://github.com/TencentCloud/Octop/pull/2484) | Fix active-turn flag leak with TTL-based stale eviction (issue # | +51/−4 | 3d | 0 |
| 18 | Octop | [#2483](https://github.com/TencentCloud/Octop/pull/2483) | fix(cron): preserve interval deadline on metadata-only PATCH edi | +31/−5 | 3d | 0 |
| 19 | Octop | [#2482](https://github.com/TencentCloud/Octop/pull/2482) | fix(agent): resolve icon_url/color from template for CLI-created | +31/−8 | 3d | 0 |
| 20 | Octop | [#2481](https://github.com/TencentCloud/Octop/pull/2481) | fix(cli): gracefully handle missing bundled plugin catalog in in | +31/−5 | 3d | 0 |
| 21 | Octop | [#2480](https://github.com/TencentCloud/Octop/pull/2480) | fix(thread-artifacts): prefer tool result path over request args | +12/−6 | 3d | 0 |
| 22 | octop-harness | [#132](https://github.com/TencentCloud/octop-harness/pull/132) | fix(session_header): catch ValueError on ContextVar reset across | +7/−1 | 3d | 0 |
| 23 | octop-harness | [#129](https://github.com/TencentCloud/octop-harness/pull/129) | fix(docker): preserve leading dots in relative paths (issue #45) | +9/−2 | 3d | 0 |
| 24 | octop-harness | [#128](https://github.com/TencentCloud/octop-harness/pull/128) | fix(tool_guard): add Windows PowerShell attack detection rules | +133/−1 | 3d | 0 |
| 25 | octop-harness | [#127](https://github.com/TencentCloud/octop-harness/pull/127) | fix(runtime): treat a non-UTF-8 workspace .env as unreadable | +5/−1 | 3d | 0 |

## 有讨论，先读再合（不在这批「无脑合」的范围）

| PR | 评论 | 为什么要先读 |
|---|---:|---|
| [#2170](https://github.com/TencentCloud/Octop/pull/2170) （Octop） | 3 | 维护者在等回复/正在复核 |
| [#83](https://github.com/TencentCloud/octop-harness/pull/83) （octop-harness） | 3 | 维护者在等回复/正在复核 |
| [#29](https://github.com/TencentCloud/octop-memory/pull/29) （octop-memory） | 2 | Bosheng0422 正在复核 P1 补丁（head 86f0308），等他表态 |

## 分布

Octop 18 个 · octop-harness 5 个 · octop-memory 2 个

## 怎么用

1. 从第 1 条开始，逐条点开 → 看 diff 是否符合标题 → 点 Merge。
2. 遇到标题与 diff 不符的，**跳过并记下来**，不要因为「反正没有冲突」就合。
3. 批量合并可用 `python autopilot/merge_prs.py <编号...> --yes`（默认 dry-run，
   会先校验 `mergeable=true`，不合格的直接拒绝）。

> 本文件只读生成：没有合并、没有评论。
