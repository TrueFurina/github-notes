import json, subprocess, time, urllib.request, http.client, re

TOKEN = subprocess.run(["powershell","-NoProfile","-Command",
    "[Environment]::GetEnvironmentVariable('GITHUB_TOKEN','User')"],
    capture_output=True, text=True).stdout.strip()
H = {"Authorization":"Bearer "+TOKEN,"User-Agent":"raccoon","Accept":"application/vnd.github+json","Connection":"close"}

def req(url, head_only=False):
    for i in range(3):
        try:
            r = urllib.request.Request(url, headers=H, method="HEAD" if head_only else "GET")
            with urllib.request.urlopen(r, timeout=40) as resp:
                link = resp.headers.get("Link","")
                if head_only: return {"link":link}
                parts=[]
                try:
                    while True:
                        b=resp.read(16384)
                        if not b: break
                        parts.append(b)
                except http.client.IncompleteRead as e:
                    parts.append(e.partial)
                body=b"".join(parts)
                try: return {"data":json.loads(body),"link":link}
                except Exception: return {"data":None,"link":link}
        except Exception as e:
            if i==2: return {"err":repr(e)[:70]}
            time.sleep(2)

d=json.load(open("raw.json",encoding="utf-8"))
own=[r for r in d["repos"] if not r.get("fork")]
targets=[r for r in own if r["stargazers_count"]>=3 or r["size"]>20000]
out={}
for r in targets:
    name=r["name"]; full=r["full_name"]
    c=req(f"https://api.github.com/repos/{full}/contents/")
    files=[x["name"] for x in (c.get("data") or [])] if isinstance(c.get("data"),list) else []
    # commit count via Link last page
    cm=req(f"https://api.github.com/repos/{full}/commits?per_page=1", head_only=False)
    link=cm.get("link","")
    cnt=None
    m=re.search(r'[?&]page=(\d+)>; rel="last"', link)
    if m: cnt=int(m.group(1))
    elif isinstance(cm.get("data"),list) and cm["data"]: cnt=len(cm["data"])
    out[name]={"files":files,"commits":cnt,"stars":r["stargazers_count"],"size":r["size"]}
    print(f'{name[:32]:34s} commits={str(cnt):>5s} files={len(files):2d} :: {", ".join(files[:18])}', flush=True)

json.dump(out, open("probe.json","w",encoding="utf-8"), ensure_ascii=False, indent=1)
