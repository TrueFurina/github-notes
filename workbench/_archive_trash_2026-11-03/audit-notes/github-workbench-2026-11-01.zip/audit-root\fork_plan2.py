import json, collections

forks = json.load(open("forks.json", encoding="utf-8"))
ext = json.load(open("ext_prs.json", encoding="utf-8"))
prs_all = json.load(open("contrib.json", encoding="utf-8"))["prs"]

def fn(p): return p["repository_url"].split("/repos/")[-1].lower()
def merged(p): return bool(p.get("pull_request",{}).get("merged_at"))

# 按上游仓库聚合 PR 状态（外部 + 本仓）
status = collections.defaultdict(lambda: {"open":0,"merged":0,"closed":0})
for p in ext + prs_all:
    r = fn(p)
    if merged(p): status[r]["merged"] += 1
    elif p["state"] == "open": status[r]["open"] += 1
    else: status[r]["closed"] += 1

keep, drop = [], []
for f in forks:
    up = (f["upstream"] or "").lower()
    s = status.get(up)
    if s and s["open"] > 0:
        f["why"] = f'open={s["open"]} merged={s["merged"]} closed={s["closed"]}'
        keep.append(f)
    else:
        f["why"] = f'no-open-PR merged={s["merged"] if s else 0} closed={s["closed"] if s else 0}'
        drop.append(f)

print(f"KEEP (有未关闭 PR) = {len(keep)}")
for f in sorted(keep, key=lambda x: -x["size_kb"]):
    print(f'  {f["size_kb"]/1024:7.0f}MB {f["upstream"]:44s} *{f["up_stars"]:6d}  {f["why"]}')

print(f"\nDROP = {len(drop)}  释放 {sum(x['size_kb'] for x in drop)/1e6:.2f} GB")
print("\n=== DROP 中体积最大 25 个 ===")
for f in sorted(drop, key=lambda x: -x["size_kb"])[:25]:
    print(f'  {f["size_kb"]/1024:7.0f}MB {f["name"]:32s} <- {f["upstream"]:42s} *{f["up_stars"]}')

json.dump({"keep":keep,"drop":drop}, open("fork_plan2.json","w",encoding="utf-8"), ensure_ascii=False, indent=1)

# 输出可直接执行的删除命令
with open("delete_forks.sh","w",encoding="utf-8") as fh:
    fh.write("#!/usr/bin/env bash\n# 删除无未关闭 PR 的 fork；PR 记录不受影响\n")
    fh.write('TOKEN=$(powershell -NoProfile -Command "[Environment]::GetEnvironmentVariable(\'GITHUB_TOKEN\',\'User\')")\n')
    fh.write('set -u\n')
    for f in sorted(drop, key=lambda x: -x["size_kb"]):
        fh.write(f'curl -s -X DELETE -H "Authorization: Bearer $TOKEN" -H "Accept: application/vnd.github+json" '
                 f'-o /dev/null -w "{f["name"]}: %{{http_code}}\\n" https://api.github.com/repos/TrueFurina/{f["name"]}\n')
print("\n已生成 delete_forks.sh")