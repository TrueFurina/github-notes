# TrueFurina 开源协作分析（Collaboration Audit）

- 账号：`TrueFurina`（Dream，DBAPPSecurity，Python / LLM-Agent / 安全方向，2025-04 注册）
- 采集时间：2026-10-28；数据源：GitHub REST API（`/search/issues`、`/search/issues?commenter:`、`/pulls/{n}`、`/orgs/*`）
- 采集口径：`per_page=30` 逐页翻取（本机代理会截断 >500KB 响应）；PR 全集 27 页、评论页 5 页，均无缺页
- 数据集：`_collab_all_prs.json`（802 条 PR）、`_collab_pr_details.json`（20 个重点 PR 详情）、`_collab_comments.json`（64 个外部议题评论线程）、`_collab_orgs.json`

---

## 一、PR 全量统计（含已合并 / 已关闭 / 仍开启）

`GET /search/issues?q=author:TrueFurina+type:pr` → `total_count = 802`，全部 802 条已落库。

### 1.1 总览

| 口径 | PR 数 | merged | 合并率 | open | 关闭未合并 |
|---|---:|---:|---:|---:|---:|
| **合计** | **802** | **643** | **80.2%** | 61 | 98 |
| 目标为 TrueFurina 自有仓库 | 602 | 588 | **97.7%** | 3 | 11 |
| 目标为外部组织/个人仓库 | 200 | 55 | **27.5%** | 58 | 87 |

> 80.2% 的总合并率是**假象**：602 个自有仓库 PR 里 588 个是本人自审自合（97.7%），其中 426 个集中在 `TrueFurina/TrueFurina` 一个仓库，标题清一色 `docs: pull-shark progress entry 441/442/…`——这是为拿 Pull Shark 徽章做的自合并流水线（2026-09 单月 426 个）。剔除后，真实对外合并率是 **27.5%**。

### 1.2 自有仓库分布（"自刷"部分）

| 仓库 | PR 数 | merged | 说明 |
|---|---:|---:|---|
| TrueFurina/TrueFurina | 426 | 426 | Pull Shark 徽章打卡，全自动自合 |
| TrueFurina/SecAutoMind-src | 74 | 71 | 主项目（LLM 安全 Agent），自审自合 |
| TrueFurina/MARS-408 | 38 | 37 | 自研项目 |
| TrueFurina/xihu-sword-ctf-agent | 25 | 25 | CTF Agent，自审自合 |
| TrueFurina/passive-recon | 17 | 16 | OSINT 工具 |
| TrueFurina/MangDeHenZhi | 16 | 12 | 依赖升级（dependabot 类） |
| 其余（CodeGraphContext fork、rich fork 等） | 6 | 1 | fork 同步 |

### 1.3 外部仓库分布（Top 15，格式：merged / 提交数）

| 仓库 | merged/提交 | 备注 |
|---|---|---|
| TencentCloud/Octop | **0 / 8** | 10 月集中投入，全部未合并（1 个被 close） |
| smicallef/spiderfoot | 0 / 7 | 8 月批量，全部被关（含 XSS/SQL 参数化 3 个） |
| agno-agi/agno | 0 / 6 | 与 #9822 重复，被 triage bot 标记缺测试 |
| CodeGraphContext/CodeGraphContext | **4 / 5** | 唯一高合并率的外部主战场，assoc=CONTRIBUTOR |
| abhisekp/Practice-Modern-JavaScript | 0 / 5 | 教学仓库刷 docs |
| fastapi/fastapi | 0 / 5 | 被维护者警告（见 §3） |
| Create-Vlang-App/create-vlang-app | **4 / 4** | 全合并，均为 docs/脚手架 |
| sqlalchemy/sqlalchemy | 0 / 4 | 4 个 SQLite/MSSQL 反射修复全被关 |
| OWASP/Nettacker | 0 / 4 | bare-except 批量 |
| MARL-ECDSA-Consensus（自建组织） | 2 / 3 | 自建组织内自合 |
| Unstructured-IO/unstructured | 1 / 3 | #4463 被 maintainer approve 并合并 |
| TencentCloud/octop-harness | 0 / 3 | tool_guard Windows 规则，仍 open |
| verialabs/ctf-agent | 0 / 3 | 3 个重构/特性 PR 全 open |
| TencentCloud/octop-memory | 0 / 2 | open |
| 其他 ~125 个仓库 | 各 0–1 | 长尾 |

- 外部 PR 覆盖 **140 个仓库**，其中 **46 个** 至少合并过 1 个。
- 时间分布：2026-07 3 个、**2026-08 152 个**、2026-09 27 个、2026-10 18 个。
- 批量峰值：**08-27 单日 57 个、08-28 46 个、08-13 18 个、08-14 11 个**。

### 1.4 类型与合并率（判断"真实贡献 vs 刷记录"的关键）

| 类型 | 数量 | merged | 合并率 |
|---|---:|---:|---:|
| `fix: replace bare except with except Exception` 同一模板（跨 20+ 仓库） | 24 | 3 | **12.5%** |
| docs / test / ci / chore / i18n / refactor 类 | 77 | 30 | 39.0% |
| fix / feat / security / perf 类 | 117 | 25 | 21.4% |

**结论（任务 1 判定）：两者都有，但结构上是"刷量为主、真实贡献为辅"。**

1. **刷记录证据确凿**：426 个 `pull-shark progress entry` 自合并；自建组织仓库 `MARL-ECDSA-Consensus` 里 2 个 PR 挂着 `author_association=MEMBER`（该组织仅本人 1 名成员，等于自己给自己发 member 身份）；8 月 152 个外部 PR 中大量是同一模板的机械替换（20 余仓库同一天提同一句 `bare except`，合并率 12.5%），且 `agno#9837`（+158/−138）、`jinja#2250`（+256/−256）出现整文件重写式 diff——典型的批量改写而非定点修复。
2. **真实贡献也确实存在，且集中在 2026-09 之后**：`unicode-rs/unicode-segmentation`、`seanmonstar/reqwest`、`Unstructured-IO/unstructured`、`CodeGraphContext`（4/5 合并）、`kubeflow/testing`（维护者逐条 review）、`TencentCloud/Octop`（issue 驱动 upstream 修复）。这批 PR 的特征是：单仓库、带复现/测试、追 review、diff 收敛（+27/−5、+1/−1、+33/−4）。
3. 换算成"可信简历口径"：对外**有效上游合并约 15–20 个**（剔除 docs 拼写、教学仓库、自建组织），其中能经受追问的硬证据是下面 5 个。

---

## 二、最有价值的上游贡献（简历级证据）

| # | PR | 改动内容 | 状态 | 对方评价 / 证据强度 |
|---|---|---|---|---|
| 1 | **unicode-rs/unicode-segmentation #183** | `GraphemeCursor` 公共 API 三处 panic 修复：越界 `offset`/`chunk_start` 的切片、`prev_chunk` 反向迭代下溢、pre-context 分块校验（+27/−5，1 文件）。源自 fuzz issue #170 | ✅ merged 2026-10-08 | 维护者 **Manishearth**（rust-analyzer 作者）先要求 `cargo fmt`，修好后 **APPROVED**：「GitHub Actions was being buggy but it finally worked. Thanks!」。**最强证据：Rust 核心生态 crate + 顶级维护者人工批准** |
| 2 | **CodeGraphContext/CodeGraphContext #1676** | 给 Cassandra / MySQL 数据源 ingestor 加 SSL 连接参数（`ssl_verify`、`ssl_ca_certs`，CERT_REQUIRED + 主机名校验，默认关闭不影响旧配置），+1214/−315，25 文件 | ✅ merged 2026-09-02 | 维护者 **Shashankss1205**：*"Verified on a local trial-merge. The security posture is right: SSL stays opt-in (no behavior change), and when enabled it demands full verification"*。同仓库另有 #1695/#1698/#1758 共 **4 个 merged**，assoc 升为 `CONTRIBUTOR` |
| 3 | **TencentCloud/Octop #2171 → #2174** | 我提 issue：`OCTOP_HOME` 不迁移向导密码文件（写死在 `~/octop-login.txt`），并**逐行指出 4 处需要同步修改的集成测试**（`test_setup_wizard.py:29/69/80/85`）；维护者据此提交 #2174 修复，我又 review 该 PR 指出漏改 `CHANGELOG.md` | ✅ #2174 merged 2026-10-19 | 维护者 **jubaoliang**（COLLABORATOR）：*"Looks merge-ready for #2171"*；changelog 条目显式署名 `（#2171）`。**这是"影响力大于代码量"的最佳案例：issue 直接驱动上游合并** |
| 4 | **seanmonstar/reqwest #3100** | 把 `base64` 依赖改为 `default-features = false, features = ["std"]`，去掉 `simd-unsafe` 默认特性 → crate 恢复 `#![forbid(unsafe_code)]`（+1/−1） | ✅ merged 2026-09-14 | **seanmonstar**（reqwest 作者本人）**APPROVED**。改动极小但方向精准，属于"能读懂依赖安全边界"的信号 |
| 5 | **Unstructured-IO/unstructured #4463** | `Text` 元素在 `None` 文本时归一化为空串，修 `TypeError`（+33/−4，4 文件，含测试） | ✅ merged 2026-10-13 | 维护者 **cragwolfe** **APPROVED**。高星文档解析项目，行为兼容性说明写得规范 |

**候补（过程价值高但未合并）**：`kubeflow/testing #1072`（Kind 集群 composite action，9 条评论/6 次 review，维护者 `juliusvonkohout` 连续要求修 DCO、rebase，均已逐条响应并收敛到 +45/−0；仍 open，属"进行中的真实协作"，可写"in review"但要如实标注）。

---

## 三、协作行为中的声誉风险（必须知道的负面证据）

| 事件 | 事实 | 影响 |
|---|---|---|
| `pallets/jinja #2250` | 维护者 **davidism** 只回了一个链接：`https://palletsprojects.com/contributing/llm-ai`，PR 关闭 | Pallets 全线（flask/click/jinja）AI 政策封口 |
| `fastapi/fastapi` 5 个 PR | 维护者 **YuriiMotov**：*"Duplicate of #14883 … @TrueFurina, please stop or you will be banned"* | 已被点名警告，继续提会被 ban |
| `getzola/zola #3282` | 通用话术 "Friendly ping — happy to address any remaining feedback" → **Keats** 回 *"Did you see my comment above?"*；最终 Keats 直接贴 `CONTRIBUTING.md#L38-L39`（"LLM usage is not accepted for the documentation … use your own words in issues/PR"）后关闭 | 提问未答先催更 = 典型 AI 工作流痕迹 |
| `CTFd/CTFd #2889` | 我在维护者讨论串里补了一大段结构化论证，**ColdHeat**（maintainer）：*"If you're going to vibe the discussion, you can vibe your own solution."* | 在别人的 issue 里"代 PR 作者发言"被视为 AI 灌水 |
| `CodeGraphContext #1758` | 合并后维护者更正：*"the full diff includes native-backend probes, Haskell tests and a Ladybug-only allowance for up to 64 missing CONTAINS edges, beyond the dependency changes described in the PR body. I checked only the dependency diff before merging and missed the tolerance."* | PR 描述与实际 diff 不一致（夹带），消耗信任 |
| `TencentCloud/Octop #2170 / #2369` | 纯 docs PR，两次 @ 维护者 "gentle ping"，零回复；#2170 的内容随后被 #2174 的合并推翻 | 低价值 docs PR + 催更，边际收益为负 |
| 评论质量 | 64 个外部线程中 **18 个**我的评论总量 ≤120 字符（多为 "Thanks, fixed in …"），16 个 ≥1000 字符 | 两极分化：要么一句话，要么长文 |
| `kubeflow/testing #1072` | 评论中出现 `您好，来件已收到。谢谢！`（邮件自动回复被粘进 PR） | 细节失分 |

---

## 四、IssueComment 参与深度

`GET /search/issues?q=commenter:TrueFurina` → **139 个议题**，分布在 48 个仓库。

| 维度 | 数值 |
|---|---:|
| 评论过的议题总数 | 139 |
| 其中自有仓库（MARS-408 31 / MangDeHenZhi 24 / xihu 16 / passive-recon 3 / SecAutoMind 1） | 75 |
| 外部仓库议题 | 64 |
| 外部议题中**由他人发起**的（真正的"进别人讨论"） | **8** |
| 外部议题中由自己 PR/issue 发起的（自问自答式跟进） | 56 |
| 他人议题中，我发言后**有维护者回复** | 4 |

**他人议题明细（全部 8 条）**

| 议题 | 我的参与 | 对方回应 |
|---|---|---|
| TencentCloud/Octop #2174 | 1 条 809 字 review，指出漏改 CHANGELOG、确认 legacy fallback 与 `O_CREAT\|O_EXCL 0o600` 正确 | ✅ jubaoliang（COLLABORATOR）triage + legend91019 采纳修改 |
| CTFd/CTFd #2889 | 1 条 1912 字，逐条回应 "插件本来就能拿到 app" 的反驳并给出 `jinja_env.globals` 对照方案 | ⚠️ ColdHeat（MEMBER）负面回应（见 §3），但**确实进入了维护者级讨论** |
| unicode-rs/unicode-segmentation #119 | 1 条 976 字，接 fuzz 报告给出 panic 分类 | 无回复（后续自己开 #183 修复并合并，闭环） |
| python-attrs/attrs #1038 | 1 条 946 字，分析 `super()` 在装饰器中的 `__class__` cell 问题 | 无回复（后续自己开 #1618 提案） |
| Textualize/rich #4214 | 2 条 2748 字，`Columns(width=)` ZeroDivisionError 复现分析 | eminsk（普通用户）跟进 |
| CTFd/CTFd #3039 / #2903 | 285 / 239 字，DB 迁移失败与 admin 404 排查 | 普通用户跟进 |
| TencentCloud/octop-memory #27 | 968 字，候选语义去重与稳定指纹设计建议 | 无回复 |

**判定**：**尚未形成"维护者级别"的常态化交流**。真实的维护者对话只有 2 处（Octop jubaoliang、CTFd ColdHeat、zola Keats 在 PR 侧），且其中 1 处是负面的。绝大多数评论是给自己的 PR 补说明（56/64），属于"自我闭环"而非"社区对话"。相比 PR 数量（802），社区讨论侧的存在感明显偏弱——这是当前最大的结构性短板。

---

## 五、两个组织是什么

| 组织 | 创建时间 | 仓库 | 成员 | 本人角色 | 实质 |
|---|---|---|---|---|---|
| **Circle1507** | 2026-07-15 | 1 个（`Project_ACT_Circle`，**private**，C# 7.85MB + ShaderLab/HLSL，364MB 体积，1 star，最后推送 2026-08-23） | 6 人：`0Reyes0`、`LightWine-61`、`Mocacy42`、`NGLSG`、`TrueFurina`、`Yumihoshi` | **member**（`/memberships/TrueFurina` → `role: member`, `state: active`, `direct_membership: true`） | 一个 6 人 Unity/C# 小组项目（游戏/仿真方向，私库）。贡献分布：Mocacy42 82、Yumihoshi 49、NGLSG 17、LightWine-61 14、**TrueFurina 1** —— 本人是**参与度最低的成员**（1 次提交） |
| **MARL-ECDSA-Consensus** | 2026-08-06 | 2 个（`MARL-ECDSA-Consensus` private，Python，13.8MB，描述 "MARL-ECDSA consensus chain: blockchain AI collaboration for multi-agent reinforcement learning (CCF competition)"；`dashboard-release` private） | **1 人（只有 TrueFurina）** | **admin**（`role: admin`, `direct_membership: true`） | **本人自建的组织**，用于承载一个 CCF 竞赛项目（多智能体强化学习 + 区块链共识）。仓库贡献者只有 TrueFurina（19 commits）。因此该组织内的 2 个 merged PR 上显示的 `MEMBER` 身份是自授的，**不构成第三方背书** |

**结论**：两个组织都不能当作"社区影响力"写进简历。Circle1507 是小组作业/竞赛协作（本人 1 commit，如实写只能写"参与"）；MARL-ECDSA-Consensus 是自建壳组织（admin），其 PR 合并率应归入"自合"而非"外部贡献"。

---

## 六、如何把现有协作行为转化为可见影响力（4 条，具体到仓库与动作）

### 1. `TencentCloud/Octop`：把"issue 驱动修复"的成打法复制成流水线，把 0/8 变成 3 个 merged
现状是 8 个 PR 全部未合并（docs 与 self-ping 拉低了维护者响应意愿），但 **issue #2171 → 维护者 MR #2174 合并、changelog 署名 #2171** 这条路已经验证可行。
动作：
- 立即把 `#2375`（MCP `tools/list` 未翻 `nextCursor`，Closes #2298）与 `wxhking` 的 `#2299` **合并为一个 PR**，在 `probe.py` 的 `_collect_mcp_tools` 上补 SSE / Streamable HTTP / stdio 三条传输的单测，PR 描述里直接引 #2299 说明"合并而非竞争"；
- 关闭 `#2170`、`#2369` 两个低价值 docs PR（内容已被 #2174 推翻），把其中真正有效的信息并入 #2371/#2372 的描述；
- 对 `#2267`（tools_disabled 未强制拦截，octop-harness #101 已关）改用 issue + 复现脚本形式重开，而不是再提"同名被关 PR 的 v2"。
量化目标：4 周内 3 个 merged / 1 个被 maintainer 采纳的 issue。

### 2. `CodeGraphContext/CodeGraphContext`：把 fork 里没回流的那一半搬上去，并修复 #1758 的信任缺口
`TrueFurina/CodeGraphContext` 有 4 个自合 PR，其中 **#3「补 Haskell parser 冒烟护栏，堵住静默产出 0 节点」至今未上游化**；而上游 #1758 被维护者在合并后指出"夹带了 64 条 CONTAINS 容差"（#1762 已回滚）。
动作：
- 把 fork #3 的 parser 护栏拆成一个**独立、单一意图**的 PR 提到 `CodeGraphContext/CodeGraphContext`，标题只讲 "test(haskell): fail loudly when parser yields 0 Class nodes"，body 里附 0 节点前后的 JSON 对比；
- 主动到 `#1762` 下认领"我这边引入的容差已移除/可复核"，把 scope creep 事件转成"自查 + 修复"的正面叙事；
- 在仓库里接 1–2 个 `good first issue` 的 review（该仓库已给到 `CONTRIBUTOR`，下一步目标是 reviewer 身份）。
量化目标：upstream 合并数 4 → 6，并获得 1 次 "reviewed by TrueFurina" 记录。

### 3. 停止跨仓库批量 PR，改为"少而深 + 复现脚本"，并清理 58 个 open PR
8 月 152 个外部 PR 里，`bare except` 模板 24 个只合了 3 个（12.5%），并已招致 `fastapi`（"please stop or you will be banned"）、`pallets/jinja`（LLM 政策）、`getzola/zola`（CONTRIBUTING L38-39）三处明确抵制。
动作：
- **冻结**：不再向 `sqlalchemy/`、`scrapy/`、`agno-agi/agno`、`OWASP/Nettacker`、`abhisekp/Practice-Modern-JavaScript` 等已关闭仓库提交新 PR；
- **清理**：对 58 个仍 open 的 PR 逐一二选一——关闭并附一句结论，或补齐测试；
- **保留并加码** 3 个还有真实技术含量的：`giampaolo/psutil #2989`（ENOTTY from ioctl）、`psutil #2990`（process_iter 复用 PID）、`python-attrs/attrs #1616/#1618`（`__class__` closure cell）——每个都补"最小复现脚本 + Linux/macOS/Windows 输出矩阵"，psutil 维护者对平台差异极敏感，这类证据决定合并与否；
- 在 `CTFd/CTFd #2889` 上用**人话**（不用模板长文）补一份最小 PoC 插件，把"vibe the discussion"的负面印象换成可验证的漏洞复现。
量化目标：open PR 从 58 降到 ≤15，外部合并率从 27.5% 提到 40%+。

### 4. 把成果做成"可点击的索引"：重写 profile 仓库，做一次公开复盘
`TrueFurina/TrueFurina` 里 426 条 `pull-shark progress entry` 是负资产——任何审核者点进来第一眼看到的就是刷徽章。
动作：
- 用一张表替换全部打卡记录：**Selected upstream contributions**，只列 5 行（unicode-segmentation #183 + Manishearth 的 APPROVED 链接、CodeGraphContext #1676、reqwest #3100、unstructured #4463、Octop #2171→#2174），每行写"改了什么 / 影响面 / 对方原话"；
- 新增一篇 `docs/upstream-log.md`（或 GitHub Discussion）：《从 issue 到 upstream fix：Octop #2171 的四层测试定位》，讲清楚怎么从"读代码"走到"维护者按我的清单改测试"，这是安全/Agent 岗位最看重的问题定位能力；
- 在 profile 里加一节"Contribution policy"：声明"不使用 LLM 生成 issue/PR 正文、单仓库优先、docs-only PR 不自荐"，把 zola/jinja/fastapi 三次踩坑转成方法论输出；
- 把 `Circle1507` 写清"6 人小组，我负责 X（1 commit 的具体内容）"，`MARL-ECDSA-Consensus` 明确标注"个人项目/竞赛，自建组织"——**主动降级比被人发现虚高更安全**。

---

## 附录：方法与可复现性

| 脚本 | 作用 |
|---|---|
| `audit_collab_1_prs.py` | 前 150 条 PR + `commenter:` 议题（含重试） |
| `audit_collab_2_allprs.py` | 27 页全量 802 条 PR（`per_page=30`，页间隔 6.5s） |
| `audit_collab_3_details.py` | 20 个重点 PR 的 `/pulls/{n}` + issue comments + reviews |
| `audit_collab_4_orgs.py` | `/orgs/*`、`/orgs/*/repos`、`/orgs/*/members`、`/orgs/*/memberships/TrueFurina` |
| `audit_collab_5_comments.py` | 64 个外部议题的评论线程，判定"我发言后是否有维护者回复" |

中间数据：`_collab_all_prs.json`、`_collab_pr_details.json`、`_collab_comments.json`、`_collab_orgs.json`（均在 `D:/github/github-audit/`，未修改任何既有文件）。

口径说明：
1. merged 判定用搜索结果中的 `pull_request.merged_at`（非空即已合并），不依赖 `state`，因此"关闭但未合并"与"已合并"可区分。
2. "自有仓库"按 `base.repo.owner.login == TrueFurina` 判定；组织仓库 `MARL-ECDSA-Consensus/*` 虽非 TrueFurina 个人名下，但组织仅本人 1 名成员（admin），单独标注，不计入"真实外部贡献"。
3. 评论深度以"他人发起的议题 + 我发言后是否有非本人回复"两个条件交叉判定，避免把自问自答算作社区对话。
