"""主页修订第二轮：去掉不可核验的统计数字，补回可点开验证的上游贡献表。

背景：
  · 另一个会话把主页改短了，同时删掉了我加的上游贡献表——那是全页唯一带维护者原话和链接的证据。
  · 新版的 Octop 统计（170+ PR / 55 merged / 87 open）与实测不符：搜索接口对 is:merged 返回 0，
    全账号 open 只有 44，而表里写 87。数字不可核验就不该上主页。
  · Featured 表里 marl-ecdsa 写 4★（实际 0★）、xuandun 写 4★（实际 3★）。

    python fix_profile2.py          # 预览
    python fix_profile2.py --yes    # 执行
"""

import argparse
import base64
import json
import sys
import urllib.request

sys.path.insert(0, r"D:/github/github-audit")
from ghlib import api, HEADERS, OWNER  # noqa: E402

STATS_HEAD = "> In ~20 days I've submitted **170+ PRs** across the Octop agent platform."
STATS_TAIL = "**Profile forks**"

NEW_INTRO = (
    "Active contributor to the Octop agent platform (CLI · harness · memory).\n"
    "I'd rather point at merged work than quote counts — the table below lists changes that were\n"
    "reviewed and merged by maintainers, with links you can click and check.\n\n"
)

CONTRIB = """## 🛠 Selected upstream contributions

只列**已被上游合并**的改动，每条都能点开核对（维护者原话在 PR 里）。

| 上游 / PR | 改了什么 | 规模 | 结果 |
|---|---|:--:|---|
| [unicode-rs/unicode-segmentation #183](https://github.com/unicode-rs/unicode-segmentation/pull/183) | `GraphemeCursor` 公共 API 的越界 panic：`offset`/`chunk_start` 切片、`prev_chunk` 反向迭代下溢、pre-context 分块校验 | +27/−5 | 维护者 **Manishearth** 要求 `cargo fmt` 后 APPROVED 并致谢 |
| [CodeGraphContext #1676](https://github.com/CodeGraphContext/CodeGraphContext/pull/1676) | 给 Cassandra / MySQL ingestor 加 SSL 连接参数（`CERT_REQUIRED` + 主机名校验，默认关闭、不影响旧配置） | +1214/−315，25 文件 | 维护者本地 trial-merge 验证后合并 |
| [TencentCloud/Octop #2171](https://github.com/TencentCloud/Octop/issues/2171) → [#2174](https://github.com/TencentCloud/Octop/pull/2174) | 报 issue：`OCTOP_HOME` 不迁移向导密码文件；逐行指出 4 处该同步修改的集成测试，维护者据此修复 | +173/−40 | 维护者 *"Looks merge-ready for #2171"*，changelog 署名 `(#2171)` |
| [seanmonstar/reqwest #3100](https://github.com/seanmonstar/reqwest/pull/3100) | `base64` 改 `default-features = false`，去掉 `simd-unsafe`，crate 恢复 `#![forbid(unsafe_code)]` | +1/−1 | 作者 **seanmonstar** 本人 APPROVED |
| [Unstructured-IO/unstructured #4463](https://github.com/Unstructured-IO/unstructured/pull/4463) | `Text` 元素在 `None` 文本时归一化为空串，修 `TypeError`（含测试） | +33/−4，4 文件 | 维护者 APPROVED |

> 我更擅长**定位**而不是堆代码：Octop 那条我没有直接改代码，而是把维护者需要同步修改的 4 处测试行号列清楚，他按清单改完就合了。

---

"""


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--yes", action="store_true")
    a = ap.parse_args()

    r = api(f"/repos/{OWNER}/TrueFurina/contents/README.md")
    text = base64.b64decode(r["content"]).decode("utf-8")
    sha = r["sha"]
    new = text

    # 1) 去掉不可核验的统计段
    if STATS_HEAD in new and STATS_TAIL in new:
        i = new.index(STATS_HEAD)
        j = new.index(STATS_TAIL)
        new = new[:i] + NEW_INTRO + new[j:]
        print("· 已移除 170+/55/87 统计表（数字不可核验，且 87 open 与实测 44 矛盾）")
    elif "I'd rather point at merged work" in new:
        print("· 统计段已是新写法，跳过")
    else:
        print("! 统计段锚点未命中")

    # 2) 补回上游贡献表
    if "Selected upstream contributions" in new:
        print("· 贡献表已存在，跳过")
    elif "## Featured Projects" in new:
        new = new.replace("## Featured Projects", CONTRIB + "## Featured Projects", 1)
        print("· 已插入 Selected upstream contributions（5 条已验证合并的 PR）")
    else:
        print("! 找不到 Featured Projects 锚点")

    # 3) 修正 Featured 星数
    fixes = [
        ("| 4 | [marl-ecdsa]", "| 0 | [marl-ecdsa]"),
        ("| 4 | [xuandun-cyber-range]", "| 3 | [xuandun-cyber-range]"),
    ]
    for old, rep in fixes:
        if old in new:
            new = new.replace(old, rep, 1)
            print(f"· 星数修正: {old.strip('| ')} → {rep.strip('| ')}")
        else:
            print(f"· 星数已是目标值或锚点未命中: {old[:28]}")

    if new == text:
        print("\n无变化")
        return 0

    if not a.yes:
        print("\n[预览] 未写入。加 --yes 执行。")
        return 0

    body = {"message": "docs(profile): drop unverifiable PR counts, restore verified contribution table\n\n"
                       "170+/55/87 这组数字与实测不符（全账号 open 仅 44，搜索接口 is:merged 返回 0），"
                       "改为可点开验证的 5 条已合并 PR；顺带把 marl-ecdsa 4→0、xuandun 4→3 两处星数改成实际值。",
            "content": base64.b64encode(new.encode()).decode(), "sha": sha, "branch": "main"}
    req = urllib.request.Request(f"https://api.github.com/repos/{OWNER}/TrueFurina/contents/README.md",
                                 data=json.dumps(body).encode("utf-8"),
                                 headers={**HEADERS, "Content-Type": "application/json"}, method="PUT")
    try:
        with urllib.request.urlopen(req, timeout=60) as resp:
            print("\ncommit:", json.loads(resp.read())["commit"]["sha"][:12])
    except Exception as e:  # noqa: BLE001
        print("\nERR", e, getattr(e, "read", lambda: b"")().decode("utf-8", "ignore")[:200])


if __name__ == "__main__":
    sys.exit(main())
