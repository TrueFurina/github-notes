import json

d = json.load(open('D:/github/_insight/candidates.json', encoding='utf-8'))
rows = [r for r in d if r.get('gfi', 0) >= 20 and not r.get('archived')]
rows.sort(key=lambda r: (-r['gfi'], -r['stars']))
for r in rows:
    print(f"{r['repo']:<42} GFI={r['gfi']:>4} HW={r.get('help_wanted', 0):>4} "
          f"30d={r['commits_30d']:>3} stars={r['stars']:>7} lic={r['license']} C={r['contributing']}")
    for t in r.get('gfi_samples', [])[:3]:
        print('    -', t)
