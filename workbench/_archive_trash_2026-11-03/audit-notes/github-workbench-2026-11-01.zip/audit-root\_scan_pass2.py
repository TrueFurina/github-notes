"""Pass 2: wider net — extra file types + unfiltered raw matches for manual triage."""
import json
import os
import re
import sys
import time

sys.path.insert(0, r"D:/github/github-audit")
import _scan_secrets as S  # noqa: E402

res = json.load(open(r"D:/github/github-audit/_scan_results.json", encoding="utf-8"))
trees = {e["repo"]: e for e in res}
blobmap = json.load(open(r"D:/github/github-audit/_scan_trees_cache.json", encoding="utf-8"))

EXTRA = re.compile(r"(docker-compose|\.ya?ml$|\.md$|\.sh$|\.ini$|\.toml$|\.cfg$|\.conf$|"
                   r"\.json$|\.txt$|\.py$|\.js$|\.ts$|\.tsx$|\.vue$|\.java$|\.go$)")
HINT = re.compile(r"(?i)(key|token|secret|passw|cred|auth|env|cookie|session|salt)")


def depth(p):
    return p.count("/")


def pick(repo, blobs, already, cap=45):
    out = []
    for b in blobs:
        p = b["path"]
        if p in already or b.get("size", 0) > 120 * 1024:
            continue
        ext = os.path.splitext(p)[1].lower()
        if ext in S.BIN_EXT or ext in (".ipynb", ".lock", ".map", ".min.js"):
            continue
        d = depth(p)
        score = 0
        if HINT.search(os.path.basename(p)):
            score += 3
        if re.match(r"(docker-compose|Dockerfile|\.env)", os.path.basename(p), re.I):
            score += 3
        if p.count("/") == 0:
            score += 2
        if ext in (".py", ".yaml", ".yml", ".json", ".sh", ".toml", ".ini", ".conf", ".txt", ".md"):
            score += 1
        if d >= 5 or p.startswith(("node_modules/", "dist/", "vendor/")):
            score -= 3
        if score >= 3:
            out.append((score, p, b.get("size", 0)))
    out.sort(key=lambda x: (-x[0], x[2]))
    return out[:cap]


def main():
    raw = []
    budget = int(os.environ.get("BUDGET", "600"))
    used = 0
    for e in res:
        repo = e["repo"]
        blobs = blobmap.get(repo, {}).get("blobs", [])
        already = {c["path"] for c in e["candidates"]}
        picks = pick(repo, blobs, already)
        scanned = 0
        for score, p, size in picks:
            if used >= budget:
                break
            text, err = S.fetch_text(repo, p, e["branch"])
            used += 1
            scanned += 1
            if text is None:
                continue
            for kind, pat in S.SECRET_PATTERNS:
                for m in re.finditer(pat, text):
                    line_no = text[:m.start()].count("\n") + 1
                    lines = text.splitlines()
                    line = lines[line_no - 1][:240] if line_no <= len(lines) else ""
                    raw.append({"repo": repo, "path": p, "kind": kind, "line": line_no,
                                "masked": S.mask(m.group(0)), "ctx": line.strip(),
                                "size": size, "ext": os.path.splitext(p)[1]})
            time.sleep(0.05)
        print(f"[{repo}] extra_scanned={scanned} raw_hits={sum(1 for r in raw if r['repo']==repo)}", flush=True)
        json.dump({"used": used, "hits": raw},
                  open(r"D:/github/github-audit/_scan_pass2.json", "w", encoding="utf-8"),
                  ensure_ascii=False, indent=1)
    print("used requests", used, "raw hits", len(raw))


if __name__ == "__main__":
    main()
