# Octop 队列的文件竞争热力图（2026-10-31 01:00）

数据来源：`autopilot/files_cache.json`（224 个 PR 的实际改动文件，由 `starter10.py` 落盘）。
**纯本地计算，没有打 API。**

## 一句话

**224 个 PR 里，168 个（75%）落在"被至少 2 个 PR 同时改"的文件上。**
单是 `manager.py` 一个文件，就有 **11 个 open PR** 在改。

## 分布

| 指标 | 数值 |
|---|---:|
| 缓存中的 open PR | 224 |
| 被 ≥2 个 PR 同时改的文件 | 78 |
| 被 ≥3 个 | 27 |
| 被 ≥5 个 | 6 |
| 落在"≥3 人争"的文件上的 PR | **101 / 224** |
| 落在"≥2 人争"的文件上的 PR | **168 / 224** |
| 若每个争用文件只合 1 个，其余需 rebase 的累计次数 | **135** |

## Top 12 争用文件

| 仓库 | 文件 | 同时在改的 PR 数 |
|---|---|---:|
| Octop | `src/octop/infra/agents/manager.py` | **11** |
| octop-harness | `src/octop_harness/agent.py` | 8 |
| octop-harness | `src/octop_harness/llm/factory.py` | 7 |
| Octop | `src/octop/infra/control/browser/setup.py` | 5 |
| Octop | `src/octop/cli/commands/init.py` | 5 |
| Octop | `src/octop/infra/cron/delivery.py` | 5 |
| Octop | `src/octop/infra/server.py` | 4 |
| Octop | `.../experts/library/cvm-cluster-doctor/skills/...` | 4 |
| Octop | `CHANGELOG.md` | 4 |
| Octop | `src/octop/cli/commands/backup.py` | 4 |
| Octop | `src/octop/infra/utils/env_file.py` | 4 |
| octop-harness | `src/octop_harness/skills/catalog.py` | 4 |

## 这解释了什么

之前我一直用"`mergeable=true` 有 221 个"来描述队列，给人的印象是"只差点一下"。
**热力图说明实际情况是：每点一下，平均要让 2.7 个别的 PR 变脏**；`manager.py` 那 11 个里，
合掉任意一个，其余 10 个立刻需要 rebase。

也就是说，维护者面对的不是 221 个独立的小改动，而是**一张互相咬住的网**：

- 合 A → B/C/D dirty → 作者要 rebase → rebase 又可能改到别的文件 → 继续牵连；
- 越晚合越乱，因为 base 一直在前进。

**队列不是"没人点"，是"点一个要付 2.7 份 rebase 成本"。**

## 对"要不要继续提 PR"的含义

如果继续按文件热点提，`manager.py` 会变成不可收拾的地方——现在已经有 11 个。
真正有价值的新 PR 应该满足：**改的文件当前没有任何 open PR 碰**（`starter10.py` 就是按这个筛的，
224 里只有 54 个独占）。

## 局限

- 只统计"文件级"重叠，不判断两个 PR 改的是不是同一段代码。同一个文件的不同函数互不冲突，
  但 GitHub 仍会在合并时要求 rebase（`mergeable_state` 变 `dirty` 通常是同一区域）。
- 数据来自缓存，时间点约 00:35；01:00 之后新开的 PR 未计入。
