"""GitHub 优质项目雷达（只读）。

用 GitHub Search API 拉多维度候选，落盘 JSON 便于复核：
  1. 2026 新晋高星项目
  2. 近期活跃的大项目
  3. FastAPI 生态
  4. LLM / Agent 生态
  5. 调度 / 优化 / 求解器
  6. React / 前端
  7. 中文社区项目
  8. 可参与贡献（good-first-issues 多的成熟项目）
  9. 可参与贡献（help-wanted 多）
"""
import json
import os
import time
import urllib.parse
import urllib.request

TOKEN = os.environ.get("GITHUB_TOKEN", "")
OUT = os.path.dirname(os.path.abspath(__file__))

QUERIES = {
    "new_2026": "created:>2026-01-01 stars:>2000",
    "active_big": "pushed:>2026-10-01 stars:>20000",
    "fastapi": "topic:fastapi stars:>1000",
    "llm_agent": "topic:llm-agent stars:>300",
    "scheduling": "topic:scheduling stars:>500",
    "optimization": "topic:optimization stars:>2000",
    "python_quality": "language:python stars:>25000 pushed:>2026-09-01",
    "react": "topic:react stars:>15000 pushed:>2026-09-01",
    "chinese": "topic:chinese stars:>3000 pushed:>2026-09-01",
    "gfi": "good-first-issues:>20 stars:>1000 pushed:>2026-09-01",
    "help_wanted": "help-wanted-issues:>50 stars:>3000 pushed:>2026-09-01",
}


def call(url):
    req = urllib.request.Request(url, headers={
        "Authorization": "Bearer " + TOKEN,
        "Accept": "application/vnd.github+json",
        "User-Agent": "insight-scout",
    })
    with urllib.request.urlopen(req, timeout=45) as r:
        return json.loads(r.read().decode("utf-8"))


def main():
    summary = {}
    for name, q in QUERIES.items():
        url = ("https://api.github.com/search/repositories?q="
               + urllib.parse.quote(q)
               + "&sort=stars&order=desc&per_page=30")
        try:
            data = call(url)
        except Exception as e:
            print(f"[FAIL] {name}: {e}")
            continue
        rows = []
        for it in data.get("items", []):
            rows.append({
                "full_name": it["full_name"],
                "stars": it["stargazers_count"],
                "lang": it.get("language"),
                "pushed": it.get("pushed_at"),
                "open_issues": it.get("open_issues_count"),
                "license": (it.get("license") or {}).get("spdx_id"),
                "archived": it.get("archived"),
                "desc": (it.get("description") or "")[:160],
                "topics": it.get("topics", [])[:8],
            })
        summary[name] = rows
        with open(os.path.join(OUT, f"q_{name}.json"), "w", encoding="utf-8") as f:
            json.dump(rows, f, ensure_ascii=False, indent=1)
        print(f"\n=== {name}  ({q})  total={data.get('total_count')} ===")
        for r in rows[:12]:
            print(f"{r['stars']:>7}  {r['full_name']:<45} {r['lang'] or '-':<10} "
                  f"{r['pushed'][:10]}  {r['desc'][:70]}")
        time.sleep(2.5)  # search 限流 30/min

    with open(os.path.join(OUT, "all.json"), "w", encoding="utf-8") as f:
        json.dump(summary, f, ensure_ascii=False, indent=1)


if __name__ == "__main__":
    main()
