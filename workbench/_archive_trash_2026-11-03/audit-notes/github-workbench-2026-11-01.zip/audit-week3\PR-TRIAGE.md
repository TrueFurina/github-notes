# 64 个 open PR 分诊表

生成时间：2026-10-28 23:2x ｜ 数据源：`GET /search/issues?q=author:TrueFurina+type:pr+state:open`（实测 64 条）

## 概览

| 指标 | 数值 |
|---|---|
| open PR 总数 | **64** |
| 其中 docs/chore 类 | 22（34%） |
| 其中 fix 类 | 28（44%） |
| 闲置 > 30 天 | 23 |
| 闲置 > 60 天 | 9 |
| 零评论（维护者从没看过） | 26 |
| 分布最集中的上游 | TencentCloud/Octop 6、Practice-Modern-JavaScript 4、octop-harness 3、octop-memory 3 |

**一句话**：64 个里有 23 个该关、3 个该自己收尾、3 个要么补复现要么关，真正值得投入的只有 10 个。
挂着不动的成本不是零——审核者点进你的 PR 列表，看到的是 22 个 docs PR 和一堆 60 天没动静的 bare-except 模板。

---

## A. 建议关闭（23 个）

| 仓库 | # | 标题 | 闲置 | 评论 | 判断依据 |
|---|---:|---|---:|---:|---|
| `antoniaci/blackbird` | [#200](https://github.com/antoniaci/blackbird/pull/200) | fix: replace bare except with except Exception (4 modules) | 63d | 1 | 8 月批量模板 PR：同类 24 个只合了 3 个（12.5%），继续挂着只增加噪音 |
| `Ayo-faks/wulo-x` | [#30](https://github.com/Ayo-faks/wulo-x/pull/30) | docs: add docker-compose troubleshooting guide | 62d | 0 | docs-only，闲置 62 天无维护者响应 |
| `abhisekp/Practice-Modern-JavaScript` | [#381](https://github.com/abhisekp/Practice-Modern-JavaScript/pull/381) | docs: add an awesome intro explaining the project purpose | 61d | 2 | docs-only，闲置 61 天无维护者响应 |
| `abhisekp/Practice-Modern-JavaScript` | [#382](https://github.com/abhisekp/Practice-Modern-JavaScript/pull/382) | docs: add technologies used in building this project | 61d | 2 | docs-only，闲置 61 天无维护者响应 |
| `abhisekp/Practice-Modern-JavaScript` | [#380](https://github.com/abhisekp/Practice-Modern-JavaScript/pull/380) | docs: add dependency status badges | 61d | 2 | docs-only，闲置 61 天无维护者响应 |
| `abhisekp/Practice-Modern-JavaScript` | [#379](https://github.com/abhisekp/Practice-Modern-JavaScript/pull/379) | docs: add CHANGELOG | 61d | 2 | docs-only，闲置 61 天无维护者响应 |
| `smtpfast/feedletter` | [#34](https://github.com/smtpfast/feedletter/pull/34) | docs: add end-to-end example recipes (blog RSS and Markdown folder digests) | 61d | 0 | docs-only，闲置 61 天无维护者响应 |
| `winstonjs/winston` | [#2640](https://github.com/winstonjs/winston/pull/2640) | docs: explain colorize must be a format, not a Console option | 61d | 0 | docs-only，闲置 61 天无维护者响应 |
| `Aryan27-max/QWENTUS` | [#14](https://github.com/Aryan27-max/QWENTUS/pull/14) | docs: expand Troubleshooting guide with common startup and runtime issues | 42d | 1 | docs-only，闲置 42 天无维护者响应 |
| `BurntSushi/aho-corasick` | [#189](https://github.com/BurntSushi/aho-corasick/pull/189) | docs: document the start-bound panic case in Input::set_range | 42d | 0 | docs-only，闲置 42 天无维护者响应 |
| `BurntSushi/termcolor` | [#95](https://github.com/BurntSushi/termcolor/pull/95) | docs: fix is_terminal example to check stdout instead of stdin | 42d | 0 | docs-only，闲置 42 天无维护者响应 |
| `barycenters-systems/barycenters-go` | [#3](https://github.com/barycenters-systems/barycenters-go/pull/3) | docs: document the live MCP side door | 42d | 1 | docs-only，闲置 42 天无维护者响应 |
| `dtolnay/proc-macro2` | [#541](https://github.com/dtolnay/proc-macro2/pull/541) | docs: document how semver-exempt APIs are enabled on Span::eq | 42d | 0 | docs-only，闲置 42 天无维护者响应 |
| `dtolnay/semver` | [#353](https://github.com/dtolnay/semver/pull/353) | docs: clarify that partial comparator expansions are not substitution-safe | 42d | 1 | docs-only，闲置 42 天无维护者响应 |
| `mxrch/GHunt` | [#606](https://github.com/mxrch/GHunt/pull/606) | fix: replace bare except with except Exception in gmaps/utils helpers | 42d | 3 | 8 月批量模板 PR：同类 24 个只合了 3 个（12.5%），继续挂着只增加噪音 |
| `codepath/pathreview-archive-aug2026` | [#75](https://github.com/codepath/pathreview-archive-aug2026/pull/75) | docs: add example curl commands to API reference | 28d | 0 | docs-only，闲置 28 天无维护者响应 |
| `corsairdev/corsair` | [#1250](https://github.com/corsairdev/corsair/pull/1250) | docs(posthog): add plugin-docs.yaml for overview examples | 28d | 8 | docs-only，闲置 28 天无维护者响应 |
| `dtolnay/thiserror` | [#456](https://github.com/dtolnay/thiserror/pull/456) | docs: document that #[from] on an opaque type needs forwarding From impls for  | 28d | 1 | docs-only，闲置 28 天无维护者响应 |
| `sous-chefs/nagios` | [#713](https://github.com/sous-chefs/nagios/pull/713) | docs: document current PagerDuty contact-group behaviour | 28d | 0 | docs-only，闲置 28 天无维护者响应 |
| `sobolevn/git-secret` | [#1428](https://github.com/sobolevn/git-secret/pull/1428) | docs: document git diff/log support via .gitattributes | 25d | 1 | docs-only，闲置 25 天无维护者响应 |
| `fail2ban/fail2ban` | [#4219](https://github.com/fail2ban/fail2ban/pull/4219) | fix: replace bare except with except Exception | 25d | 4 | 8 月批量模板 PR：同类 24 个只合了 3 个（12.5%），继续挂着只增加噪音 |
| `TencentCloud/Octop` | [#2170](https://github.com/TencentCloud/Octop/pull/2170) | docs: complete the ~/.octop layout tree and note the wizard password location | 4d | 3 | #2174 已改掉该路径，内容被推翻 |
| `TencentCloud/Octop` | [#2369](https://github.com/TencentCloud/Octop/pull/2369) | docs: fix wizard password path in .env.example (post-#2174) | 0d | 1 | 同上，是 #2174 之后的事后补丁 |

关闭不等于失败。一条"结论 + 一句话原因"的关闭，比挂着 60 天更像专业维护者的做法。
模板（选一条改）：

> 已经被后续改动覆盖了（见 #xxx），先关掉，避免留下过期信息。

> 这个改动维护者没有响应，我这边不再跟进；需要时可以重开并补测试。

> 这是 8 月批量扫出来的模板改动，缺最小复现，主动关闭。

---

## B. 自有仓库，自己收尾（3 个）

| 仓库 | # | 标题 | 闲置 | 评论 | 判断依据 |
|---|---:|---|---:|---:|---|
| `TrueFurina/rich` | [#1](https://github.com/TrueFurina/rich/pull/1) | fix: Columns(width=...) no longer raises ZeroDivisionError when width does not | 46d | 0 | 自有仓库的 PR：自己 merge 或关掉，不需要等上游 review |
| `TrueFurina/xihu-sword-ctf-agent` | [#28](https://github.com/TrueFurina/xihu-sword-ctf-agent/pull/28) | [无任务:测试] core.bare 判据补 29 条用例（实现已随 02e6f998 进 main） | 4d | 0 | 自有仓库的 PR：自己 merge 或关掉，不需要等上游 review |
| `TrueFurina/SecAutoMind-src` | [#74](https://github.com/TrueFurina/SecAutoMind-src/pull/74) | feat(llmchannel): 新增 LLM 调用全局并发护栏 LLMGuard | 1d | 0 | 自有仓库的 PR：自己 merge 或关掉，不需要等上游 review |

`TrueFurina/rich #1` 特别值得注意：它是对 fork 提的 PR，46 天没往上推。要么把它 rebase 后提到 `Textualize/rich`（你已经有 #4214 的讨论基础），要么关掉——留在 fork 里的 PR 只是自我安慰。

---

## C. 补复现 or 关闭（3 个）

| 仓库 | # | 标题 | 闲置 | 评论 | 判断依据 |
|---|---:|---|---:|---:|---|
| `protectai/modelscan` | [#371](https://github.com/protectai/modelscan/pull/371) | build: make NumPy an optional dependency | 62d | 0 | fix 类但闲置 62 天、零评论：补最小复现，否则关闭 |
| `uiri/toml` | [#460](https://github.com/uiri/toml/pull/460) | fix: parse inline tables in string arrays without IndexError | 45d | 0 | fix 类但闲置 45 天、零评论：补最小复现，否则关闭 |
| `petgraph/petgraph` | [#1043](https://github.com/petgraph/petgraph/pull/1043) | fix(visit): grow FixedBitSet visit map instead of panicking when the graph out | 42d | 0 | fix 类但闲置 42 天、零评论：补最小复现，否则关闭 |

固定动作：补一个**最小复现脚本**（10 行以内）+ 三平台输出矩阵（Windows / Linux / macOS）。
维护者对"能自己复现"的 PR 响应率明显更高，尤其是 `psutil`、`tomllib` 这类底层库。

---

## D. 保留并加码（10 个）

| 仓库 | # | 标题 | 闲置 | 评论 | 判断依据 |
|---|---:|---|---:|---:|---|
| `python-attrs/attrs` | [#1618](https://github.com/python-attrs/attrs/pull/1618) | fix: rewrite __class__ closure cells of methods hidden in decorators | 55d | 0 | 有真实技术含量，值得补复现/测试 |
| `python-attrs/attrs` | [#1616](https://github.com/python-attrs/attrs/pull/1616) | fix: compare `Attribute` instances by identity in `include`/`exclude` | 24d | 3 | 有真实技术含量，值得补复现/测试 |
| `Unstructured-IO/unstructured` | [#4462](https://github.com/Unstructured-IO/unstructured/pull/4462) | feat: add `clean_newline` to concatenate words wrapped across lines | 18d | 1 | 有真实技术含量，值得补复现/测试 |
| `giampaolo/psutil` | [#2990](https://github.com/giampaolo/psutil/pull/2990) | fix: process_iter() no longer skips reused PIDs for one iteration | 11d | 2 | 有真实技术含量，值得补复现/测试 |
| `giampaolo/psutil` | [#2989](https://github.com/giampaolo/psutil/pull/2989) | fix: handle ENOTTY from ioctl(SIOCETHTOOL) in net_if_duplex_speed | 11d | 2 | 有真实技术含量，值得补复现/测试 |
| `Unstructured-IO/unstructured` | [#4464](https://github.com/Unstructured-IO/unstructured/pull/4464) | fix: switch `skip_infer_table_types` default to `None` | 4d | 1 | 有真实技术含量，值得补复现/测试 |
| `kubeflow/testing` | [#1072](https://github.com/kubeflow/testing/pull/1072) | feat: add reusable create-cluster (Kind) composite action | 1d | 9 | 有真实技术含量，值得补复现/测试 |
| `TencentCloud/Octop` | [#2474](https://github.com/TencentCloud/Octop/pull/2474) | fix(cli): guard bundled import when --force clears site-packages (#2458) | 0d | 0 | 有真实技术含量，值得补复现/测试 |
| `TencentCloud/Octop` | [#2376](https://github.com/TencentCloud/Octop/pull/2376) | fix(utils): bound download filename by UTF-8 bytes to avoid oversized non-ASCI | 0d | 1 | 有真实技术含量，值得补复现/测试 |
| `TencentCloud/octop-harness` | [#116](https://github.com/TencentCloud/octop-harness/pull/116) | fix(teams): isolate inbox worker from caller's contextvars (#115) | 0d | 0 | 有真实技术含量，值得补复现/测试 |

这些是真正能换来信用的：`attrs` 一条（`#1616` 已在 CI 上磨过 ruff format）、`kubeflow/testing`（9 条评论、已收敛到 +45/−0）、`Octop` 三条、`unstructured` 一条。

> ⚠️ **本节已修正，见下方「23:20 复核修正」**——`psutil` 两条并非最值得投入，而是别人 PR 的重复品；`unstructured #4462` 是 `dirty` 状态的大 diff。

---

## E. 继续观察（25 个）

| 仓库 | # | 标题 | 闲置 | 评论 | 判断依据 |
|---|---:|---|---:|---:|---|
| `opendatahub-io/notebooks` | [#4461](https://github.com/opendatahub-io/notebooks/pull/4461) | ci: migrate local action/workflow references from ./ to $/ self-repository syn | 47d | 8 | 仍在活跃窗口 |
| `ProjectRecon/awesome-ai-agents-security` | [#104](https://github.com/ProjectRecon/awesome-ai-agents-security/pull/104) | Add xihu-sword-ctf-agent to Red Teaming section | 42d | 1 | 仍在活跃窗口 |
| `m-fyi/awesome-claude-skills` | [#2](https://github.com/m-fyi/awesome-claude-skills/pull/2) | add comment-distillery | 32d | 0 | awesome 清单收录 PR，价值在曝光不在代码 |
| `agno-agi/agno` | [#9838](https://github.com/agno-agi/agno/pull/9838) | fix: cap Gemini media URL download size to prevent memory exhaustion | 26d | 2 | 仍在活跃窗口 |
| `boto/boto3` | [#4836](https://github.com/boto/boto3/pull/4836) | fix: DynamoDB placeholder generation no longer overwrites caller values | 26d | 1 | 仍在活跃窗口 |
| `ComposioHQ/awesome-claude-skills` | [#2002](https://github.com/ComposioHQ/awesome-claude-skills/pull/2002) | Add Comment Distillery: distill crowd text into an evidence-cited guide | 25d | 1 | 仍在活跃窗口 |
| `marketcalls/openalgo` | [#1920](https://github.com/marketcalls/openalgo/pull/1920) | security: add no-store headers to API-key responses | 24d | 4 | 仍在活跃窗口 |
| `jd/tenacity` | [#712](https://github.com/jd/tenacity/pull/712) | fix: wait_exponential with zero multiplier no longer overflows into max wait | 21d | 5 | 仍在活跃窗口 |
| `Trustpoint-Project/trustpoint` | [#901](https://github.com/Trustpoint-Project/trustpoint/pull/901) | docs: improve .env.example with per-variable explanations | 11d | 1 | docs-only 但仍在窗口内 |
| `arrow-py/arrow` | [#1343](https://github.com/arrow-py/arrow/pull/1343) | fix: treat explicit tzinfo=None in arrow.get() like an omitted tzinfo | 11d | 2 | 仍在活跃窗口 |
| `dask/dask` | [#12576](https://github.com/dask/dask/pull/12576) | Add `mode` parameter to `dask.array.linalg.qr` | 11d | 3 | 仍在活跃窗口 |
| `httpie/cli` | [#1952](https://github.com/httpie/cli/pull/1952) | feat: show request items separators in naked invocation usage | 11d | 2 | 仍在活跃窗口 |
| `loopbackio/loopback-next` | [#11767](https://github.com/loopbackio/loopback-next/pull/11767) | docs: explain why interdependent tests are bad | 11d | 0 | docs-only 但仍在窗口内 |
| `CTFd/CTFd` | [#3103](https://github.com/CTFd/CTFd/pull/3103) | fix: pass challenge read() output to view template renderer | 4d | 3 | 仍在活跃窗口 |
| `PyGithub/PyGithub` | [#3577](https://github.com/PyGithub/PyGithub/pull/3577) | feat: add immutable releases configuration methods to Repository | 4d | 3 | 仍在活跃窗口 |
| `TencentCloud/Octop` | [#2371](https://github.com/TencentCloud/Octop/pull/2371) | fix(cli): 跨文件系统导出备份不再因 EXDEV 失败 (#2321) | 4d | 0 | 仍在活跃窗口 |
| `TencentCloud/octop-harness` | [#83](https://github.com/TencentCloud/octop-harness/pull/83) | feat(tool_guard): detect Windows and PowerShell attack commands | 4d | 2 | 仍在活跃窗口 |
| `verialabs/ctf-agent` | [#11](https://github.com/verialabs/ctf-agent/pull/11) | feat(skills): wire skill playbooks into the prompt and mount them into the san | 3d | 0 | 仍在活跃窗口 |
| `verialabs/ctf-agent` | [#10](https://github.com/verialabs/ctf-agent/pull/10) | refactor(runner): 拆分 425 行上帝模块为 5 个可测模块 | 3d | 0 | 仍在活跃窗口 |
| `verialabs/ctf-agent` | [#9](https://github.com/verialabs/ctf-agent/pull/9) | fix: 修复容器题「有脑无手」SPOF——靶机地址获取阻塞到就绪 + 双通道注入 | 3d | 0 | 仍在活跃窗口 |
| `TencentCloud/octop-harness` | [#106](https://github.com/TencentCloud/octop-harness/pull/106) | fix(llm): bound OpenAI-compatible requests with a default timeout (#2241) | 2d | 0 | 仍在活跃窗口 |
| `TencentCloud/octop-memory` | [#30](https://github.com/TencentCloud/octop-memory/pull/30) | fix(storage): honor rejected candidates when deduplicating re-scanned events ( | 2d | 0 | 仍在活跃窗口 |
| `TencentCloud/octop-memory` | [#29](https://github.com/TencentCloud/octop-memory/pull/29) | fix(memory): batch extraction and persist the extracted cursor (#25) | 1d | 1 | 仍在活跃窗口 |
| `TencentCloud/Octop` | [#2372](https://github.com/TencentCloud/Octop/pull/2372) | fix(env): 未闭合引号不再吞掉 ~/.octop/env 后续变量 (#2269) | 0d | 1 | 仍在活跃窗口 |
| `TencentCloud/octop-memory` | [#33](https://github.com/TencentCloud/octop-memory/pull/33) | fix(manual-docs): advance audit cursor on uncertain results | 0d | 0 | 仍在活跃窗口 |

这批的共同特征：还在 30 天窗口内，或有维护者在评论里回过话。别催——催更已经被 `zola`、`Octop #2170` 各打过一次脸。

---

## 今天 30 分钟能做完的

1. 关掉 A 组里 **idle ≥ 60 天**的 8 个（`Practice-Modern-JavaScript` 4 个、`winstonjs`、`smtpfast`、`Ayo-faks`、`antoniaci/blackbird`），每个附一句结论；
2. 关掉 `Octop #2170`、`#2369`（内容已被 #2174 推翻）；
3. `TrueFurina/rich #1` 二选一：推上游 or 关闭；
4. 给 `psutil #2989` 补一条 Windows 上的输出对照（它已经有 2 条评论在等这个）。

做完这四步，open PR 从 64 降到 **50 左右**，而且列表里第一条不再是 docs。

---

## 附：可复跑的关闭脚本（默认 dry-run）

`close_prs.py` 已生成，**默认只打印不执行**；要真关必须显式传 `--yes` 并给出仓库与编号。

```bash
python close_prs.py list                    # 列出 A 组全部
python close_prs.py close giampaolo/psutil#2989 --yes   # 单个（示例，不建议关这个）
```

---

# 23:20 复核修正：D 组名单有 5 个是错的

上一版只看了 title 和 idle 天数，没读讨论串。逐条读完之后，D 组（"保留加码"）必须重判。

## 一、psutil 两条：不是最值得投入，是别人 PR 的重复品

| PR | 真实状况 | 该做什么 |
|---|---|---|
| [psutil #2989](https://github.com/giampaolo/psutil/pull/2989) | 与 **#2985**（另一位贡献者的同类 PR）重复。`fabiancrt` 8 月 28 日就问了"为什么要单独开一个"，**你自己 9 月 11 日回复说 "I'm happy to close #2989"** —— 47 天后仍然开着 | **按承诺关掉**。说到没做到，比 PR 本身伤害更大 |
| [psutil #2990](https://github.com/giampaolo/psutil/pull/2990) | 标题写 `Fixes #2983`，但 #2983 是**另一个 PR** 不是 issue。`KaiErikNiermann` 10 月 11 日直接指出"这是 #2983 的重复，你应该去那边 review 代码" | **关掉**，去 #2983 留 review 意见 |

这条也修正了一个方法论问题：**"有技术含量"和"值得推进"是两件事**。重复品技术含量再高，合并也是零收益。

## 二、另外 3 个也够呛

| PR | 真实状况 | 该做什么 |
|---|---|---|
| [unstructured #4462](https://github.com/Unstructured-IO/unstructured/pull/4462) | `mergeable_state=dirty`（有冲突），而且 **+932/−903** —— 这种规模的 diff 说明分支严重落后或夹带了格式化噪音，维护者不会看 | 关掉，或从最新 master 重做一遍只保留实质改动 |
| [unstructured #4464](https://github.com/Unstructured-IO/unstructured/pull/4464) | 同样 `dirty`，你 10 月 24 日贴了长 status note 承认"unmergeable" | 先解决冲突再看，不要靠解释推动 |
| [attrs #1618](https://github.com/python-attrs/attrs/pull/1618) | `blocked`、**零评论**、开源两个月 | 先看 CI 为什么红，再决定要不要留 |

## 三、正在发生的两条负面信号（今天/前天）

| 位置 | 发生了什么 | 处理 |
|---|---|---|
| [kubeflow/testing #1072](https://github.com/kubeflow/testing/pull/1072) | 10-24 你刚贴完 substantively 的 rebase 说明，**10-27 紧接着出现一条 `您好，来件已收到。谢谢！`** —— 邮件自动回复被粘进了维护者的 review 线程。这条现在挂在页面最下面 | 删掉（一条命令，见下）。这是全账号最不该出现在别人 PR 里的 10 个字 |
| [TencentCloud/Octop #2376](https://github.com/TrueFurina/Octop/pull/2376) | **今天 15:00** 你又发了一条 `Hi @jubaoliang ?? ... gently bump it to the top of your review queue` —— PR 才开 3 天，而 jubaoliang 上周才合了你的 #2174 | 别再 ping。3 天不是催合理由，`zola` 那次就是这么翻车的 |

## 四、立即可执行的止血命令

```bash
# 1) 删掉 kubeflow #1072 里那条邮件自动回复（评论 id 6444802667）
python fix_reputation.py delete-comment kubeflow/testing#1072:6444802667 --yes

# 2) 按你 9/11 的承诺关掉 psutil #2989；同时关掉重复的 #2990
python close_prs.py close giampaolo/psutil#2989 --yes
python close_prs.py close giampaolo/psutil#2990 --yes
```

两条命令跑完，open PR 从 64 降到 62，但**更重要的变化在你的 PR 页面观感上**：重复品和自动回复都不在了。

## 五、修正后的"今天 30 分钟"

1. 删 kubeflow 那条自动回复（30 秒）；
2. 关 psutil 两条重复（1 分钟）；
3. 关 A 组里 idle ≥ 60 天的 8 个（5 分钟，每个附一句结论）；
4. 关 `rich#1`（对 fork 提的 PR，46 天没推上游）；
5. 剩下的时间拿去把 `kubeflow #1072` 的 CI 弄绿——它是 D 组里唯一"维护者已经手动跑到 +45/−0、只差 CI"的，合并概率最高。

**别再去 ping `Octop #2376`。** 3 天没动静的 PR 留着不动，比催更安全。

---

# 执行记录（23:24–23:32）

## 已关闭 20 个

| 批次 | 数量 | 内容 |
|---|---:|---|
| psutil | 2 | #2989（兑现 9/11 承诺，指向 #2985）、#2990（重复 #2983） |
| A 组 idle ≥ 60d | 8 | blackbird#200、wulo-x#30、Practice-Modern-JavaScript #379/380/381/382、feedletter#34、winston#2640 |
| A 组 idle 25–42d | 10 | QWENTUS#14、aho-corasick#189、termcolor#95、barycenters-go#3、proc-macro2#541、semver#353、GHunt#606、thiserror#456、nagios#713、git-secret#1428 |

每个都附了具体说明（docs 类说"纯文档、N 天无回应、可随时重开"；模板类说"批量扫描产出、缺最小复现"），没有套同一句话。

**open PR：64 → 43。**

## 刻意留下的 4 个

| PR | 为什么留 |
|---|---|
| `fail2ban/fail2ban#4219` | 维护者 `sebres` 提了 find&replace 安全性质疑，已逐条作答、**等对方回**。这时候关掉等于回避实质问题 |
| `corsairdev/corsair#1250` | 全绿、单 commit、+3/−0、9 个检查全过，只差一次点击。这是资产不是负债 |
| `TencentCloud/Octop#2170` | 维护者 jubaoliang 刚合过 #2174，关系正热；不在别人仓库里顺手清自己的杂物 |
| `TencentCloud/Octop#2369` | 同上，且才开 0 天 |

## 一个关不掉的

`codepath/pathreview-archive-aug2026#75` —— 仓库已归档（read-only），403 `Repository was archived so is read-only`。归档仓的 PR 本来就会随仓库冻结，不用处理。

## 下次别再犯的

批量关闭要么带"逐条说明"，要么别做。10 个 PR 用同一句模板关掉，和当初用模板批量提 PR 是同一个错误的反面版本。
