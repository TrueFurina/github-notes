import json, subprocess, time, urllib.request, http.client, base64, re

TOKEN = subprocess.run(["powershell","-NoProfile","-Command",
    "[Environment]::GetEnvironmentVariable('GITHUB_TOKEN','User')"],
    capture_output=True, text=True).stdout.strip()
H = {"Authorization":"Bearer "+TOKEN,"User-Agent":"raccoon","Accept":"application/vnd.github+json","Connection":"close"}

def get(url):
    for i in range(3):
        try:
            r = urllib.request.Request(url, headers=H)
            with urllib.request.urlopen(r, timeout=45) as resp:
                parts=[]
                try:
                    while True:
                        b=resp.read(16384)
                        if not b: break
                        parts.append(b)
                except http.client.IncompleteRead as e:
                    parts.append(e.partial)
                return json.loads(b"".join(parts))
        except Exception:
            time.sleep(2)
    return None

d=json.load(open("raw.json",encoding="utf-8"))
own=[r for r in d["repos"] if not r.get("fork")]

print("=== FLAGSHIP DETAIL ===")
for r in sorted(own,key=lambda x:(-x["stargazers_count"],-x["size"]))[:10]:
    fn=r["full_name"]
    c=get(f"https://api.github.com/repos/{fn}/contributors?per_page=5")
    langs=get(f"https://api.github.com/repos/{fn}/languages")
    ncontrib=len(c) if isinstance(c,list) else 0
    print(f'{r["name"][:30]:32s} *{r["stargazers_count"]:2d} watchers={r["watchers_count"]:2d} forks={r["forks_count"]} '
          f'issues_open={r["open_issues_count"]:2d} contribs={ncontrib} '
          f'langs={list((langs or {}).keys())[:4]} disc={r.get("has_discussions")}')

print("\n=== PROFILE README ===")
rm=get("https://api.github.com/repos/TrueFurina/TrueFurina/readme")
if rm and rm.get("content"):
    txt=base64.b64decode(rm["content"]).decode("utf-8","replace")
    print(txt[:3000])

print("\n=== SECRET / JUNK CHECK (top repos root) ===")
bad=[]
for r in sorted(own,key=lambda x:-x["size"])[:15]:
    c=get(f'https://api.github.com/repos/{r["full_name"]}/contents/')
    if isinstance(c,list):
        names=[x["name"] for x in c]
        hits=[n for n in names if n in (".env",".env.local","id_rsa","config.json","secrets.json") or n.endswith(".pem") or n.endswith(".key")]
        if hits: bad.append((r["name"],hits))
print("suspicious root files:", bad if bad else "none found in top-15 by size")