"""关闭剩余 11 个无维护者响应的 docs/模板 PR（默认 dry-run）。

刻意排除（理由写在 EXCLUDED）：
  · fail2ban#4219  —— 维护者 sebres 提了实质质疑，已逐条作答、等对方回，关掉像回避
  · corsairdev/corsair#1250 —— 全绿、单 commit +3/−0，只差一次点击，关掉是丢资产
  · TencentCloud/Octop#2170 / #2369 —— 该仓库维护者刚合过 #2174，关系正热，不在别人家里清垃圾
"""
import argparse
import json
import sys
import urllib.request

sys.path.insert(0, r"D:/github/github-audit")
from ghlib import api, HEADERS  # noqa: E402

TARGETS = [
    ("Aryan27-max/QWENTUS", 14, 42, "docs"),
    ("BurntSushi/aho-corasick", 189, 42, "docs"),
    ("BurntSushi/termcolor", 95, 42, "docs"),
    ("barycenters-systems/barycenters-go", 3, 42, "docs"),
    ("dtolnay/proc-macro2", 541, 42, "docs"),
    ("dtolnay/semver", 353, 42, "docs"),
    ("mxrch/GHunt", 606, 42, "template"),
    ("codepath/pathreview-archive-aug2026", 75, 28, "docs"),
    ("dtolnay/thiserror", 456, 28, "docs"),
    ("sous-chefs/nagios", 713, 28, "docs"),
    ("sobolevn/git-secret", 1428, 25, "docs"),
]

EXCLUDED = {
    "fail2ban/fail2ban#4219": "维护者 sebres 提了 find&replace 安全性质疑，已逐条作答、等回复",
    "corsairdev/corsair#1250": "全绿单 commit +3/−0，只差一次点击",
    "TencentCloud/Octop#2170": "维护者刚合过 #2174，不在别人仓库里清垃圾",
    "TencentCloud/Octop#2369": "同上",
}


def _req(method, path, body=None):
    req = urllib.request.Request(
        "https://api.github.com" + path,
        data=json.dumps(body).encode("utf-8") if body else None,
        headers={**HEADERS, "Content-Type": "application/json"}, method=method)
    try:
        with urllib.request.urlopen(req, timeout=60) as r:
            return json.loads(r.read() or b"{}")
    except Exception as e:  # noqa: BLE001
        detail = getattr(e, "read", lambda: b"")()
        return {"__error": str(e), "detail": detail.decode("utf-8", "ignore")[:200]}


def body_for(kind, idle):
    if kind == "template":
        return (f"Closing this: it came out of a batch sweep rather than a specific bug report, "
                f"and there has been no movement in {idle} days. Without a minimal reproduction "
                f"there is nothing concrete for a reviewer to act on.\n\n"
                f"（自主关闭：批量扫描产出的模板改动，{idle} 天无进展且缺最小复现。）")
    return (f"Closing this myself — documentation-only, open {idle} days without review. "
            f"Keeping it open only adds to the queue; happy to reopen if the text is still wanted.\n\n"
            f"（自主关闭：纯文档改动，{idle} 天无回应；若仍需可随时重开。）")


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--yes", action="store_true")
    a = ap.parse_args()
    done = 0
    for repo, num, idle, kind in TARGETS:
        tag = f"{repo}#{num}"
        pr = api(f"/repos/{repo}/pulls/{num}")
        if "__error" in pr:
            print(f"  {tag:44} 读不到，跳过"); continue
        if pr["state"] != "open":
            print(f"  {tag:44} 已 {pr['state']}，跳过"); continue
        print(f"  {tag:44} idle={idle}d  {pr['title'][:50]}")
        if not a.yes:
            continue
        c = _req("POST", f"/repos/{repo}/issues/{num}/comments", {"body": body_for(kind, idle)})
        if c.get("__error"):
            print("     评论失败:", c["__error"], c.get("detail", "")[:100]); continue
        r = _req("PATCH", f"/repos/{repo}/pulls/{num}", {"state": "closed"})
        if r.get("__error"):
            print("     关闭失败:", r["__error"], r.get("detail", "")[:100]); continue
        done += 1
        print("     已关闭")
    print(f"\n{'完成：关闭 %d 个' % done if a.yes else '[试运行] 加 --yes 执行'}")
    print("\n刻意排除：")
    for k, v in EXCLUDED.items():
        print(f"  - {k}: {v}")


if __name__ == "__main__":
    main()
