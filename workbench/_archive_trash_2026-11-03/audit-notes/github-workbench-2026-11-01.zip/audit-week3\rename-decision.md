# SecAutoMind 三合一：改名这件事卡在一个我刚发现的事实上

## 先说结论：我上一轮的建议是错的

我说过"把 `SecAutoMind-src` 改名 `secautomind` 即可"。**这个操作在 GitHub 上不可能执行**——仓库名大小写不敏感：

```
GET /repos/TrueFurina/secautomind
→ 返回的是 TrueFurina/SecAutoMind    ← 已存在
```

`secautomind` 就是 `SecAutoMind` 的另一种写法，同名冲突。改名 API 会直接 422。

这是规划层的错误，不是执行层的：定位报告建议"合并品牌"时，没有验证新名字是否可用。

## 现状（实测）

| 仓库 | 体积 | ★ | Release | 角色 | 关键约束 |
|---|---:|---:|---:|---|---|
| `SecAutoMind` | 153 KB | 1 | 0 | 官网单页（`index.html` + `robots.txt`） | **GitHub Pages 已上线**：`https://truefurina.github.io/SecAutoMind/`，`status=built`，无自定义域名 |
| `SecAutoMind-src` | 90 MB | 0 | **9 个** | 源码 + 安装包分发 | 9 个 Release 的附件下载 URL 都带仓库名 |
| `xihu-sword-ctf-agent` | 6.2 MB | 5 | 0 | 已自宣冻结、并入前者 | README 已指向 SecAutoMind |

流量事实：官网仓是**全账号浏览最高的仓库**（14 天 78 views / 23 uniq，release 页 13 views / 7 uniq），源码仓几乎没人直接访问。

## 三条路，代价不同

### 方案 A · 不改名，只做文档层合并（零风险）

- 源码仓 README 首屏加一行"产品官网 →"，官网仓 README 指向源码（**已经做完了**，就在今天的 commit `40f825a` 里）。
- profile「Featured Projects」置顶时只放一个入口。
- 代价：仓库列表里仍然是 `SecAutoMind` 和 `SecAutoMind-src` 并列，搜索会命中两个。

### 方案 B · 让产品仓拿走 `SecAutoMind` 这个名字（推荐，但有代价）

```
1. SecAutoMind      → SecAutoMind-site     （官网仓让位）
2. SecAutoMind-src  → SecAutoMind          （产品仓接管）
3. 更新两个仓 README 里的互相引用
```

- 收益：搜索结果、profile 卡片、Release 下载链接全部收敛到 `TrueFurina/SecAutoMind`，这才是"三合一"。
- **代价：官网 Pages 地址会变成 `https://truefurina.github.io/SecAutoMind-site/`**。GitHub Pages **不做重定向**，旧地址直接 404。仓库链接会被重定向，Pages 不会。
- 量化：受影响的是 23 个 14 天内的独立访客 + 所有外部引用（简历、简历附件、群里发过的链接）。

### 方案 B+ · 先给官网绑自定义域名，再改名（零损失）

```
1. 给官网仓配自定义域名（如 secautomind.<your-domain>），等 HTTPS 证书签发
2. 再执行方案 B 的两步改名
```

- 因为 Pages 换成自定义域名后，`github.io` 路径就只是内部实现，改名不再影响对外地址。
- 需要你有一个域名。没有域名的话这条走不通。

### 方案 C · 换个名字（不推荐）

`secautomind-ai`、`SecAutoMind-core` 之类都可用，但**换来一个更长、更不自解释的名字**，比现状更差。

## 我的建议

**如果近期不打算推这个项目对外**：走方案 A，成本 0，等真要推广时再动。
**如果打算把它当旗舰项目**（定位报告的建议）：走方案 B+——先绑域名，再改名。花 20 分钟买域名 + 配 DNS，换永久零损失。
**只有在你确认那个 github.io 链接从来没对外发过**，才建议直接走方案 B。

## 需要你回一句

1. `https://truefurina.github.io/SecAutoMind/` 这个链接**对外发过吗**（简历/公众号/群/issue）？
2. 有域名吗？

答完我按选定的方案一次做完：两次改名 + 两个 README 的引用更新 + 重定向验证（仓库链接应 301、Release 附件应可下载）+ 回滚脚本。
