"""给 unstructured #4464 贴一条说明（幂等，发过就跳过）。"""
import argparse
import json
import sys
import urllib.request

sys.path.insert(0, r"D:/github/github-audit")
from ghlib import api, HEADERS  # noqa: E402

BODY = """Rebuilt this on current `main` — it is now a single DCO-signed commit, **+8/−2, one file**,
and no longer conflicts.

**What changed and why it was unmergeable.** The branch carried four hunks, and one of them is
already in `main`: `partition()` forwards `encoding=encoding` to the partitioner on the JSON/NDJSON
path (around line 271), so that hunk is not just redundant — it was fighting the upstream change and
producing the conflict. I dropped it. If anything in it is still needed, it is not visible from
`main`, so tell me and I will bring it back as its own PR.

What remains is exactly what #3063 asks for:

```python
skip_infer_table_types: Optional[list[str]] = None,
...
if skip_infer_table_types is None:
    skip_infer_table_types = ["pdf", "jpg", "png", "heic", "webp"]
```

The reason to prefer this over a list default is not style: a mutable default is created once and
shared across calls, so a caller that appends to it silently changes the default for everyone after
them. Resolving inside the function also lets the docstring state the real default, which it now does.

**Behaviour is unchanged** for every caller that passes a value or omits it — the effective list is
still `["pdf", "jpg", "png", "heic", "webp"]`.

**What I verified.** The file parses (`ast.parse`) and every use of `skip_infer_table_types` in the
function body sits after the resolution point. I did **not** run the test suite locally. Happy to add
a regression test that calls `partition()` twice with a mutated list if that would help the review.
"""


def _post(body):
    req = urllib.request.Request(
        "https://api.github.com/repos/Unstructured-IO/unstructured/issues/4464/comments",
        data=json.dumps({"body": body}).encode("utf-8"),
        headers={**HEADERS, "Content-Type": "application/json"}, method="POST")
    try:
        with urllib.request.urlopen(req, timeout=60) as r:
            return json.loads(r.read())
    except Exception as e:  # noqa: BLE001
        d = getattr(e, "read", lambda: b"")()
        return {"__error": str(e), "detail": d.decode("utf-8", "ignore")[:200]}


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--yes", action="store_true")
    a = ap.parse_args()
    cs = api("/repos/Unstructured-IO/unstructured/issues/4464/comments?per_page=20") or []
    if any("Rebuilt this on current" in (c["body"] or "") for c in cs):
        print("已发过，跳过")
        return 0
    if not a.yes:
        print("[试运行] 将发布 %d 字符的说明" % len(BODY))
        return 0
    r = _post(BODY)
    print("已发布:", r.get("html_url") if not r.get("__error")
          else "ERROR %s %s" % (r["__error"], r.get("detail", "")[:150]))


if __name__ == "__main__":
    main()
