"""把 unstructured #4464 重建为「基于最新 master 的单个 DCO commit」。

背景（都是实测出来的，不是猜的）：
  · 原 PR 有 4 个 hunk，其中「JSON 分支补 encoding=」这一处在 master 已被上游自己修好（第 271 行），
    属于过时改动 —— 正是这个 PR 一直 dirty/unmergeable 的原因之一。
  · master 第 40 行的默认值已加入 "webp"，但仍是可变默认参数（issue #3063 仍然 open，要求改成 None）。
  · 所以真正还有价值的是：默认值改 None + 在函数体内解析出默认列表 + 文档同步。

    python fix_4464.py            # 生成新文件 + 打印 diff，不推
    python fix_4464.py --yes      # 建 blob/tree/commit 并强制更新 fork 分支
"""

import argparse
import ast
import base64
import difflib
import json
import os
import sys
import urllib.request

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, r"D:/github/github-audit")
from ghlib import api, HEADERS  # noqa: E402

FORK = "TrueFurina/unstructured"
BRANCH = "fix/skip-infer-table-types-default"
PATH = "unstructured/partition/auto.py"
SIGNOFF = "Signed-off-by: Dream <2468001320@qq.com>"
MSG = ("fix: default `skip_infer_table_types` to `None` in `partition()`\n\n"
       "A mutable list default is shared across calls, so a caller mutating it would leak into\n"
       "later calls. Switch the default to `None` and resolve the effective list inside the\n"
       "function, which is what issue #3063 asks for and what the docstring can then describe\n"
       "honestly (\"when omitted, defaults to ...\").\n\n"
       "Drops the unrelated `encoding=` forwarding hunk from the original branch: master already\n"
       "passes `encoding` on that path, so keeping it only produced conflicts.\n\n" + SIGNOFF)

OLD_SIG = '    skip_infer_table_types: list[str] = ["pdf", "jpg", "png", "heic", "webp"],'
NEW_SIG = "    skip_infer_table_types: Optional[list[str]] = None,"

OLD_DOC = """    skip_infer_table_types
        The document types that you want to skip table extraction with.
"""
NEW_DOC = """    skip_infer_table_types
        The document types that you want to skip table extraction with. When omitted, defaults to
        `["pdf", "jpg", "png", "heic", "webp"]`.
"""

OLD_ANCHOR = """    set_partition_document_type(file_type)

    if file is not None:
"""
NEW_ANCHOR = """    set_partition_document_type(file_type)

    # `None` is the documented default; resolve it here rather than in the signature so that a
    # mutable list is not shared between calls (issue #3063).
    if skip_infer_table_types is None:
        skip_infer_table_types = ["pdf", "jpg", "png", "heic", "webp"]

    if file is not None:
"""


def _req(method, path, body=None):
    req = urllib.request.Request(
        "https://api.github.com" + path,
        data=json.dumps(body).encode("utf-8") if body else None,
        headers={**HEADERS, "Content-Type": "application/json"}, method=method)
    try:
        with urllib.request.urlopen(req, timeout=90) as r:
            return json.loads(r.read() or b"{}")
    except Exception as e:  # noqa: BLE001
        d = getattr(e, "read", lambda: b"")()
        return {"__error": str(e), "detail": d.decode("utf-8", "ignore")[:300]}


def build(text):
    problems = []
    for old, new, label in ((OLD_SIG, NEW_SIG, "签名默认值"),
                            (OLD_DOC, NEW_DOC, "文档字符串"),
                            (OLD_ANCHOR, NEW_ANCHOR, "函数体内解析")):
        if old not in text:
            problems.append(f"锚点未命中：{label}")
            continue
        text = text.replace(old, new, 1)
    return text, problems


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--yes", action="store_true")
    a = ap.parse_args()

    base = api("/repos/Unstructured-IO/unstructured/git/ref/heads/main")["object"]["sha"]
    base_commit = api(f"/repos/Unstructured-IO/unstructured/git/commits/{base}")
    tree_sha = base_commit["tree"]["sha"]
    cur = base64.b64decode(
        api(f"/repos/{FORK}/contents/{PATH}?ref={BRANCH}")["content"]).decode("utf-8")
    master = base64.b64decode(
        api(f"/repos/Unstructured-IO/unstructured/contents/{PATH}")["content"]).decode("utf-8")

    new, problems = build(master)
    print("master head:", base[:10], "| 分支当前文件", len(cur), "字符")
    print("校验:", "通过" if not problems else "；".join(problems))
    if problems:
        return 1
    try:
        ast.parse(new)
        print("AST 解析: 通过")
    except SyntaxError as e:
        print("AST 解析失败:", e)
        return 1

    d = list(difflib.unified_diff(master.splitlines(), new.splitlines(),
                                  fromfile="master", tofile="proposed", lineterm="", n=2))
    for ln in d[:40]:
        print("   ", ln[:150])

    out = os.path.join(HERE, "auto_patched.py")
    open(out, "w", encoding="utf-8", newline="\n").write(new)
    print("\n已写入", out)

    if not a.yes:
        print("确认后加 --yes 推送到 fork 分支。")
        return 0

    blob = _req("POST", f"/repos/{FORK}/git/blobs",
                {"content": base64.b64encode(new.encode()).decode(), "encoding": "base64"})
    tree = _req("POST", f"/repos/{FORK}/git/trees",
                {"base_tree": tree_sha,
                 "tree": [{"path": PATH, "mode": "100644", "type": "blob", "sha": blob["sha"]}]})
    commit = _req("POST", f"/repos/{FORK}/git/commits",
                  {"message": MSG, "tree": tree["sha"], "parents": [base]})
    if commit.get("__error"):
        print("commit 失败:", commit)
        return 1
    ref = _req("PATCH", f"/repos/{FORK}/git/refs/heads/{BRANCH}",
               {"sha": commit["sha"], "force": True})
    print("新 commit:", commit["sha"][:10],
          "| ref:", ref.get("object", {}).get("sha", "")[:10] if not ref.get("__error") else ref)
    return 0


if __name__ == "__main__":
    sys.exit(main())
