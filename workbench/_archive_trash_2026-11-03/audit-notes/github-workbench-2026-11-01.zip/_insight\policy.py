"""严格版：CLA / DCO / AI 披露策略。用词边界，避免 "class" 命中 "CLA"。"""
import base64
import json
import os
import re
import urllib.request

TOKEN = os.environ["GITHUB_TOKEN"]
REPOS = ["apache/airflow", "topoteretes/cognee", "rtk-ai/rtk", "nexu-io/open-design",
         "cvat-ai/cvat", "ueberdosis/tiptap", "aws/aws-cdk", "excalidraw/excalidraw",
         "OpenHands/OpenHands", "elastic/elasticsearch", "langgenius/dify", "grafana/grafana"]
CLA = re.compile(r"(\bCLA\b|Contributor License Agreement|\bDCO\b|"
                 r"Developer Certificate of Origin|signed-off-by|sign[- ]off)", re.I)
AI = re.compile(r"(AI-generated|AI usage|AI tools|ChatGPT|Copilot|Claude|LLM)", re.I)


def fetch(full, path):
    req = urllib.request.Request(
        f"https://api.github.com/repos/{full}/contents/{path}",
        headers={"Authorization": "Bearer " + TOKEN,
                 "Accept": "application/vnd.github+json",
                 "User-Agent": "insight-scout"})
    with urllib.request.urlopen(req, timeout=45) as r:
        return base64.b64decode(json.loads(r.read().decode())["content"]).decode("utf-8", "ignore")


for full in REPOS:
    txt, which = None, None
    for p in ("CONTRIBUTING.md", ".github/CONTRIBUTING.md", "docs/CONTRIBUTING.md"):
        try:
            txt, which = fetch(full, p), p
            break
        except Exception:
            continue
    print(f"\n### {full}  ({which})")
    if not txt:
        print("   （无 CONTRIBUTING 文件）")
        continue
    lines = txt.splitlines()
    cla = [l.strip() for l in lines if CLA.search(l)][:4]
    ai = [l.strip() for l in lines if AI.search(l)][:3]
    print("   CLA/DCO:", cla if cla else "未检出")
    print("   AI 政策:", ai if ai else "未检出")
