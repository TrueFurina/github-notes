"""Who is waiting on you: open PRs whose last comment is not yours.

The signal that matters most for a contributor is not "how many PRs are open",
it is "where has a human already replied and the ball is in my court".
Manually found this once for the Octop repos; this makes it account-wide.

Strategy: list all open PRs authored by me (search returns a comment COUNT, so
only PRs with comments > 0 need a further call), then keep those whose last
comment is from someone else.
"""

import sys

sys.path.insert(0, r"D:/github/github-audit")
from ghlib import OWNER, api  # noqa: E402


def open_prs():
    out, page = [], 1
    while page <= 4:
        r = api(f"/search/issues?q=author:{OWNER}+type:pr+state:open"
                f"&per_page=100&page={page}&sort=updated")
        items = (r or {}).get("items") or []
        out.extend(items)
        if len(items) < 100:
            break
        page += 1
    return out


def main():
    prs = open_prs()
    print(f"open PR 总数: {len(prs)}")
    with_comments = [p for p in prs if (p.get("comments") or 0) > 0]
    print(f"其中有人评论过: {len(with_comments)}\n")

    waiting, answered, only_bots = [], [], []
    bots = {"github-actions[bot]", "dependabot[bot]", "codecov[bot]", "coderabbitai[bot]",
            "copilot-pull-request-reviewer[bot]", "openshift-ci[bot]"}

    for p in with_comments:
        repo = p["repository_url"].split("/repos/")[-1]
        cs = api(f"/repos/{repo}/issues/{p['number']}/comments?per_page=100")
        if not isinstance(cs, list) or not cs:
            continue
        human = [c for c in cs if c["user"]["login"] != OWNER
                 and c["user"]["login"] not in bots
                 and not c["user"]["login"].endswith("[bot]")]
        if not human:
            only_bots.append((repo, p["number"]))
            continue
        last = cs[-1]
        row = (repo, p["number"], p["title"][:52], human[-1]["user"]["login"],
               human[-1]["created_at"][:16], len(human))
        if last["user"]["login"] == OWNER:
            answered.append(row)
        else:
            waiting.append(row)

    print(f"=== 最后一条来自他人（在等你）: {len(waiting)} ===")
    for repo, num, title, who, at, n in sorted(waiting, key=lambda x: x[4], reverse=True):
        print(f"  {repo:38} #{num:<5} {n} 条 | 最近 {who} @ {at}")
        print(f"      {title}")
        print(f"      https://github.com/{repo}/pull/{num}")

    print(f"\n=== 已回应（最后一条是你）: {len(answered)} ===")
    for repo, num, title, who, at, n in answered[:12]:
        print(f"  {repo:38} #{num:<5} {n} 条 | {title[:40]}")

    print(f"\n=== 只有 bot 评论: {len(only_bots)} ===")


if __name__ == "__main__":
    main()
