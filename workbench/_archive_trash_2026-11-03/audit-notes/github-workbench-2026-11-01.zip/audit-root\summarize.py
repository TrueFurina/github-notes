import json, os, collections, time
from datetime import datetime, timezone

HERE = os.path.dirname(os.path.abspath(__file__))
d = json.load(open(os.path.join(HERE, "raw.json"), encoding="utf-8"))
u = d["user"]
repos = [r for r in d["repos"] if not r.get("__error")]
stars = [r for r in d.get("starred") or [] if not r.get("__error")]
events = [e for e in d.get("events") or [] if not e.get("__error")]

def dt(s):
    return datetime.fromisoformat(s.replace("Z", "+00:00")) if s else None

print("== PROFILE ==")
print("login", u.get("login"), "| name", u.get("name"), "| bio", u.get("bio"))
print("company", u.get("company"), "| blog", u.get("blog"), "| loc", u.get("location"),
      "| twitter", u.get("twitter_username"))
print("public_repos", u.get("public_repos"), "followers", u.get("followers"),
      "following", u.get("following"), "created", u.get("created_at"))

own = [r for r in repos if not r.get("fork")]
forks = [r for r in repos if r.get("fork")]
arch = [r for r in repos if r.get("archived")]
print("\n== REPO CENSUS ==")
print("total", len(repos), "own", len(own), "fork", len(forks), "archived", len(arch))

langs = collections.Counter()
for r in own:
    if r.get("language"):
        langs[r["language"]] += 1
print("langs(own):", langs.most_common(12))

starsum = sorted(own, key=lambda r: -r.get("stargazers_count", 0))[:12]
print("\ntop by stars:")
for r in starsum:
    print(f"  {r['name'][:34]:34} s={r['stargazers_count']:4} f={r['forks_count']:3} "
          f"{str(r.get('language'))[:10]:10} lic={r.get('license') and r['license']['spdx_id']} "
          f"push={r['pushed_at'][:10]} desc={bool(r.get('description'))} top={r.get('topics')}")

recent = sorted(own, key=lambda r: r["pushed_at"], reverse=True)[:15]
print("\nrecently pushed:")
for r in recent:
    print(f"  {r['name'][:30]:30} push={r['pushed_at'][:10]} size={r['size']:6}KB "
          f"openissues={r['open_issues_count']:3} lic={str(r.get('license') and r['license']['spdx_id'])}")

n = len(own)
print("\n== HYGIENE ==")
print("no_descr", sum(1 for r in own if not r.get("description")),
      "| no_license", sum(1 for r in own if not r.get("license")),
      "| no_topics", sum(1 for r in own if not r.get("topics")),
      "| homepage", sum(1 for r in own if r.get("homepage")),
      "| zero_star", sum(1 for r in own if r.get("stargazers_count") == 0),
      "| size<50KB", sum(1 for r in own if r.get("size", 0) < 50))
emptyish = [r["name"] for r in own if r.get("size", 0) < 20]
print("tiny repos(<20KB):", len(emptyish), emptyish[:25])

print("\n== STARRED ==")
sl = collections.Counter(s.get("language") for s in stars)
print("count", len(stars), "langs:", sl.most_common(10))
owners = collections.Counter(s["owner"]["login"] for s in stars)
print("top owners:", owners.most_common(12))
print("starred repos (topics):", collections.Counter(
    t for s in stars for t in (s.get("topics") or [])).most_common(15))

print("\n== ACTIVITY ==")
typ = collections.Counter(e["type"] for e in events)
print("events", len(events), dict(typ))
if events:
    print("window", events[-1]["created_at"][:10], "->", events[0]["created_at"][:10])
h = collections.Counter(dt(e["created_at"]).hour for e in events if dt(e["created_at"]))
print("hour histogram(UTC):", sorted(h.items()))
wd = collections.Counter(dt(e["created_at"]).weekday() for e in events if dt(e["created_at"]))
print("weekday(0=Mon):", sorted(wd.items()))
per_repo = collections.Counter(f"{e['repo']['name']}" for e in events)
print("event repos:", per_repo.most_common(15))

print("\n== ORGS ==")
for o in d.get("orgs") or []:
    print(" ", o.get("login"), o.get("description"))
print("\n== RATE ==", (d.get("rate_limit") or {}).get("rate"))
