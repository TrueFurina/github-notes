import json, subprocess, time, urllib.request, http.client, collections, urllib.parse

TOKEN = subprocess.run(["powershell","-NoProfile","-Command",
    "[Environment]::GetEnvironmentVariable('GITHUB_TOKEN','User')"],
    capture_output=True, text=True).stdout.strip()
H = {"Authorization":"Bearer "+TOKEN,"User-Agent":"raccoon","Accept":"application/vnd.github+json","Connection":"close"}

def get(url):
    for i in range(4):
        try:
            r = urllib.request.Request(url, headers=H)
            with urllib.request.urlopen(r, timeout=45) as resp:
                parts=[]
                try:
                    while True:
                        b=resp.read(16384)
                        if not b: break
                        parts.append(b)
                except http.client.IncompleteRead as e:
                    parts.append(e.partial)
                return json.loads(b"".join(parts))
        except Exception as e:
            time.sleep(2)
    return None

q = urllib.parse.quote("is:pr author:TrueFurina -user:TrueFurina")
ext, total = [], None
for page in range(1,5):
    d=get(f"https://api.github.com/search/issues?q={q}&per_page=50&page={page}")
    if not d or "items" not in d: break
    total = d.get("total_count")
    ext.extend(d["items"])
    if len(d["items"])<50: break

print("EXTERNAL PR total:", total, "sampled:", len(ext))
merged=[i for i in ext if i.get("pull_request",{}).get("merged_at")]
closed_un=[i for i in ext if i["state"]=="closed" and not i.get("pull_request",{}).get("merged_at")]
op=[i for i in ext if i["state"]=="open"]
print(f"merged={len(merged)} closed_unmerged={len(closed_un)} open={len(op)}")
print("distinct repos:", len({i['repository_url'] for i in ext}))
print("by date:", collections.Counter(i["created_at"][:10] for i in ext).most_common(10))
print("by type prefix:", collections.Counter(i["title"].split(":")[0].split("(")[0].strip().lower() for i in ext).most_common(10))
print("by month:", collections.Counter(i["created_at"][:7] for i in ext).most_common())

# how many external PRs have body length tiny (drive-by)
short=[i for i in ext if len(i.get("body") or "")<120]
print("body<120 chars:", len(short), "/", len(ext))

# touched files per PR sample
files_stat=[]
for i in ext[:12]:
    fn=i["repository_url"].split("/repos/")[-1]
    f=get(f"https://api.github.com/repos/{fn}/pulls/{i['number']}/files")
    if isinstance(f,list):
        files_stat.append((fn, i["number"], len(f), [x["filename"] for x in f][:4]))
for x in files_stat: print("  ", x[0], "#"+str(x[1]), "files=", x[2], x[3])

json.dump(ext, open("ext_prs.json","w",encoding="utf-8"), ensure_ascii=False)