import json, subprocess, time, urllib.request, http.client, base64, re

TOKEN = subprocess.run(["powershell","-NoProfile","-Command",
    "[Environment]::GetEnvironmentVariable('GITHUB_TOKEN','User')"],
    capture_output=True, text=True).stdout.strip()
H = {"Authorization":"Bearer "+TOKEN,"User-Agent":"raccoon","Accept":"application/vnd.github+json","Connection":"close"}

def get(url):
    for i in range(3):
        try:
            r = urllib.request.Request(url, headers=H)
            with urllib.request.urlopen(r, timeout=45) as resp:
                parts=[]
                try:
                    while True:
                        b=resp.read(16384)
                        if not b: break
                        parts.append(b)
                except http.client.IncompleteRead as e:
                    parts.append(e.partial)
                return json.loads(b"".join(parts))
        except Exception:
            time.sleep(2)
    return None

print("=== LARGE REPO BLOAT ===")
for fn in ["SecAutoMind-src","MARS-408","coastal-traffic-visual-analytics","2026-crypto-math-challenge","2025-Challenge-Cup-CyberRange-AI-Arena","cyber-terms-hub","MangDeHenZhi","Denia"]:
    c=get(f"https://api.github.com/repos/TrueFurina/{fn}/contents/")
    if not isinstance(c,list):
        print(fn,"?", c); continue
    # sizes of top-level dirs
    big=[]
    for x in c:
        if x["type"]=="dir":
            sub=get(f'https://api.github.com/repos/TrueFurina/{fn}/contents/{urllib.parse.quote(x["name"])}')
            if isinstance(sub,list):
                sz=sum(i.get("size",0) for i in sub if i["type"]=="file")
                if sz>2_000_000: big.append((x["name"], round(sz/1e6,1)))
    binfiles=[(x["name"],round(x.get("size",0)/1e6,1)) for x in c if x["type"]=="file" and x.get("size",0)>1_000_000]
    ga=get(f"https://api.github.com/repos/TrueFurina/{fn}/contents/.gitattributes")
    lfs="?"
    if ga and ga.get("content"):
        lfs = "LFS" if "lfs" in base64.b64decode(ga["content"]).decode("utf-8","replace").lower() else "no-LFS"
    print(f'{fn:38s} lfs={lfs:6s} bigdirs={big[:4]} bigfiles={binfiles[:4]}')

print("\n=== PRIVACY: personal info in repo names/content ===")
c=get("https://api.github.com/repos/TrueFurina/2026-crypto-math-challenge/contents/")
if isinstance(c,list):
    for x in c:
        n=x["name"]
        flag = bool(re.search(r'\d{8,}|张|同学|学号|docx|pdf', n))
        if flag: print("  ", n, x["type"], round(x.get("size",0)/1e6,2),"MB")

print("\n=== FORK CLEANUP CANDIDATE: forks with zero own commits ===")
d=json.load(open("raw.json",encoding="utf-8"))
forks=[r for r in d["repos"] if r.get("fork")]
dead=[r for r in forks if r["pushed_at"]==r["created_at"]]
print("forks never pushed:", len(dead), "/", len(forks))
print("sample:", [r["name"] for r in dead[:15]])