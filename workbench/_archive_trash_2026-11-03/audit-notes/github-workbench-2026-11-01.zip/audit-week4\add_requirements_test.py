"""给 Denia 补 requirements-test.txt，并让 ci.yml 从它安装依赖。

动机（2026-10-30）：
    CI 的 pip 行是手写的包名清单，每加一个测试都可能再红一轮（websockets、ollama 各让
    CI 多跑了一次）。把清单落成文件，是让"缺哪个包"这件事有唯一真源。

改动分两步、两个 commit（Contents API 一次一个文件）：
    1. 新增 requirements-test.txt
    2. ci.yml 的两个 job 改为 `pip install -r requirements-test.txt`

幂等：文件已存在且内容相同则跳过；ci.yml 锚点已替换也跳过。
用法：python add_requirements_test.py [--yes]
"""
from __future__ import annotations

import base64
import json
import os
import sys
import urllib.error
import urllib.request
from urllib.parse import quote

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from ghlib import HEADERS, OWNER, api  # noqa: E402

REPO = f"{OWNER}/Denia"
BRANCH = "master"
LOCAL = os.path.join(os.path.dirname(os.path.abspath(__file__)), "requirements-test.txt")
REQ_PATH = "requirements-test.txt"
CI_PATH = ".github/workflows/ci.yml"

# ci.yml 里两条手写 pip 行 → 统一读文件
OLD_SELF = ("          python -m pip install PyYAML httpx numpy websockets requests "
            "rich psutil Pillow mss ollama dashscope pywebview")
OLD_PYTEST = ("          python -m pip install pytest PyYAML httpx numpy websockets requests "
              "rich psutil Pillow mss ollama dashscope pywebview")
NEW_PIP = "          python -m pip install -r requirements-test.txt"


def put(path: str, text: str, sha: str | None, message: str) -> tuple[int, dict]:
    body = {"message": message,
            "content": base64.b64encode(text.encode("utf-8")).decode(),
            "branch": BRANCH}
    if sha:
        body["sha"] = sha
    url = f"https://api.github.com/repos/{REPO}/contents/{quote(path, safe='/')}"
    req = urllib.request.Request(url, data=json.dumps(body).encode("utf-8"),
                                 headers={**HEADERS, "Content-Type": "application/json; charset=utf-8"},
                                 method="PUT")
    try:
        with urllib.request.urlopen(req, timeout=90) as r:
            d = json.loads(r.read())
        return r.status, {"commit": d["commit"]["sha"][:12]}
    except urllib.error.HTTPError as e:
        return e.code, {"detail": e.read().decode("utf-8", "ignore")[:240]}


def main() -> int:
    dry = "--yes" not in sys.argv
    new_req = open(LOCAL, encoding="utf-8").read()

    print("=" * 74)
    print("步骤 1/2 · requirements-test.txt")
    cur = api(f"/repos/{REPO}/contents/{REQ_PATH}?ref={BRANCH}")
    if isinstance(cur, dict) and cur.get("sha"):
        sha = cur["sha"]
        old = base64.b64decode(cur["content"]).decode("utf-8")
        if old == new_req:
            print("  已存在且内容一致，跳过")
        else:
            print(f"  已存在（{len(old)} 字符）→ 覆盖为 {len(new_req)} 字符")
            if not dry:
                print("  写入:", put(REQ_PATH, new_req, sha,
                                    "test: add requirements-test.txt (single source for CI deps)\n\n"
                                    "CI 的 pip 行原是手写清单，websockets / ollama 各让 CI 多红过一轮。\n"
                                    "把测试依赖落成文件，缺包时只有一个地方要改。"))
    else:
        print(f"  新建 {len(new_req)} 字符 / {len(new_req.splitlines())} 行")
        if not dry:
            print("  写入:", put(REQ_PATH, new_req, None,
                                "test: add requirements-test.txt (single source for CI deps)\n\n"
                                "CI 只需要跑测试，不必装 74 行运行依赖（含 PyAudio/pycaw/vosk 等，\n"
                                "在 Windows runner 上没有设备）。清单由 CI 实际缺失项反推，\n"
                                "每条都对应一次真实失败。"))
        else:
            print("  （dry-run 未写入）")

    print("\n" + "=" * 74)
    print("步骤 2/2 · ci.yml 改为读文件")
    ci = api(f"/repos/{REPO}/contents/{CI_PATH}?ref={BRANCH}")
    if not (isinstance(ci, dict) and ci.get("content")):
        print("  读不到 ci.yml:", ci)
        return 1
    text = base64.b64decode(ci["content"]).decode("utf-8")
    hits = 0
    new = text
    for old_line in (OLD_SELF, OLD_PYTEST):
        if old_line in new:
            new = new.replace(old_line, NEW_PIP, 1)
            hits += 1
    if hits == 0:
        print("  两条 pip 行都已是目标形态（或锚点未命中），跳过")
    else:
        print(f"  替换 {hits} 条 pip 行 -> {NEW_PIP.strip()}")
        if not dry:
            print("  写入:", put(CI_PATH, new, ci["sha"],
                                "ci: install test deps from requirements-test.txt\n\n"
                                "两个 job 原来各有一份手写包名清单，容易漏（websockets/ollama 都漏过）。\n"
                                "改为读同一份文件。"))
        else:
            print("  （dry-run 未写入）")

    if dry:
        print("\n这是 dry-run。加 --yes 执行。")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
