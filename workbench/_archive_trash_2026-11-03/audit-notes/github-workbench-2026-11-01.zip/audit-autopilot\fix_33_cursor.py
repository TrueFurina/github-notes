"""修 `octop-memory #33`：只有"真的比较过"的原子才推进审计游标。

PR 原来的改动把 `checked[atom.id] = hashes[atom.id]` 提到了判断之前，于是三种情况全被记成
"已审计"：

    1. match 存在但 uncertain   → 确实比较过，结论不确定     ✅ 该记（这是 PR 想解决的）
    2. match is None            → **没比较过**（LLM 异常/不可用/批次中断）  ❌ 不该记
    3. 事实已变/已废止/取不到   → 需要重审                     ❌ 不该记

第 2 类的后果最严重：`checked` 会被持久化进 meta，下一次 `remaining = sum(checked != hashes)`
直接算出 0 —— **一次瞬时的 LLM 故障会把整批事实永久标成"已核对"**，报告 status 里那几个原子的
"不确定"从此消失。这正是这个仓库最忌讳的"假绿"。

改法：把三种情况拆开，只在"确实比较过"时推进。

用法：python autopilot/fix_33_cursor.py [--yes]
"""
from __future__ import annotations

import ast
import base64
import json
import os
import sys
import urllib.error
import urllib.request
from urllib.parse import quote

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from ghlib import HEADERS, api  # noqa: E402

PR = 33
UPSTREAM = "TencentCloud/octop-memory"
PATH = "src/octop_memory/operations/retention.py"

OLD = '''            checked[atom.id] = hashes[atom.id]
            if match is None or match.get("uncertain") or current is None or current.deprecated_at is not None or current.assertion != atom.assertion:
                continue
'''

NEW = '''            # 只有"确实比较过"的原子才推进游标。三种情况必须分开：
            #   1) match is None  → 没比较（LLM 异常 / 不可用 / 批次中断），不能记，
            #      否则一次瞬时故障会把事实永久标成已核对（假绿）。
            #   2) 事实已变/已废止 → 需要重审，不能记。
            #   3) match.uncertain → 比较过但结论不确定，记下游标避免无限重审（本 PR 的初衷）。
            if match is None:
                continue
            if current is None or current.deprecated_at is not None or current.assertion != atom.assertion:
                continue
            checked[atom.id] = hashes[atom.id]
            if match.get("uncertain"):
                continue
'''


def main() -> int:
    dry = "--yes" not in sys.argv
    d = api(f"/repos/{UPSTREAM}/pulls/{PR}")
    head_repo, branch = d["head"]["repo"]["full_name"], d["head"]["ref"]
    print(f"PR #{PR}: {head_repo} @ {branch} (head {d['head']['sha'][:8]})")

    cur = api(f"/repos/{head_repo}/contents/{quote(PATH, safe='/')}?ref={branch}")
    if not (isinstance(cur, dict) and cur.get("content")):
        print("读不到:", cur)
        return 1
    text = base64.b64decode(cur["content"]).decode("utf-8")

    if "只有\"确实比较过\"的原子才推进游标" in text:
        print("已应用过，跳过")
        return 0
    if OLD not in text:
        print("锚点未命中，当前片段：")
        lines = text.splitlines()
        for i, ln in enumerate(lines, 1):
            if "checked[atom.id] = hashes[atom.id]" in ln:
                for n in range(max(0, i - 2), min(len(lines), i + 3)):
                    print(f"  {n+1:4}| {lines[n]}")
        return 1

    new = text.replace(OLD, NEW, 1)
    try:
        ast.parse(new)
        ok = True
    except SyntaxError as e:
        ok = False
        print("改后语法错误:", e.lineno, e.msg)
    print(f"改动：3 行 → 12 行（+{len(new.splitlines()) - len(text.splitlines())}），语法 {'OK' if ok else 'FAIL'}")
    if not ok:
        return 1
    if dry:
        print("\n这是 dry-run。加 --yes 写入。")
        return 0

    body = {"message": "fix(retention): only advance the audit cursor for atoms actually compared\n\n"
                       "The previous version recorded the hash before the match check, so three\n"
                       "different cases all counted as audited: (1) uncertain — intended, (2) no\n"
                       "match at all because the LLM failed or the batch broke — this would mark\n"
                       "facts as audited after a single transient failure and persist it in\n"
                       "`checked`, (3) stale/deprecated atoms that still need review. Split them:\n"
                       "advance only when a comparison actually happened.",
            "content": base64.b64encode(new.encode("utf-8")).decode(),
            "sha": cur["sha"], "branch": branch}
    req = urllib.request.Request(
        f"https://api.github.com/repos/{head_repo}/contents/{quote(PATH, safe='/')}",
        data=json.dumps(body).encode("utf-8"),
        headers={**HEADERS, "Content-Type": "application/json; charset=utf-8"},
        method="PUT")
    try:
        with urllib.request.urlopen(req, timeout=90) as r:
            print("写入 HTTP", r.status, json.loads(r.read())["commit"]["sha"][:12])
    except urllib.error.HTTPError as e:
        print("失败", e.code, e.read().decode("utf-8", "ignore")[:240])
        return 1
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
