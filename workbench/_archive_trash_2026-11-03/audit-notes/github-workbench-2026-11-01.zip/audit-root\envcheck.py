import json, subprocess, time, urllib.request, http.client, base64, re

TOKEN = subprocess.run(["powershell","-NoProfile","-Command",
    "[Environment]::GetEnvironmentVariable('GITHUB_TOKEN','User')"],
    capture_output=True, text=True).stdout.strip()
H = {"Authorization":"Bearer "+TOKEN,"User-Agent":"raccoon","Accept":"application/vnd.github+json","Connection":"close"}

def get(url):
    for i in range(3):
        try:
            r = urllib.request.Request(url, headers=H)
            with urllib.request.urlopen(r, timeout=45) as resp:
                parts=[]
                try:
                    while True:
                        b=resp.read(16384)
                        if not b: break
                        parts.append(b)
                except http.client.IncompleteRead as e:
                    parts.append(e.partial)
                return json.loads(b"".join(parts))
        except Exception:
            time.sleep(2)
    return None

c = get("https://api.github.com/repos/TrueFurina/MangDeZhiXun/contents/.env")
if c and c.get("content"):
    txt = base64.b64decode(c["content"]).decode("utf-8","replace")
    print("size:", len(txt), "lines:", len(txt.splitlines()))
    for line in txt.splitlines():
        line=line.strip()
        if not line or line.startswith("#"):
            continue
        if "=" in line:
            k,v=line.split("=",1)
            v=v.strip().strip('"').strip("'")
            verdict = "EMPTY" if not v else ("PLACEHOLDER" if re.search(r'your|xxx|changeme|placeholder|example|\*\*\*|\.\.\.', v, re.I) else f"LIVE? len={len(v)} head={v[:2]}***")
            print(f"  {k.strip():28s} {verdict}")
    # show file history count / whether it was ever removed
    commits = get("https://api.github.com/repos/TrueFurina/MangDeZhiXun/commits?path=.env&per_page=20")
    print("commits touching .env:", len(commits) if isinstance(commits,list) else "?")
else:
    print("not readable:", c)

# also check .env.example presence and .gitignore coverage on flagship repos
for fn in ["MangDeZhiXun","SecAutoMind-src","MARS-408","AGI-Distiller","passive-recon"]:
    g = get(f"https://api.github.com/repos/TrueFurina/{fn}/contents/.gitignore")
    cov="?"
    if g and g.get("content"):
        t=base64.b64decode(g["content"]).decode("utf-8","replace")
        cov = ".env" if re.search(r'^\.env', t, re.M) else "no-.env"
    print(fn, "gitignore .env:", cov)