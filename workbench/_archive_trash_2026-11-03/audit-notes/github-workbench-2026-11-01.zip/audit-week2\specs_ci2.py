"""Denia CI 第二版：区分 `pytest 用例` 与 `脚本式自检`。

首跑发现的事实：src/tests/ 下 41 个 .py 里，只有 5 个含 `def test_`（真 pytest 用例），
其余 36 个是自检脚本——import 阶段就跑完整检查、末尾 `sys.exit(1)`。
把脚本丢进 pytest 收集会抛 SystemExit，pytest 只能以 INTERNALERROR 中断整个会话。

所以 CI 分两条腿：
  · pytest 只跑那 5 个真用例；
  · self-check 逐个执行白名单里的自检脚本，按脚本粒度报告成败。
"""

CONFTEST = '''"""pytest 收集策略。

`src/tests/` 下混着两类文件：

1. **pytest 用例** —— 含 `def test_*()`，由 pytest 收集执行（当前 5 个）；
2. **自检脚本** —— 模块级顺序执行一段检查，打印 `OK/FAIL`，末尾 `sys.exit(1)` 收场。
   例如 `test_doctor_asr.py`、`test_doctor_voice_backend.py`。

第 2 类被 pytest 当成用例模块 import 时，会在 import 阶段抛出 `SystemExit`。
pytest 无法把 import 期的 SystemExit 记成普通失败，只能 `INTERNALERROR` **中断整个会话**
——结果是所有正常用例都跑不到。（2026-10-28 接入 CI 时实测：55 个文件 0 个用例执行。）

处置：下面按"文件里有没有 `def test_`"动态生成忽略名单。
新增脚本式自检会自动被排除，新增真用例会自动被收集，不用维护白名单。

脚本仍可单独执行，失败与否看退出码：

    python src/tests/test_doctor_asr.py

要把某个脚本改造成真用例：把检查体包进 `def test_xxx():`，`sys.exit(1)` 换成
`assert` / `pytest.fail`，改完这个文件就会自动被收集。
"""

import pathlib

_HERE = pathlib.Path(__file__).parent


def _is_script(path: pathlib.Path) -> bool:
    if not path.name.endswith(".py"):
        return False
    try:
        text = path.read_text(encoding="utf-8", errors="ignore")
    except OSError:
        return True
    return "def test_" not in text


# 脚本式自检（含辅助 harness）不参与 pytest 收集
collect_ignore = sorted(
    p.name for p in _HERE.glob("*.py") if _is_script(p)
)
'''

CI = """name: ci

on:
  push:
    branches: [master]
  pull_request:
  workflow_dispatch:

permissions:
  contents: read

# Windows runner 默认控制台编码不是 UTF-8；项目里的中文输出会抛
# UnicodeEncodeError: 'charmap' codec ...（2026-10-28 实测）。
env:
  PYTHONUTF8: "1"
  PYTHONIOENCODING: "utf-8"

concurrency:
  group: ci-${{ github.ref }}
  cancel-in-progress: true

jobs:
  syntax:
    name: syntax gate
    runs-on: windows-latest
    steps:
      - uses: actions/checkout@v4
      - uses: actions/setup-python@v5
        with:
          python-version: "3.12"
      - name: byte-compile (hard gate)
        run: python -m compileall -q src main.py tools
      - name: validate requirements syntax (advisory)
        continue-on-error: true
        run: python tools/check_requirements.py

  unit:
    name: pytest (real cases only)
    needs: syntax
    runs-on: windows-latest
    steps:
      - uses: actions/checkout@v4
      - uses: actions/setup-python@v5
        with:
          python-version: "3.12"
      - name: install test deps
        # 不装 PyAudio / sounddevice / pywebview：CI 无音频设备与桌面会话，
        # 装了只会让安装阶段先炸。依赖它们的用例会在 self-check 里被列为已知不可跑。
        run: |
          python -m pip install --upgrade pip
          python -m pip install pytest PyYAML httpx numpy websockets requests rich psutil Pillow mss ollama dashscope pywebview sounddevice
      - name: pytest
        run: python -m pytest src/tests -q -p no:cacheprovider

  self-check:
    name: self-check scripts (observe mode)
    needs: syntax
    runs-on: windows-latest
    # 观察模式：这些脚本历史上没有被自动跑过，先看真实失败面。
    # 连续稳定后，把不依赖音频/桌面的脚本移到硬门禁 job 里。
    continue-on-error: true
    env:
      SCRIPTS: >-
        test_config_schema.py
        test_config_env_refs.py
        test_config_path_refs.py
        test_config_migrate.py
        test_io_safe.py
        test_log_rotate.py
        test_secret_box.py
        test_package_secrets_scan.py
        test_make_dist_deps.py
        test_release_template.py
        test_check_await_sync.py
        test_check_async_blocking.py
    steps:
      - uses: actions/checkout@v4
      - uses: actions/setup-python@v5
        with:
          python-version: "3.12"
      - name: install deps
        run: |
          python -m pip install --upgrade pip
          python -m pip install PyYAML httpx numpy websockets requests rich psutil Pillow mss ollama dashscope pywebview sounddevice
      - name: run each self-check, report per script
        shell: pwsh
        run: |
          $failed = @()
          foreach ($s in $env:SCRIPTS -split '\\s+') {
            if (-not $s) { continue }
            Write-Host "::group::$s"
            python "src/tests/$s"
            if ($LASTEXITCODE -ne 0) {
              Write-Host "::error file=src/tests/$s::自检失败（exit $LASTEXITCODE）"
              $failed += $s
            }
            Write-Host "::endgroup::"
          }
          Write-Host ""
          Write-Host ("通过 {0} / 失败 {1}" -f (($env:SCRIPTS -split '\\s+' | Where-Object {$_}).Count - $failed.Count), $failed.Count)
          if ($failed.Count -gt 0) { Write-Host ("失败: " + ($failed -join ', ')) }
"""
