"""Read-only GitHub secret scan. Writes only _scan_*.json temp files."""
import base64
import json
import os
import re
import sys
import time

sys.path.insert(0, r"D:/github/github-audit")
from ghlib import api, OWNER  # noqa: E402

RAW = json.load(open(r"D:/github/github-audit/raw.json", encoding="utf-8"))
TARGETS = [x["name"] for x in sorted(
    [r for r in RAW["repos"]
     if r["owner"]["login"] == OWNER and not r["fork"] and not r["archived"]],
    key=lambda r: r.get("pushed_at") or "", reverse=True)][:25]

NAME_PATTERNS = [
    (r"(^|/)\.env($|\.)", "dotenv"),
    (r"(^|/)\.env\.", "dotenv"),
    (r"\.pem$", "pem"),
    (r"\.key$", "key"),
    (r"(^|/)id_rsa", "id_rsa"),
    (r"\.pfx$", "pfx"),
    (r"\.p12$", "p12"),
    (r"(^|/)config\.py$", "config.py"),
    (r"(^|/)settings\.py$", "settings.py"),
    (r"(^|/)secrets?\.", "secrets.*"),
    (r"credentials", "credentials"),
    (r"\.sql$", "sql"),
    (r"\.db$", "db"),
    (r"token.*\.json$", "token.json"),
    (r"(^|/)\.npmrc$", "npmrc"),
    (r"(^|/)\.pypirc$", "pypirc"),
    (r"\.ovpn$", "ovpn"),
    (r"\.kdbx$", "kdbx"),
]
BIN_EXT = {".png", ".jpg", ".jpeg", ".gif", ".webp", ".ico", ".zip", ".gz", ".tar",
           ".pdf", ".exe", ".dll", ".so", ".dylib", ".bin", ".woff", ".woff2",
           ".ttf", ".mp4", ".mp3", ".jar", ".class", ".pyc", ".wasm", ".7z",
           ".rar", ".xlsx", ".xls", ".docx", ".pptx", ".db", ".sqlite", ".pkl",
           ".onnx", ".pt", ".safetensors", ".mov", ".psd", ".iso"}

SECRET_PATTERNS = [
    ("openai_sk", r"\bsk-[A-Za-z0-9]{20,}"),
    ("github_pat", r"\bghp_[A-Za-z0-9]{36}\b"),
    ("github_oauth", r"\bgho_[A-Za-z0-9]{36}\b"),
    ("aws_akid", r"\bAKIA[0-9A-Z]{16}\b"),
    ("google_api", r"\bAIza[0-9A-Za-z\-_]{35}\b"),
    ("slack", r"\bxox[baprs]-[A-Za-z0-9-]{10,}"),
    ("jwt", r"\beyJ[A-Za-z0-9_-]{20,}\.[A-Za-z0-9_-]{20,}\.[A-Za-z0-9_-]{10,}"),
    ("private_key", r"-----BEGIN (RSA |OPENSSH |EC |DSA |PGP )?PRIVATE KEY( BLOCK)?-----"),
    ("intranet_ip", r"\b(?:10\.\d{1,3}\.\d{1,3}\.\d{1,3}|192\.168\.\d{1,3}\.\d{1,3}|172\.(?:1[6-9]|2\d|3[01])\.\d{1,3}\.\d{1,3})\b"),
    ("hardcoded_cred", r"(?i)\b(?:password|passwd|pwd|secret|api_key|apikey|access_key|token|app_secret)\b\s*[:=]\s*[\"']([^\"'\s]{8,})[\"']"),
    ("db_dsn", r"(?i)\b(?:mysql|postgres|postgresql|redis|mongodb|mssql|clickhouse)(?:\+[a-z0-9]+)?://[^\s\"'<>]{10,}"),
    ("bearer_literal", r"(?i)authorization\s*[:=]\s*[\"']?Bearer\s+[A-Za-z0-9\-._~+/]{20,}"),
]
PLACEHOLDER = re.compile(
    r"(?i)(your|xxx|placeholder|example|dummy|test_key|fake|changeme|change_me|"
    r"<[^>]*>|\$\{\{|%\(|\*{3,}|sample|redacted|todo|xxxx|abc123|123456|password123|"
    r"sk-xxx|ghp_xxx|none|null|true|false|\[|\])")


CACHE_PATH = r"D:/github/github-audit/_scan_trees_cache.json"
TREE_CACHE = {}
if os.path.exists(CACHE_PATH):
    TREE_CACHE = json.load(open(CACHE_PATH, encoding="utf-8"))


def _fast_json(path, timeout=25):
    """One-shot GET; returns None fast on truncation/JSON error (proxy cuts >500KB)."""
    import urllib.request
    from ghlib import HEADERS
    url = "https://api.github.com" + path
    try:
        req = urllib.request.Request(url, headers=HEADERS)
        with urllib.request.urlopen(req, timeout=timeout) as r:
            raw = r.read(600 * 1024)
        return json.loads(raw)
    except Exception:
        return None


def get_tree(repo, branch):
    """Return (blobs, mode). Recursive first, BFS fallback for >500KB trees."""
    if repo in TREE_CACHE:
        return TREE_CACHE[repo]["blobs"], TREE_CACHE[repo]["mode"]

    blobs, mode = None, None
    r = _fast_json(f"/repos/{OWNER}/{repo}/git/trees/{branch}?recursive=1", timeout=12)
    if isinstance(r, dict) and r.get("tree") and not r.get("truncated"):
        blobs = [{"path": t["path"], "size": t.get("size", 0)} for t in r["tree"]
                 if t["type"] == "blob"]
        mode = "recursive"
    if blobs is None:
        blobs, queue, seen, failed = [], [(branch, "")], set(), []
        from concurrent.futures import ThreadPoolExecutor

        def one(item):
            sha, prefix = item
            t = _fast_json(f"/repos/{OWNER}/{repo}/git/trees/{sha}", timeout=10)
            if isinstance(t, dict) and t.get("tree"):
                return prefix, [(prefix + e["path"],
                                 "tree" if e["type"] == "tree" else "blob",
                                 e.get("size", 0), e["sha"]) for e in t["tree"]], None
            c = _fast_json(f"/repos/{OWNER}/{repo}/contents/{prefix.rstrip('/')}"
                           f"?ref={branch}", timeout=10)
            if isinstance(c, list):
                return prefix, [(f"{prefix}{e['name']}",
                                 "tree" if e["type"] == "dir" else "blob",
                                 e.get("size", 0), f"{prefix}{e['name']}") for e in c], None
            return prefix, None, prefix or "/"

        with ThreadPoolExecutor(max_workers=8) as pool:
            while queue:
                batch, queue = queue[:200], queue[200:]
                for prefix, tree, err in pool.map(one, batch):
                    if tree is None:
                        failed.append(err)
                        continue
                    for p, typ, size, sha in tree:
                        if typ == "blob":
                            blobs.append({"path": p, "size": size})
                        elif sha not in seen:
                            seen.add(sha)
                            queue.append((sha, p + "/"))
        mode = "bfs" + (f"(unscanned:{len(failed)})" if failed else "")
        if failed:
            print(f"  !! unscanned dirs: {failed[:5]}", flush=True)
    TREE_CACHE[repo] = {"blobs": blobs, "mode": mode}
    json.dump(TREE_CACHE, open(CACHE_PATH, "w", encoding="utf-8"))
    return blobs, mode


def fetch_text(repo, path, ref):
    from urllib.parse import quote
    q = quote(path)
    r = api(f"/repos/{OWNER}/{repo}/contents/{q}?ref={ref}")
    if not isinstance(r, dict) or "content" not in r:
        return None, r
    try:
        raw = base64.b64decode(r["content"])
    except Exception:
        return None, "b64fail"
    if b"\x00" in raw[:4096]:
        return None, "binary"
    if len(raw) > 200 * 1024:
        return None, "too-big"
    return raw.decode("utf-8", "ignore"), None


def name_hits(path):
    out = []
    for pat, label in NAME_PATTERNS:
        if re.search(pat, path, re.I if label in ("token.json",) else 0):
            out.append(label)
    return sorted(set(out))


def mask(s):
    s = s.strip()
    if len(s) <= 8:
        return s[:2] + "****"
    return s[:4] + "****" + s[-4:]


def main():
    repo_meta = {x["name"]: x for x in RAW["repos"]}
    results = []
    for repo in TARGETS:
        meta = repo_meta[repo]
        branch = meta.get("default_branch") or "main"
        t0 = time.time()
        blobs, mode = get_tree(repo, branch)
        cands = []
        for b in blobs:
            labels = name_hits(b["path"])
            if labels:
                cands.append({"path": b["path"], "size": b.get("size", 0),
                              "labels": labels})
        print(f"[{repo}] blobs={len(blobs)} mode={mode} candidates={len(cands)} "
              f"{time.time()-t0:.1f}s", flush=True)
        results.append({"repo": repo, "branch": branch, "mode": mode,
                        "size_kb": meta.get("size"), "private": meta.get("private"),
                        "pushed_at": meta.get("pushed_at"),
                        "blob_count": len(blobs), "candidates": cands,
                        "hits": []})
        json.dump(results, open(r"D:/github/github-audit/_scan_trees.json", "w",
                                encoding="utf-8"), ensure_ascii=False, indent=1)

    # scan contents
    for entry in results:
        repo, ref = entry["repo"], entry["branch"]
        for c in entry["candidates"][:60]:
            ext = os.path.splitext(c["path"])[1].lower()
            if ext in BIN_EXT:
                c["skipped"] = "binary-ext"
                continue
            if c.get("size", 0) > 200 * 1024:
                c["skipped"] = "too-big"
                continue
            text, err = fetch_text(repo, c["path"], ref)
            if text is None:
                c["skipped"] = str(err)
                continue
            c["scanned"] = True
            for kind, pat in SECRET_PATTERNS:
                for m in re.finditer(pat, text):
                    val = m.group(0)
                    line_no = text[:m.start()].count("\n") + 1
                    line = text.splitlines()[line_no - 1][:300] if line_no <= len(text.splitlines()) else ""
                    if kind in ("intranet_ip",):
                        if re.search(r"(?i)(example|sample|test|dummy|0\.0\.0\.0|127\.0\.0\.1)", line):
                            continue
                    elif PLACEHOLDER.search(val) or PLACEHOLDER.search(line[:160]):
                        # keep placeholder handling but allow real key formats
                        if kind in ("openai_sk", "github_pat", "github_oauth",
                                    "aws_akid", "google_api", "slack", "jwt",
                                    "private_key"):
                            if not re.search(r"(?i)(xxx|your|placeholder|example|dummy|sample|<)", val):
                                pass
                            else:
                                continue
                        else:
                            continue
                    entry["hits"].append({"path": c["path"], "kind": kind,
                                          "line": line_no, "masked": mask(val),
                                          "ctx": line.strip()[:200]})
            time.sleep(0.15)
        json.dump(results, open(r"D:/github/github-audit/_scan_results.json", "w",
                                encoding="utf-8"), ensure_ascii=False, indent=1)
        print(f"[{repo}] done hits={len(entry['hits'])}", flush=True)
    print("TOTAL repos", len(results), "hits", sum(len(e["hits"]) for e in results))


if __name__ == "__main__":
    main()
