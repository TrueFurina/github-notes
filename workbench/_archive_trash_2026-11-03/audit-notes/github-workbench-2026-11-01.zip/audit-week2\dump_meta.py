"""只读摸底：为缺 description / topics 的仓库拉 README 摘要，为零文档仓拉目录树。"""
import base64
import json
import os
import re
import sys

sys.path.insert(0, r"D:/github/github-audit")
from ghlib import api, api_all, OWNER  # noqa: E402

HERE = os.path.dirname(os.path.abspath(__file__))
OUT = os.path.join(HERE, "week2")
os.makedirs(OUT, exist_ok=True)

repos = api_all(f"/user/repos?affiliation=owner&sort=pushed", per=25, cap=300)
own = [r for r in repos if not r.get("fork")]
print("own repos:", len(own))

need_desc = [r for r in own if not r.get("description")]
need_topic = [r for r in own if not r.get("topics")]
print("缺 description:", len(need_desc), "| 缺 topics:", len(need_topic))


def readme_head(repo, branch, n=6):
    r = api(f"/repos/{OWNER}/{repo}/contents/README.md?ref={branch}")
    if not (isinstance(r, dict) and r.get("content")):
        for alt in ("README.zh.md", "readme.md"):
            r = api(f"/repos/{OWNER}/{repo}/contents/{alt}?ref={branch}")
            if isinstance(r, dict) and r.get("content"):
                break
        else:
            return None
    txt = base64.b64decode(r["content"]).decode("utf-8", "ignore")
    lines = []
    for ln in txt.split("\n"):
        s = ln.strip()
        if not s or s.startswith(("<", "![", "[![", "|", "```", "---")):
            continue
        s = re.sub(r"^#+\s*", "", s)
        s = re.sub(r"\[([^\]]*)\]\([^)]*\)", r"\1", s)
        s = re.sub(r"[*`>]", "", s).strip()
        if len(s) < 4:
            continue
        lines.append(s[:150])
        if len(lines) >= n:
            break
    return lines


rows = []
for r in sorted(own, key=lambda x: x["pushed_at"], reverse=True):
    name = r["name"]
    head = readme_head(name, r["default_branch"])
    rows.append({
        "name": name,
        "desc": r.get("description"),
        "topics": r.get("topics") or [],
        "lang": r.get("language"),
        "size_kb": r.get("size"),
        "pushed": r["pushed_at"][:10],
        "private": r.get("private"),
        "head": head,
    })

with open(os.path.join(OUT, "repos_dump.json"), "w", encoding="utf-8") as f:
    json.dump(rows, f, ensure_ascii=False, indent=1)

for x in rows:
    flag = []
    if not x["desc"]:
        flag.append("NO-DESC")
    if not x["topics"]:
        flag.append("NO-TOPICS")
    if x["head"] is None:
        flag.append("NO-README")
    if not flag:
        continue
    print(f"\n[{','.join(flag)}] {x['name']}  ({x['lang']}, {x['size_kb']}KB, {x['pushed']}"
          f"{', private' if x['private'] else ''})")
    print("   desc:", (x["desc"] or "-")[:100])
    for h in (x["head"] or [])[:4]:
        print("   ·", h[:130])
