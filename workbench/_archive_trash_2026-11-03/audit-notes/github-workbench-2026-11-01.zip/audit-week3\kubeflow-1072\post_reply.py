"""发布 kubeflow #1072 的修复说明评论（默认 dry-run）。"""
import argparse
import json
import sys
import urllib.request

sys.path.insert(0, r"D:/github/github-audit")
from ghlib import api, HEADERS  # noqa: E402

SHA = "df25a71"

BODY = """Thanks @juliusvonkohout — both points are addressed in `df25a71`, now a single
DCO-signed commit rebased on current `master` (+65/−0 and +18/−0, two files).

**1. Kubernetes version selection.** You were right that the version input was decorative:
`kubernetes-version` only fed `kubectl_version`, while the cluster's server version was decided
by the `kind-node-image` default. Overriding the version alone still produced a v1.37.0 cluster —
the exact failure mode this action is meant to prevent.

The image now follows the version unless it is pinned explicitly:

```yaml
kind-node-image:
  default: ""            # was: kindest/node:v1.37.0@sha256:...
node_image: ${{ inputs.kind-node-image || format('kindest/node:{0}', inputs.kubernetes-version) }}
```

- default path: `kubernetes-version: v1.36.0` → `kindest/node:v1.36.0` and kubectl v1.36.0, one input, one version;
- pinned path: set `kind-node-image` to `tag@sha256:...` and it wins, so digest pinning is still available for supply-chain reasons.

Both input descriptions now say which one takes precedence.

**2. License headers.** Both new YAML files start with the year-less Apache-2.0 header copied
verbatim from `hack/boilerplate/boilerplate.sh.txt`. The `sh` template is the right one here:
`boilerplate.py` maps `yaml`/`yml` to the `sh` stem in `EXTENSION_TEMPLATES`.

**What I did not verify.** YAML parses and the headers match the template byte-for-byte, but I
could not exercise real cluster creation — no Docker on my side either. So this is not evidence
that the Kind bootstrap works end to end, only that the two review points are gone. If you want
that covered, a smoke job that creates a cluster with `kubernetes-version: v1.36.0` and asserts
`kubectl version` would close the gap.
"""


def _post(body):
    req = urllib.request.Request(
        "https://api.github.com/repos/kubeflow/testing/issues/1072/comments",
        data=json.dumps({"body": body}).encode("utf-8"),
        headers={**HEADERS, "Content-Type": "application/json"}, method="POST")
    try:
        with urllib.request.urlopen(req, timeout=60) as r:
            return json.loads(r.read())
    except Exception as e:  # noqa: BLE001
        detail = getattr(e, "read", lambda: b"")()
        return {"__error": str(e), "detail": detail.decode("utf-8", "ignore")[:200]}


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--yes", action="store_true")
    a = ap.parse_args()

    if SHA not in (api("/repos/kubeflow/testing/pulls/1072")["head"]["sha"]):
        print("警告：分支 head 已不是", SHA, "——评论里的 sha 需要更新")

    cs = api("/repos/kubeflow/testing/issues/1072/comments?per_page=30") or []
    if any("both points are addressed" in (c["body"] or "") for c in cs):
        print("已经发过一次，跳过")
        return 0

    if not a.yes:
        print("[试运行] 将发布评论，正文 %d 字符：\n" % len(BODY))
        print(BODY[:400], "...\n")
        return 0

    r = _post(BODY)
    print("已发布:", r.get("html_url") if not r.get("__error")
          else f"ERROR {r['__error']} {r.get('detail','')[:150]}")


if __name__ == "__main__":
    main()
