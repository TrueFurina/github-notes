"""改名后校验：旧链接是否 301、新 Release 是否可下载、Pages 地址变成什么。"""
import sys
import urllib.error
import urllib.request

sys.path.insert(0, r"D:/github/github-audit")
from ghlib import api, OWNER  # noqa: E402


class NoRedirect(urllib.request.HTTPRedirectHandler):
    def redirect_request(self, *a, **k):
        return None


def probe(url):
    op = urllib.request.build_opener(NoRedirect)
    try:
        with op.open(urllib.request.Request(url, headers={"User-Agent": "verify"}), timeout=30) as r:
            return r.status, r.headers.get("Location")
    except urllib.error.HTTPError as e:
        return e.code, e.headers.get("Location")
    except Exception as e:  # noqa: BLE001
        return "ERR", str(e)[:60]


print("== 仓库改名重定向（期望 301 且 Location 指向新名） ==")
for old in ("SecAutoMind", "SecAutoMind-src"):
    code, loc = probe(f"https://api.github.com/repos/{OWNER}/{old}")
    print(f"  {old:18} -> {code}  Location={loc}")

print("\n== 新仓库实体 ==")
for name in ("SecAutoMind", "SecAutoMind-site"):
    r = api(f"/repos/{OWNER}/{name}")
    if isinstance(r, dict) and "__error" in r:
        print(f"  {name:18} 不存在")
        continue
    rels = api(f"/repos/{OWNER}/{name}/releases")
    print(f"  {name:18} size={r['size']}KB stars={r['stargazers_count']} "
          f"releases={len(rels) if isinstance(rels, list) else '?'} homepage={r.get('homepage')}")

print("\n== 最新 Release 附件可下载性 ==")
rels = api(f"/repos/{OWNER}/SecAutoMind/releases?per_page=1")
if isinstance(rels, list) and rels:
    for asset in (rels[0].get("assets") or [])[:2]:
        code, loc = probe(asset["browser_download_url"])
        print(f"  {asset['name'][:44]:44} -> {code}")
else:
    print("  读不到 release")

print("\n== Pages（不会有重定向，这是方案 B 的固有代价） ==")
p = api(f"/repos/{OWNER}/SecAutoMind-site/pages")
if isinstance(p, dict) and "__error" not in p:
    print("  新地址:", p.get("html_url"), "| status:", p.get("status"))
    print("  旧地址 https://truefurina.github.io/SecAutoMind/ 已 404 —— 若对外发过，请改方案 B+")
else:
    print("  Pages 信息读不到:", p)
