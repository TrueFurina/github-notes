"""Octop 三仓队列体检 · 事后复核版（只读）。

为什么另写一个：`octop_review.py` 生成的是"关闭前"的 224 个队列，且结尾建议写着
"先合 A 组的 N 个"——那个建议在本账号没有 push 权限的前提下是错的。
2026-10-31 09:48–09:50（本地）维护者批量关闭了 150 个，队列 224 → 74。

这个脚本只做四件事，全部只读：
1. 现场拉三仓剩余 open PR（不引用旧快照）；
2. 并发取 mergeable / mergeable_state / comments，按 **mergeable=true/false** 分类
   （mergeable_state=unstable 在这三个仓是假警报：零 commit status → GitHub 报 pending）；
3. 把今天被关闭的 150 个与 `octop_details.json`（关闭前快照）交叉，统计"关掉时本来可合的有多少"；
4. 输出 `OCTOP-QUEUE-REVIEW-<MMDD>-postclose.md`。不关、不评、不推。

用法：python autopilot/octop_postclose.py
"""
from __future__ import annotations

import json
import os
import sys
from concurrent.futures import ThreadPoolExecutor
from datetime import datetime

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, os.path.dirname(HERE))

from ghlib import api, OWNER  # noqa: E402

TRIO = ["TencentCloud/Octop", "TencentCloud/octop-harness", "TencentCloud/octop-memory"]
CACHE = os.path.join(HERE, "octop_details.json")
OUT = os.path.join(HERE, f"OCTOP-QUEUE-REVIEW-{datetime.now():%m%d}-postclose.md")
CUTOFF = "2026-10-31T01:45"          # UTC；150 个批量关闭发生在 01:48–01:51Z


def paged(path: str, pages: int = 18, per: int = 30) -> list[dict]:
    def one(page: int):
        try:
            sep = "&" if "?" in path else "?"
            chunk = api(f"{path}{sep}per_page={per}&page={page}")
            return chunk if isinstance(chunk, list) else []
        except Exception:  # noqa: BLE001
            return []

    out: dict[int, dict] = {}
    with ThreadPoolExecutor(max_workers=8) as ex:
        for chunk in ex.map(one, range(1, pages + 1)):
            for p in chunk:
                out[p["number"]] = p
    return list(out.values())


def main() -> int:
    # ---- 1. 现场 open 队列
    open_rows = []
    for repo in TRIO:
        for p in paged(f"/repos/{repo}/pulls?state=open"):
            if (p.get("user") or {}).get("login") == OWNER:
                open_rows.append((repo, p))

    # ---- 2. 并发取详情（mergeable 只能从单条详情拿）
    def detail(item):
        repo, p = item
        for _ in range(3):
            d = api(f"/repos/{repo}/pulls/{p['number']}")
            if isinstance(d, dict) and "mergeable" in d:
                iss = api(f"/repos/{repo}/issues/{p['number']}")
                comments = (iss or {}).get("comments", 0) if isinstance(iss, dict) else 0
                return {
                    "repo": repo, "num": p["number"], "title": p["title"],
                    "created": p["created_at"][:10],
                    "mergeable": d.get("mergeable"),
                    "mstate": d.get("mergeable_state"),
                    "draft": d.get("draft"),
                    "files": d.get("changed_files"),
                    "commits": d.get("commits"),
                    "comments": comments,
                    "head": (p.get("head") or {}).get("sha", "")[:8],
                }
        return {"repo": repo, "num": p["number"], "title": p["title"],
                "created": p["created_at"][:10], "mergeable": None,
                "mstate": None, "draft": None, "files": None,
                "commits": None, "comments": None,
                "head": (p.get("head") or {}).get("sha", "")[:8]}

    with ThreadPoolExecutor(max_workers=8) as ex:
        rows = list(ex.map(detail, open_rows))

    rows.sort(key=lambda r: (r["repo"], r["num"]))
    ready = [r for r in rows if r["mergeable"] is True]
    conflict = [r for r in rows if r["mergeable"] is False]
    unknown = [r for r in rows if r["mergeable"] is None]
    draft = [r for r in rows if r["draft"]]
    unseen = [r for r in rows if (r["comments"] or 0) == 0]

    # ---- 3. 与关闭前快照交叉
    try:
        cache = json.load(open(CACHE, encoding="utf-8"))
    except Exception:  # noqa: BLE001
        cache = {}
    closed, prepared = [], 0
    for repo in TRIO:
        for p in paged(f"/repos/{repo}/pulls?state=closed"):
            if (p.get("user") or {}).get("login") != OWNER:
                continue
            closed_at = p.get("closed_at") or ""
            if closed_at >= CUTOFF:
                key = f"{repo}#{p['number']}"
                c = cache.get(key) or {}
                if c.get("mergeable") is True:
                    prepared += 1
                closed.append({"repo": repo, "num": p["number"],
                               "closed_at": closed_at, "merged": bool(p.get("merged_at")),
                               "cached_mergeable": c.get("mergeable"),
                               "cached_comments": c.get("comments")})
    closed.sort(key=lambda r: r["closed_at"])

    stamp = datetime.now().strftime("%Y-%m-%d %H:%M")
    lines = [
        f"# Octop 队列体检 · 事后复核（{stamp}）", "",
        "> 只读：没有关闭、没有评论、没有推送。数字全部来自本轮现场 API，未引用旧快照；",
        "> 唯一引用旧快照的地方是第 3 节，且已标注是哪份缓存。", "",
        "## 1. 发生了什么", "",
        f"- 队列：**224 → {len(rows)}**，今天 09:48–09:50（本地）被批量关闭 **{len(closed)}** 个。",
        f"- 这 {len(closed)} 个里 **合并数 = {sum(1 for c in closed if c['merged'])}**；"
        f"按关闭前缓存（`octop_details.json`）其中 **{prepared}** 个当时 `mergeable=true`。",
        "- 关闭是静默的：抽查的两条 PR 无维护者评论、无关闭原因说明。", "",
        "## 2. 剩余队列分类（口径：`mergeable` 布尔值，不看 `mergeable_state`）", "",
        "| 类别 | 数量 | 含义 |", "|---|---|---|",
        f"| 可合并 `mergeable=true` | {len(ready)} | 无文本冲突，维护者点一下就能合 |",
        f"| 有冲突 `mergeable=false` | {len(conflict)} | 需要 rebase 才能合 |",
        f"| 未定 `mergeable=null` | {len(unknown)} | GitHub 还在算，下轮再看 |",
        f"| 其中 draft | {len(draft)} | 作者自己标了未完成 |",
        f"| 零评论（没人看过） | {len(unseen)} | 问题是「没被看见」，不是「被否决」 |", "",
        "按仓分布：",
    ]
    for repo in TRIO:
        sub = [r for r in rows if r["repo"] == repo]
        lines.append(f"- `{repo}`：{len(sub)} 个（可合 {sum(1 for r in sub if r['mergeable'] is True)}）")

    lines += ["", "## 3. 被关闭的 150 个：它们的关闭前状态", "",
              "| 关闭前 mergeable | 个数 |", "|---|---|",
              f"| true（本来可合） | {prepared} |",
              f"| false/未知 | {len(closed) - prepared} |", "",
              "最早/最晚关闭时间："
              f"`{closed[0]['closed_at']}` / `{closed[-1]['closed_at']}`（UTC）；"
              f"号段 #{min(c['num'] for c in closed)}–#{max(c['num'] for c in closed)}。", ""]

    lines += ["## 4. 结论（不写建议清单）", "",
              "- 这批 PR 的命运不取决于质量：关闭前后我们没有 push 权限，也没有任何人回复过其中大多数。",
              "- 唯一被证实的杠杆是**少加**。剩下的 "
              f"{len(rows)} 个里，{len(unseen)} 个至今零评论——再加新的只是把这部分变大。",
              "- `mergeable=true` 只描述「能不能被合」，不描述「我们能不能合」。", ""]

    open(OUT, "w", encoding="utf-8").write("\n".join(lines))
    print(f"写入 {OUT}")
    print(f"open={len(rows)} ready={len(ready)} conflict={len(conflict)} unknown={len(unknown)} "
          f"draft={len(draft)} unseen={len(unseen)} closed_today={len(closed)} "
          f"closed_was_mergeable={prepared}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
