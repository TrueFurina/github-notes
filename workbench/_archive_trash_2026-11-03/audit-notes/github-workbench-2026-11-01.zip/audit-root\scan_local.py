import os, re, json, sys

ROOT = sys.argv[1] if len(sys.argv) > 1 else "./scan_out"

EXT = (".py", ".js", ".ts", ".tsx", ".jsx", ".go", ".java", ".php", ".rb",
       ".yml", ".yaml", ".toml", ".env.example", ".example")
SKIP_DIR = re.compile(r"(node_modules|\.venv|/dist/|/build/|__pycache__|/vendor/|\.min\.|/archive/|/references/)")

GETENV = re.compile(
    r"""(?:os\.getenv|os\.environ\.get|os\.getenv\(\s*|getenv)\s*\(\s*
        (?P<q1>['"])(?P<name>[A-Za-z0-9_]+)(?P=q1)\s*,\s*
        (?P<q2>['"])(?P<default>[^'"]{0,120})(?P=q2)""",
    re.X)

# 其他语言的默认值模式
JS_DEFAULT = re.compile(
    r"""process\.env\.(?P<name>[A-Za-z0-9_]+)\s*\|\|\s*['"](?P<default>[^'"]{1,120})['"]""")
JS_DEFAULT2 = re.compile(
    r"""process\.env\[(?P<q>['"])(?P<name>[A-Za-z0-9_]+)(?P=q)\]\s*\|\|\s*['"](?P<default>[^'"]{1,120})['"]""")


def is_secretish(n):
    return bool(re.search(r"(PASS|PWD|SECRET|KEY|TOKEN|CRED|AUTH)", n, re.I))


def is_placeholder(v):
    s = v.strip()
    if not s:
        return True
    if re.match(r"^(your|xxx|change|placeholder|example|dummy|todo|none|null|<|\$\{|\.\.\.|-)", s, re.I):
        return True
    # 纯表达式 / 函数调用
    if re.match(r"^[A-Za-z_][A-Za-z0-9_\.]*\(\)$", s):
        return True
    return False


findings = []
scanned_files = 0
scanned_repos = 0

for repo in sorted(os.listdir(ROOT)):
    base = os.path.join(ROOT, repo)
    if not os.path.isdir(base):
        continue
    scanned_repos += 1
    repo_hits = []
    for dirpath, dirnames, filenames in os.walk(base):
        dirnames[:] = [d for d in dirnames if d not in
                       ("node_modules", ".venv", "dist", "build", "__pycache__", "vendor", ".git")]
        for fn in filenames:
            if not fn.endswith(EXT):
                continue
            p = os.path.join(dirpath, fn)
            rel = os.path.relpath(p, base)
            if SKIP_DIR.search(p.replace(os.sep, "/")):
                continue
            try:
                if os.path.getsize(p) > 800_000:
                    continue
                text = open(p, "r", encoding="utf-8", errors="replace").read()
            except Exception:
                continue
            scanned_files += 1

            for m in GETENV.finditer(text):
                nm, dv = m.group("name"), m.group("default")
                if is_secretish(nm) and not is_placeholder(dv):
                    line = text[:m.start()].count("\n") + 1
                    repo_hits.append((rel, line, nm, dv))

            for rx in (JS_DEFAULT, JS_DEFAULT2):
                for m in rx.finditer(text):
                    nm, dv = m.group("name"), m.group("default")
                    if is_secretish(nm) and not is_placeholder(dv):
                        line = text[:m.start()].count("\n") + 1
                        repo_hits.append((rel, line, nm, dv))

    if repo_hits:
        findings.append({"repo": repo, "hits": repo_hits})
        print(f"[{repo}] ⚠ {len(repo_hits)} 处")
    else:
        print(f"[{repo}] -")

print()
print("=" * 78)
print(f"扫描仓库 {scanned_repos} | 文件 {scanned_files}")
print("=" * 78)

for item in findings:
    print(f"\n[{item['repo']}]")
    seen = set()
    for rel, line, nm, dv in item["hits"]:
        key = (rel, nm)
        if key in seen:
            continue
        seen.add(key)
        masked = (dv[:2] + "***") if len(dv) > 2 else "***"
        print(f"   {rel}:{line}")
        print(f"      {nm:34s} 默认值={masked} (len {len(dv)})")

json.dump(findings, open("failopen_local.json", "w", encoding="utf-8"), ensure_ascii=False, indent=1)
print(f"\n命中仓库 {len(findings)} / {scanned_repos}")
