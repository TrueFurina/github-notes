import json, subprocess, urllib.request, http.client

TOKEN = subprocess.run(["powershell","-NoProfile","-Command",
    "[Environment]::GetEnvironmentVariable('GITHUB_TOKEN','User')"],
    capture_output=True, text=True).stdout.strip()
H = {"Authorization":"Bearer "+TOKEN,"User-Agent":"raccoon","Accept":"application/vnd.github+json","Connection":"close"}

def get(u):
    try:
        r = urllib.request.Request(u, headers=H)
        with urllib.request.urlopen(r, timeout=45) as resp:
            parts=[]
            try:
                while True:
                    b=resp.read(32768)
                    if not b: break
                    parts.append(b)
            except http.client.IncompleteRead as e:
                parts.append(e.partial)
            return json.loads(b"".join(parts))
    except Exception as e:
        return {"__e": repr(e)[:60]}

d = json.load(open("raw.json", encoding="utf-8"))
own = [r for r in d["repos"] if not r.get("fork")]

print("=== 所有仓库的 Release 下载量（真实影响力硬指标）===")
total_dl = 0
rows = []
for r in own:
    fn = r["full_name"]
    rel = get(f"https://api.github.com/repos/{fn}/releases?per_page=100")
    if not isinstance(rel, list) or not rel:
        continue
    dl = sum(a.get("download_count", 0) for x in rel for a in x.get("assets", []))
    tags = [x["tag_name"] for x in rel]
    assets = [(a["name"], a.get("download_count",0)) for x in rel for a in x.get("assets", [])]
    total_dl += dl
    rows.append((r["name"], len(rel), dl, tags[:3], assets[:6]))

rows.sort(key=lambda x: -x[2])
for name, nrel, dl, tags, assets in rows:
    print(f'\n  {name}  —— {nrel} 个 release, 总下载 {dl}')
    print(f'    版本: {tags}')
    for a, c in assets:
        print(f'      {c:5d}  {a}')

print(f'\n\n全账号 Release 总下载量: {total_dl}')

# 对比星数
print("\n=== 影响力换算 ===")
print(f'  Star 总数: {sum(r["stargazers_count"] for r in own)}')
print(f'  Release 下载总数: {total_dl}')
if total_dl:
    print(f'  下载/Star 比: {total_dl/max(sum(r["stargazers_count"] for r in own),1):.1f}x')
    print('  → 说明有真实用户在用，但社区可见度极低')