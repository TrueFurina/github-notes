import sys, json, base64, re, collections
sys.path.insert(0, r'D:/github/github-audit')
from ghlib import api
d=json.load(open('raw.json',encoding='utf-8'))
own=[x for x in d['repos'] if not x.get('fork')]
zh=sum(1 for x in own if re.search(r'[\u4e00-\u9fff]', x.get('description') or ''))
print('own with zh desc', zh, 'of', len(own))
noli=[x['name'] for x in own if not x.get('license')]
print('no license', len(noli))
notopic=[x['name'] for x in own if not x.get('topics')]
print('no topics', len(notopic), notopic[:20])
nodesc=[x['name'] for x in own if not x.get('description')]
print('no desc', nodesc)
# gif / demo presence in readme
for n in ['passive-recon','SecAutoMind-src','AGI-Distiller','MARS-408','physics-scheduler-agent','cyber-terms-hub']:
    rd=api(f'/repos/TrueFurina/{n}/readme')
    t=base64.b64decode(rd['content']).decode('utf-8','ignore') if isinstance(rd,dict) and rd.get('content') else ''
    print(f"{n:26s} len={len(t):6d} gif={t.lower().count('.gif')} img={len(re.findall(r'!\[', t))} yt={'youtu' in t.lower()} demo={'demo' in t.lower()} bench={'benchmark' in t.lower()} zh={'README.zh' in t or '中文' in t}")
