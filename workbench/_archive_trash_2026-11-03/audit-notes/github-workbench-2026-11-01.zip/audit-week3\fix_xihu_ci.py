"""修 xihu-sword-ctf-agent 的三处问题，走分支 + PR（不直接改 main）。

背景（2026-10-29 复核）
----------------------
main 的 CI 从 10-24 起连续 8 次失败，红徽章一直挂着。拉日志定位到两类原因：

1. `ctf_agent/tests/test_pcap_probe.py` 有 6 个 `async def test_*`（都带
   `@pytest.mark.asyncio`），但 CI 只装了 `pytest-timeout pytest-cov ruff`，
   **没装 pytest-asyncio** → 报 "async def functions are not natively supported"。
2. `test_unknown_lane_is_rejected_not_silently_fallback` 期望 "未知 lane"，
   实际得到 "REA 不可用：node 不存在: C:\\Users\\Lenovo\\..." ——
   因为 `_run_sync()` 先做环境检查、后做参数校验。**参数校验不该依赖本机环境。**

顺带发现（更严重）：`rea_probe.py` 里写死了 4 处本机绝对路径：
    C:\\Users\\Lenovo\\.workbuddy\\binaries\\node\\versions\\22.22.2-6\\node.exe
    C:\\Users\\Lenovo\\WorkBuddy\\2026-10-17-01-34-31\\.rea-probe\\node_modules\\...
    E:\\Program\\ghidra_12.1.4_PUBLIC
    E:\\Program\\jdk-21.0.12.1+1
这既泄露本机目录（还打印进了**公开的** CI 日志），也让工具换台机器就废。

用法：
    python fix_xihu_ci.py          # dry-run：只打印将要改什么
    python fix_xihu_ci.py --yes    # 建分支、提交、开 PR
"""

import base64
import json
import sys
import urllib.request

sys.path.insert(0, r"D:/github/github-audit")
from ghlib import HEADERS, OWNER, api, api_raw  # noqa: E402

REPO = f"{OWNER}/xihu-sword-ctf-agent"
BRANCH = "fix/ci-asyncio-and-portable-rea-paths"
SRC = "ctf_agent/tools/adapters/rea_probe.py"
WF = ".github/workflows/ci.yml"

HELPERS = '''def _first_existing(*candidates: str) -> str:
    for c in candidates:
        if c and os.path.exists(c):
            return c
    return ""


def _discover_node() -> str:
    """定位 node，**不写死用户名**。

    顺序：REA_NODE 环境变量 → PATH 上的 node → WorkBuddy 自带的版本目录
    （``~/.workbuddy/binaries/node/versions/*/node.exe``，取版本号最大的那个）。
    """
    import glob

    pat = os.path.expanduser(
        os.path.join("~", ".workbuddy", "binaries", "node", "versions", "*",
                     "node.exe" if os.name == "nt" else os.path.join("bin", "node"))
    )
    return _first_existing(
        os.environ.get("REA_NODE", ""),
        shutil.which("node") or "",
        *sorted(glob.glob(pat), reverse=True),
    )


def _discover_rea_mjs() -> str:
    """定位 rea.mjs：REA_MJS 环境变量 → 常见的 node_modules 落点。"""
    import glob

    cand = [os.environ.get("REA_MJS", "")]
    for pat in (
        os.path.join("~", "WorkBuddy", "*", ".rea-probe", "node_modules",
                     "rea-agents", "scripts", "rea.mjs"),
        os.path.join("~", ".rea-probe", "node_modules",
                     "rea-agents", "scripts", "rea.mjs"),
    ):
        cand.extend(sorted(glob.glob(os.path.expanduser(pat)), reverse=True))
    return _first_existing(*cand)


def _program_globs(name_glob: str) -> list:
    """常见安装根目录下的候选路径（ProgramFiles / ProgramW6432 / 各盘符的 Program）。"""
    pats = [os.path.join(r, name_glob)
            for r in (os.environ.get("ProgramFiles", ""), os.environ.get("ProgramW6432", "")) if r]
    if os.name == "nt":
        for drive in "CDEFGH":
            base = drive + ":\\\\Program"
            if os.path.isdir(base):
                pats.append(os.path.join(base, name_glob))
    return pats


def _discover_tool_dir(env_key: str, name_glob: str) -> str:
    """Ghidra / JDK 这类不在 PATH 上的**目录**：环境变量 → 常见安装位置。

    扫盘符是为了兼容"装在非系统盘的 Program 目录下"这种位置；找不到返回空串，
    由调用方按"未配置"处理，不抛异常。
    """
    import glob

    v = os.environ.get(env_key, "")
    if v and os.path.isdir(v):
        return v
    for p in _program_globs(name_glob):
        hit = sorted(glob.glob(p), reverse=True)
        if hit:
            return hit[0]
    return ""


def _discover_executable(env_key: str, name_glob: str, which_name: str) -> str:
    """单个可执行文件（如 upx）：环境变量 → PATH → 常见安装位置。"""
    import glob

    v = os.environ.get(env_key, "")
    if v and os.path.exists(v):
        return v
    found = shutil.which(which_name)
    if found:
        return found
    for p in _program_globs(name_glob):
        hit = sorted(glob.glob(p), reverse=True)
        if hit:
            return hit[0]
    return ""


'''

OLD_PATHS = '''# ── REA 定位（可用环境变量覆盖，便于换机器）─────────────────────────
_DEFAULT_NODE = r"C:\\Users\\Lenovo\\.workbuddy\\binaries\\node\\versions\\22.22.2-6\\node.exe"
_DEFAULT_MJS = r"C:\\Users\\Lenovo\\WorkBuddy\\2026-10-17-01-34-31\\.rea-probe\\node_modules\\rea-agents\\scripts\\rea.mjs"

_NODE = os.environ.get("REA_NODE", _DEFAULT_NODE)
_REA_MJS = os.environ.get("REA_MJS", _DEFAULT_MJS)'''

NEW_PATHS = '''# ── REA 定位（可移植：环境变量优先，其次自动探测，不写死本机路径）──────────
# 早期版本把用户主目录下的 node.exe 与某个 Program 盘下的 Ghidra/JDK 绝对路径
# 直接写在这里，后果有两个：
#   1) 换一台机器整套 REA 不可用；
#   2) 本机目录名随报错信息打印进日志（CI 日志是公开的）。
# 现在改为：环境变量 > PATH / 常见安装位置探测 > 空（调用方按"未配置"处理）。
_NODE = _discover_node()
_REA_MJS = _discover_rea_mjs()'''

OLD_TOOL = '''_DEFAULT_GHIDRA = os.environ.get("REA_GHIDRA_DIR", r"E:\\Program\\ghidra_12.1.4_PUBLIC")
_DEFAULT_JAVA = os.environ.get("REA_JAVA_HOME", r"E:\\Program\\jdk-21.0.12.1+1")'''

NEW_TOOL = '''_DEFAULT_GHIDRA = _discover_tool_dir("REA_GHIDRA_DIR", "ghidra_*")
_DEFAULT_JAVA = _discover_tool_dir("REA_JAVA_HOME", "jdk-21*")'''

OLD_UPX = r'_DEFAULT_UPX = os.environ.get("REA_UPX", r"E:\Program\tools\upx-5.2.1-win64\upx.exe")'
NEW_UPX = ('_DEFAULT_UPX = _discover_executable('
           '"REA_UPX", "tools/upx-*/upx.exe", "upx")')

OLD_ORDER = '''        ok, why = _rea_available()
        if not ok:
            return ToolOutput(
                text=f"[rea_probe] REA 不可用：{why}（not_applicable，勿当作'分析干净'）",
                ok=False,
            )
        if lane == "auto":'''

NEW_ORDER = '''        if lane == "auto":'''

# 环境检查下移到"未知 lane"判定之后：参数错就是参数错，不该被本机环境掩盖
AVAIL_BLOCK = '''        ok, why = _rea_available()
        if not ok:
            return ToolOutput(
                text=f"[rea_probe] REA 不可用：{why}（not_applicable，勿当作'分析干净'）",
                ok=False,
            )
'''

ANCHOR_UNKNOWN_TAIL = '''                     f"合法值：{'|'.join(sorted(_KNOWN_LANES))}",
                ok=False,
            )
'''

OLD_PIP = "          pip install pytest-timeout pytest-cov ruff==0.17.1"
NEW_PIP = "          pip install pytest-timeout pytest-cov pytest-asyncio ruff==0.17.1"


def patch_source(text):
    problems = []
    if OLD_PATHS not in text:
        problems.append("锚点 OLD_PATHS 未命中")
    if OLD_TOOL not in text:
        problems.append("锚点 OLD_TOOL 未命中")
    if OLD_UPX not in text:
        problems.append("锚点 OLD_UPX 未命中")
    if OLD_ORDER not in text:
        problems.append("锚点 OLD_ORDER 未命中")
    if ANCHOR_UNKNOWN_TAIL not in text:
        problems.append("锚点 ANCHOR_UNKNOWN_TAIL 未命中")
    if problems:
        return None, problems

    out = text.replace(OLD_PATHS, NEW_PATHS, 1)
    out = out.replace(OLD_TOOL, NEW_TOOL, 1)
    out = out.replace(OLD_UPX, NEW_UPX, 1)
    # 1) 去掉顶部的可用性检查
    out = out.replace(OLD_ORDER, NEW_ORDER, 1)
    # 2) 插到"未知 lane"返回之后
    out = out.replace(ANCHOR_UNKNOWN_TAIL,
                      ANCHOR_UNKNOWN_TAIL + AVAIL_BLOCK, 1)
    # 3) 顶层辅助函数插在 logger 之后
    marker = 'logger = logging.getLogger(__name__)\n'
    if marker not in out:
        return None, ["logger 锚点未命中"]
    out = out.replace(marker, marker + "\n" + HELPERS, 1)
    return out, []


def put_file(path, text, branch, message, sha=None):
    payload = {"message": message, "branch": branch,
               "content": base64.b64encode(text.encode("utf-8")).decode()}
    if sha:
        payload["sha"] = sha
    req = urllib.request.Request(
        f"https://api.github.com/repos/{REPO}/contents/{path}",
        data=json.dumps(payload, ensure_ascii=False).encode("utf-8"),
        headers={**HEADERS, "Content-Type": "application/json; charset=utf-8"},
        method="PUT")
    try:
        with urllib.request.urlopen(req, timeout=120) as r:
            return r.status, json.loads(r.read())["commit"]["sha"][:12]
    except urllib.error.HTTPError as e:
        return e.code, e.read().decode("utf-8", "ignore")[:300]


def main():
    dry = "--yes" not in sys.argv
    main_sha = api(f"/repos/{REPO}/git/ref/heads/main")["object"]["sha"]
    print("main head:", main_sha[:10])

    src = api_raw(f"/repos/{REPO}/contents/{SRC}?ref=main")
    src_text = src.decode("utf-8")
    new_src, problems = patch_source(src_text)
    if problems:
        print("源码锚点问题:", problems)
        return 1
    print(f"源码 {len(src_text)} -> {len(new_src)} 字符 "
          f"（+{len(new_src.splitlines()) - len(src_text.splitlines())} 行）")

    # 语法门禁：只 compile，不 import（import 会真的去探测本机 node/ghidra）
    try:
        compile(new_src, SRC, "exec")
        print("语法检查: OK")
    except SyntaxError as e:
        print(f"语法检查失败: 第 {e.lineno} 行 {e.msg}")
        print("  ", (e.text or "").rstrip()[:110])
        return 1

    wf = api_raw(f"/repos/{REPO}/contents/{WF}?ref=main").decode("utf-8")
    if OLD_PIP not in wf:
        print("CI 锚点未命中，pip 安装行可能是别的写法")
        for ln in wf.splitlines():
            if "pip install" in ln:
                print("   实际:", ln.strip())
        return 1
    new_wf = wf.replace(OLD_PIP, NEW_PIP, 1)
    print("CI: 装 pytest-asyncio  ->", NEW_PIP.strip())

    # scapy 是 pcap_probe 的"主引擎"（见该文件 docstring），却不在 requirements 里。
    # 补进 requirements 而不是只在 CI 加，否则按文档装环境的人拿到的是坏的工具。
    req_path = "ctf_agent/requirements.txt"
    req_text = api_raw(f"/repos/{REPO}/contents/{req_path}?ref=main").decode("utf-8")
    if "scapy" in req_text.lower():
        new_req = req_text
        print("requirements: 已有 scapy，不动")
    else:
        new_req = req_text.replace("starlette==1.3.1",
                                   "scapy>=2.6\nstarlette==1.3.1", 1)
        if new_req == req_text:
            print("requirements: 锚点 starlette 未命中，跳过")
            new_req = None
        else:
            print("requirements: 补 scapy>=2.6（pcap_probe 主引擎，原先只写在 docstring 里）")

    print("\n--- 源码关键改动确认 ---")
    for probe in ('_NODE = _discover_node()', '_DEFAULT_GHIDRA = _discover_tool_dir',
                  'def _discover_node()', 'def _discover_rea_mjs()', 'def _discover_tool_dir('):
        hit = probe in new_src
        print(f"  {'OK ' if hit else 'MISS'} {probe}")
    leaks = [p for p in ("Lenovo", "E:\\Program", "C:\\Users") if p in new_src]
    print("  残留本机路径:", leaks or "无")
    i = new_src.find("def _run_sync")
    seg = new_src[i:i + 1200]
    order = [seg.find("if lane == \"auto\""), seg.find("_KNOWN_LANES"),
             seg.find("_rea_available()")]
    print("  顺序位置 auto/未知lane/可用性 =", order,
          "-> 正确" if order == sorted(order) and -1 not in order else "-> **顺序仍不对**")

    if dry:
        print("\ndry-run，加 --yes 建分支并开 PR")
        return 0

    # 建分支
    body = json.dumps({"ref": f"refs/heads/{BRANCH}", "sha": main_sha}).encode()
    req = urllib.request.Request(f"https://api.github.com/repos/{REPO}/git/refs",
                                 data=body, headers={**HEADERS, "Content-Type": "application/json"},
                                 method="POST")
    try:
        with urllib.request.urlopen(req, timeout=60) as r:
            print("分支创建:", json.loads(r.read())["ref"])
    except urllib.error.HTTPError as e:
        msg = e.read().decode("utf-8", "ignore")[:200]
        print("分支创建:", e.code, msg)
        if "already exists" not in msg:
            return 1

    msg_src = ("fix(rea_probe): make REA/Ghidra/JDK paths portable and validate lane before env check\n\n"
               "1. `_NODE` / `_REA_MJS` / Ghidra / JDK 原先写死本机绝对路径"
               "（C:\\\\Users\\\\<user>\\\\... 与 E:\\\\Program\\\\...），导致换机器整套 REA 不可用，"
               "且本机目录名会随报错打印进公开的 CI 日志。改为：环境变量 > PATH/常见位置探测 > 空。\n"
               "2. `_run_sync()` 原先先 `_rea_available()` 后校验 lane，于是在没装 node 的机器上，"
               "拼错的 lane 会报\"REA 不可用\"，把调用错误伪装成环境问题。"
               "参数校验已上移到环境检查之前。")
    plan = [(SRC, new_src, msg_src), (WF, new_wf, None)]
    if new_req:
        plan.append((req_path, new_req, "deps: add scapy (pcap_probe main engine was missing from requirements)\n\n"
                                        "pcap_probe.py 的 docstring 写明 scapy 2.x 是主引擎，"
                                        "但 requirements.txt 里没有它 —— 按文档装环境的人"
                                        "拿到的 pcap 适配器是坏的，测试里直接 ModuleNotFoundError。"))
    for path, text, m in plan:
        if path == WF:
            m = ("ci: install pytest-asyncio\n\n"
                 "ctf_agent/tests/test_pcap_probe.py 有 6 个 async def 用例并带 "
                 "@pytest.mark.asyncio，但 CI 未安装 pytest-asyncio，"
                 "报 \"async def functions are not natively supported\"。")
        cur = api(f"/repos/{REPO}/contents/{path}?ref={BRANCH}")
        if not (isinstance(cur, dict) and cur.get("sha")):
            cur = api(f"/repos/{REPO}/contents/{path}?ref=main")
        sha = cur["sha"] if isinstance(cur, dict) and cur.get("sha") else None
        st, res = put_file(path, text, BRANCH, m, sha)
        print(f"{path}: HTTP {st} {res}")
        if st != 200:
            return 1

    pr_body = ("## 这个 PR 修什么\n\n"
               "main 的 CI 从 10-24 起连续 8 次失败。拉日志定位到三类问题，都不是新引入的：\n\n"
               "**1. 6 个 async 用例永远无法通过**\n"
               "`ctf_agent/tests/test_pcap_probe.py` 里有 6 个 `async def test_*`，都带 "
               "`@pytest.mark.asyncio`，但 CI 只装了 `pytest-timeout pytest-cov ruff`。\n"
               "pytest 报 `async def functions are not natively supported` → 这 6 条必红。\n"
               "修法：补 `pytest-asyncio`。\n\n"
               "**2. lane 校验被环境检查挡住**\n"
               "`test_unknown_lane_is_rejected_not_silently_fallback` 期望 `未知 lane`，"
               "实际得到 `REA 不可用：node 不存在`。原因是 `_run_sync()` 先 "
               "`_rea_available()`、后校验 lane。**参数校验不该依赖本机装没装 REA**——"
               "否则拼错 lane 的人会去查环境，而不是改参数。已把校验上移。\n\n"
               "**3. 源码里有 4 处本机绝对路径**\n"
               "```\n"
               "C:\\Users\\Lenovo\\.workbuddy\\binaries\\node\\versions\\22.22.2-6\\node.exe\n"
               "C:\\Users\\Lenovo\\WorkBuddy\\2026-10-17-01-34-31\\.rea-probe\\node_modules\\...\n"
               "E:\\Program\\ghidra_12.1.4_PUBLIC\n"
               "E:\\Program\\jdk-21.0.12.1+1\n"
               "```\n"
               "两个后果：换机器整套 REA 不可用；本机目录名随报错打印进**公开的** CI 日志。\n"
               "改为 `_discover_node()` / `_discover_rea_mjs()` / `_discover_tool_dir()`："
               "环境变量优先，其次 PATH 与常见安装位置探测，找不到返回空串（按\"未配置\"处理，不抛异常）。\n\n"
               "## 我没有验证的部分\n\n"
               "没有在本机跑整套 pytest（没有 clone 这个仓库）。CI 会跑 `-m \"not slow and not local\"`，"
               "以它为准。若 `_discover_*` 在 runner 上返回空串，依赖 REA 的用例本来就会以"
               "\"REA 不可用\"失败，与改动前一致，不会更差。")

    req = urllib.request.Request(
        f"https://api.github.com/repos/{REPO}/pulls",
        data=json.dumps({"title": "fix(ci): 补 pytest-asyncio + REA 路径可移植 + lane 校验前置",
                         "head": BRANCH, "base": "main", "body": pr_body},
                        ensure_ascii=False).encode("utf-8"),
        headers={**HEADERS, "Content-Type": "application/json; charset=utf-8"}, method="POST")
    try:
        with urllib.request.urlopen(req, timeout=60) as r:
            d = json.loads(r.read())
        print("PR:", d["html_url"], f"#{d['number']}")
    except urllib.error.HTTPError as e:
        msg = e.read().decode("utf-8", "ignore")[:300]
        if "already exists" in msg:
            ex = api(f"/repos/{REPO}/pulls?head={OWNER}:{BRANCH}&state=open")
            url = ex[0]["html_url"] if isinstance(ex, list) and ex else "(已存在)"
            print("PR 已存在，已推送新提交:", url)
            return 0
        print("PR 创建失败", e.code, msg)
        return 1
    return 0


if __name__ == "__main__":
    sys.exit(main())
