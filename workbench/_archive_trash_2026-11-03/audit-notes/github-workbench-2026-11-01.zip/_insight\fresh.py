import json, os, re, urllib.parse, urllib.request

TOKEN = os.environ["GITHUB_TOKEN"]
H = {"Authorization": "Bearer " + TOKEN,
     "Accept": "application/vnd.github+json",
     "User-Agent": "insight-scout"}
H_TL = dict(H, Accept="application/vnd.github.mockingbird-preview+json")
CLAIM = re.compile(
    r"i'?d like to work|i will work|i'll work|working on (this|it)|pick this up|"
    r"interested in working|assign (it|this|me)|i'?ve submitted|i have prepared|"
    r"i am working|would like to take|can i take|submit a (pr|rp)|please assign|"
    r"/claim|i'?ll take|taking this|i can take", re.I)


def api(url, h=H):
    return json.loads(urllib.request.urlopen(urllib.request.Request(url, headers=h), timeout=30).read().decode())


def scan(repo, label):
    q = urllib.parse.quote(f'repo:{repo} is:issue is:open label:"{label}" created:>=2026-09-30')
    js = api(f"https://api.github.com/search/issues?q={q}&sort=created&order=desc&per_page=60")
    items = js.get("items", [])
    free = []
    for it in items[:12]:
        n = it["number"]
        try:
            tl = api(f"https://api.github.com/repos/{repo}/issues/{n}/timeline?per_page=40", H_TL)
        except Exception:
            continue
        open_prs, merged_prs = [], []
        for ev in tl:
            if ev.get("event") != "cross-referenced":
                continue
            si = ((ev.get("source") or {}).get("issue") or {})
            if not si.get("pull_request"):
                continue
            if ((si.get("repository") or {}).get("full_name")) != repo:
                continue
            if si.get("state") == "open":
                open_prs.append(si["number"])
            else:
                merged_prs.append((si["number"], (si.get("pull_request") or {}).get("merged_at")))
        claims = []
        if it["comments"]:
            try:
                cs = api(f"https://api.github.com/repos/{repo}/issues/{n}/comments?per_page=20")
                claims = [c["user"]["login"] for c in cs
                          if CLAIM.search(" ".join((c["body"] or "").split()))]
            except Exception:
                pass
        if not open_prs and not claims and not it.get("assignees") and not any(m for _, m in merged_prs):
            free.append((n, it["created_at"][:10], it["comments"], it["title"][:80]))
        elif merged_prs:
            pass
    print(f"{repo} [{label}] 新开 {js.get('total_count')} | 扫描 {min(len(items),12)} | 真空闲 {len(free)}")
    for f in free:
        print(f"   FREE #{f[0]} {f[1]} c={f[2]} | {f[3]}")


for repo, label in [("apache/airflow", "good first issue"),
                    ("apache/airflow", "help wanted"),
                    ("nexu-io/open-design", "good first issue"),
                    ("nexu-io/open-design", "help wanted"),
                    ("ueberdosis/tiptap", "good first issue"),
                    ("langgenius/dify", "good first issue"),
                    ("rtk-ai/rtk", "good first issue")]:
    try:
        scan(repo, label)
    except Exception as e:
        print(f"{repo} [{label}] ERR {e}")
