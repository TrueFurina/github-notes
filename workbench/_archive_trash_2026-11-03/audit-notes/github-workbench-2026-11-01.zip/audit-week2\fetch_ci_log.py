"""抓取 Denia CI 的 pytest 作业日志，提炼失败用例清单（只读）。"""
import io
import json
import os
import re
import sys
import urllib.request
import zipfile

sys.path.insert(0, r"D:/github/github-audit")
from ghlib import api, HEADERS, OWNER  # noqa: E402

HERE = os.path.dirname(os.path.abspath(__file__))

run = (api(f"/repos/{OWNER}/Denia/actions/runs?per_page=1") or {}).get("workflow_runs")[0]
jobs = (api(f"/repos/{OWNER}/Denia/actions/runs/{run['id']}/jobs?per_page=5") or {}).get("jobs") or []
unit = next((j for j in jobs if "unit" in j["name"]), None)
print("run:", run["id"], run["conclusion"], "| unit job:", unit and unit["id"])

req = urllib.request.Request(
    f"https://api.github.com/repos/{OWNER}/Denia/actions/jobs/{unit['id']}/logs",
    headers=HEADERS)
with urllib.request.urlopen(req, timeout=120) as r:
    raw = r.read()

with zipfile.ZipFile(io.BytesIO(raw)) as z:
    txt = "\n".join(z.read(n).decode("utf-8", "ignore") for n in z.namelist())

with open(os.path.join(HERE, "denia_ci_pytest.log"), "w", encoding="utf-8") as f:
    f.write(txt)

failed = re.findall(r"^FAILED\s+(\S+)(?:\s+-\s+(.*))?$", txt, flags=re.M)
passed = re.findall(r"(\d+) passed", txt)
errs = re.findall(r"(\d+) error", txt)
print("summary:", "passed", passed[:1], "errors", errs[:1], "failed", len(failed))
for name, why in failed:
    print("  FAIL", name.split("::")[-1][:60], "|", (why or "")[:70])

tail = [ln for ln in txt.splitlines() if re.search(r"(short test summary|=+ .*(passed|failed).* =+)$", ln)]
print("\n--- 日志尾部关键行 ---")
for ln in tail[-12:]:
    print("  ", ln[:160])
