import sys, json, time
sys.path.insert(0, r"D:/github/github-audit")
from ghlib import api, api_all, OWNER

out = {}

# 1) all PRs authored by user (search API)
prs = []
for page in range(1, 6):
    r = api(f"/search/issues?q=author:{OWNER}+type:pr&per_page=30&sort=created&order=desc&page={page}")
    if not isinstance(r, dict) or "items" not in r:
        print("ERR page", page, str(r)[:200]); break
    print("page", page, "total_count", r.get("total_count"), "got", len(r["items"]))
    prs.extend(r["items"])
    if len(r["items"]) < 30:
        break
    time.sleep(7)

print("PR total fetched:", len(prs))
out["prs"] = prs

# 2) issue comments authored by user (search)
cmts = []
for page in range(1, 6):
    r = api(f"/search/issues?q=commenter:{OWNER}&per_page=30&sort=created&order=desc&page={page}")
    if not isinstance(r, dict) or "items" not in r:
        print("ERR cmt page", page, str(r)[:200]); break
    print("cmt page", page, "total_count", r.get("total_count"), "got", len(r["items"]))
    cmts.extend(r["items"])
    if len(r["items"]) < 30: break
    time.sleep(7)
out["commented"] = cmts

json.dump(out, open(r"D:/github/github-audit/_collab_prs.json", "w", encoding="utf-8"), ensure_ascii=False)
print("saved", len(prs), len(cmts))
