import json, subprocess, urllib.request, http.client, base64, re

TOKEN = subprocess.run(["powershell","-NoProfile","-Command",
    "[Environment]::GetEnvironmentVariable('GITHUB_TOKEN','User')"],
    capture_output=True, text=True).stdout.strip()
H = {"Authorization":"Bearer "+TOKEN,"User-Agent":"raccoon","Accept":"application/vnd.github+json","Connection":"close"}

def get(u):
    try:
        r = urllib.request.Request(u, headers=H)
        with urllib.request.urlopen(r, timeout=45) as resp:
            parts=[]
            try:
                while True:
                    b=resp.read(32768)
                    if not b: break
                    parts.append(b)
            except http.client.IncompleteRead as e:
                parts.append(e.partial)
            return json.loads(b"".join(parts))
    except Exception as e:
        return {"__e": repr(e)[:50]}

c = get("https://api.github.com/repos/TrueFurina/SecAutoMind/contents/index.html")
if c.get("content"):
    html = base64.b64decode(c["content"]).decode("utf-8","replace")
    print("index.html 大小:", len(html), "字符")
    print("--- 出站链接 ---")
    links = set(re.findall(r'href=["\']([^"\']+)["\']', html))
    for l in sorted(links):
        if l.startswith("#") or l.startswith("mailto"): continue
        print("   ", l)
    print("\n--- 是否提到 -src 仓库 ---")
    for kw in ["SecAutoMind-src", "github.com/TrueFurina", "star", "doc", "下载", "download"]:
        print(f'   {kw:24s} {"YES" if kw.lower() in html.lower() else "no"}')
    print("\n--- 页面前 400 字 ---")
    txt = re.sub(r'<[^>]+>', ' ', html)
    txt = re.sub(r'\s+', ' ', txt)
    print(txt[:400])

print("\n\n=== sage-paper vs sage-paper-public 是否重复 ===")
for name in ["sage-paper","sage-paper-public"]:
    t = get(f"https://api.github.com/repos/TrueFurina/{name}/git/trees/HEAD?recursive=1") or {}
    tree = t.get("tree",[])
    files=[(x["path"], x["sha"], x.get("size",0)) for x in tree if x["type"]=="blob"]
    print(f'  {name}: {len(files)} files, {sum(f[2] for f in files)/1e6:.2f}MB')
    print(f'    示例: {[f[0] for f in files][:6]}')