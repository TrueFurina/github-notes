"""给 Denia README 补一节「本地跑一遍 CI 同款检查」。

动机：README 只有 `tools/check_all.py`（57 道闸门），但 CI 走的是另一套（compileall +
逐脚本 + pytest），而测试依赖此前是 ci.yml 里的手写 pip 行，外部看不到。
2026-10-30 已把依赖落成 requirements-test.txt，README 应该指向它。

幂等：已存在「本地跑一遍 CI」小节则跳过。
用法：python add_readme_test_section.py [--yes]
"""
from __future__ import annotations

import base64
import json
import os
import sys
import urllib.error
import urllib.request

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from ghlib import HEADERS, OWNER, api  # noqa: E402

REPO = f"{OWNER}/Denia"
BRANCH = "master"
PATH = "README.md"

ANCHOR = "新增能力请同时补：闸门 + 变异 + CHANGELOG 明细（问题 → 改动 → 验证证据）。"

SECTION = """
### 本地跑一遍 CI 同款检查

CI 是三条腿，任一红即不通过（[`ci.yml`](.github/workflows/ci.yml)）：

```bash
python -m pip install -r requirements-test.txt   # 只装测试依赖，不装整套运行依赖
python -m compileall -q src main.py tools        # 腿 1：语法（硬门禁）
python -m pytest src/tests -q                    # 腿 2：pytest
```

腿 3 是 `src/tests` 下的**脚本式自检**，要逐个跑：

```powershell
Get-ChildItem src/tests/test_*.py | ForEach-Object { python $_.FullName }
```

它们不是 pytest 用例——`import` 阶段就会跑完整检查并 `sys.exit(1)`，混进 pytest 会让
整个收集以 `INTERNALERROR` 中断（2026-10-28 实测：55 个文件 0 个用例执行）。所以
`src/tests/conftest.py` 用 `collect_ignore` 把它们挡在外面，而不是让它们"看起来跑了"。

需要音频设备 / 桌面会话的用例（见 `ci.yml` 的 `SKIP` 列表、以及依赖 imagehash 的
`test_phash.py`）在 CI 上必然失败，刻意不跑——**它们需要在真机上验，不要靠 CI 判定**。
"""


def main() -> int:
    dry = "--yes" not in sys.argv
    cur = api(f"/repos/{REPO}/contents/{PATH}?ref={BRANCH}")
    if not (isinstance(cur, dict) and cur.get("content")):
        print("读不到 README:", cur)
        return 1
    text = base64.b64decode(cur["content"]).decode("utf-8")

    if "本地跑一遍 CI 同款检查" in text:
        print("已存在该小节，跳过")
        return 0
    if ANCHOR not in text:
        print("锚点未命中，当前文本可能已变；未做改动")
        print("  找:", ANCHOR[:40])
        return 1

    new = text.replace(ANCHOR, ANCHOR + "\n" + SECTION.rstrip() + "\n", 1)
    print(f"README {len(text)} -> {len(new)} 字符（+{len(new.splitlines()) - len(text.splitlines())} 行）")
    print("新增小节：本地跑一遍 CI 同款检查")

    if dry:
        print("\n这是 dry-run。加 --yes 执行。")
        return 0

    body = {"message": "docs(readme): how to reproduce the CI checks locally\n\n"
                       "README 原来只指 tools/check_all.py（57 道闸门），但 CI 走的是另一套：\n"
                       "compileall + 逐脚本自检 + pytest。补上三条腿的跑法，并指向新的\n"
                       "requirements-test.txt（此前测试依赖只存在于 ci.yml 的手写 pip 行里）。",
            "content": base64.b64encode(new.encode("utf-8")).decode(),
            "sha": cur["sha"], "branch": BRANCH}
    req = urllib.request.Request(f"https://api.github.com/repos/{REPO}/contents/{PATH}",
                                 data=json.dumps(body).encode("utf-8"),
                                 headers={**HEADERS, "Content-Type": "application/json; charset=utf-8"},
                                 method="PUT")
    try:
        with urllib.request.urlopen(req, timeout=90) as r:
            d = json.loads(r.read())
        print("写入 HTTP", r.status, "commit", d["commit"]["sha"][:12])
    except urllib.error.HTTPError as e:
        print("失败", e.code, e.read().decode("utf-8", "ignore")[:240])
        return 1
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
