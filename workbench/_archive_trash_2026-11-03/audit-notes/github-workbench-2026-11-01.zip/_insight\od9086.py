import base64, json, os, re, urllib.parse, urllib.request

TOKEN = os.environ["GITHUB_TOKEN"]
H = {"Authorization": "Bearer " + TOKEN,
     "Accept": "application/vnd.github+json",
     "User-Agent": "insight-scout"}
REPO = "nexu-io/open-design"


def api(url, h=H):
    last = None
    for _ in range(3):
        try:
            return json.loads(urllib.request.urlopen(urllib.request.Request(url, headers=h), timeout=30).read().decode())
        except Exception as e:  # 本机到 api.github.com 偶发 SSL EOF
            last = e
    raise last


def raw(path):
    js = api(f"https://api.github.com/repos/{REPO}/contents/{path}")
    return base64.b64decode(js["content"]).decode("utf-8")


print("=== issue 9086 ===")
iss = api(f"https://api.github.com/repos/{REPO}/issues/9086")
print("labels:", [l["name"] for l in iss["labels"]], "| comments:", iss["comments"])
print(iss["body"])

print("\n=== comments ===")
for c in api(f"https://api.github.com/repos/{REPO}/issues/9086/comments?per_page=10"):
    print(f"- {c['user']['login']}: {' '.join((c['body'] or '').split())[:400]}")

print("\n=== mcp.ts 里 start_run / conversationId ===")
s = raw("apps/daemon/src/mcp.ts")
lines = s.splitlines()
print("总行数:", len(lines))
for i, ln in enumerate(lines):
    if "start_run" in ln or "conversationId" in ln or "conversation" in ln.lower():
        print(f"{i+1:5d}| {ln.rstrip()[:140]}")

print("\n=== runs.ts 里 conversationId ===")
r = raw("apps/daemon/src/routes/runs.ts")
rl = r.splitlines()
print("总行数:", len(rl))
for i, ln in enumerate(rl):
    if "conversationId" in ln:
        print(f"{i+1:5d}| {ln.rstrip()[:140]}")
