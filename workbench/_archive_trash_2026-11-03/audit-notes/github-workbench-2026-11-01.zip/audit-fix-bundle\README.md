# P0 止血改动包 · 第 1 周 6 项

生成时间：2026-10-28 22:30 ｜ 目标账号：`TrueFurina`

**状态（22:41 更新）：F1 / F1B / F3 / F4 / F6 已执行并核验通过（FAIL=0，PEND=4）。F2 / F5 仍在等你决策。**

---

## 怎么用

```bash
cd D:/github/github-audit/fix-bundle

python apply_p0.py plan               # 默认动作：只打印 diff，不写远端
python apply_p0.py plan F3,F4         # 只看某几项
python apply_p0.py apply all --yes    # 确认后真正写入（7 个公开仓会各多一条 commit）
python apply_p0.py verify             # 应用后核验
```

`apply` 不带 `--yes` 会被拒绝执行——这是防止手滑的最后一道闸。

---

## 六项改动

| 编号 | 仓库 | 改什么 | 为什么 | 可逆性 |
|---|---|---|---|---|
| **F1** | AGI-Distiller、passive-recon、DevRadar | `LICENSE` → 标准 MIT 全文（保留 `Copyright (c) 2026 TrueFurina`） | 三个仓 README 已挂 MIT 徽章并正文承诺 MIT，`LICENSE` 却是 752 字的 "All Rights Reserved"，两者互斥。方向选"改 LICENSE"而非"改 README"，因为徽章已被外部引用 | 可 `git revert` |
| **F1B** | AGI-Distiller | README 第 3 行版权声明 → 与 MIT 一致（"禁止商用/禁止竞赛使用"降级为非强制请求） | 只改 LICENSE 不够：README 顶部仍写 "All Rights Reserved + 禁止…"，三方仍然互斥 | 可 revert |
| **F2** | pikachu | `LICENSE` → Apache-2.0；新增 `NOTICE`（上游署名 + 改动清单）；README 4 处同步（徽章/表格/许可证段）+ 删除与 Apache 互斥的 All Rights Reserved 段 | **上游是 `zhuifengshaonianhanlu/pikachu`（4,578★，Apache-2.0），不是 MIT**。派生作品按 Apache-2.0 §4 必须保留许可与署名、声明改动——原来既没署名、又用 source-available 覆盖，是最实的一条法律风险 | 可 revert |
| **F3** | xuandun-cyber-range、2026-Challenge-Cup-Security-LLM-Triage-Agent | 删除同一篇 README 末尾的 "## License & Usage Notice / All Rights Reserved" 整段（保留前面的 `[MIT](LICENSE)`） | 同一文件里两套互斥授权，评审方一眼看到矛盾 | 可 revert |
| **F4** | xihu-sword-ctf-agent | 首屏 FROZEN 横幅 4 行 → 1 行，**删掉两处本机路径 `E:\Program\SecAutoMind`**；Honesty disclaimer 与口径更正两段收进 `<details>`，内容逐字保留 | 首屏暴露本地目录结构 + 把内部项目管理笔记放在访客第一屏 | 可 revert |
| **F5** | MARS-408 | `py-server/iq_run_tmp/.env.test` 内容占位化（**不删文件**）；`.gitignore` 追加 `.env.test` / `*.env.test` | 公开仓里有 `AUTH_SECRET` / `ADMIN_PASSWORD` 明文。gitignore 只写了 `.env` 与 `py-server/.env`，漏了 `.env.test` | 可 revert；**历史仍留旧值** |
| **F6** | SecAutoMind-src、xihu-sword-ctf-agent、aerorider-delivery、win-appx-doctor | PATCH 开启 Secret Scanning + Push Protection | 4 个仓当前 `disabled`；其中 88MB 的安全工具源码仓优先级最高 | UI 可关 |

---

## 三个必须由你决定、脚本不替你做的事

### 0. ⚠️ 最重要：你 2026-08-16 是**有意**把一批仓库改成 source-available 的

`DevRadar` 的历史提交 `10eae30` 叫 "chore: README 追加 source-available / all-rights-reserved 声明"，
`pikachu` 的 `877c850` 叫 "chore: 许可证改为 source-available / all-rights-reserved"，同一个时间戳。
也就是说 8 月那次是一次**有意的批量收紧**，不是手滑。

本次 F1/F1B 的方向是"按 README 现状（徽章 + 正文都已承诺 MIT）统一到 MIT"。如果 8 月那次才是你的真实意图，
正确做法是**反方向**：撤掉 MIT 徽章、README 的 License 段改回保留所有权利。两条路都能自洽，但不能各改一半。

一键回退（把这三个仓恢复到动手之前的 LICENSE）：

```bash
python apply_p0.py apply F1B --yes   # 只是示例；真正回退请用 git
# 或在 GitHub 上对 672dd2d / 4983c3b / 6d87410 / 49afea6 逐个 revert
```

1. **`AUTH_SECRET=***`（len=31）是否曾用于任何真实部署环境？**
   若从未上线 → 直接跑 F5 即可。
   若曾上线 → **先轮换**再跑 F5，并在服务端作废所有在用会话。覆盖文件不会清除 Git 历史，历史里的旧值仍可被 `git log -p` 翻出来。
   历史清理（**我没执行，也不建议我自动执行**）：
   ```bash
   pip install git-filter-repo
   git filter-repo --path py-server/iq_run_tmp/.env.test --invert-paths
   git push --force --all     # 需要你确认；会改写所有人本地历史
   ```

2. **`MangDeHenZhi-materials` 里 495 人学生名单去留。**
   这是《个人信息保护法》口径下的敏感个人信息（姓名 + 学号 + 宿舍/分班）。private 只降低概率，不消除风险（协作者、误转公开、fork 都会漏）。建议迁到本地加密盘，仓库只留字段说明与脱敏样例。

3. **xuandun-cyber-range / 2026-CC-Triage 是否真的有权改 MIT。**
   前者署名"玄盾 XUANDUN"、后者"Minjiang University Team"——若是团队/学校成果，relicense 需要团队同意。F3 只做了"去矛盾"（保留原 MIT 声明、删掉后加的 All Rights Reserved），没有改动授权本身，属安全动作；要不要把 `LICENSE` 也换成标准 MIT 全文，你确认后再加一项。

---

## 顺带发现的两处新问题（未纳入自动改动）

| 问题 | 位置 | 建议 |
|---|---|---|
| 技能数量自相矛盾：首屏写 **72 个**，正文 Architecture / 实现说明三处写 **78 个** | `xihu-sword-ctf-agent/README.md` 第 8 行 vs 第 24/32/54 行 | 以 `scripts/_kpi_canonical.py` 的实际计数为准，全文统一 |
| README 承诺 MIT 但仓库 license 显示 `NOASSERTION` 的还有 4 个仓 | `desktop-tutorial`、`cyber-terms-hub`、`soft-skills-platform`、`2025-Challenge-Cup-CyberRange-AI-Arena` | 第 2 周和第 1 批一起处理 |

---

## 应用后的预期核验输出

`python apply_p0.py verify` 应全部 `OK`：

```
OK  AGI-Distiller            license=MIT
OK  passive-recon            license=MIT
OK  DevRadar-...             license=MIT
OK  pikachu                  license=Apache-2.0
OK  xuandun-cyber-range      license=MIT
OK  2026-CC-...              license=MIT
OK  SecAutoMind-src          secret_scanning=enabled
...
OK  xihu README 本机路径泄露=False
```

注意：GitHub 的 license 检测有缓存，改完 LICENSE 后可能要几分钟才从 `NOASSERTION` 变成 `MIT`。

---

## 文件清单

```
fix-bundle/
├─ README.md                     ← 本文件（审阅入口）
├─ apply_p0.py                   ← 计划 / 执行 / 核验
├─ specs.py                      ← 六项改动的锚点与新内容
├─ snapshot.py                   ← 抓取目标文件现状（只读）
├─ probe_prereq.py               ← 上游许可、.gitignore、扫描开关取证（只读）
├─ current/                      ← 改动前的原文快照，供逐字比对
└─ files/
   ├─ LICENSE-MIT.txt            ← GitHub License API 取回的官方全文
   ├─ LICENSE-APACHE-2.0.txt     ← 同上（11,357 字符，非手抄）
   └─ (NOTICE 由 specs.py 生成)
```

许可证全文来自 `GET /licenses/mit` 与 `GET /licenses/apache-2.0`，不是手打，避免法务文本转录错误。

---

## 执行记录（2026-10-28 22:37–22:41）

| 仓库 | commit | 内容 |
|---|---|---|
| AGI-Distiller | `672dd2d` → `49afea6` | LICENSE → MIT；README 版权行对齐 |
| passive-recon | `4983c3b` | LICENSE → MIT |
| DevRadar-GitHub-Trending-Monitor | `6d87410` | LICENSE → MIT |
| xuandun-cyber-range | `ac9c6b9` → `a948fee` | 删互斥许可段；清尾部孤立分隔线 |
| 2026-Challenge-Cup-Security-LLM-Triage-Agent | `57db727` → `e352f14` | 同上 |
| xihu-sword-ctf-agent | `1d4e22f` | 首屏去本机路径 + 声明收进 `<details>` |
| SecAutoMind-src / xihu / aerorider-delivery / win-appx-doctor | （设置项） | Secret Scanning + Push Protection：disabled → **enabled** |

`python apply_p0.py verify` 结果：

```
[OK] F1 AGI-Distiller / passive-recon / DevRadar     license=MIT
[OK] F3 xuandun / 2026-CC                            README 单一授权
[PEND] xuandun / 2026-CC 的 LICENSE 换 MIT 全文      需团队授权
[OK] F4 xihu                                         本机路径泄露=False details=True
[OK] F6 四个仓                                        scan=enabled push=enabled
[PEND] F2 pikachu                                    license=NOASSERTION（未执行）
[PEND] F5 MARS-408 .env.test                         仍有明文值（未执行）
结论: FAIL=0  PEND=4
```

所有改动都是单文件、单 commit、message 里写明了原因，`git revert <sha>` 即可回退。

