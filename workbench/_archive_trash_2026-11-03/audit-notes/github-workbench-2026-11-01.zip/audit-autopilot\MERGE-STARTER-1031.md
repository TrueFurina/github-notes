# 起步 10 个（文件独占，不会连锁制造冲突）

生成时间：2026-10-31 00:36
队列 224 个 · `mergeable=true` 且非保护 210 个 · 其中**改动的文件没有其他 open PR 同时碰** 的 54 个

## 为什么按这个顺序合

`mergeable=true` 只代表「此刻」无冲突。若一个文件被队列里另外 N 个 PR 同时改，
合掉一个之后其余立刻变 `dirty`——**合一个制造 N 个冲突**。下面这些 PR 改的文件，
在队列里**没有第二个 PR 碰**，所以合掉它们不会让任何别的 PR 失效。

| # | 仓库 | PR | 标题 | 文件 | 规模 | 年龄 |
|---:|---|---|---|---|---:|---:|
| 1 | Octop | [#2369](https://github.com/TencentCloud/Octop/pull/2369) | docs: fix wizard password path in .env.example (post-#2174) | .env.example | +1/−1 | 8d |
| 2 | Octop | [#2494](https://github.com/TencentCloud/Octop/pull/2494) | fix(grep_safety): search only target file path, not parent d | grep_safety.py | +3/−0 | 3d |
| 3 | Octop | [#2484](https://github.com/TencentCloud/Octop/pull/2484) | Fix active-turn flag leak with TTL-based stale eviction (iss | ws_hub.py | +51/−4 | 3d |
| 4 | octop-harness | [#129](https://github.com/TencentCloud/octop-harness/pull/129) | fix(docker): preserve leading dots in relative paths (issue  | docker_sandbox.py | +9/−2 | 3d |
| 5 | octop-harness | [#127](https://github.com/TencentCloud/octop-harness/pull/127) | fix(runtime): treat a non-UTF-8 workspace .env as unreadable | runtime_env.py | +5/−1 | 3d |
| 6 | octop-harness | [#124](https://github.com/TencentCloud/octop-harness/pull/124) | fix(decision): remove system-prompt text mutation in _reloca | decision.py | +8/−9 | 3d |
| 7 | octop-memory | [#36](https://github.com/TencentCloud/octop-memory/pull/36) | fix(router): add episode to default recall sources | router.py | +6/−0 | 3d |
| 8 | octop-memory | [#35](https://github.com/TencentCloud/octop-memory/pull/35) | fix(hermes): pass llm and extraction config blocks through b | __init__.py | +6/−0 | 3d |
| 9 | octop-memory | [#33](https://github.com/TencentCloud/octop-memory/pull/33) | fix(manual-docs): advance audit cursor on uncertain results | retention.py | +2/−8 | 3d |
| 10 | Octop | [#2606](https://github.com/TencentCloud/Octop/pull/2606) | fix(ldap): narrow _safe_unbind suppress(Exception) to LDAPEx | client.py | +1/−1 | 2d |

## 备选（同样独占，若上面有跳过可替补）

| 仓库 | PR | 标题 | 文件 |
|---|---|---|---|
| Octop | [#2601](https://github.com/TencentCloud/Octop/pull/2601) | fix(api): add missing_ok=True to daily-memory delete unlin | agent_files.py |
| Octop | [#2592](https://github.com/TencentCloud/Octop/pull/2592) | fix(core): make cleanup and datetime parsing resilient | clean.py, usage.py |
| Octop | [#2588](https://github.com/TencentCloud/Octop/pull/2588) | fix(infra): add encoding=utf-8 to subprocess text=True in  | capture.py, setup.py |
| Octop | [#2585](https://github.com/TencentCloud/Octop/pull/2585) | fix(cli): guard remaining bare asyncio.run() in skills.py  | skills.py, launch.py |
| Octop | [#2583](https://github.com/TencentCloud/Octop/pull/2583) | fix(cli): replace deprecated utcnow() with now(timezone.ut | run.py |
| Octop | [#2580](https://github.com/TencentCloud/Octop/pull/2580) | fix(shell): guard bare int() in shell_ws resize handler | shell_ws.py |
| Octop | [#2578](https://github.com/TencentCloud/Octop/pull/2578) | fix(voice): guard bare int() on tencent voice_type coercio | adapters.py |
| Octop | [#2571](https://github.com/TencentCloud/Octop/pull/2571) | fix(tls): guard POSIX-only os.chmod on Windows (#2370) | acme_issue.py, store.py |
| Octop | [#2548](https://github.com/TencentCloud/Octop/pull/2548) | fix(skillhub): retry HTTP request on transient CDN IPv4 fa | skillhub_market.py |
| Octop | [#2539](https://github.com/TencentCloud/Octop/pull/2539) | fix(message_keys): group-chat sessions key by room not by  | message_keys.py |

## 执行

```bash
python autopilot/merge_prs.py \
  TencentCloud/Octop#2369 \
  TencentCloud/Octop#2494 \
  TencentCloud/Octop#2484 \
  TencentCloud/octop-harness#129 \
  TencentCloud/octop-harness#127 \
  TencentCloud/octop-harness#124 \
  TencentCloud/octop-memory#36 \
  TencentCloud/octop-memory#35 \
  TencentCloud/octop-memory#33 \
  TencentCloud/Octop#2606 \
  --yes
```

不加 `--yes` 就是 dry-run：会逐个校验 `state=open` / `mergeable=true` / 保护名单再报告。

> 本文件只读生成：没有合并、没有评论。
