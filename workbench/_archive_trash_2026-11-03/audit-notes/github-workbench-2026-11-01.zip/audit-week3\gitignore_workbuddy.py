"""给三个公开仓补 .gitignore：阻止 .workbuddy/memory/ 继续入库。

只**追加**忽略规则，不触碰任何已跟踪文件——已提交的 memory 文件仍然在仓库里
（要摘出去得用 `git rm --cached`，那是删除动作，不在本次范围）。

参考实现：physics-scheduler-agent 的 .gitignore 早已有一条同义规则
（注释写着"个人工作日志，含真实联系人 PII / 会议转写，不入库"），本次照它的口径补齐。

用法：
    python gitignore_workbuddy.py          # dry-run
    python gitignore_workbuddy.py --yes
"""

import base64
import json
import sys
import urllib.request

sys.path.insert(0, r"D:/github/github-audit")
from ghlib import HEADERS, OWNER, api  # noqa: E402

REPOS = ["mcd-meal-optimizer", "MangDeHenZhi", "coastal-traffic-visual-analytics"]

BLOCK = """
# ---- Agent 工作记忆（不入库）----
# .workbuddy/memory/ 是 AI 会话的长期记忆与每日工作日志，可能包含本机绝对路径、
# 其他项目的内部名称、以及未经脱敏的第三方信息。它属于本地工作状态，不属于项目产物。
# 注：本规则只阻止新增；此前已提交的历史文件需要单独决定是否摘出索引。
.workbuddy/memory/
.workbuddy/logs/
.workbuddy/sessions/
.workbuddy/cache/
"""


def put(repo, path, text, sha, branch, message):
    body = {
        "message": message,
        "content": base64.b64encode(text.encode("utf-8")).decode(),
        "sha": sha,
        "branch": branch,
    }
    req = urllib.request.Request(
        f"https://api.github.com/repos/{OWNER}/{repo}/contents/{path}",
        data=json.dumps(body, ensure_ascii=False).encode("utf-8"),
        headers={**HEADERS, "Content-Type": "application/json; charset=utf-8"},
        method="PUT",
    )
    try:
        with urllib.request.urlopen(req, timeout=90) as r:
            return r.status, json.loads(r.read())["commit"]["sha"][:12]
    except urllib.error.HTTPError as e:
        return e.code, e.read().decode("utf-8", "ignore")[:200]


def main():
    dry = "--yes" not in sys.argv
    done = 0
    for repo in REPOS:
        info = api(f"/repos/{OWNER}/{repo}")
        branch = info["default_branch"]
        r = api(f"/repos/{OWNER}/{repo}/contents/.gitignore")
        if not (isinstance(r, dict) and r.get("content")):
            print(f"[{repo}] .gitignore 读不到: {r}")
            continue
        old = base64.b64decode(r["content"]).decode("utf-8")
        sha = r["sha"]

        if ".workbuddy/memory/" in old:
            print(f"[{repo}] 已有 .workbuddy/memory/ 规则，跳过")
            continue

        new = old.rstrip("\n") + "\n" + BLOCK
        added = len(new.splitlines()) - len(old.splitlines())
        print(f"[{repo}] branch={branch} .gitignore {len(old.splitlines())} 行 -> "
              f"{len(new.splitlines())} 行（+{added}）")
        if dry:
            continue
        status, res = put(
            repo, ".gitignore", new, sha, branch,
            "chore(gitignore): keep agent working memory out of the repo\n\n"
            ".workbuddy/memory/ 是 AI 会话的长期记忆与日志，可能含本机绝对路径、"
            "其他项目内部名称与未脱敏第三方信息，属本地工作状态而非项目产物。"
            "本规则只阻止新增，已提交的历史文件不受影响。",
        )
        print(f"    HTTP {status} commit={res}")
        if status == 200:
            done += 1

    print(f"\n{'dry-run，加 --yes 写入' if dry else f'写入 {done} 个仓库'}")


if __name__ == "__main__":
    main()
