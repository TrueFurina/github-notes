"""批量关闭分诊表 A 组中闲置 ≥60 天的 PR（默认 dry-run）。

每个 PR 单独评论，说明具体原因（不用同一句话套所有），关闭后可随时重开。
"""
import argparse
import json
import os
import sys
import urllib.request

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, r"D:/github/github-audit")
from ghlib import api, HEADERS  # noqa: E402

MIN_IDLE = 60


def _req(method, path, body=None):
    req = urllib.request.Request(
        "https://api.github.com" + path,
        data=json.dumps(body).encode("utf-8") if body else None,
        headers={**HEADERS, "Content-Type": "application/json"}, method=method)
    try:
        with urllib.request.urlopen(req, timeout=60) as r:
            return json.loads(r.read() or b"{}")
    except Exception as e:  # noqa: BLE001
        detail = getattr(e, "read", lambda: b"")()
        return {"__error": str(e), "detail": detail.decode("utf-8", "ignore")[:200]}


def comment_for(row):
    idle = row["idle"]
    if "bare except" in row["title"].lower():
        return (f"Closing this myself: it came out of a batch sweep rather than a specific bug "
                f"report, and it has had no movement in {idle} days. Without a minimal "
                f"reproduction there is nothing for a reviewer to act on.\n\n"
                f"（自主关闭：批量扫描产出的模板改动，{idle} 天无进展，且缺少最小复现。）")
    return (f"Closing this myself — it is a documentation-only change that has been open for "
            f"{idle} days without review. Keeping it open only adds to the review queue; happy "
            f"to reopen if the text is still wanted.\n\n"
            f"（自主关闭：纯文档改动，{idle} 天无回应，不再占用 review 队列；若仍需要可随时重开。）")


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--yes", action="store_true")
    ap.add_argument("--min-idle", type=int, default=MIN_IDLE)
    a = ap.parse_args()

    rows = json.load(open(os.path.join(HERE, "pr_rows.json"), encoding="utf-8"))
    todo = [r for r in rows if r["action"] == "关闭" and r["idle"] >= a.min_idle]
    todo.sort(key=lambda r: -r["idle"])
    print(f"候选 {len(todo)} 个（action=关闭 且 idle>={a.min_idle}）\n")

    done = 0
    for r in todo:
        tag = f"{r['repo']}#{r['num']}"
        pr = api(f"/repos/{r['repo']}/pulls/{r['num']}")
        if "__error" in pr:
            print(f"  {tag:44} 读不到，跳过"); continue
        if pr["state"] != "open":
            print(f"  {tag:44} 已非 open（{pr['state']}），跳过"); continue
        print(f"  {tag:44} idle={r['idle']:>3}d  {r['title'][:52]}")
        if not a.yes:
            continue
        c = _req("POST", f"/repos/{r['repo']}/issues/{r['num']}/comments",
                 {"body": comment_for(r)})
        if c.get("__error"):
            print("     评论失败:", c["__error"], c.get("detail", "")[:100]); continue
        res = _req("PATCH", f"/repos/{r['repo']}/pulls/{r['num']}", {"state": "closed"})
        if res.get("__error"):
            print("     关闭失败:", res["__error"], res.get("detail", "")[:100]); continue
        done += 1
        print("     已关闭")

    if a.yes:
        print(f"\n完成：关闭 {done} 个")
    else:
        print("\n[试运行] 加 --yes 执行")


if __name__ == "__main__":
    main()
