"""主页 README 修订执行器：python apply_profile.py plan | apply --yes | verify"""
import argparse
import base64
import difflib
import json
import os
import sys
import urllib.request

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, r"D:/github/github-audit")
sys.path.insert(0, HERE)

import specs_profile as S  # noqa: E402
from ghlib import api, HEADERS, OWNER  # noqa: E402

REPO = "TrueFurina"
PATH = "README.md"


def _request(method, path, body=None):
    req = urllib.request.Request(
        "https://api.github.com" + path,
        data=json.dumps(body).encode("utf-8") if body else None,
        headers={**HEADERS, "Content-Type": "application/json"}, method=method)
    try:
        with urllib.request.urlopen(req, timeout=60) as r:
            return json.loads(r.read() or b"{}")
    except Exception as e:  # noqa: BLE001
        detail = getattr(e, "read", lambda: b"")()
        return {"__error": str(e), "detail": detail.decode("utf-8", "ignore")[:300]}


def fetch():
    r = api(f"/repos/{OWNER}/{REPO}/contents/{PATH}")
    if not (isinstance(r, dict) and r.get("content")):
        return None, None
    return base64.b64decode(r["content"]).decode("utf-8"), r["sha"]


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("cmd", choices=["plan", "apply", "verify"])
    ap.add_argument("--yes", action="store_true")
    a = ap.parse_args()

    old, sha = fetch()
    if old is None:
        print("抓取失败")
        return 1

    if a.cmd == "verify":
        print("水印残留:", S.TITLE_OLD in old or "Trae AI Agent" in old)
        print("有上游贡献段:", "## 🛠 Selected upstream contributions" in old)
        print("有投稿政策:", "## 📜 Contribution policy" in old)
        ok = (S.TITLE_OLD not in old and "Trae AI Agent" not in old
              and "Selected upstream contributions" in old)
        print("结论:", "通过" if ok else "未通过")
        return 0 if ok else 1

    new, steps = S.build(old)
    if new == old:
        print("无变化（已是最新）")
        return 0

    print("将执行:")
    for s in steps:
        print("  -", s)
    d = list(difflib.unified_diff(old.splitlines(), new.splitlines(),
                                  fromfile="current", tofile="proposed", lineterm="", n=2))
    for ln in d[:44]:
        print("   ", ln[:190])
    if len(d) > 44:
        print(f"    ... 省略 {len(d)-44} 行")

    if a.cmd == "plan":
        print("\n确认无误后: python apply_profile.py apply --yes")
        return 0
    if not a.yes:
        print("拒绝执行：apply 需要 --yes")
        return 1

    r = _request("PUT", f"/repos/{OWNER}/{REPO}/contents/{PATH}", {
        "message": "docs(profile): drop AI-tool watermark, add selected upstream contributions\n\n"
                   "页脚原写 'auto-optimized by Trae AI Agent'，与 bio 的 'code first, buzzwords never' 相冲；\n"
                   "补 5 条已合并的上游贡献（含维护者原话链接）与三条投稿政策。",
        "content": base64.b64encode(new.encode("utf-8")).decode("ascii"),
        "sha": sha,
        "branch": "main",
    })
    print("commit:", (r.get("commit") or {}).get("sha", "")[:12] if not r.get("__error")
          else f"ERROR {r['__error']} {r.get('detail','')[:150]}")
    return 0


if __name__ == "__main__":
    sys.exit(main())
