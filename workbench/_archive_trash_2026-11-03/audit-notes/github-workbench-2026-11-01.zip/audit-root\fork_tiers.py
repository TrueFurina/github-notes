import json, datetime as dt

forks = json.load(open("forks.json", encoding="utf-8"))
pa = json.load(open("pr_age.json", encoding="utf-8"))
stale_up = {r["upstream"].lower() for r in pa["stale"]}
fresh_up = {r["upstream"].lower() for r in pa["fresh"]}

TODAY = dt.date(2026, 10, 28)
tierA, tierB, tierC = [], [], []
for f in forks:
    up = (f["upstream"] or "").lower()
    if up in fresh_up: tierC.append(f)
    elif up in stale_up: tierB.append(f)
    else: tierA.append(f)

def mb(x): return round(x["size_kb"]/1024, 1)

print(f"A 立即删除（无未关闭 PR）: {len(tierA)} 个 / {sum(mb(x) for x in tierA):.0f} MB")
print(f"B 关闭停滞 PR 后删除:     {len(tierB)} 个 / {sum(mb(x) for x in tierB):.0f} MB")
print(f"C 保留（PR 活跃）:         {len(tierC)} 个 / {sum(mb(x) for x in tierC):.0f} MB")
print(f"合计释放: {sum(mb(x) for x in tierA+tierB):.0f} MB / 当前 {sum(mb(x) for x in forks):.0f} MB")

with open("fork-cleanup-plan.md","w",encoding="utf-8") as fh:
    fh.write("# fork 清理执行清单\n\n")
    fh.write(f"生成日期 {TODAY} · 当前 160 个 fork / {sum(mb(x) for x in forks):.0f} MB · 目标 12 个 / 149 MB\n\n")
    fh.write("> 删除 fork **不会**删除已提交的 PR，贡献图与 Star 均不受影响。\n\n")
    fh.write(f"## A 组：立即删除（{len(tierA)} 个，{sum(mb(x) for x in tierA):.0f} MB）\n\n")
    fh.write("这些上游没有你任何未关闭的 PR，fork 已无用途。\n\n")
    fh.write("| 体积MB | fork 名 | 上游 | 上游星 |\n|---:|---|---|---:|\n")
    for f in sorted(tierA, key=lambda x:-x["size_kb"]):
        fh.write(f'| {mb(f)} | `{f["name"]}` | {f["upstream"]} | {f["up_stars"]} |\n')
    fh.write(f"\n## B 组：先关闭停滞 PR，再删除（{len(tierB)} 个，{sum(mb(x) for x in tierB):.0f} MB）\n\n")
    fh.write("PR 已挂起 45 天以上，维护者无响应。关闭自己的 PR 是礼貌且干净的做法，之后即可删除 fork。\n\n")
    fh.write("| 体积MB | fork 名 | 上游 | 上游星 | 挂起天数 |\n|---:|---|---|---:|---:|\n")
    agemap = {r["upstream"].lower(): r["age"] for r in pa["stale"]}
    for f in sorted(tierB, key=lambda x:-x["size_kb"]):
        fh.write(f'| {mb(f)} | `{f["name"]}` | {f["upstream"]} | {f["up_stars"]} | {agemap.get((f["upstream"] or "").lower(),"-")} |\n')
    fh.write(f"\n## C 组：保留（{len(tierC)} 个，{sum(mb(x) for x in tierC):.0f} MB）\n\n")
    fh.write("| 体积MB | fork 名 | 上游 | 上游星 |\n|---:|---|---|---:|\n")
    for f in sorted(tierC, key=lambda x:-x["size_kb"]):
        fh.write(f'| {mb(f)} | `{f["name"]}` | {f["upstream"]} | {f["up_stars"]} |\n')

# 生成 A 组批量删除命令
with open("delete-tierA.sh","w",encoding="utf-8",newline="\n") as fh:
    fh.write("#!/usr/bin/env bash\n")
    fh.write("# A 组批量删除 fork。逐条输出 HTTP 状态，204 = 成功。\n")
    fh.write("# 用法：bash delete-tierA.sh\n")
    fh.write('TOKEN=$(powershell -NoProfile -Command "[Environment]::GetEnvironmentVariable(\'GITHUB_TOKEN\',\'User\')")\n\n')
    for f in sorted(tierA, key=lambda x:-x["size_kb"]):
        fh.write(f'curl -s -X DELETE -H "Authorization: Bearer $TOKEN" -H "Accept: application/vnd.github+json" '
                 f'-o /dev/null -w "DEL {f["name"]} -> %{{http_code}}\\n" '
                 f'https://api.github.com/repos/TrueFurina/{f["name"]}\n')
print("\n已生成 fork-cleanup-plan.md 与 delete-tierA.sh")