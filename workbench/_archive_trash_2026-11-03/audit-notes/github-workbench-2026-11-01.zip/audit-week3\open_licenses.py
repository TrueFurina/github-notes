"""把 20 个 NOASSERTION 仓的许可证统一切到标准 SPDX 许可。

用户决定：2026-10-29「不用管已拿到副本的人……通通放开」。
即接受"MIT 授予不可撤回"这一点，按 LICENSE-DECISION.md 的建议放开。

三类动作
--------
1. LICENSE  ↓
   - 17 个软件/应用/工具仓 -> MIT 全文（1,069 字符，从 /licenses/mit 取）
   - 3 个内容/落地页仓     -> CC-BY-4.0 全文（18,654 字符，从 /licenses/cc-by-4.0 取）
2. README    ↓
   只改 3 个仓：MangDeHenZhi / soft-skills-platform / cyber-terms-hub。
   它们正文里的 "Source-Available · All Rights Reserved" 与新 LICENSE 直接互斥，
   不一起改就等于把今晚清掉的那种矛盾重新造出来。
3. 不动      ↓
   mcd-meal-optimizer、2025-CC-CyberRange（赛事作品，可能受主办方条款约束）
   sage-paper-public（未发表论文工作区，放开等于允许转载草稿）

用法：
    python open_licenses.py            # dry-run，逐仓打印将改什么
    python open_licenses.py --yes
    python open_licenses.py --only mit --yes
"""

import base64
import json
import re
import sys
import urllib.request

sys.path.insert(0, r"D:/github/github-audit")
from ghlib import HEADERS, OWNER, api  # noqa: E402

YEAR = "2026"
DEFAULT_HOLDER = "TrueFurina"

MIT_REPOS = [
    # 排错工具 / 小脚本
    "win-appx-doctor", "docker-forensics-toolkit", "wsl-docker-recovery", "workbuddy-vivo-fix",
    # 论文复现包
    "aerorider-delivery", "AeroRider", "marl-ecdsa",
    # 旗舰与学术系统
    "MARS-408", "SecAutoMind-src",
    # 应用 / 平台
    "MangDeHenZhi", "FDE", "soft-skills-platform", "AI-Arena", "MangDeZhiXun",
    "physics-scheduler-agent",
    # 暂存 / 已归档
    "workspace", "coastal-traffic-visual-analytics",
]

CC_REPOS = ["cyber-terms-hub", "TrueFurina", "SecAutoMind"]

# ---------------------------------------------------------------- README 改写
OLD_BLOCK = """## License & Usage Notice

**Source-Available · All Rights Reserved**

This project is source-available and all rights are reserved by the author. The code is provided for **viewing and evaluation purposes only** — access does not grant any right to copy, modify, redistribute, use commercially, or create derivative works. Unauthorized reuse may carry legal risk. Contact the author for explicit written permission before any other use.

**本仓库为「源码可查、权利保留」项目（source-available / all-rights-reserved）。代码仅供查看与评估，未授权任何复制、再分发、修改、商用或衍生创作。擅自借用代码存在法律风险；如有需要请先联系作者获取明确书面许可。**"""

NEW_BLOCK_MIT = """## License

[MIT](LICENSE) © 2026 {holder}

可自由使用、修改、分发与商用。若用于学术论文或竞赛作品，欢迎注明来源与仓库链接
（这是礼貌请求，不构成 MIT 之外的额外限制）。"""

NEW_BLOCK_CC = """## License

[CC BY 4.0](LICENSE) © 2026 {holder}

可自由复制、分发、修改与商用，**但须保留署名**——注明来源与本仓库链接。
This work is licensed under a Creative Commons Attribution 4.0 International License."""

# soft-skills-platform 顶部那条独立的版权声明（不在上面那个块里）
OLD_COPYRIGHT = ("> **版权声明 Copyright**：© 2026 All Rights Reserved. "
                 "未经作者书面许可，禁止复制、修改、分发、商用、用于各类学科竞赛。")
NEW_COPYRIGHT = "> **版权与许可 Copyright & License**：© 2026 {holder}，以 [MIT](LICENSE) 发布。"

_cache = {}


def license_body(key):
    if key not in _cache:
        _cache[key] = api(f"/licenses/{key}")["body"]
    return _cache[key]


def holder_for(repo):
    r = api(f"/repos/{OWNER}/{repo}/readme")
    if isinstance(r, dict) and r.get("content"):
        t = base64.b64decode(r["content"]).decode("utf-8", "ignore")
        m = re.search(r"©\s*\d{4}\s*([^\n，,。|*<]{2,40})", t)
        if m:
            name = m.group(1).strip(" )）")
            if name and "All Rights" not in name:
                return name
    return DEFAULT_HOLDER


def build_license(repo, key):
    body = license_body(key)
    if key == "mit":
        return body.replace("Copyright (c) [year] [fullname]",
                            f"Copyright (c) {YEAR} {holder_for(repo)}")
    return body  # CC 正文不含占位符，逐字使用以保证 GitHub 能识别


def put(repo, path, text, sha, branch, message):
    payload = {"message": message,
               "content": base64.b64encode(text.encode("utf-8")).decode(),
               "branch": branch}
    if sha:
        payload["sha"] = sha
    req = urllib.request.Request(
        f"https://api.github.com/repos/{OWNER}/{repo}/contents/{path}",
        data=json.dumps(payload, ensure_ascii=False).encode("utf-8"),
        headers={**HEADERS, "Content-Type": "application/json; charset=utf-8"},
        method="PUT")
    try:
        with urllib.request.urlopen(req, timeout=120) as r:
            return r.status, json.loads(r.read())["commit"]["sha"][:12]
    except urllib.error.HTTPError as e:
        return e.code, e.read().decode("utf-8", "ignore")[:240]


def do_repo(repo, key, dry):
    """返回 (ok, 说明)。"""
    want = "MIT" if key == "mit" else "CC-BY-4.0"
    info = api(f"/repos/{OWNER}/{repo}")
    if isinstance(info, dict) and "__error" in info:
        return False, f"读取失败 {info['__error']}"
    branch = info["default_branch"]
    cur = (info.get("license") or {}).get("spdx_id")
    holder = holder_for(repo)

    notes = []
    old = api(f"/repos/{OWNER}/{repo}/contents/LICENSE")
    sha = old["sha"] if isinstance(old, dict) and old.get("sha") else None
    if cur == want:
        notes.append(f"LICENSE 已是 {want}")
    else:
        text = build_license(repo, key)
        notes.append(f"LICENSE {cur} -> {want}（{len(text)} 字符，© {holder}）")
        if not dry:
            st, res = put(repo, "LICENSE", text, sha, branch,
                          f"chore(license): switch to {want}\n\n"
                          f"原先是 752 字符的自定义 source-available 文本，GitHub 不识别"
                          f"（spdx=NOASSERTION），仓库页与搜索结果里不显示任何许可标识。"
                          f"改用标准 {want} 全文；README 中互斥的保留权利声明同步更新。")
            notes.append(f"  LICENSE HTTP {st} {res}")
            if st != 200:
                return False, " | ".join(notes)

    # README 互斥声明
    rd = api(f"/repos/{OWNER}/{repo}/readme")
    if isinstance(rd, dict) and rd.get("content"):
        rt = base64.b64decode(rd["content"]).decode("utf-8", "ignore")
        new_rt = rt
        if OLD_BLOCK in new_rt:
            block = (NEW_BLOCK_CC if key != "mit" else NEW_BLOCK_MIT).format(holder=holder)
            new_rt = new_rt.replace(OLD_BLOCK, block, 1)
            notes.append("README 替换 License & Usage Notice 段")
        if OLD_COPYRIGHT in new_rt:
            new_rt = new_rt.replace(OLD_COPYRIGHT, NEW_COPYRIGHT.format(holder=holder), 1)
            notes.append("README 替换顶部版权声明行")
        if new_rt != rt:
            notes.append(f"  README 剩余 'All Rights Reserved': "
                         f"{new_rt.count('All Rights Reserved')}")
            if not dry:
                st, res = put(repo, "README.md", new_rt, rd["sha"], branch,
                              f"docs(readme): align license section with {want}\n\n"
                              f"正文原写 Source-Available · All Rights Reserved，"
                              f"与新的 {want} LICENSE 互斥，同步改为 {want}。")
                notes.append(f"  README HTTP {st} {res}")
                if st != 200:
                    return False, " | ".join(notes)
    return True, " | ".join(notes)


def main():
    dry = "--yes" not in sys.argv
    only = None
    if "--only" in sys.argv:
        only = sys.argv[sys.argv.index("--only") + 1]

    plan = []
    if only in (None, "mit"):
        plan += [(r, "mit") for r in MIT_REPOS]
    if only in (None, "cc"):
        plan += [(r, "cc-by-4.0") for r in CC_REPOS]

    ok_n = fail_n = 0
    for repo, key in plan:
        ok, note = do_repo(repo, key, dry)
        print(f"{'OK ' if ok else 'FAIL'} {repo:34} {note}")
        ok_n += 1 if ok else 0
        fail_n += 0 if ok else 1

    print(f"\n成功 {ok_n} / 失败 {fail_n}  "
          f"{'（dry-run，加 --yes 写入）' if dry else '（已写入）'}")


if __name__ == "__main__":
    main()
