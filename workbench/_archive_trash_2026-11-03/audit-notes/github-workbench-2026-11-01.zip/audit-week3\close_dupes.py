"""关掉 3 个重复 PR，每个附具体说明（默认 dry-run）。

判断依据是**内容不是体积**：
  #2491  -> 关，留 #2372（后者带 3 项回归测试、作者实测 16 passed）
  #2490  -> 关，留 #2371（后者含 _atomic_move_to + 110 行回归测试、失败保留旧备份）
  #122   -> 关，留 #132（同一处修复；#122 的 agent.py aclosing 重构是另一件事）

我第一版计划是"留小的关大的"，看完 diff 后推翻——那会关掉唯一带测试的 PR。

用法：
    python close_dupes.py            # dry-run
    python close_dupes.py --yes
"""

import json
import sys
import urllib.request

sys.path.insert(0, r"D:/github/github-audit")
from ghlib import HEADERS, OWNER, api  # noqa: E402

TARGETS = [
    {
        "repo": "TencentCloud/Octop",
        "num": 2491,
        "keep": 2372,
        "body": (
            "Closing this in favour of #2372, which fixes the same issue (#2269) and adds three "
            "regression tests in `tests/unit/test_env_file.py` (author reports `16 passed` on that file).\n\n"
            "Both add the same guardrail — stop the unterminated-quote continuation when the next line is "
            "itself a valid `KEY=VALUE` — so keeping two PRs for one bug only makes review more expensive.\n\n"
            "The branch stays here; reopen if #2372 stalls."
        ),
    },
    {
        "repo": "TencentCloud/Octop",
        "num": 2490,
        "keep": 2371,
        "body": (
            "Closing this in favour of #2371, which closes the same issue (#2321) and goes further:\n\n"
            "- routes the `--output` path through `_atomic_move_to()` — atomic `Path.replace` first, "
            "`EXDEV` fallback that copies to a **target-side** temp file before `os.replace`;\n"
            "- keeps the pre-existing target backup when the copy or replace fails, instead of leaving "
            "a half-written file;\n"
            "- adds 110 lines of regression tests in `tests/unit/backup/test_backup_cli.py`.\n\n"
            "This PR is `import shutil` plus 7 lines with no tests. The tested version is the better "
            "starting point for review. Reopen if #2371 stalls."
        ),
    },
    {
        "repo": "TencentCloud/octop-harness",
        "num": 122,
        "keep": 132,
        "body": (
            "Closing in favour of #132, which fixes the same crash (#89) with a single "
            "`try/except ValueError` around `reset(token)` in `session_header_scope()`.\n\n"
            "The second half of this PR — uniform `aclosing` in `agent.py::_stream()` — is a separate "
            "concern, and `agent.py` is also touched by #123 and #125, so folding it in here guarantees "
            "a conflict for whoever merges second. That refactor deserves its own PR where it can be "
            "reviewed on its own merits."
        ),
    },
]


def post_comment(repo, num, body):
    req = urllib.request.Request(
        f"https://api.github.com/repos/{repo}/issues/{num}/comments",
        data=json.dumps({"body": body}, ensure_ascii=False).encode("utf-8"),
        headers={**HEADERS, "Content-Type": "application/json; charset=utf-8"},
        method="POST")
    try:
        with urllib.request.urlopen(req, timeout=60) as r:
            return r.status, json.loads(r.read()).get("id")
    except urllib.error.HTTPError as e:
        return e.code, e.read().decode("utf-8", "ignore")[:240]


def close(repo, num):
    req = urllib.request.Request(
        f"https://api.github.com/repos/{repo}/pulls/{num}",
        data=json.dumps({"state": "closed"}).encode("utf-8"),
        headers={**HEADERS, "Content-Type": "application/json"},
        method="PATCH")
    try:
        with urllib.request.urlopen(req, timeout=60) as r:
            return r.status, json.loads(r.read()).get("state")
    except urllib.error.HTTPError as e:
        return e.code, e.read().decode("utf-8", "ignore")[:240]


def main():
    dry = "--yes" not in sys.argv
    for t in TARGETS:
        repo, num, keep = t["repo"], t["num"], t["keep"]
        d = api(f"/repos/{repo}/pulls/{num}")
        if isinstance(d, dict) and "__error" in d:
            print(f"[{repo}#{num}] 读取失败 {d}"); continue
        if d["state"] != "open":
            print(f"[{repo}#{num}] 已是 {d['state']}，跳过"); continue
        k = api(f"/repos/{repo}/pulls/{keep}")
        if k.get("state") != "open":
            print(f"[{repo}#{num}] 保留对象 #{keep} 是 {k.get('state')}，**不关**（会没有替代品）")
            continue

        print("=" * 74)
        print(f"[{repo}#{num}] {d['title'][:66]}")
        print(f"   -> 关闭，保留 #{keep}  {k['title'][:56]}")
        if dry:
            print("   （dry-run，未提交评论/未关闭）")
            continue

        st, cid = post_comment(repo, num, t["body"])
        print(f"   评论 HTTP {st} id={cid}")
        if st not in (200, 201):
            print("   评论失败，放弃关闭（避免无说明关单）")
            continue
        st2, state = close(repo, num)
        print(f"   关闭 HTTP {st2} state={state}")

    print("\n" + ("dry-run，加 --yes 执行" if dry else "完成"))


if __name__ == "__main__":
    main()
