# TrueFurina 公开仓库泄密风险体检（只读）

- 审计时间：2026-10-28
- 范围：`raw.json` 中 owner=TrueFurina、`fork=false`、`archived=false` 的仓库，按 `pushed_at` 倒序取前 25 个
- 方式：纯 REST API（`git/trees` + `contents`），**未 clone、未执行仓库内任何代码、未改动任何既有文件**
- 说明：扫描对象含 3 个 private 仓库（Denia、MangDeHenZhi-materials、marl-ecdsa-competition-materials），因其为活跃仓库且题面点名 Denia；private 仓库的风险性质是"协作者/误转公开"，已在表中标注

## 0. 结论（先看这里）

**未发现高置信泄露（可直接利用的真实密钥为 0 条）。**

- 共扫描 **25 个仓库 / 9,444 条文件路径**，其中 **约 500 个文件**读取正文做了正则匹配
- 原始正则命中 **19 条**，逐条人工复核后：高置信 **0**、中 **3**、低 **5 类**
- 唯一被 GitHub 平台判定为密钥的是 **1 条 Secret Scanning 告警（仍为 open 状态）**：微信 AppID，属"标识符"而非密钥
- 真正需要今天处理的是 **配置与数据卫生问题**，不是"轮换密钥"

该用户的密钥卫生意识明显高于平均水平：Denia 的 `src/config.py` 有专门的 `secret_box`（DPAPI 落盘加密），MARS-408 的 `config.py` 有 `_strip_secrets()` 与 `/api/config` 掩码逻辑，注释里明确写着"完整 key 一律 setx 进环境变量，不落盘、不进 git"。因此**当前 HEAD 干净是可信的，不是漏扫**。

## 1. 扫描覆盖

| 项目 | 数量 |
|---|---|
| 枚举仓库 | 25（22 public + 3 private） |
| 枚举文件路径 | 9,444 |
| 命中高风险文件名 | 35 个（`.env*` / `config.py` / `*.sql` / `*.pem` / `credentials*` / `*.db`） |
| 读取正文的文件 | 约 500（34 个高风险命名 + 303 个扩展配置/脚本 + 170 个 physics-scheduler-agent 全量文本 + 28 个 CI/compose） |
| 二进制/超大文件跳过 | 1 个（`coastal-traffic-visual-analytics/backend/legacy/prisma/dev.db`，40KB SQLite） |
| Git 历史 | 仅探测 `.env` / `config.json` / `.npmrc` 路径（6 个重点仓库，均无历史提交记录），未做全历史内容扫描 |

大仓库处理：`MARS-408`（109MB）递归树响应被代理截断，改用逐目录 BFS 枚举，按 blob SHA 去重后 1,694 条（去重前约 2,057，差异来自 `deliverables/`、`submission/` 下内容完全相同的 py-server 副本）；`SecAutoMind-src`（88MB）3,339 条；`Denia`（25MB）825 条。

## 2. 风险表

| 仓库 | 文件路径 | 命中类型 | 置信度 | 建议动作 |
|---|---|---|---|---|
| MARS-408（public） | `py-server/iq_run_tmp/.env.test` | 明文 `AUTH_SECRET=test-****tem`、`ADMIN_PASSWORD=adm****456` | 中 | 删除文件 + 加 `.gitignore`；确认该 secret 是否为线上同一把，若是则**轮换** |
| MangDeHenZhi-materials（private） | `06-学生信息/*.xlsx`、`*.csv`（12 个，含"2024级新生495人名单及分班""宿舍安排表""学生人员基本情况"） | 学生个人信息（PII） | 中 | 评估是否必须托管在 GitHub；转本地加密存储或至少收紧协作者，禁止转 public |
| physics-scheduler-agent（public） | `docs/安全风险清单-公开链接数据暴露-20261015.md` L358、L7 | 微信 AppID `wx31****c69e`（Secret Scanning alert #1，**open**）、`wbapp_C5QC****SAoS` / sandboxId `77cf****a52` | 中 | 处理告警（关闭 or 确认非凭据）；AppID/sandboxId 建议打码后重发文档 |
| MangDeHenZhi（public） | `README.md` L113-118 | 默认账号表 admin/admin123、teacher/teacher123、student/student123 | 中低 | 改为"首次启动随机生成"，README 仅描述获取方式 |
| AI-Arena（public） | `README.md` L37、`ROADMAP.md` L281/391/393、`FINAL-REPORT-2026-10-13.md` L193 | 内网服务器 `172.16.***.99` + "SSH user，ed25519 免密" | 低中 | 删除 IP 与免密说明；此类信息配合社工可放大攻击面 |
| MangDeHenZhi（public） | `docker-compose.yml` L15/18/48、`docker-compose.umami.yml` L17/28/29 | 兜底默认口令 `changeme_root` / `changeme_app` / `umami123` / 默认 JWT_SECRET | 低 | 兜底值改为 `${VAR:?must-set}`，缺失即启动失败 |
| SecAutoMind-src / xihu-sword-ctf-agent / aerorider-delivery / win-appx-doctor（public） | 仓库级配置 | Secret Scanning + Push Protection **未开启** | 中（配置风险） | 见第 5 节开启命令 |
| Denia / SecAutoMind-src / marl-ecdsa（public 或 private） | `src/tests/test_package_secrets_scan.py`、`scripts/secret_guard_test.py`、`tests/test_secrets_scan.py` | 测试夹具假密钥（`sk-live-1234****`、`AKIA****MPLE`、`xoxb-1234****`、`BEGIN RSA PRIVATE KEY` 空壳） | 低（误报） | 无需处理；建议加 `gitleaks:allow` 注释减少噪音 |

## 3. 命中统计与最危险的 3 条

原始命中 19 条按类型：`hardcoded_cred` 5、`intranet_ip` 7、`private_key` 2（均为测试字符串）、`openai_sk`/`aws_akid`/`slack` 各 1（均为测试夹具）、`db_dsn` 1（compose 兜底口令）。经剔除占位符、README 示例、`${{ secrets.X }}` 后，**高置信 0 条**。

**Top 1 — MARS-408 `py-server/iq_run_tmp/.env.test`（public）**
```
AUTH_SECRET=test-****tem
ADMIN_PASSWORD=adm****456
```
虽名为 test，但 `AUTH_SECRET` 是会话签名密钥的字段名；公开仓库出现真实字段名+可用形态口令，若开发环境与线上共用同一套变量命名/同一份 env，则可伪造会话。

**Top 2 — MangDeHenZhi-materials 学生 PII（private）**
```
06-学生信息/计算机与大数据学院2024级新生495人名单及分班情况.xlsx
06-学生信息/【20240828】计算机与大数据学院宿舍安排表.xlsx
06-学生信息/信息安全1班学生人员基本情况.xlsx
```
495 人级别真实姓名+学号+宿舍/分班，属《个人信息保护法》敏感个人信息。private 只能降低概率，不能消除（协作者、fork、误转公开均可泄露）。

**Top 3 — physics-scheduler-agent 微信 AppID 告警未处理（public）**
```
alert #1 open | tencent_wechat_api_app_id | docs/...-20261015.md:358 | wx31****c69e
```
AppID 本身不是密钥（可公开），但同文档还并列了 `appId` 与 sandboxId；一旦 `app_secret` 曾出现在同一批文档里，即可换取 access_token。当前未扫到配套 secret，风险等级取决于是否配对泄露——需人工确认。

## 4. 立即行动清单（今天）

**必须今天轮换的 key：无。** 没有发现任何真实可用的 API key / token / 私钥。

今天必须做的（按优先级）：

1. **核对 `MARS-408/py-server/iq_run_tmp/.env.test` 的 `AUTH_SECRET` 是否与任何部署环境同值** —— 若相同，立即轮换该密钥并作废所有在用会话；若不同，删除该文件并加 `.gitignore`。（30 分钟内可判定）
2. **处理 physics-scheduler-agent 的 Secret Scanning alert #1** —— 确认微信 `app_secret` 从未进入过仓库/文档；确认后 mark as "won't fix/false positive"，否则先换 secret。
3. **给 4 个未开扫描的 public 仓库开启 Secret Scanning + Push Protection**（命令见第 5 节），其中 `SecAutoMind-src`（88MB，安全工具源码）优先级最高。
4. **AI-Arena 删除 `172.16.222.99` 与免密 SSH 描述**（4 处文档）。
5. **MangDeHenZhi-materials 做去留决策** —— 若确需云端协作，收紧到最小协作者并确认未 fork；否则迁出 GitHub。

## 5. 防御建议

### 5.1 pre-commit + gitleaks（本地拦截，最有效）

```bash
# 安装（Windows）
winget install zricethezav.gitleaks      # 或 scoop install gitleaks

# 全历史体检（在仓库根目录，只读不改）
gitleaks detect --source . --redact --report-format sarif --report-path gitleaks.sarif -v

# 只扫暂存区（pre-commit 用）
gitleaks protect --staged --redact -v
```

`.pre-commit-config.yaml`（`MARS-408` 已经接入 gitleaks v8.21.0 + `.gitleaks.toml`，可直接照抄到其余仓库）：

```yaml
repos:
  - repo: https://github.com/gitleaks/gitleaks
    rev: v8.28.0
    hooks:
      - id: gitleaks
```

```bash
pip install pre-commit && pre-commit install && pre-commit run --all-files
```

配套 `.gitleaks.toml` 放行测试夹具目录，避免"狼来了"：

```toml
[allowlist]
paths = [
  '''tests?/.*secrets?_scan.*''',
  '''scripts/secret_guard_test\.py''',
  '''.*\.example$''',
]
```

### 5.2 GitHub 侧开关（public 仓库免费）

```bash
# 查看当前状态
gh api repos/TrueFurina/SecAutoMind-src --jq '.security_and_analysis'

# 开启 Secret Scanning + Push Protection
gh api -X PATCH repos/TrueFurina/SecAutoMind-src \
  -f 'security_and_analysis[secret_scanning][status]=enabled' \
  -f 'security_and_analysis[secret_scanning_push_protection][status]=enabled'
```

需同样处理的 4 个仓库：`SecAutoMind-src`、`xihu-sword-ctf-agent`、`aerorider-delivery`、`win-appx-doctor`。
（private 仓库的 Secret Scanning 需 GitHub Advanced Security 授权，`Denia` 当前返回 404。）

### 5.3 本次 Secret Scanning 实测状态（25 个仓库）

| 状态 | 数量 | 仓库 |
|---|---|---|
| 已开启 + Push Protection | 18 | MARS-408、MangDeHenZhi、AI-Arena、physics-scheduler-agent、marl-ecdsa、comment-distillery、2026-Challenge-Cup-…、dev-snippets-archive、mcd-meal-optimizer、SecAutoMind、docker-forensics-toolkit、AGI-Distiller、workbuddy-vivo-fix、wsl-docker-recovery、coastal-traffic-…、FDE、cyber-terms-hub、TrueFurina |
| **未开启** | 4 | **SecAutoMind-src、xihu-sword-ctf-agent、aerorider-delivery、win-appx-doctor** |
| 不适用（private，无 GHAS） | 3 | Denia、MangDeHenZhi-materials、marl-ecdsa-competition-materials |
| 未处理告警 | 1 | physics-scheduler-agent（#1 open） |

### 5.4 结构性建议

- 目前仅 `MARS-408` 落地了 gitleaks pre-commit；`Denia`（代码量最大、含用户配置与 DPAPI 密文）应优先补齐，否则"落盘加密"的防线在提交环节是空的。
- 把 `.env.example` 里的值统一写成 `${VAR}` 占位（现有仓库已基本做到），compose 用 `${VAR:?required}` 让缺配置直接失败，避免"默认弱口令上线"。
- 文档类仓库（docs/、报告 md）单独做一次"IP/域名/AppID/项目名"脱敏 pass —— 本次 3 条中风险里有 2 条来自文档而非代码。
- 大仓库里的 `*.zip`（MARS-408 的 3 个源码包共 59MB）是本次唯一无法覆盖的盲区：压缩包内若含真实 `.env` 不会被任何基于文件树/正则的扫描发现。建议本地解包后用 `gitleaks detect` 扫一遍。

## 6. 局限（避免过度解读"未发现"）

1. 仅覆盖 default branch 的当前快照，**Git 历史未做全量内容扫描**（历史里删除的 `.env` 仍需 `gitleaks detect --source .` 本地确认）。
2. 二进制与 >200KB 文件跳过：`dev.db`（SQLite，可能含用户数据）、3 个 `*.zip` 源码包、大型 CSV。
3. `MARS-408` 树枚举因代理 500KB 截断走 BFS + SHA 去重，路径数少于 git 实际条目（内容等价）。
4. 代码搜索（`user:TrueFurina "sk-"` 等 4 组）仅命中 3 个占位符文件，可交叉印证"无真实 key"，但代码搜索索引不含 private 仓库全量与 >384KB 文件。
