"""个人主页 README 定点修订：去 AI 工具水印 + 补上游贡献索引 + 写明投稿政策。

只做三处锚点替换，不重写整份 README。
所有 PR 数据均来自 GET /repos/{repo}/pulls/{n} 实测（merged_at 非空），不是回忆。
"""

TITLE_OLD = "# 🔬 TrueFurina GitHub — README v3 (Dynamic Stats)"
TITLE_NEW = "# 🔬 TrueFurina"

FOOTER_OLD = """<div align="center">
  <sub>🧱 This README is auto-optimized by Trae AI Agent · v3 · Dynamic Stats Edition</sub>
</div>"""
FOOTER_NEW = """<div align="center">
  <sub>Agent systems · LLM-MARL · adversarial security</sub>
</div>"""

ANCHOR_OLD = """---

## 🔬 Research Interests"""

SECTION = """---

## 🛠 Selected upstream contributions

只列**已被上游合并**的改动，每条都能点开核对（维护者原话在 PR 里）。

| 上游 / PR | 改了什么 | 规模 | 结果 |
|---|---|:--:|---|
| [unicode-rs/unicode-segmentation #183](https://github.com/unicode-rs/unicode-segmentation/pull/183) | `GraphemeCursor` 公共 API 的越界 panic：`offset`/`chunk_start` 切片、`prev_chunk` 反向迭代下溢、pre-context 分块校验 | +27/−5 | 维护者 **Manishearth** 要求 `cargo fmt` 后 APPROVED 并致谢 |
| [CodeGraphContext #1676](https://github.com/CodeGraphContext/CodeGraphContext/pull/1676) | 给 Cassandra / MySQL ingestor 加 SSL 连接参数（`CERT_REQUIRED` + 主机名校验，默认关闭、不影响旧配置） | +1214/−315，25 文件 | 维护者本地 trial-merge 验证后合并 |
| [TencentCloud/Octop #2171](https://github.com/TencentCloud/Octop/issues/2171) → [#2174](https://github.com/TencentCloud/Octop/pull/2174) | 报 issue：`OCTOP_HOME` 不迁移向导密码文件；**逐行指出 4 处该同步修改的集成测试**，维护者据此修复 | +173/−40，11 文件 | 维护者 *"Looks merge-ready for #2171"*，changelog 署名 `(#2171)` |
| [seanmonstar/reqwest #3100](https://github.com/seanmonstar/reqwest/pull/3100) | `base64` 改 `default-features = false, features = ["std"]`，去掉 `simd-unsafe`，crate 恢复 `#![forbid(unsafe_code)]` | +1/−1 | 作者 **seanmonstar** 本人 APPROVED |
| [Unstructured-IO/unstructured #4463](https://github.com/Unstructured-IO/unstructured/pull/4463) | `Text` 元素在 `None` 文本时归一化为空串，修 `TypeError`（含测试） | +33/−4，4 文件 | 维护者 APPROVED |

> 我更擅长的是**定位**而不是堆代码：Octop 那条我没有直接改代码，而是把维护者需要同步修改的 4 处测试行号列清楚，他按清单改完就合了。

---

## 📜 Contribution policy

三条自己定的规矩，因为踩过坑：

1. **一个 PR 只做一件可验证的事。** 不做跨仓库批量模板 PR——那类 PR 的合并率不到 13%，还会消耗维护者耐心。
2. **不用 LLM 代写 issue / PR 正文。** 上游对这点很敏感（Pallets 全线关闭 LLM 相关投稿，zola 的 CONTRIBUTING 明确写了不接受）。
3. **docs-only 的 PR 不自荐、不催更。** 内容已被后续改动覆盖时主动关闭，而不是留着等合并。

"""


def build(text: str):
    """返回 (new_text, 已应用的步骤列表)。幂等：已改过就跳过。"""
    steps, out = [], text
    if TITLE_OLD in out:
        out = out.replace(TITLE_OLD, TITLE_NEW, 1)
        steps.append("标题去掉 v3 / Dynamic Stats 版本号")
    if FOOTER_OLD in out:
        out = out.replace(FOOTER_OLD, FOOTER_NEW, 1)
        steps.append("页脚去掉 'auto-optimized by Trae AI Agent' 水印")
    if "## 🛠 Selected upstream contributions" not in out and ANCHOR_OLD in out:
        out = out.replace(ANCHOR_OLD, SECTION + "## 🔬 Research Interests", 1)
        steps.append("插入 Selected upstream contributions + Contribution policy")
    return out, steps
