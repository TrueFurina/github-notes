"""按根目录实际文件找贡献指南（含 .rst / .md / .github/ / docs/），再抽 CLA/DCO/AI 行。"""
import base64
import json
import os
import re
import urllib.request

TOKEN = os.environ["GITHUB_TOKEN"]
REPOS = ["apache/airflow", "topoteretes/cognee", "rtk-ai/rtk", "nexu-io/open-design",
         "cvat-ai/cvat", "ueberdosis/tiptap", "aws/aws-cdk", "excalidraw/excalidraw",
         "OpenHands/OpenHands", "langgenius/dify", "grafana/grafana"]
CLA = re.compile(r"(\bCLA\b|Contributor License Agreement|\bICLA\b|\bDCO\b|"
                 r"Developer Certificate of Origin|signed-off-by|sign[- ]off)", re.I)
AI = re.compile(r"(AI-generated|AI usage|AI tools|LLM-based|LLM-generated|"
                r"do not.*LLM|reject PRs)", re.I)


def get_json(path):
    req = urllib.request.Request("https://api.github.com" + path, headers={
        "Authorization": "Bearer " + TOKEN,
        "Accept": "application/vnd.github+json",
        "User-Agent": "insight-scout"})
    with urllib.request.urlopen(req, timeout=45) as r:
        return json.loads(r.read().decode("utf-8"))


def text_file(full, path):
    js = get_json(f"/repos/{full}/contents/{path}")
    return base64.b64decode(js["content"]).decode("utf-8", "ignore")


for full in REPOS:
    found = []
    for prefix in ("", ".github/", "docs/"):
        try:
            items = get_json(f"/repos/{full}/contents/{prefix.rstrip('/')}")
        except Exception:
            continue
        for it in items:
            n = it["name"].lower()
            if n.startswith("contributing") or n in ("agents.md", "claude.md"):
                p = (prefix + it["name"]) if prefix else it["name"]
                found.append(p)
    print(f"\n### {full}")
    print("   文件:", found or "未找到")
    for p in found:
        try:
            txt = text_file(full, p)
        except Exception as e:
            print(f"   {p}: 读取失败 {e}")
            continue
        cla = [l.strip() for l in txt.splitlines() if CLA.search(l)][:3]
        ai = [l.strip() for l in txt.splitlines() if AI.search(l)][:3]
        if cla:
            print(f"   {p} CLA/DCO:")
            for l in cla:
                print("     -", l[:180])
        if ai:
            print(f"   {p} AI:")
            for l in ai:
                print("     -", l[:180])
