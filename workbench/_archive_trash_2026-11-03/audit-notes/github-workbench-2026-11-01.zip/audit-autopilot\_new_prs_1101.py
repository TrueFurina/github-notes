"""列出 2026-11-01T02:31 之后本账号新开的 PR（只读）。"""
from __future__ import annotations

import os
import sys
from urllib.parse import quote

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from ghlib import api, OWNER  # noqa: E402

SINCE = "2026-11-01T02:31:17"
q = (
    f"is:pr author:{OWNER} created:>={SINCE} "
    "repo:TencentCloud/Octop repo:TencentCloud/octop-harness repo:TencentCloud/octop-memory"
)
res = api("/search/issues?q=" + quote(q) + "&per_page=30&sort=created&order=asc")
if not isinstance(res, dict) or "items" not in res:
    print("ERROR:", res)
    raise SystemExit(1)
items = res["items"]
print("total_count:", res.get("total_count"), " returned:", len(items))
for it in items:
    repo = it["repository_url"].split("/repos/")[-1]
    print(f"  {it['created_at'][:16]}  {repo}#{it['number']}  {it['title'][:90]}")
