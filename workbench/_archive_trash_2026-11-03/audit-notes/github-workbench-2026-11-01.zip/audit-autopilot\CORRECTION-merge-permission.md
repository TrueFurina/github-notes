# 更正：`MERGE-SHORTLIST` / `MERGE-STARTER` 给的执行建议是错的

生成时间：2026-10-31 00:45 ｜ 触发：核对了对上游仓的权限

## 事实

```
GET /repos/TencentCloud/Octop        permissions = {admin: false, maintain: false, push: false, triage: false, pull: true}
GET /repos/TencentCloud/octop-harness permissions = 同上
GET /repos/TencentCloud/octop-memory  permissions = 同上

CTFd/CTFd                  push: false
Unstructured-IO/unstructured push: false
kubeflow/testing           push: false
```

**这个账号在所有上游仓都只有 `pull`（读）权限。**

## 所以前面两份清单的建议是错的

我之前写的是「先合最老的 20 个，点一下就行」「`merge_prs.py` 加 `--yes` 就合掉」。**这两句话都建立在
一个未经核实的假设上：你有合并按钮。**

实际上没有。PR 页面上不会有 Merge 按钮，API 调 `PUT /pulls/{n}/merge` 会返回 403/405。合并权在维护者
（`jubaoliang` 等）手里。

## 这改变了什么

| 之前的判断 | 更正后 |
|---|---|
| 「221 个技术上可合，缺维护者一次点击」 | 仍然对，但**那次点击不是你能点的** |
| 「先合 20 个把队列降下来」 | **做不到**，只能等维护者 |
| 「`merge_prs.py --yes` 批量合」 | 会全部 `403`；已改为先查 `permissions.push`，没有就直接拒绝 |
| 「队列是被注意力卡住的」 | 更准确：**队列完全由维护者的节奏决定，你这边没有任何推动手段** |

## 那还剩什么可做

**1. 停止新增。** 这是唯一完全在你控制内的动作。当前增速约 50–90 个/小时，每多开一个都在
拉长维护者的队列，而**你无法自己消化**。

**2. 把低价值/过时的关掉。** 作者能关自己的 PR。这是唯一能真正让 open 数字下降的动作，
但它是社交动作——关之前要写清为什么，别静默关闭（10-28 就有一批静默关闭的记录）。

**3. 把剩下的做扎实。** 既然只能等，就让等待的那几个值得等：有复现、有测试、说明写清
"改了什么/没做什么/没验证什么"。`#2484` 与 `#33` 这轮就是这么处理的。

**4. 换战场。** 在自己的仓里（`admin: true`）能合、能发版、能改设置；在上游只能提。
三天的挂机任务如果把力气都花在上游 224 个 PR 上，收益率接近 0。

## 已经改掉的工具

- `merge_prs.py`：逐个 PR 前先查 `permissions.push`，没有就 `[SKIP] 无 push 权限`。
  实测 `TencentCloud/Octop#2494` → 直接拒绝，不再白跑一次 API 才失败。
- 两份清单文件保留（它们描述的是"代码状态"），但执行建议以本文件为准。

## 这条更正值得单独记一笔

`mergeable=true` 回答的是"这个 PR 能不能被合并"，**不是"你能不能合并它"**。
两件事差一个权限位，而我昨晚写建议时没查那个位。
