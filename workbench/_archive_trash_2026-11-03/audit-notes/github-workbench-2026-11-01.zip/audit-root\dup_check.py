import json, subprocess, time, urllib.request, http.client, collections, hashlib

TOKEN = subprocess.run(["powershell","-NoProfile","-Command",
    "[Environment]::GetEnvironmentVariable('GITHUB_TOKEN','User')"],
    capture_output=True, text=True).stdout.strip()
H = {"Authorization":"Bearer "+TOKEN,"User-Agent":"raccoon","Accept":"application/vnd.github+json","Connection":"close"}

def get(url):
    for i in range(3):
        try:
            r = urllib.request.Request(url, headers=H)
            with urllib.request.urlopen(r, timeout=40) as resp:
                parts=[]
                try:
                    while True:
                        b=resp.read(16384)
                        if not b: break
                        parts.append(b)
                except http.client.IncompleteRead as e:
                    parts.append(e.partial)
                return json.loads(b"".join(parts))
        except Exception:
            time.sleep(1.5)
    return None

def tree(fn):
    r = get(f"https://api.github.com/repos/TrueFurina/{fn}/git/trees/HEAD?recursive=1")
    return (r or {}).get("tree", [])

print("=== 测试真实分布 ===")
for fn in ["xihu-sword-ctf-agent","SecAutoMind-src","MARS-408","AGI-Distiller","passive-recon"]:
    t=tree(fn)
    files=[x["path"] for x in t if x["type"]=="blob"]
    tp=[f for f in files if f.split("/")[-1].startswith("test_") or "/tests/" in f]
    dirs=collections.Counter("/".join(f.split("/")[:2]) for f in tp)
    print(f'{fn:24s} test_files={len(tp):3d} 分布={dict(list(dirs.items())[:5])}')

print("\n=== MARS-408 重复代码检测 ===")
t=tree("MARS-408")
blobs={x["path"]: x.get("size",0) for x in t if x["type"]=="blob"}
# 用 git blob sha 判断完全相同内容
sha=collections.defaultdict(list)
for x in t:
    if x["type"]=="blob" and x["path"].endswith(".py"):
        sha[x["sha"]].append(x["path"])
dups={k:v for k,v in sha.items() if len(v)>1}
print("python 文件总数:", sum(1 for p in blobs if p.endswith(".py")))
print("内容完全相同的 py 组数:", len(dups))
print("涉及文件数:", sum(len(v) for v in dups.values()))
# 展示跨目录重复
cross=[v for v in dups.values() if len({p.split('/')[0] for p in v})>1]
print("跨顶层目录重复组数:", len(cross))
for v in cross[:5]:
    print("   ", v[:3])
sz=sum(blobs[p] for v in dups.values() for p in v[1:])
print("重复占用:", round(sz/1e6,1), "MB (仅 py)")

print("\n=== MARS-408 目录体积 ===")
agg=collections.Counter()
for p,s in blobs.items():
    top=p.split("/")[0] if "/" in p else "(root)"
    agg[top]+=s
for k,v in agg.most_common(8):
    print(f'  {k:22s} {v/1e6:8.1f} MB')

print("\n=== SecAutoMind-src 目录体积 ===")
t2=tree("SecAutoMind-src")
b2={x["path"]: x.get("size",0) for x in t2 if x["type"]=="blob"}
agg2=collections.Counter()
for p,s in b2.items():
    top=p.split("/")[0] if "/" in p else "(root)"
    agg2[top]+=s
for k,v in agg2.most_common(8):
    print(f'  {k:24s} {v/1e6:8.1f} MB')
sha2=collections.defaultdict(list)
for x in t2:
    if x["type"]=="blob" and x["path"].endswith(".py"):
        sha2[x["sha"]].append(x["path"])
d2={k:v for k,v in sha2.items() if len(v)>1}
print("重复 py 组:", len(d2), "涉及文件:", sum(len(v) for v in d2.values()))